YOUR INBOX

Drop every video you record in this folder. That's the only place you have to remember.

When you're ready, open Claude in your engine folder and say:
  "Edit the video in my inbox"
Claude will show you what's here and you pick one.

Your original stays in the inbox. The engine makes its own copy to work on and never changes your original.
