B-ROLL CLIPS

Drop short clips of your real world here (3 to 5 seconds each: hands, your shop, your space, your product). Say "make a B-roll reel" and Claude will match them to your script.
