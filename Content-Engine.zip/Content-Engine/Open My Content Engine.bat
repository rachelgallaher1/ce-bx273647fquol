@echo off
cd /d "%~dp0"
set PY=%USERPROFILE%\.cache\content-engine\whisper-venv\Scripts\python.exe
if not exist "%PY%" set PY=python
"%PY%" -I engine\tools\batch_day.py hub
pause
