# Side-by-side

Raw on the left, edited on the right, playing together from the first frame.

**Best for:** The main proof format. Use it for most niche examples.

**Output:** vertical 9:16, 1080 x 1920, 30 fps, 7 to 10 seconds, ready for Instagram Reels. Also writes a suggested caption next to the video.

## Required inputs
- raw clip
- edited clip
- niche name
- one-line "what changed" text, like "Added captions, cut dead air, tightened pacing"

## Optional settings
- --fill fit|crop (default fit: the whole picture shows in each half, with a soft blurred fill)
- --raw-x / --edited-x 0..1: where to center the crop when cropping
- --length freeze|speed: if the clips are different lengths, freeze (default) holds the shorter one on its last frame, speed stretches the raw clip to match
- --best-section: for footage over 10 seconds, use the loudest 10 seconds instead of the first 10
- --niche-text: custom top line

## Timeline (what the engine follows)
- **0.0-10.0s:** 1080x1920 frame split into two vertical halves with a thin divider. Raw left, edited right. Both play from 0.0s.
- **always:** BEFORE label above the left half, AFTER label above the right half
- **0.0-2.0s:** Niche line at the top, like "Real estate agents: raw vs. edited"
- **last 2.8s:** The "what changed" line near the bottom, above Instagram's bottom bar
- **audio:** Edited clip's audio only. The raw clip is muted.

## Edge cases
- Burned-in captions on the edited clip stay inside the right half (fit mode shows the whole picture).
- A horizontal clip is center-cropped and the tool tells you so. Shift the crop with --raw-x / --edited-x.

## How it runs
```
python3 engine/tools/before_after.py side-by-side RAW EDITED --niche "Your niche" --out reel.mp4
```
(For this effect the two clips are: the raw clip, then the edited clip.) Built with ffmpeg through `engine/tools/before_after.py`. See `engine/instructions/before-after-reels.md` for how to ask for it.

## Example captions by niche

**Real estate agents** (works for: tour of a listing, open house walk-through, a quick market update)
> Real estate agents: raw on the left, edited on the right. Same clip. What changed: added captions, cut the dead air, tightened the pacing.
> 
> Want yours edited like this? Comment WAITLIST and I'll make sure you're the first to know when it launches.

**Salon owners** (works for: a stylist talking over a transformation, a quick tip while working)
> Salon owners: raw on the left, edited on the right. Same clip. What changed: added captions, cut the pauses between clients, put the result up front.
> 
> Want yours edited like this? Comment WAITLIST and I'll make sure you're the first to know when it launches.

**Product shops** (works for: unboxing, a demo, a packing-orders clip)
> Product shops: raw on the left, edited on the right. Same clip. What changed: added captions, cut the slow parts, showed the product in the first second.
> 
> Want yours edited like this? Comment WAITLIST and I'll make sure you're the first to know when it launches.

**Talking head** (works for: an expert tip, a story, a hot take to camera)
> Talking head: raw on the left, edited on the right. Same clip. What changed: added captions, cut the restarts, a hook in the first second.
> 
> Want yours edited like this? Comment WAITLIST and I'll make sure you're the first to know when it launches.

**Network marketers (lifestyle)** (works for: a raw 'morning with the kids' or 'coffee and a quick thought' clip becoming a polished, captioned reel)
> Network marketers (lifestyle): raw on the left, edited on the right. Same clip. What changed: added captions, cut the pauses, a hook in the first second, made a casual clip look finished.
> 
> Want yours edited like this? Comment WAITLIST and I'll make sure you're the first to know when it launches.
