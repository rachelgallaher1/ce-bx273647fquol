# Effects Library: before and after reels

The four before and after effects customers can choose from. Each one is a reusable recipe: drop in your clips, answer a few questions, and the engine assembles the finished reel. All are 1080 x 1920, 30 fps, 7 to 10 seconds.

| Effect | What it does | You give it |
|---|---|---|
| [Freeze-frame reveal](freeze-reveal.md) | Raw clip plays, freezes on its most awkward moment, then snaps to the edited version. | raw clip; edited clip; hook text, like "3 things buyers hate about open houses"; niche name |
| [Screen recording to result](screen-to-result.md) | A sped-up screen recording of the engine working, then a whoosh to the finished reel. | screen recording of the engine working; finished reel; niche name |
| [Side-by-side](side-by-side.md) | Raw on the left, edited on the right, playing together from the first frame. | raw clip; edited clip; niche name; one-line "what changed" text, like "Added captions, cut dead air, tightened pacing" |
| [Curtain wipe](curtain-wipe.md) | A curtain edge slides across the frame between raw and edited, ending on the edited version full screen. | raw clip; edited clip; niche name |

## How a customer picks one
Ask: "make a before and after of my video". The engine shows the four names as one click each (Recommended first), asks only for the niche and the one-line "what changed" (it can fill that in from the edit), and builds the reel. The result and the suggested caption are saved in `customer/content/before-after/`.

## What is automatic and what is not
- Everything above is built with ffmpeg (`engine/tools/before_after.py`). CapCut is not used for these four: the engine's CapCut link exports a draft of one edit (cuts, captions, sounds), and CapCut cannot swap two clips into a template automatically. If you want one as a CapCut project, tell the engine and it will export the finished reel as a clip to drop into CapCut.
- Screen recording to result: the engine cannot find private information (account names, file paths, notifications) by itself. It warns you every time and asks you for the box to crop or blur, or you check the result before posting.
- The overlay effects (typing bar, comment popup, counting number and the rest) are a separate list in the editor's Effects library.
