# Freeze-frame reveal

Raw clip plays, freezes on its most awkward moment, then snaps to the edited version.

**Best for:** Talking-head reels (any niche where someone speaks to camera).

**Output:** vertical 9:16, 1080 x 1920, 30 fps, 7 to 10 seconds, ready for Instagram Reels. Also writes a suggested caption next to the video.

## Required inputs
- raw clip (the unedited video)
- edited clip (the engine's finished version of the same footage)
- hook text, like "3 things buyers hate about open houses"
- niche name

## Optional settings
- --freeze-at SECONDS: the freeze moment (default 3.0s, or 60% of the clip if it is under 3 seconds)
- --edited-start SECONDS: which moment of the edited clip matches (default: the same point in proportion, adjusted for the cuts)
- --fill fit|crop, --raw-x, --edited-x: how clips fill the frame (default fit, so captions are never cut off)
- --changed: the one-line "what changed" text

## Timeline (what the engine follows)
- **0.0-3.0s:** Raw clip plays, no captions, small BEFORE label (top left, inside the safe zone)
- **3.0s:** Raw freezes on its current frame for 0.4s. Shutter sound.
- **3.4s:** Hard cut to the edited clip with a quick white flash and a short whoosh. Label swaps to AFTER.
- **3.4s-end:** Edited clip plays with its captions and tight cuts. Hook text sits at the top for the first 2 seconds.
- **audio:** Raw audio before the freeze, edited audio after. Both are loudness-matched (-16 LUFS) so the swap does not jump.

## Edge cases
- Raw clip under 3 seconds: freeze at 60% of its length.
- Total length is kept between 7 and 10 seconds.

## How it runs
```
python3 engine/tools/before_after.py freeze RAW EDITED --niche "Your niche" --out reel.mp4
```
(For this effect the two clips are: the raw clip, then the edited clip.) Built with ffmpeg through `engine/tools/before_after.py`. See `engine/instructions/before-after-reels.md` for how to ask for it.

## Example captions by niche

**Real estate agents** (works for: tour of a listing, open house walk-through, a quick market update)
> Real estate agents: the raw take, frozen, then the same take edited. What changed: added captions, cut the dead air, tightened the pacing.
> 
> Want yours edited like this? Comment WAITLIST.

**Salon owners** (works for: a stylist talking over a transformation, a quick tip while working)
> Salon owners: the raw take, frozen, then the same take edited. What changed: added captions, cut the pauses between clients, put the result up front.
> 
> Want yours edited like this? Comment WAITLIST.

**Product shops** (works for: unboxing, a demo, a packing-orders clip)
> Product shops: the raw take, frozen, then the same take edited. What changed: added captions, cut the slow parts, showed the product in the first second.
> 
> Want yours edited like this? Comment WAITLIST.

**Talking head** (works for: an expert tip, a story, a hot take to camera)
> Talking head: the raw take, frozen, then the same take edited. What changed: added captions, cut the restarts, a hook in the first second.
> 
> Want yours edited like this? Comment WAITLIST.

**Network marketers (lifestyle)** (works for: a raw 'morning with the kids' or 'coffee and a quick thought' clip becoming a polished, captioned reel)
> Network marketers (lifestyle): the raw take, frozen, then the same take edited. What changed: added captions, cut the pauses, a hook in the first second, made a casual clip look finished.
> 
> Want yours edited like this? Comment WAITLIST.
