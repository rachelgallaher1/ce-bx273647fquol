# Screen recording to result

A sped-up screen recording of the engine working, then a whoosh to the finished reel.

**Best for:** Showing the process: how raw video becomes a finished reel.

**Output:** vertical 9:16, 1080 x 1920, 30 fps, 7 to 10 seconds, ready for Instagram Reels. Also writes a suggested caption next to the video.

## Required inputs
- screen recording of the engine working
- finished reel
- niche name

## Optional settings
- --title "text": default "Raw video in, finished reel out."
- --speed 2..4: playback speed of the recording (default picked automatically)
- --crop x:y:w:h: keep only this box of the recording, in source pixels (use it to cut out names, file paths, notifications)
- --blur x:y:w:h: blur one private spot (use up to three times)

## Timeline (what the engine follows)
- **0.0-2.0s:** Title text over the first frame of the screen recording
- **2.0-5.0s:** The most active part of the recording, sped up 2 to 4x to fit 3 seconds. Waiting and dead time is skipped by choosing the busiest stretch.
- **about 4.75-5.0s:** Quick slide transition with a whoosh into the finished reel
- **5.0s-end:** Finished reel plays full screen with its own captions, cuts, and its own music or voice

## Edge cases
- Recording longer than needed: auto-trimmed to the most active stretch and sped up to fit.
- PRIVACY: the engine cannot find account names, file paths or notifications by itself. Tell it where they are (--crop or --blur) or watch the result before posting. It warns every time you do not.

## How it runs
```
python3 engine/tools/before_after.py screen RAW EDITED --niche "Your niche" --out reel.mp4
```
(For this effect the two clips are: the raw screen recording, then the finished reel.) Built with ffmpeg through `engine/tools/before_after.py`. See `engine/instructions/before-after-reels.md` for how to ask for it.

## Example captions by niche

**Real estate agents** (works for: tour of a listing, open house walk-through, a quick market update)
> Real estate agents: here's what happens when you drop a raw video into the engine. Raw video in, finished reel out. What changed: added captions, cut the dead air, tightened the pacing.
> 
> Want yours edited like this? Comment WAITLIST.

**Salon owners** (works for: a stylist talking over a transformation, a quick tip while working)
> Salon owners: here's what happens when you drop a raw video into the engine. Raw video in, finished reel out. What changed: added captions, cut the pauses between clients, put the result up front.
> 
> Want yours edited like this? Comment WAITLIST.

**Product shops** (works for: unboxing, a demo, a packing-orders clip)
> Product shops: here's what happens when you drop a raw video into the engine. Raw video in, finished reel out. What changed: added captions, cut the slow parts, showed the product in the first second.
> 
> Want yours edited like this? Comment WAITLIST.

**Talking head** (works for: an expert tip, a story, a hot take to camera)
> Talking head: here's what happens when you drop a raw video into the engine. Raw video in, finished reel out. What changed: added captions, cut the restarts, a hook in the first second.
> 
> Want yours edited like this? Comment WAITLIST.

**Network marketers (lifestyle)** (works for: a raw 'morning with the kids' or 'coffee and a quick thought' clip becoming a polished, captioned reel)
> Network marketers (lifestyle): here's what happens when you drop a raw video into the engine. Raw video in, finished reel out. What changed: added captions, cut the pauses, a hook in the first second, made a casual clip look finished.
> 
> Want yours edited like this? Comment WAITLIST.
