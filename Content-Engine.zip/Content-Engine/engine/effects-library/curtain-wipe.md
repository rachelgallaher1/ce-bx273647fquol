# Curtain wipe

A curtain edge slides across the frame between raw and edited, ending on the edited version full screen.

**Best for:** The signature scroll-stopper. Use it for your strongest examples.

**Output:** vertical 9:16, 1080 x 1920, 30 fps, 7 to 10 seconds, ready for Instagram Reels. Also writes a suggested caption next to the video.

## Required inputs
- raw clip
- edited clip
- niche name

## Optional settings
- --hook "text": optional hook shown near the top once the edited version fills the screen
- --timing "1.0,2.0,3.0,4.0": when the curtain starts, when edited is mostly shown, when raw is mostly shown, when edited fills the frame
- --fill, --raw-x, --edited-x, --length, --best-section: same as side-by-side

## Timeline (what the engine follows)
- **0.0-1.0s:** Frame split about halfway, raw left and edited right, a clean curtain edge between them
- **1.0-2.0s:** Curtain slides to show mostly the edited version
- **2.0-3.0s:** Curtain pulls back to show mostly the raw version
- **3.0-4.0s:** Curtain moves fully across so the edited version fills the frame (ease in, ease out)
- **4.0s-end:** Edited version full screen with its captions, hook text near the top
- **always:** Both clips keep playing in sync underneath. BEFORE and AFTER labels ride on their own side of the curtain until it finishes.
- **audio:** Edited clip's audio the whole time, plus a soft whoosh on each curtain move

## Edge cases
- Curtain timings are adjustable with --timing.

## How it runs
```
python3 engine/tools/before_after.py curtain RAW EDITED --niche "Your niche" --out reel.mp4
```
(For this effect the two clips are: the raw clip, then the edited clip.) Built with ffmpeg through `engine/tools/before_after.py`. See `engine/instructions/before-after-reels.md` for how to ask for it.

## Example captions by niche

**Real estate agents** (works for: tour of a listing, open house walk-through, a quick market update)
> Real estate agents: watch the curtain. Raw footage, then the finished reel. Same clip. What changed: added captions, cut the dead air, tightened the pacing.
> 
> Want yours edited like this? Comment WAITLIST.

**Salon owners** (works for: a stylist talking over a transformation, a quick tip while working)
> Salon owners: watch the curtain. Raw footage, then the finished reel. Same clip. What changed: added captions, cut the pauses between clients, put the result up front.
> 
> Want yours edited like this? Comment WAITLIST.

**Product shops** (works for: unboxing, a demo, a packing-orders clip)
> Product shops: watch the curtain. Raw footage, then the finished reel. Same clip. What changed: added captions, cut the slow parts, showed the product in the first second.
> 
> Want yours edited like this? Comment WAITLIST.

**Talking head** (works for: an expert tip, a story, a hot take to camera)
> Talking head: watch the curtain. Raw footage, then the finished reel. Same clip. What changed: added captions, cut the restarts, a hook in the first second.
> 
> Want yours edited like this? Comment WAITLIST.

**Network marketers (lifestyle)** (works for: a raw 'morning with the kids' or 'coffee and a quick thought' clip becoming a polished, captioned reel)
> Network marketers (lifestyle): watch the curtain. Raw footage, then the finished reel. Same clip. What changed: added captions, cut the pauses, a hook in the first second, made a casual clip look finished.
> 
> Want yours edited like this? Comment WAITLIST.
