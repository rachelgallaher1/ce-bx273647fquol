# Release notes

Version 0.9.1 pre-launch: Pick your brand. Choose from 12 ready-made color and font sets, or create your own. Your carousels and videos use them.

Version 0.9.0 pre-launch: the first version customers get.
