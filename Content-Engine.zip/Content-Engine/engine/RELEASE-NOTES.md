# Release notes

Version 0.9.0 pre-launch: the first version customers get.
