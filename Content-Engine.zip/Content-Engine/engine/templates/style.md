# My Style

*Learned on: <date>. Say "learn my style again" any time to redo it.*

## From the reel I'm proud of
- **Reel:** <file name> · **Length:** <seconds> · **Cuts:** <number> · **Average shot:** <seconds> · **Cuts per 10 seconds:** <number>
- **Caption look:** <plain words: size, color, where they sit, one word at a time or a line, bold or light>
- **The opening (hook):** <how the first words appear on screen>
- **Graphics and effects:** <what she uses and how often: zooms, GIFs, takeover words, sounds>
- **Colors and feel:** <plain words>

## From the screenshots I love (each one: what she likes about it)
- <screenshot name>: <what she said she likes> · link: <if she has it>

## My own GIFs
<how many, where they live: customer/profile/gifs/>. The engine uses these before searching Giphy.

## What this means for my edits (the engine reads this before every build)
- <plain rules, for example "fast cuts, about 2 seconds a shot", "captions low and bold", "one takeover word per reel">
