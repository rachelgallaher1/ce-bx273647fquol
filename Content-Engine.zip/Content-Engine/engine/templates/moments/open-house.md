# Moment: open house
**Ask one at a time:** the date, the time, the address.
**Make:** an announcement post, a reminder story (day before) and a "doors open now" story. Add a countdown sticker note for the stories.
**Rules:** no invented details. Brokerage line where required. Compliance scan before showing her.
