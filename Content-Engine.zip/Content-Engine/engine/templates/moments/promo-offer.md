# Moment: promo or offer
**Ask one at a time:** the offer, the deadline.
**Make:** an offer post with soft-sell framing (what it is, who it is for, the deadline, one easy next step) and 3 story frames (heads up, reminder, last day).
**Rules:** never gross, never fake urgency. The deadline must be real. Her conversion goal is the ask.
