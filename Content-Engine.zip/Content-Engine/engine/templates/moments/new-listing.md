# Moment: new listing
**Ask one at a time:** the address (or the neighborhood only, if she prefers), three features, the price.
**Make:** a listing post (caption, 3 to 5 lines, no steering language), a carousel outline (cover, three features, the ask), and 3 story frames.
**Rules:** features describe the home, never who should live there. Add her brokerage line where her rules require it. Run `compliance_scan.py` on everything. Never invent a feature or price. Her conversion goal is the ask.
