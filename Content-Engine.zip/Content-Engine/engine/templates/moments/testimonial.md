# Moment: testimonial
**Ask one at a time:** the client's own words (a voice note is fine). Then: "Okay to use their name or photo, or keep it as 'a client'?" Default: anonymous.
**Make:** a proof post that follows the proof rules: the words, what changed, the feeling line. A receipt-style card with anything private blurred.
**Rules:** never edit their words into a bigger claim. No identifying detail without a yes. For network marketing and wellness, no income or health claims even if the client said them: run the compliance scan and show the rewrite.
