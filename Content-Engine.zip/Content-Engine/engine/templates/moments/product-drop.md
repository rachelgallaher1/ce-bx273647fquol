# Moment: product drop
**Ask one at a time:** what is new, the price.
**Make:** a drop post (one idea, one photo note, the ask) and 3 story frames (tease, reveal, last few left only if true).
**Rules:** never say "limited" or "selling out" unless she says it is true. Her conversion goal is the ask.
