# Month plan: [month and year]

**Posts a week:** [number] · **Videos:** [number] · **Fixed days:** [launch, event, holiday, or none]
**Approved on:** [date]

| # | Date | Format | Job | Idea | Why it's here | Script | Status | Pillar | Mix |
|---|------|--------|-----|------|---------------|--------|--------|--------|-----|
| 1 | [date] | video | get found | [one line] | [one line] | [link to the full script, or to the outline in customer/plans/outlines/] | ready | [pillar name] | VALUE |

**Mix:** VALUE · SOFT PITCH · HARD PITCH (default 3 value to 1 soft pitch a week, never two hard pitches in a row). Pillar and Mix are optional columns.
**Format:** video · carousel · text carousel · stories
**Job:** get found · keep people · get them to act · proof
**Status (depth is part of it):** outline (only an outline, the script unlocks at the Sunday refresh) · ready (full script written) · filmed · edited · posted. Older plans may say planned (same as outline) or scripted (same as ready).
**Calendar states:** ready · planned, script unlocks Sunday · posted · missed (the date passed and it was never posted).

## I need from you
- [Post #: the true story or fact the script is waiting for]

## Notes
Weekly refresh: [on / off] · Paused: [no]
Month 1 runs on what works in her niche. From month 2 it runs on what works for her.

[Her notes and swaps]
