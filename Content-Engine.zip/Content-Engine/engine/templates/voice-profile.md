# Voice Profile: <her name or business>

*Saved on: <date>*

## About her business
- **What she sells and who it's for:**
- **The main problem she solves:**
- **What makes her different:**

## Platform and pace
- **Main platform:**
- **How often she can realistically post:**

## Her words and tone
- **Words and tone she would NEVER use:**
- **Words and phrases she loves or repeats:**

## Her choices
- **Hook tone she picked:**
- **Caption length she picked:**
- **Emoji use she picked:**
- **Call to action style she picked:**
- **Changes she asked for:**

## Her labels
<Short two to four word names she uses for a feeling or a situation, each with a quote showing where she said it. "Not enough yet" if none.>

## Stories she retells
<One line each, with a quote. "Not enough yet" if none.>

## Her spoken words
<Word for word, never tidied: her talk-it-out answers and, if she agreed, transcripts of her top videos. Spoken words count most for her voice.>

## Her real writing samples
<Her pasted captions, or what she said when she talked. Her exact words, not cleaned up.>

## Voice summary (approved by her)
<5 to 8 plain lines. Only saved once she said "Yes, this sounds like me.">
