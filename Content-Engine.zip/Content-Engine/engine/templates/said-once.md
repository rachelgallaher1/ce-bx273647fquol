# Said once (the engine's own log; she does not need to read this)

Tick a line the moment you say it. Before you say any "once" line, check it is not ticked. Never repeat a ticked line unless she asks.

- [ ] Conversion-goal question asked ("one quick thing before I write")
- [ ] On-camera and off-limits questions asked (with the film-day list)
- [ ] Benchmarks said at the start ("here's what's normal"), or "no niche data yet" said
- [ ] Unlock line said after the week-1 build ("say 'weekly refresh' or 'unlock week 2'")
- [ ] "Post for today" line said in the Today view
- [ ] Moment templates line said after week 1
- [ ] Mining old posts offered after week 1
- [ ] Reply drafts offered after her first post went live
- [ ] Pause and shift line said ("going on vacation? just say 'pause my plan'")
- [ ] Benchmarks said again at her first refresh
- [ ] Talk-don't-type offered at her first friction point
- [ ] Offered "learn my style" once before her first video edit
- [ ] Offered film mode (the phone teleprompter) once, after the first film-day list
