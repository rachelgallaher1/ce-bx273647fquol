# Carousel templates: design notes (builder only, not shown to customers)

Six original templates ship with the engine. Each is designed from style ideas in screenshots Rachel collects (inbox/one, two, three ...). We take style only (layout, type feel, color mood, kinds of doodles), never another creator's photos, words, names, logos or exact artwork. Every shipped template must pass the test: "would the original designer say it looks like theirs, or just the same style?"

## Template 1 (from inbox/one): "Scrapbook"
Source: 9 slides, a before/after photo carousel on cream torn paper.
What Rachel likes (she picked): **the handwritten lettering, the photo layout, the stickers and doodles.** She did NOT pick the paper background, so it can be simpler or follow brand colors.
Elements to build as original drawings: whimsical handwritten title; small typewriter-style labels; two rounded, white-bordered, slightly tilted photos in a zig-zag; a hand-drawn curved arrow; dashed note bubble; small hand-drawn stickers (our own: heart, star, squiggle, fruit); last slide = one big comment-word with a collage of earlier slides.
For text-only slides: same lettering and doodles on a flat color, notes and tape instead of photos.

## Template 2 (from inbox/two): "Numbered tips"
Source: 8 slides, a numbered-tips carousel on a soft off-white textured background.
Elements to build as original drawings: big number plus a mixed-font title (a bold condensed word beside a thin handwritten or serif word); small handwritten note with a hand-drawn underline beside a plain body paragraph; die-cut sticker photo (colored outline, wavy white border) on the right; gold star and glitter stickers, a pink star, tape; last slide = a handwritten "want mine?" in a speech bubble, a big serif comment word with outline, "and I'll send it to you", and a cut-out photo.
Rachel's picks: she likes ALL of it: the mixed-font numbered titles, the sticker-style photos, the handwritten notes with underlines, and the sticker add-on. On the stars: she likes the note about stars (they are optional). She likes the **sticker add-on** (die-cut sticker photos and sticker-style add-ons). Stars are NOT required: do not make gold stars a fixed part of the design; stickers can be anything fitting the topic (shapes, food, hearts, tape, arrows).

## Template 3 (from inbox/three): "Bold editorial"
Source: 9 slides, a numbered trend/tips carousel with huge condensed serif headlines.
Elements to build as original drawings: huge tall condensed serif headline filling the slide; soft marker-style highlight bars behind a few key words (yellow or lavender); small pill label with the number as a word (ONE, TWO, THREE); two-tone soft palette (blush with deep maroon on cover and last slide, warm cream with dark text in the middle); layout = headline on top, a visual area in the middle, a short plain paragraph below; a round rotated stamp badge in a corner; a handwritten coral emphasis line; a cut-out halftone object on the cover; last slide = same big headline plus a handwritten "comment WORD" line.
Rachel's picks: she likes ALL of it: the big condensed headlines, the highlight bars behind words, the number-word pills, and the pink-and-cream color mood. **IMPORTANT: she wants each customer's own brand colors used in this template instead of fixed pink and cream** (the pink/cream is only the default if the customer has no brand colors yet).

## Template 4 (from inbox, loose files IMG_4657 to IMG_4660): "Photo statement"
Source: 4 slides, personal photos filling the slide with a dark veil.
Elements to build as original drawings: full-bleed photo (stills from the customer's own video) with a soft dark overlay; thin elegant serif white text; ONE giant bold keyword in a pale accent color (AND, BOTH, YES); split layout with two photos stacked top and bottom, a statement on each and the big word between; hand-brushed stroke underline under the big word on the cover.
Rachel's picks: she likes ALL of it: full-photo slides with the dark layer, the thin serif text, the one giant bold word, and the split two-photo layout. Use the customer's brand accent color for the giant word (default pale yellow).
Note: pairs with the "best three stills from your video" feature (bg_frame). The existing make_carousel `bgphoto` + `overlay` already does the full-photo part; the split layout and giant keyword are new.

## Template 5 (from inbox/five): "Warm flat color"
Source: 3 slides, flat butter-yellow background with deep brown condensed serif text.
Elements to build as original drawings: flat warm background (a brand color), bold condensed serif headline in the dark brand color, a "POV:" style spoken hook; a row of three rounded photos with brand-palette color circles underneath (reads from the customer's brand colors); a 3-by-3 feed-grid slide (a "look at the result" slide made from the customer's own earlier slides or photos); tilted comment-bubble slide (social proof: ONLY real comments the customer pastes, never invented) with a small round stamp; a handwritten red-orange comment-word call to action; small handle at the foot of each slide.
Rachel's picks: she likes ALL of it: the flat warm color with brown serif, the photo row with color circles, the feed grid and comment bubbles, and the handwritten call to action. **Again: use the colors of the person using the engine** (butter yellow and brown are only the default when no brand colors exist).
Honesty rule for this template: the comments and feed-result slides may only show real comments and real results the customer provides. If she has none, leave those slides out.

## Template 6 (from inbox/six): "Photo story"
Source: 3 slides, a full-bleed photo with a soft dark fade at the bottom and caption-style words.
Elements to build as original drawings: full-bleed photo (stills from the customer's own video) with a gradient fade at the bottom; words low and left like a film caption; a small handwritten colored lead-in line (like "and honestly?"); a bold serif sentence with ONE italic word in an accent color; a smaller plain line below with one bold phrase; a tiny sparkle icon in a top corner; small handle and page count at the bottom; a second layout where one word is much bigger than the smaller words flowing around it, in a warm accent serif.
Rachel's picks: she likes ALL of it: words low and left, the handwritten lead-in, the italic color accent word, and the one big word with smaller words around it. Use the customer's brand accent color for the lead-in and accent word. Fits storytelling posts (the customer's story bank).

# Summary: the six templates
1 Scrapbook | 2 Numbered tips | 3 Bold editorial | 4 Photo statement | 5 Warm flat color | 6 Photo story
Rachel's rules for all six: original designs (never copies); each uses the customer's OWN brand colors and font (defaults only when none); stickers/stars optional; real proof only (no invented comments or results); customers can add their own template from screenshots ("learn this carousel look").

## Template 7 (from inbox/Seven): "Notebook caps" (LOCKED Oct 31 2026: cover = full photo, short white caps headline right on top of a big thin-italic word (Instrument Serif Italic) whose color auto-contrasts with the photo; later slides = headline, framed photo with the italic word on it, note blocked in a bright box; last slide = boxed comment word + italic line)
Source: 4 slides on cream graph-paper. Big bold all-caps black headline across the top; a tall framed portrait photo in the middle with script-style colored words over it; a hand-drawn arrow and pointing-hand sticker; a short body paragraph; a rectangular label box for a call to action ("Comment: WORD"). Cover = stacked headline over a photo with a highlight bar.
Status: Rachel is still collecting templates. Build the first six first; Template 7 stays an extra until she says what she likes about it.

## Template 8 (from inbox/Eight): "Face and contrast" (LOCKED Oct 31 2026: accent words in thin Instrument Serif Italic, lead line tucked close under/over the headline, last slide centered; she likes ALL of it)
Source: a 5-slide carousel on stills of the creator's own video (face always visible, dark layer), plus a reel and a text-over-video post in the same look.
Elements to build as original drawings: small spaced-out lead-in line; bold sans headline with ONE big italic serif word; a split "THE OLD WAY / THE NEW WAY" slide (two columns on one photo, bullet list under each); a proof card (a small real screenshot of her results placed on the photo, REAL screenshots only, never invented numbers); an italic "Comment WORD to get ..." call to action at the bottom.
Rachel's picks: all four (split slide, photo with mixed words, proof card, italic call to action). Customer's brand colors and font. Fits Template 4/6 as a photo-led family: build as Template 8 with kinds cover, split2 (old/new), point, proof, cta.
