# <Working title>

**Job:** get found / keep people / get them to act · **Kind:** teaching / personal and honest · **Length:** about <N> seconds
**Idea:** <the idea in one line>
**Shape:** <story / list / contrarian take / personal and honest / comparison / series episode>

## Hook
- **Said:** <spoken first line, first sentence under 12 words>
- **Shown:** <what the first frame shows>
- **Read (text at the top):** <small top line naming who it's for> / <big line naming the tension. Never the spoken line>

## Ten hooks (and the two to test)
<The ten hooks, numbered. The two to test are marked TEST, with the one thing that differs between them. No lever names or other jargon.>

## Script (word for word, in her voice)
<line one>
<line two>
<line three>

## Beats
| Beat | Time | What happens |
| --- | --- | --- |
| Hook | 0:00 to 0:03 | <one line> |

## What to show on screen
<For a teaching video: what the viewer sees that proves the point, and the line it lands on. For a personal and honest video: "none, the words carry it," or one quiet visual.>

## The ask
<one ask, after the payoff>

## Filming direction
<where to stand, the setting, the energy, a prop, the pause. A suggestion, not a rule.>

## Caption first line
<a second hook for the feed>

## Check notes
**What's already working:** <two or three strengths, quoting her lines>
**Three ways to take it further:** <each: the change, one line of why, the new line in her voice>
**One line to try:** <a stronger version of one line, as an option>
**Changes made:** <anything already changed, if any>

## After posting
- Posted: <date> · Link:
- Views: · Likes: · Comments: · Shares: · Saves: · Follows:
- What it taught me:
