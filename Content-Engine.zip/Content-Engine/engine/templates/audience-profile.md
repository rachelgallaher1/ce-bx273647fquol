# Who I'm Talking To

*Saved on: <date>*

## Where she is
<just starting / posting and growing / already selling> · <one line: how many videos so far, anything already working>

## What kind of account
<teaches or helps / sells a product / shares her life> · <one line: what she teaches, sells or shares>

## Her person
<One real person in a real situation, and what they want. Not a label on its own.>

## Their moments
- <a time, room or place> · "<the thought they have right then, in their words>"
- <a time, room or place> · (no thought given)

## Their words
- "<a question or phrase her people actually say, word for word>"

## My topics
- <each small enough for one video>

## What my videos lead to
- **Offer:** <what it is, or "not yet"> · **Comment word:** <the word, or "not yet">
- **Until then:** <follow / save / send / come back, or "not yet">

## My core message
<The one frustration behind everything she posts, in her own words, and why she built what she built. A few short sentences.>

## My proof
- <a real number, result, credential or story she'd say out loud. Unsure numbers marked [check this]. Or "figuring it out as I go.">

## Check
<Each part: strong or could be sharper, with one line on what would sharpen it.>
