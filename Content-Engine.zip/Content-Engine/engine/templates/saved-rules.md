# My Saved Rules

Rules I asked to be remembered. They apply to everything written for me.

**Next rule number: 1**

*(No rules saved yet.)*

<!-- Format for each rule, added in order:
1. The rule in one plain sentence. (Saved <date>)
When a rule is saved, use the "Next rule number" for it, then add 1 to that number.
When a rule is deleted, remove it but never lower the "Next rule number", so numbers are never reused.
-->
