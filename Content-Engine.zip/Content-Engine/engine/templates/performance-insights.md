# My Reel Performance

*Pulled on: <date>* · *Handle: <@handle>* · *Reels looked at: <number>*

## My typical reel
- **Typical views (middle value):**

## My hits
<Each hit: date, first line of caption, views, likes, comments, and how far above my typical.>

## My misses
<The lowest few, same details.>

## Patterns (approved by me)
<2 to 4 plain observations, each naming the reels that show it. Only saved once I said they were right.>

## My own notes
<What I know that the numbers can't show.>

## Note on the numbers
These are public numbers only (views, likes, comments). They do not include reach, saves, shares or watch time.
