# Outline: [short title]

**Depth:** outline (the full script unlocks at the Sunday refresh)
**Plan row:** [number] · **Date:** [date] · **Format:** [video, carousel, text carousel, stories]

## Hook
[One line. Concrete first, no brag number, no ask.]

## Beats
1. [what the script covers, in order]
2. [...]
3. [3 to 5 beats in all]

## Format and filming note
[Setup, place, energy level.]

## Why it's there
[One line, carried from the plan table.]

## CTA intent
[Soft (follow, save, send) or hard (comment keyword). Hard keyword asks about 1 post in 3 or 4 while waitlisting or launching.]
