# My Marketing Settings

*Saved on: <date>. Change any line any time by saying it ("my goal is now ...", "add kids to my off-limits list").*

**Niche:** <real-estate / network-marketing / boutique / salon / insurance / other, in her words>
**Conversion goal (the ONE action she wants a follower to take):** <her words>
**Last posted for the business:** <date or "never consistently"> · **Has posted reels or carousels before:** <yes / no>
**On camera:** <all / about half / none>
**Sell to value ratio:** 3 value : 1 soft pitch (change to 2:1 or 4:1 on request)
**Post time (default for every post, a script can override it):** <for example 11:30am>
**Hashtag set (niche and local, added to every copied caption):** <3 to 5 hashtags, for example #yourniche #yourcity>
**Cringe filter (no dance trends, thirst traps, pranks, teenage-style challenges):** on

## Off-limits on camera
<kids or family · home interior · workplace · car or license plate · client faces · other>

## Things she refuses to post (what everyone in her industry posts)
- <her answer>

## Content pillars (3 to 4, approved by her)
1. **<plain name>:** <what it is> · Why it fits her: <something she said> · Why it works in her niche: <source labeled: "from top reels this month" or "general pattern"> · Example ideas: <two>
