#!/usr/bin/env python3
"""Draws the eight built-in carousel looks in HER brand colors and font (a grey picture placeholder stands in for her photos),
so the "My looks" row on the Carousels tab can show them, with sample words and sample stock photos.

  python3 make_looks.py [--handle @hers] [--force]

Writes customer/looks/look-N/slide-01.png .. slide-03.png (N = 1 to 8). Skips a look that already exists unless --force.
The pictures are the free sample stock photos in engine/templates/carousel/sample-photos/ (a plain grey picture icon only if one is missing).
"""
import json, os, shutil, subprocess, sys
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
OUT = os.path.join(ROOT, "customer", "looks")


def brand_colors():
    """Her saved brand colors (customer/profile/brand.json). Fewer than two means she has not set them yet."""
    try:
        d = json.load(open(os.path.join(ROOT, "customer", "profile", "brand.json"), encoding="utf-8"))
        return [c["hex"] for c in d.get("colors", []) if c.get("hex")]
    except Exception:
        return []


HER = {}


def her_source():
    """Her newest finished carousel in a look: its cover, first middle slide and ask become the previews, so the looks show HER words.
    Returns (cover, point, cta, photos) or None."""
    import glob
    best = None
    for p in glob.glob(os.path.join(ROOT, "customer", "content", "**", "slides.json"), recursive=True):
        if os.sep + "zz-" in p:
            continue   # test carousels
        try:
            sp = json.load(open(p, encoding="utf-8"))
            sl = [s for s in sp.get("slides", []) if s.get("type") == "tpl"]
            if len(sl) >= 3 and (best is None or os.path.getmtime(p) > best[0]):
                best = (os.path.getmtime(p), sl, sp.get("handle") or "")
        except Exception:
            pass
    if not best:
        return None
    sl = best[1]
    HER["handle"] = best[2]
    cover = next((s for s in sl if s.get("kind") == "cover"), sl[0])
    cta = next((s for s in reversed(sl) if s.get("kind") == "cta"), sl[-1])
    point = next((s for s in sl if s.get("kind") in ("point", "list", "quote", "stat") and s is not cover), sl[1])
    photos = []
    for s in sl:
        for q in ([s.get("photo")] if s.get("photo") else []) + list(s.get("photos") or []):
            if q and os.path.exists(q) and q not in photos:
                photos.append(q)
    return cover, point, cta, photos


def signature():
    src = her_source()
    words = None
    if src:
        c, p_, a_, ph = src
        words = [c.get("headline") or c.get("top"), p_.get("headline") or p_.get("top"), p_.get("body"), a_.get("keyword"), a_.get("line"), ph]
    return json.dumps([brand_colors(), words])


def stale():
    """True when the saved previews were drawn with different brand colors than she has now."""
    try:
        return open(os.path.join(OUT, ".work", "sig.txt"), encoding="utf-8").read() != signature()
    except Exception:
        return True


def placeholder(path):
    w, h = 1200, 1500
    im = Image.new("RGB", (w, h), (216, 213, 207))
    d = ImageDraw.Draw(im)
    for y in range(h):   # a soft, quiet gradient
        v = int(14 * y / h)
        d.line((0, y, w, y), fill=(216 - v, 213 - v, 207 - v))
    cx, cy, s = w // 2, h // 2, 150
    d.rounded_rectangle((cx - s, cy - int(s * 0.8), cx + s, cy + int(s * 0.8)), radius=26, outline=(150, 147, 141), width=14)
    d.ellipse((cx - s + 60, cy - int(s * 0.8) + 50, cx - s + 120, cy - int(s * 0.8) + 110), fill=(150, 147, 141))
    d.polygon([(cx - s + 20, cy + int(s * 0.8) - 20), (cx - 20, cy - 10), (cx + 40, cy + 50), (cx + 90, cy + 5), (cx + s - 20, cy + int(s * 0.8) - 20)], fill=(150, 147, 141))
    im.save(path, quality=90)


def specs(ph, handle):
    """The eight sample carousels (one kind of business each, no photo used twice), from engine/templates/carousel/look-specs.json.
    Their pictures are in engine/templates/carousel/sample-photos/ (free stock photos, used only to show the looks)."""
    base = os.path.join(os.path.dirname(HERE), "templates", "carousel")
    data = json.load(open(os.path.join(base, "look-specs.json"), encoding="utf-8"))

    def fix(v):
        if isinstance(v, str) and v.endswith(".jpg"):
            q = os.path.join(base, "sample-photos", v)
            return q if os.path.exists(q) else ph
        if isinstance(v, list):
            return [fix(x) for x in v]
        return v
    out = {int(k): [{a_: fix(b_) for a_, b_ in s.items()} for s in sl] for k, sl in data.items()}
    src = her_source()
    if not src:
        return out
    cover, point, cta, photos = src   # her own words (and photos, if she has them) in every look
    def mine(t, kind, s, k):
        stock = next((x for x in out[t] if x.get("photo")), {})
        ph_ = photos[k % len(photos)] if photos else stock.get("photo", ph)
        pl_ = [photos[(k + j) % len(photos)] for j in range(3)] if photos else list(out[t][0].get("photos") or [ph_, ph_, ph_])
        d = dict(type="tpl", template=t, kind=kind, photo=ph_, photos=pl_)
        if kind == "cta":
            d.update(keyword=s.get("keyword") or "WORD", line=s.get("line") or "and I'll send it to you")
            if t in (1, 2, 3, 7) and False:
                pass
            return d
        head = s.get("headline") or s.get("top") or ""
        d["headline"] = head
        if t == 4:
            d["top"], d["bottom"] = head, s.get("body") or s.get("bottom") or ""
        elif s.get("body"):
            d["body"] = s["body"]
        if kind == "cover" and s.get("hi"):
            d["hi"] = s["hi"]
        return d
    for t in out:
        out[t] = [mine(t, "cover", cover, 0), mine(t, "point", point if point.get("kind") == "point" else dict(point, kind="point", headline=point.get("headline") or point.get("top") or "", body=point.get("body") or ""), 1), mine(t, "cta", cta, 2)]
    return out


def main():
    handle = ""
    force = "--force" in sys.argv
    if "--handle" in sys.argv:
        handle = sys.argv[sys.argv.index("--handle") + 1]
    else:
        her_source()
        handle = HER.get("handle", "")
    look = "brand" if len(brand_colors()) >= 2 else "1"   # with no brand colors yet, the engine's own colors show instead of one flat color
    if stale():
        force = True
    work = os.path.join(OUT, ".work")
    os.makedirs(work, exist_ok=True)
    ph = os.path.join(work, "placeholder.jpg")
    placeholder(ph)
    py = sys.executable
    made = 0
    for t, slides in specs(ph, handle).items():
        dest = os.path.join(OUT, f"look-{t}")
        if os.path.exists(os.path.join(dest, "slide-01.png")) and not force:
            continue
        spec = os.path.join(work, f"look-{t}.json")
        json.dump({"title": f"look-{t}", "handle": handle or "@yourhandle", "look": look, "slides": slides}, open(spec, "w"))
        tmp = os.path.join(work, f"out-{t}")
        shutil.rmtree(tmp, ignore_errors=True)
        r = subprocess.run([py, "-X", "utf8", "-I", os.path.join(HERE, "make_carousel.py"), spec, tmp], capture_output=True, text=True, encoding="utf-8", errors="replace")
        if not os.path.exists(os.path.join(tmp, "slide-01.png")):
            print(f"Look {t} did not draw: {(r.stderr or r.stdout)[-300:]}")
            continue
        shutil.rmtree(dest, ignore_errors=True)
        os.makedirs(dest)
        for f in sorted(os.listdir(tmp)):
            if f.startswith("slide-0") and f.endswith(".png"):
                shutil.copy(os.path.join(tmp, f), os.path.join(dest, f))
        shutil.rmtree(tmp, ignore_errors=True)
        made += 1
    open(os.path.join(work, "sig.txt"), "w", encoding="utf-8").write(signature())
    print(f"Drew {made} look(s) in {OUT}.")


if __name__ == "__main__":
    main()
