"""The ready-made look picker on the My brand tab: twelve sets of colors and fonts, plus Make it yours.
Picking one saves its colors and its three fonts (headline, easy-to-read, script) to brand.json; carousels and video hook words use them."""
import json
import os
import re
import urllib.parse

GROUPS = [
 {
  "group": "Calm and classic",
  "sub": "Easy on the eye. Works for almost anyone.",
  "sets": [
   {
    "name": "Warm and Homey",
    "colors": [
     "#9A5B2E",
     "#D9A441",
     "#FAF3E7",
     "#3E2A1A",
     "#8A9A7B"
    ],
    "fonts": [
     "Fraunces",
     "Nunito",
     "Caveat"
    ]
   },
   {
    "name": "Modern Neutral",
    "colors": [
     "#111111",
     "#C2A27C",
     "#8A6F50",
     "#FFFFFF",
     "#D9D4CC"
    ],
    "fonts": [
     "Syne",
     "Jost",
     "Cormorant Garamond Italic"
    ]
   },
   {
    "name": "Fresh and Calm",
    "colors": [
     "#2F5D57",
     "#8FBFA8",
     "#F2F0E6",
     "#E4B84A",
     "#D98B5F"
    ],
    "fonts": [
     "DM Serif Display",
     "Albert Sans",
     "Satisfy"
    ]
   },
   {
    "name": "Clean and Trusted",
    "colors": [
     "#1F3A5F",
     "#6FA8DC",
     "#F2B134",
     "#FFF9EC",
     "#E8735A"
    ],
    "fonts": [
     "Poppins",
     "Inter",
     "Kalam"
    ]
   }
  ]
 },
 {
  "group": "Soft and pretty",
  "sub": "Gentle, friendly and feminine.",
  "sets": [
   {
    "name": "Soft and Pretty",
    "colors": [
     "#D98BA3",
     "#7B2D43",
     "#FFF8F5",
     "#F7D6E0",
     "#D9B27C"
    ],
    "fonts": [
     "Playfair Display",
     "Lato",
     "Dancing Script"
    ]
   },
   {
    "name": "Cottage Garden",
    "colors": [
     "#C97B84",
     "#6B8F5E",
     "#FBF4E8",
     "#3F4A36",
     "#E9C46A"
    ],
    "fonts": [
     "Cormorant Garamond",
     "Quicksand",
     "Sacramento"
    ]
   },
   {
    "name": "Pink Party",
    "colors": [
     "#FF4FA3",
     "#FFB3D1",
     "#C9A7FF",
     "#8E2A5E",
     "#FFF0F6"
    ],
    "fonts": [
     "Bagel Fat One",
     "Nunito",
     "Great Vibes"
    ]
   }
  ]
 },
 {
  "group": "Bright and fun",
  "sub": "Playful and full of color.",
  "sets": [
   {
    "name": "Sunny Pop",
    "colors": [
     "#FF4F8B",
     "#FFB400",
     "#00B5C8",
     "#FFF6E5",
     "#7B4BC4"
    ],
    "fonts": [
     "Lilita One",
     "Fredoka",
     "Pacifico"
    ]
   },
   {
    "name": "Playful",
    "colors": [
     "#6A4C93",
     "#FF8FAB",
     "#FFD166",
     "#FDF6FF",
     "#3EC7B6"
    ],
    "fonts": [
     "Chewy",
     "Baloo 2",
     "Pacifico"
    ]
   },
   {
    "name": "Neon Pop",
    "colors": [
     "#C8F53C",
     "#3D5AFE",
     "#0F1230",
     "#F7FBEA",
     "#FF5FA2"
    ],
    "fonts": [
     "Bungee",
     "Outfit",
     "Caveat Brush"
    ]
   }
  ]
 },
 {
  "group": "Bold and different",
  "sub": "Stand-out looks with a lot of personality.",
  "sets": [
   {
    "name": "Arizona Turquoise",
    "colors": [
     "#1CA9A0",
     "#C8693A",
     "#3B2A22",
     "#F6E7D2",
     "#9DB08A"
    ],
    "fonts": [
     "Rye",
     "Josefin Sans",
     "Homemade Apple"
    ]
   },
   {
    "name": "Retro Sunset",
    "colors": [
     "#E8590C",
     "#F2B632",
     "#6D1F3A",
     "#FFF1DC",
     "#7A8B3C"
    ],
    "fonts": [
     "Shrikhand",
     "Karla",
     "Yellowtail"
    ]
   }
  ]
 }
]


def font_files(engine_fonts):
    """{family name: [file, ...]} for every font file the engine carries (so the picker can show each font as it really looks)."""
    out = {}
    for f in sorted(os.listdir(engine_fonts)) if os.path.isdir(engine_fonts) else []:
        if not f.lower().endswith((".ttf", ".otf")):
            continue
        n = re.sub(r"\[.*?\]|-(Regular|Bold|Medium|SemiBold|ExtraBold|Black|Italic|Light).*$", "", os.path.splitext(f)[0])
        n = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", n).strip()
        out.setdefault(n, []).append(f)
    return out


def _css(engine_fonts):
    ff = font_files(engine_fonts)
    css, fams = "", set()
    for n, files in ff.items():
        for f in files:
            fam = n + (" Italic" if "italic" in f.lower() else "")
            fams.add(fam)
            css += "@font-face{font-family:'" + fam + "';src:url('/engine-fonts/" + urllib.parse.quote(f) + "');font-weight:100 900}"
    return css, sorted(fams)


def picker_html(engine_fonts, current):
    css, fams = _css(engine_fonts)
    return ("<style>" + css + PICKER_CSS + "</style>" + PICKER_BODY + "<script>var PK_GROUPS=" + json.dumps(GROUPS) + ",PK_FONTS=" + json.dumps(fams)
            + ",PK_CUR=" + json.dumps(current or {}) + ";" + PICKER_JS + "</script>")


PICKER_CSS = """
.pk{margin:0 0 22px}.pk .hero{background:transparent;border-bottom:2px solid rgba(0,0,0,.08);padding:6px 0 16px;color:inherit;margin:4px 0 14px}
.pk .hero-t{font:800 30px/1.1 system-ui}.pk .hero-s{font-size:15px;margin-top:6px;max-width:560px;opacity:.75}
.pk .hero-o{font-size:15px;margin:-4px 0 10px}.pk .hero-o a{color:#2f6f6a;font-weight:700}.pk .hero-d{margin-top:12px;font-weight:700;font-size:14px}.pk .hero-d span{display:inline-block;background:#2f6f6a;color:#fff;border-radius:99px;width:22px;height:22px;line-height:22px;text-align:center;margin:0 6px 0 12px}.pk .hero-d span:first-child{margin-left:0}
.pk .c{transition:transform .15s,box-shadow .15s}.pk .c:hover{transform:translateY(-3px);box-shadow:0 8px 16px rgba(0,0,0,.12)}.pk .c.s{box-shadow:0 0 0 3px #2A6E6F33}.pk .c.s b:after{content:"  Picked";font-size:11px;background:#2A6E6F;color:#fff;border-radius:99px;padding:2px 8px;margin-left:6px;font-weight:700}.pk h3{margin:0 0 4px}.pk .gh{font-size:16px;font-weight:800;margin:18px 0 0}.pk .gh small{display:block;font-size:13px;font-weight:400;color:#6b5c4c;margin-top:2px}
.pk .g{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:12px;margin-top:8px}
.pk .c{background:#fff;border:2px solid #e3d6c3;border-radius:14px;padding:10px;cursor:pointer}.pk .c:hover,.pk .c.s{border-color:#2A6E6F}
.pk .sw{display:flex;height:34px;border-radius:8px;overflow:hidden;margin-bottom:8px}.pk .sw i{flex:1}
.pk .demo{border:1px solid #eee;border-radius:8px;padding:9px;margin-bottom:8px}.pk .c b{display:block}.pk .c span{font-size:12px;color:#6b5c4c}
.pk .own{background:#fff;border:2px dashed #2A6E6F;border-radius:14px;padding:14px;margin:18px 0}.pk .own .sw{height:50px}.pk .own .sw input{flex:1;border:0;padding:0;height:50px;width:100%;cursor:pointer;background:none}
.pk .own button{border:1px solid #2A6E6F;background:#fff;color:#2A6E6F;border-radius:99px;padding:6px 14px;cursor:pointer;margin:6px 8px 0 0;font:inherit;font-size:14px}.pk .own button.go{background:#2A6E6F;color:#fff}
.pk .fr{display:flex;gap:10px;flex-wrap:wrap}.pk .lb{font-size:12px;color:#6b5c4c;flex:1;min-width:150px}
.pk .dd{position:relative;margin-top:3px}.pk .dd .cur{padding:8px 10px;border-radius:8px;border:1px solid #cdbfa9;background:#fff;cursor:pointer;font-size:18px;display:flex;justify-content:space-between;align-items:center;color:#222}
.pk .dd .cur:after{content:"\\25BE";font-size:12px;color:#6b5c4c}.pk .dd .lst{display:none;position:absolute;left:0;right:0;top:100%;z-index:20;max-height:260px;overflow:auto;background:#fff;border:1px solid #cdbfa9;border-radius:8px;box-shadow:0 8px 20px rgba(0,0,0,.15)}
.pk .dd.open .lst{display:block}.pk .dd .lst div{padding:7px 10px;font-size:18px;cursor:pointer;color:#222}.pk .dd .lst div:hover{background:#f6efe4}
.pk .note{font-size:13px;color:#6b5c4c;margin-top:6px}
"""

PICKER_BODY = """<div class="pk"><div class="hero"><div class="hero-t">Pick your brand</div><div class="hero-s">Choose the colors and fonts that feel like you. Your carousels and videos will use them, and you can change anything later.</div><div class="hero-d"><span>1</span> Tap a look <span>2</span> Make it yours <span>3</span> Use this look</div></div><div class="hero-o">Or <a href="#pkown" onclick="document.getElementById('pkown').scrollIntoView({behavior:'smooth'});return false">create your own</a>: scroll to the bottom to change any color or font.</div><div id="pkg"></div>
<div class="own" id="pkown"><b>Create your own</b><p class="sub" style="margin:4px 0 10px">Start from any look above, then change any color or font. Tap Use this look when you are happy.</p>
<div class="sw" id="pksw"></div>
<div class="fr"><div class="lb">Headline font<select id="pkf0" style="display:none"></select></div><div class="lb">Easy-to-read font<select id="pkf1" style="display:none"></select></div><div class="lb">Script font<select id="pkf2" style="display:none"></select></div></div>
<div class="demo" id="pkpv" style="margin-top:10px"><div id="pkp0" style="font-size:28px;line-height:1.1">Your headline</div><div id="pkp1" style="font-size:15px;margin:4px 0">Easy-to-read words go here</div><div id="pkp2" style="font-size:24px">a little script</div></div>
<button id="pkadd">+ Add a color</button><button id="pkrem">Take one away</button><button id="pkreset">Start over</button><button class="go" id="pkuse">Use this look</button><div class="note" id="pknote"></div></div></div>"""

PICKER_JS = r"""
(function(){
var cur=null,box=document.getElementById('pkg'),sw=document.getElementById('pksw');
function el(t,c,h){var e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e}
function fam(n){return /\sItalic$/.test(n)?"font-family:'"+n.replace(/\sItalic$/,'')+"';font-style:italic":"font-family:'"+n+"';font-style:normal"}
function L(h){var n=parseInt(h.slice(1),16);return .299*(n>>16)+.587*(n>>8&255)+.114*(n&255)}
PK_GROUPS.forEach(function(g){box.appendChild(el('div','gh',g.group+'<small>'+g.sub+'</small>'));var gr=el('div','g');
 g.sets.forEach(function(s,i){var o=s.colors.slice().sort(function(a,b){return L(a)-L(b)}),ink=o[0],paper=o[o.length-1],acc=s.colors.filter(function(x){return x!==ink&&x!==paper});
  var c=el('div','c');c.innerHTML='<div class="sw">'+s.colors.map(function(x){return '<i style="background:'+x+'"></i>'}).join('')+'</div><div class="demo" style="background:'+paper+';color:'+ink+'"><div style="'+fam(s.fonts[0])+';font-size:25px;color:'+hc(acc,paper,ink)+';line-height:1.1">Your headline</div><div style="'+fam(s.fonts[1])+';font-size:14px;margin:3px 0">Easy-to-read words go here</div><div style="'+fam(s.fonts[2])+';font-size:22px;color:'+(acc[1]||acc[0]||ink)+'">a little script</div></div><b>'+s.name+'</b><span>'+s.fonts.join(' · ')+'</span>';
  c.onclick=function(){pick(c,s)};s._el=c;gr.appendChild(c)});box.appendChild(gr)});
function sel(k){return document.getElementById('pkf'+k)}
[0,1,2].forEach(function(k){var s=sel(k);PK_FONTS.forEach(function(f){var o=document.createElement('option');o.value=o.textContent=f;s.appendChild(o)});
 var w=el('div','dd'),cu=el('div','cur'),ls=el('div','lst');PK_FONTS.forEach(function(f){var d=el('div','',f);d.setAttribute('style',fam(f));d.onclick=function(e){e.stopPropagation();s.value=f;w.classList.remove('open');draw()};ls.appendChild(d)});
 cu.onclick=function(e){e.stopPropagation();document.querySelectorAll('.pk .dd.open').forEach(function(x){if(x!==w)x.classList.remove('open')});w.classList.toggle('open')};w.appendChild(cu);w.appendChild(ls);s.parentNode.appendChild(w);s._cur=cu});
document.addEventListener('click',function(){document.querySelectorAll('.pk .dd.open').forEach(function(x){x.classList.remove('open')})});
function cols(){return [].map.call(sw.children,function(x){return x.value})}
function hc(a,p,i){var b=i,m=-1;a.forEach(function(x){var d=Math.abs(L(x)-L(p));if(d>m){m=d;b=x}});return m>90?b:i}
function draw(){var c=cols(),o=c.slice().sort(function(a,b){return L(a)-L(b)}),ink=o[0],paper=o[o.length-1],acc=c.filter(function(x){return x!==ink&&x!==paper}),p=document.getElementById('pkpv');p.style.background=paper;p.style.color=ink;
 [0,1,2].forEach(function(k){var f=sel(k).value,e=document.getElementById('pkp'+k),sz=[28,15,24][k];e.setAttribute('style','font-size:'+sz+'px;'+(k==1?'margin:4px 0;':k==0?'line-height:1.1;':'')+fam(f)+';color:'+(k==0?hc(acc,paper,ink):k==2?(acc[1]||acc[0]||ink):ink));sel(k)._cur.textContent=f;sel(k)._cur.setAttribute('style',fam(f))})}
function fill(colors,fonts){sw.innerHTML='';colors.forEach(function(v){var i=document.createElement('input');i.type='color';i.value=v;i.oninput=draw;sw.appendChild(i)});fonts.forEach(function(f,k){sel(k).value=f});draw()}
function pick(c,s){cur=s;document.querySelectorAll('.pk .c').forEach(function(x){x.classList.remove('s')});c.classList.add('s');fill(s.colors,s.fonts)}
document.getElementById('pkadd').onclick=function(){if(sw.children.length<5){var i=document.createElement('input');i.type='color';i.value='#cccccc';i.oninput=draw;sw.appendChild(i);draw()}};
document.getElementById('pkrem').onclick=function(){if(sw.children.length>2){sw.lastChild.remove();draw()}};
document.getElementById('pkreset').onclick=function(){if(cur)fill(cur.colors,cur.fonts)};
document.getElementById('pkuse').onclick=function(){var b=this;b.disabled=true;document.getElementById('pknote').textContent='Saving...';
 fetch('/api/brand/look',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({colors:cols(),fonts:{headline:sel(0).value,body:sel(1).value,script:sel(2).value}})}).then(function(r){return r.json()}).then(function(j){if(j.ok){location.reload()}else{b.disabled=false;document.getElementById('pknote').textContent=j.error||'That did not work.'}}).catch(function(){b.disabled=false;document.getElementById('pknote').textContent='That did not work. Try again.'})};
var start=PK_GROUPS[0].sets[0];
if(PK_CUR&&PK_CUR.colors&&PK_CUR.colors.length&&PK_CUR.fonts){fill(PK_CUR.colors,[PK_CUR.fonts.headline||start.fonts[0],PK_CUR.fonts.body||start.fonts[1],PK_CUR.fonts.script||start.fonts[2]]);document.getElementById('pknote').textContent='This shows the look you are using now.'}else{pick(start._el,start)}
})();
"""


def save_look(d, req):
    """Apply a picked look to the brand dict d (colors, three fonts); returns an error text or None."""
    cols = [c for c in (req.get("colors") or []) if isinstance(c, str) and re.fullmatch(r"#[0-9A-Fa-f]{6}", c)]
    fs = req.get("fonts") or {}
    if len(cols) < 2 or not all(fs.get(k) for k in ("headline", "body", "script")):
        return "Pick at least two colors and three fonts."
    d["colors"] = cols[:5]
    d["fontSet"] = {k: str(fs[k]) for k in ("headline", "body", "script")}
    d["fonts"] = [d["fontSet"]["headline"]]
    lum = lambda h: 0.299 * int(h[1:3], 16) + 0.587 * int(h[3:5], 16) + 0.114 * int(h[5:7], 16)
    d["dark"] = min(cols, key=lum)
    return None
