"""Suggest three cover frames: clean (no text), face centered, eyes open, looking at the camera.
Usage:  python make_covers.py EDITED_DIR NAME
Writes customer/content/covers/NAME_cover1.jpg to _cover3.jpg. She picks one and uses it as her reel cover.
"""
import json, os, re, sys
import cv2

W, H = 1080, 1920


def main():
    edited = os.path.abspath(sys.argv[1])
    name = sys.argv[2]
    vs = sorted(int(m.group(1)) for f in os.listdir(edited) for m in [re.fullmatch(re.escape(name) + r"_edit(\d+)\.plan\.json", f)] if m)
    if not vs:
        sys.exit("I can't find a finished edit yet.")
    plan = json.load(open(os.path.join(edited, f"{name}_edit{vs[-1]}.plan.json"), encoding="utf-8"))
    segs = [(s["start"], s["end"]) for s in plan["segments"]]
    src = plan["source"]
    cap = cv2.VideoCapture(src)
    try:
        cap.set(cv2.CAP_PROP_ORIENTATION_AUTO, 1)
    except Exception:
        pass
    face_c = cv2.CascadeClassifier(os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml"))
    eye_c = cv2.CascadeClassifier(os.path.join(cv2.data.haarcascades, "haarcascade_eye.xml"))
    cands, off = [], 0.0
    for s, e in segs:
        t = s + 0.2
        while t < e - 0.2:
            cands.append((off + (t - s), t))
            t += 0.5
        off += e - s
    scored = []
    for et, st in cands:
        if et < 3.0:
            continue
        cap.set(cv2.CAP_PROP_POS_MSEC, st * 1000)
        ok, frame = cap.read()
        if not ok:
            continue
        h0, w0 = frame.shape[:2]
        sc = max(W / w0, H / h0)
        fr = cv2.resize(frame, (int(w0 * sc) + 1, int(h0 * sc) + 1))
        l, t0 = (fr.shape[1] - W) // 2, (fr.shape[0] - H) // 2
        fr = fr[t0:t0 + H, l:l + W]
        small = cv2.cvtColor(cv2.resize(fr, (540, 960)), cv2.COLOR_BGR2GRAY)
        faces = face_c.detectMultiScale(small, 1.1, 4, minSize=(100, 100))
        if len(faces) == 0:
            continue
        x, y, w, h = max(faces, key=lambda f: f[2] * f[3])
        eyes = eye_c.detectMultiScale(small[y:y + h // 2, x:x + w], 1.1, 5, minSize=(20, 20))
        cx = (x + w / 2) / 540
        score = -abs(cx - 0.5) * 2 - abs(w / 540 - 0.45) * 2 + 0.4 * min(len(eyes), 2)
        sharp = cv2.Laplacian(small, cv2.CV_64F).var()
        scored.append((score + min(sharp, 400) / 800, et, fr))
    scored.sort(key=lambda x: -x[0])
    picks = []
    for sc_, et, fr in scored:
        if all(abs(et - p[1]) > 4 for p in picks):
            picks.append((sc_, et, fr))
        if len(picks) == 3:
            break
    out = os.path.abspath(os.path.join(edited, "..", "..", "content", "covers"))
    os.makedirs(out, exist_ok=True)
    for i, (_, et, fr) in enumerate(picks, 1):
        p = os.path.join(out, f"{name}_cover{i}.jpg")
        cv2.imwrite(p, fr, [cv2.IMWRITE_JPEG_QUALITY, 92])
        print(f"COVER: {p}  (at {et:.1f}s)")
    if not picks:
        print("I couldn't find a clear frame looking at the camera.")


main()
