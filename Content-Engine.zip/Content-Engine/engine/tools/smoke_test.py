#!/usr/bin/env python3
"""Fresh-install smoke test: unpack the engine into an empty folder (no customer data, like a brand new customer), then check that it starts and every page of the hub
opens without an error. Run before every release.
  python smoke_test.py [PATH/TO/Content-Engine.zip]      (default: the newest zip in "My Engine DIST" next to this folder)
Prints PASS or FAIL for each check and exits 1 if any failed. Uses the helper Python space (same one the engine uses)."""
import glob, os, py_compile, subprocess, sys, tempfile, time, urllib.request, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
VENV_PY = os.path.join(os.path.expanduser("~"), ".cache", "content-engine", "whisper-venv", "Scripts" if sys.platform.startswith("win") else "bin", "python.exe" if sys.platform.startswith("win") else "python")
fails = []


def check(ok, name, why=""):
    print(("PASS  " if ok else "FAIL  ") + name + ("" if ok else "  (" + why + ")"))
    if not ok:
        fails.append(name)
    return ok


def main():
    zp = sys.argv[1] if len(sys.argv) > 1 else (sorted(glob.glob(os.path.join(os.path.dirname(ROOT), "My Engine DIST", "*.zip"))) or [None])[-1]
    if not zp or not os.path.exists(zp):
        sys.exit("I can't find the engine zip. Pass its path.")
    tmp = tempfile.mkdtemp(prefix="engine-smoke-")
    with zipfile.ZipFile(zp) as z:
        z.extractall(tmp)
    entries = os.listdir(tmp)
    base = tmp if os.path.isdir(os.path.join(tmp, "engine")) else os.path.join(tmp, entries[0])
    check(os.path.isdir(os.path.join(base, "engine")) and os.path.exists(os.path.join(base, "CLAUDE.md")), "The zip unpacks to an engine folder with CLAUDE.md")
    check(not os.path.exists(os.path.join(base, "customer", "profile", "voice-profile.md")), "No personal files are inside the zip")
    bad = []
    for p in glob.glob(os.path.join(base, "engine", "tools", "*.py")):
        try:
            py_compile.compile(p, doraise=True, cfile=os.path.join(tmp, "pyc.tmp"))
        except Exception as e:
            bad.append(os.path.basename(p))
    check(not bad, "Every tool file is valid Python", ", ".join(bad))
    py = VENV_PY if os.path.exists(VENV_PY) else sys.executable
    proc = subprocess.Popen([py, "-X", "utf8", "-I", os.path.join(base, "engine", "tools", "batch_day.py"), "serve", "--no-open"], cwd=base, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
    port = None
    t0 = time.time()
    lines = []
    while time.time() - t0 < 25 and port is None:
        line = proc.stdout.readline()
        if not line:
            if proc.poll() is not None:
                break
            continue
        lines.append(line)
        if "http://" in line and ":" in line.split("http://")[-1]:
            try:
                port = int(line.split("http://")[-1].split(":")[1].split("/")[0].strip())
            except Exception:
                pass
    check(port is not None, "The hub starts on an empty folder", " | ".join(lines[-3:])[:200])
    if port:
        for path in ("/", "/calendar.html", "/batch", "/edit", "/content", "/results", "/brand", "/api/hub/status"):
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=20) as r:
                    body = r.read(400000).decode("utf-8", "ignore")
                    check(r.status == 200 and "Traceback" not in body, f"Page {path} opens with no error", f"status {r.status}")
            except Exception as e:
                check(False, f"Page {path} opens with no error", str(e)[:100])
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except Exception:
        proc.kill()
    r = subprocess.run([sys.executable, os.path.join(base, "engine", "tools", "check_setup.py")], capture_output=True, text=True, encoding="utf-8", errors="replace")
    check("READY" in r.stdout or "NOT READY" in r.stdout, "The setup check runs and gives an answer", r.stderr[-120:])
    print(f"\nTried it in {tmp}")
    print("All checks passed." if not fails else f"{len(fails)} check(s) failed.")
    sys.exit(1 if fails else 0)


main()
