#!/usr/bin/env python3
"""A tiny private problem log, kept on HER computer (customer/insights/problems.jsonl). It never leaves her computer unless she sends the help file.

  python3 help_log.py add "<area>" "<the problem, in one plain line>" "<what you tried>" fixed|not_fixed|unsure
  python3 help_log.py recent [N]

Rules: one short plain line each. NEVER put her scripts, words, names, passwords or anything private in it: only what kind of problem it was.
area is one of: setup, interview, scripts, recording, editing, carousels, stories, calendar, hub, other.
The help file (help_packet.py) includes the last entries, so whoever reads it can see which problems are common and what fixed them.
"""
import datetime, json, os, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
LOG = os.path.join(ROOT, "customer", "insights", "problems.jsonl")


def recent(n=10):
    try:
        rows = [json.loads(l) for l in open(LOG, encoding="utf-8") if l.strip()]
    except Exception:
        rows = []
    return rows[-n:]


def main():
    a = sys.argv[1:]
    if a and a[0] == "add" and len(a) >= 5:
        os.makedirs(os.path.dirname(LOG), exist_ok=True)
        row = {"date": datetime.date.today().isoformat(), "area": a[1][:20], "problem": a[2][:160], "tried": a[3][:160], "result": a[4] if a[4] in ("fixed", "not_fixed", "unsure") else "unsure"}
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps(row) + "\n")
        print(json.dumps({"ok": True}))
        return
    if a and a[0] == "recent":
        n = int(a[1]) if len(a) > 1 and a[1].isdigit() else 10
        for r in recent(n):
            print(f"{r['date']} [{r['area']}] {r['problem']} | tried: {r['tried']} | {r['result']}")
        return
    print(__doc__)


if __name__ == "__main__":
    main()
