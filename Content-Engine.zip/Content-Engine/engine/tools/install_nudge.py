#!/usr/bin/env python3
"""One-time, quiet setup of the Sunday nudge: at 10am every Sunday, if the results refresh has not run, show a notification that says to open Claude.
Runs from the launcher every time and does nothing once it is set up. Mac: a small scheduled job. Windows: a scheduled task. Nothing else on her computer changes."""
import os, subprocess, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
nudge = os.path.join(ROOT, "engine", "tools", "refresh_nudge.py")
flag = os.path.join(ROOT, "customer", "insights", ".nudge-installed")
if os.path.exists(flag):
    sys.exit(0)
try:
    if sys.platform == "darwin":
        label = "com.contentengine.refreshnudge"
        path = os.path.expanduser(f"~/Library/LaunchAgents/{label}.plist")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        open(path, "w", encoding="utf-8").write(f'''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict><key>Label</key><string>{label}</string>
<key>ProgramArguments</key><array><string>/usr/bin/python3</string><string>{nudge}</string></array>
<key>StartCalendarInterval</key><dict><key>Weekday</key><integer>0</integer><key>Hour</key><integer>10</integer><key>Minute</key><integer>0</integer></dict></dict></plist>''')
        subprocess.run(["launchctl", "unload", path], capture_output=True)
        ok = subprocess.run(["launchctl", "load", path], capture_output=True).returncode == 0
    elif sys.platform.startswith("win"):
        ok = subprocess.run(["schtasks", "/Create", "/F", "/SC", "WEEKLY", "/D", "SUN", "/ST", "10:00", "/TN", "ContentEngineRefreshNudge",
                             "/TR", f'"{sys.executable}" "{nudge}"'], capture_output=True).returncode == 0
    else:
        ok = False
    if ok:
        os.makedirs(os.path.dirname(flag), exist_ok=True)
        open(flag, "w", encoding="utf-8").write("ok")
except Exception:
    pass
