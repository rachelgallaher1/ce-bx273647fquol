#!/usr/bin/env python3
"""Plan helper for the weekly build. Reads her month plan and answers the questions the planner asks.
  python plan.py weeks               every calendar week (Mon to Sun) with each post and its state
  python plan.py week N              the posts in week N and which still need a full script
  python plan.py missed              posts whose date passed and were never posted (ask: roll forward or drop?)
  python plan.py roll N [DATE]       move missed post N to DATE (default: the next free day this week)... or: python plan.py drop N
  python plan.py shift DAYS [--keep 17,24]   move every unbuilt (outline) post forward DAYS days; built, filmed, edited,
                                      posted posts and any --keep post numbers (fixed days) stay where they are
  python plan.py swap N "new idea" ["why it is here"]   replace post N's idea; the old idea goes to the Banked ideas list in Notes. Refuses if it is filmed, edited or posted
  python plan.py file N PATH         remember which file to post for post N (shown as "File to use" on the calendar)
  python plan.py format N VALUE      change post N's format (for example: carousel, text reel, video)
  python plan.py mix N VALUE         set post N's sell/value mix (for example: VALUE, SOFT PITCH, HARD PITCH)
  python plan.py add YYYY-MM-DD FORMAT JOB IDEA   put a new post on an empty day
  python plan.py posted N            mark post N as posted (the calendar's Post it check does this)
  python plan.py pause | resume      freeze or restart building (a line in the plan's Notes)
Week 1 is the calendar week that holds the plan's first post. Weeks run Monday to Sunday and the refresh is Sunday.
States: ready (script built), outline (script unlocks Sunday), posted, missed.
"""
import datetime, glob, os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_calendar as mc

ROOT = mc.ROOT


def plan_path():
    plans = sorted(glob.glob(os.path.join(ROOT, "customer", "plans", "*-month-plan.md")))
    if not plans:
        sys.exit("No month plan found in customer/plans/.")
    return plans[-1]


def rows_of(path):
    _, rows = mc.read_plan(path)
    for r in rows:
        r["state"] = mc.state_of(r)
        r["d"] = datetime.date.fromisoformat(r["date"])
    return rows


def week_no(r, first):
    mon0 = first - datetime.timedelta(days=first.weekday())
    return (r["d"] - mon0).days // 7 + 1


def edit_lines(path, fn):
    lines = open(path, encoding="utf-8").read().split("\n")
    for i, line in enumerate(lines):
        m = re.match(r"\|\s*(\d+)\s*\|", line)
        if m:
            c = line.split("|")
            if len(c) >= 10:
                new = fn(int(m.group(1)), c)
                if new is not None:
                    lines[i] = "|".join(new)
    open(path, "w", encoding="utf-8").write("\n".join(lines))


def label(d):
    return d.strftime("%a %b ") + str(d.day)


def show_weeks(rows, only=None):
    first = min(r["d"] for r in rows)
    for r in rows:
        r["w"] = week_no(r, first)
    for w in sorted({r["w"] for r in rows}):
        if only and w != only:
            continue
        mine = [r for r in rows if r["w"] == w]
        need = [r for r in mine if r["state"] == "outline"]
        tag = " (partial week, built when the plan is approved)" if w == 1 and first.weekday() != 0 else ""
        print(f"Week {w}{tag}: {len(mine)} posts, {len(need)} still outline only")
        for r in mine:
            print(f"  {r['n']:>2}. {label(r['d'])} · {r['format']} · {r['state']:<7} · {r['idea']}")


def main():
    a = sys.argv[1:]
    if not a:
        sys.exit(__doc__)
    path = plan_path()
    rows = rows_of(path)
    cmd = a[0]
    if cmd == "weeks":
        show_weeks(rows)
    elif cmd == "week":
        show_weeks(rows, int(a[1]))
    elif cmd == "missed":
        miss = [r for r in rows if r["state"] == "missed"]
        print("\n".join(f"{r['n']}. {label(r['d'])} · {r['idea']}" for r in miss) or "Nothing missed.")
    elif cmd == "posted":
        n = int(a[1])
        if not any(r["n"] == n for r in rows):
            sys.exit("No post %d in the plan." % n)
        edit_lines(path, lambda k, c: (c[:8] + [" posted "] + c[9:]) if k == n else None)
        print("Post %d is marked posted. Tell me how it did, and I will log it so the engine learns." % n)
    elif cmd == "drop":
        n = int(a[1])
        edit_lines(path, lambda k, c: (c[:8] + [" dropped "] + c[9:]) if k == n else None)
        print("Dropped. It stays in the plan as dropped and is ignored from now on.")
    elif cmd == "roll":
        n = int(a[1])
        year = int(os.path.basename(path)[:4])
        target = datetime.date.fromisoformat(a[2]) if len(a) > 2 else datetime.date.today()
        def fn(k, c):
            if k != n:
                return None
            c[2] = " " + label(target) + " "
            return c
        edit_lines(path, fn)
        print("Moved post %d to %s." % (n, label(target)))
    elif cmd == "shift":
        days = int(a[1])
        keep = set()
        if "--keep" in a:
            keep = {int(x) for x in a[a.index("--keep") + 1].split(",") if x}
        state = {r["n"]: r for r in rows}
        moved = []
        def fn(k, c):
            r = state.get(k)
            if not r or k in keep or r["state"] != "outline":
                return None
            nd = r["d"] + datetime.timedelta(days=days)
            c[2] = " " + label(nd) + " "
            moved.append(k)
            return c
        edit_lines(path, fn)
        print(f"Moved {len(moved)} unbuilt posts forward {days} days. Built, posted and kept posts stayed put.")
    elif cmd == "format":
        n, newf = int(a[1]), " ".join(a[2:]).replace("|", "/").strip()
        if not any(r["n"] == n for r in rows):
            sys.exit("No post %d in the plan." % n)
        edit_lines(path, lambda k, c: (c[:3] + [" " + newf + " "] + c[4:]) if k == n else None)
        print("Post %d is now a %s." % (n, newf))
    elif cmd == "mix":
        n, val = int(a[1]), " ".join(a[2:]).replace("|", "/").strip()
        if not any(r["n"] == n for r in rows):
            sys.exit("No post %d in the plan." % n)

        def fnm(k, c):
            if k != n:
                return None
            c = list(c)
            while len(c) < 12:
                c.insert(-1, " ")
            c[10] = " " + val + " "
            return c
        edit_lines(path, fnm)
        print("Post %d is now marked %s." % (n, val))
    elif cmd == "add":
        # add DATE(YYYY-MM-DD) FORMAT JOB IDEA...   puts a new post on an empty day
        day = datetime.date.fromisoformat(a[1])
        fmt, job, idea = a[2].replace("|", "/"), a[3].replace("|", "/"), " ".join(a[4:]).replace("|", "/")
        if any(r["d"] == day for r in rows):
            sys.exit("That day already has a post.")
        newn = max(r["n"] for r in rows) + 1
        lines = open(path, encoding="utf-8").read().split("\n")
        last = max(i for i, l in enumerate(lines) if re.match(r"\|\s*\d+\s*\|", l))
        lines.insert(last + 1, f"| {newn} | {label(day)} | {fmt} | {job} | {idea} | Added by hand for an empty day | none yet | planned |")
        open(path, "w", encoding="utf-8").write("\n".join(lines))
        print(f"Added post {newn} on {label(day)}: {idea}")
    elif cmd == "swap":
        n = int(a[1])
        new = a[2].replace("|", "/").strip()
        why = a[3].replace("|", "/").strip() if len(a) > 3 else None
        r = [x for x in rows if x["n"] == n]
        if not r:
            sys.exit("No post %d in the plan." % n)
        if (r[0]["status"] or "").lower() in ("filmed", "edited", "posted"):
            sys.exit("Post %d is already %s, so I won't change it." % (n, r[0]["status"]))
        old = r[0]["idea"]
        def fn(k, c):
            if k != n:
                return None
            c[5] = " " + new + " "
            if why:
                c[6] = " " + why + " "
            return c
        edit_lines(path, fn)
        text = open(path, encoding="utf-8").read()
        line = "- %s (was post %d, swapped %s)" % (old, n, datetime.date.today().isoformat())
        if "## Banked ideas" in text:
            text = text.replace("## Banked ideas\n", "## Banked ideas\n" + line + "\n", 1)
        else:
            text = text.rstrip("\n") + "\n\n## Banked ideas\n" + line + "\n"
        open(path, "w", encoding="utf-8").write(text)
        print("Post %d is now: %s. The old idea is banked: %s" % (n, new, old))
    elif cmd == "file":
        import json as _j
        n = int(a[1])
        r = [x for x in rows if x["n"] == n]
        if not r:
            sys.exit("No post %d in the plan." % n)
        fp = os.path.join(os.path.dirname(path), "post-files.json")
        try:
            d = _j.load(open(fp, encoding="utf-8"))
        except Exception:
            d = {}
        d[r[0]["date"]] = a[2]
        _j.dump(d, open(fp, "w", encoding="utf-8"), indent=1)
        print("Saved: post %d (%s) uses %s." % (n, r[0]["date"], a[2]))
    elif cmd in ("pause", "resume"):
        text = open(path, encoding="utf-8").read()
        text = re.sub(r"\n- Paused: [^\n]*", "", text)
        if cmd == "pause":
            text = text.rstrip("\n") + "\n- Paused: yes (since %s). The weekly refresh does not build until she says resume.\n" % datetime.date.today().isoformat()
        open(path, "w", encoding="utf-8").write(text)
        print("Paused." if cmd == "pause" else "Resumed.")
    else:
        sys.exit(__doc__)
    if cmd in ("shift", "roll", "drop", "pause", "resume", "file", "swap", "posted"):
        mc_path = os.path.join(os.path.dirname(path), "calendar.html")
        open(mc_path, "w", encoding="utf-8").write(mc.page_for(path, False))
        mc.write_shortcut()


if __name__ == "__main__":
    main()
