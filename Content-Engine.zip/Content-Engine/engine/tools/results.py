#!/usr/bin/env python3
"""Results log and learning loop: log how a post did, then learn what works for HER audience.
  python results.py add --kind reel --title "..." --hook "..." --pattern "..." --views 1200 --saves 40 --shares 12 [--likes --comments --follows --reach --posted 2026-10-17 --script FILE --ab A]
  python results.py add --kind carousel --carousel customer/content/<folder> --title "..." --saves N --shares N --reach N      (the look is read from that carousel)
  python results.py add --kind story --title "..." --frames 5 --forward 400 --back 60 --exits 30 --replies 12
  python results.py learn      (writes customer/insights/learned.md and learned.json)
  python results.py show
Files live in customer/insights/: results-log.jsonl (the data), results-log.md (a readable table), learned.md and learned.json (what the engine has learned).
A missing number stays unknown, never zero. Nothing is claimed until there are enough posts.
"""
import argparse, json, os, statistics, sys, datetime

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
INS = os.path.join(ROOT, "customer", "insights")
LOG = os.path.join(INS, "results-log.jsonl")
MIN_POSTS = 5     # total posts before any "this works" claim
MIN_PER_PATTERN = 2
MIN_PER_LOOK = 3      # carousels in one look before the engine says anything about that look


def load():
    if not os.path.exists(LOG):
        return []
    return [json.loads(l) for l in open(LOG, encoding="utf-8") if l.strip()]


def score(r):
    """Saves plus shares first (the actions that mean 'this was worth keeping'). Per 1,000 views when views are known."""
    s = (r.get("saves") or 0) + (r.get("shares") or 0)
    if r.get("saves") is None and r.get("shares") is None:
        return None
    v = r.get("views") or r.get("reach")
    return round(s / v * 1000, 1) if v else float(s)


def pscore(r):
    """What anyone can see without her private numbers: likes plus 3 for every comment, per 1,000 views or reach when known."""
    if r.get("likes") is None and r.get("comments") is None:
        return None
    s = (r.get("likes") or 0) + 3 * (r.get("comments") or 0)
    v = r.get("views") or r.get("reach")
    return round(s / v * 1000, 1) if v else float(s)


def looks_block(rows, out, lines):
    """Which carousel LOOK does best for her. Uses saves plus shares when she has them for enough carousels, else likes and comments."""
    names = {"1": "Scrapbook", "2": "Numbered tips", "3": "Bold editorial", "4": "Photo statement", "5": "Warm flat color", "6": "Photo story", "7": "Notebook caps", "8": "Face and contrast"}
    car = [r for r in rows if r.get("kind") == "carousel" and r.get("look")]
    for metric, fn, label in (("saves+shares", score, "saves plus shares"), ("likes+comments", pscore, "likes and comments (Instagram keeps saves and shares private, so add them on Sundays for a better answer)")):
        scored = [(r, fn(r)) for r in car if fn(r) is not None]
        if len(scored) >= MIN_POSTS:
            base = statistics.median(s for _, s in scored)
            by = {}
            for r, s in scored:
                by.setdefault(str(r["look"]), []).append(s)
            out["looks"] = {k: {"posts": len(v), "median": statistics.median(v)} for k, v in by.items()}
            out["looks_baseline"], out["looks_metric"], out["looks_enough"] = base, metric, True
            ranked = [(k, v) for k, v in out["looks"].items() if v["posts"] >= MIN_PER_LOOK]
            lines.append("")
            lines.append(f"## Carousel looks (judged by {label})")
            if ranked:
                for k, v in sorted(ranked, key=lambda kv: -kv[1]["median"]):
                    tag = "beats" if v["median"] > base * 1.15 else ("is below" if v["median"] < base * 0.85 else "is about the same as")
                    lines.append(f"- **{names.get(k, 'Your own look ' + k)}**: {v['posts']} carousels, median {v['median']}, {tag} your typical carousel ({base}).")
            else:
                lines.append(f"- Not enough carousels in one look yet (I need {MIN_PER_LOOK} per look). Keep going.")
            return
    out["looks_enough"] = False


def write_md(rows):
    os.makedirs(INS, exist_ok=True)
    with open(os.path.join(INS, "results-log.md"), "w", encoding="utf-8") as f:
        f.write("# Results log\n\nSaves plus shares decide a winner. A blank is unknown, never zero.\n\n")
        f.write("| Posted | Kind | Title | Hook | Pattern | Views | Saves | Shares | Score | Version |\n|---|---|---|---|---|---|---|---|---|---|\n")
        for r in rows:
            g = lambda k: "" if r.get(k) is None else r.get(k)
            f.write(f"| {g('posted')} | {g('kind')} | {g('title')} | {g('hook')} | {g('pattern')} | {g('views')} | {g('saves')} | {g('shares')} | {score(r) if score(r) is not None else ''} | {g('ab')} |\n")


def learn(rows):
    rows_all = list(rows)
    today = datetime.date.today().isoformat()
    early = [r for r in rows if (r.get("posted") or "") >= today]
    rows = [r for r in rows if r not in early]
    scored = [(r, score(r)) for r in rows if score(r) is not None]
    out = {"posts": len(rows), "scored": len(scored), "enough": len(scored) >= MIN_POSTS, "baseline": None, "patterns": {}, "formats": {}, "ab": [], "looks": {}, "looks_baseline": None}
    lines = ["# What the engine has learned about your audience", ""]
    if early:
        lines += [f"Too early to call: {len(early)} post(s) logged the day they went up. I will count them tomorrow.", ""]
    if not scored:
        lines.append("Nothing yet. Log a few posts (say \"I posted it\") and this fills in.")
    else:
        base = statistics.median(s for _, s in scored)
        out["baseline"] = base
        lines.append(f"Based on {len(scored)} posts. Your typical post scores {base} (saves plus shares, per 1,000 views when views are known). Only your own numbers are used.")
        lines.append("")
        by = {}
        for r, s in scored:
            for key in (r.get("pattern"),):
                if key:
                    by.setdefault(key, []).append(s)
        fm = {}
        for r, s in scored:
            fm.setdefault(r.get("kind", "reel"), []).append(s)
        for k, v in by.items():
            out["patterns"][k] = {"posts": len(v), "median": statistics.median(v)}
        for k, v in fm.items():
            out["formats"][k] = {"posts": len(v), "median": statistics.median(v)}
        if not out["enough"]:
            lines.append(f"That's not enough to call anything a pattern yet. I need at least {MIN_POSTS} posts. Keep logging.")
        else:
            lines.append("## Patterns that are beating your typical post")
            good = [(k, v) for k, v in out["patterns"].items() if v["posts"] >= MIN_PER_PATTERN and v["median"] > base]
            if good:
                for k, v in sorted(good, key=lambda kv: -kv[1]["median"]):
                    lines.append(f"- **{k}**: {v['posts']} posts, median {v['median']} (typical {base}). Lean toward this.")
            else:
                lines.append("- No pattern has beaten your typical post twice yet.")
            weak = [(k, v) for k, v in out["patterns"].items() if v["posts"] >= MIN_PER_PATTERN and v["median"] < base]
            if weak:
                lines.append("")
                lines.append("## Patterns that are below your typical post")
                for k, v in sorted(weak, key=lambda kv: kv[1]["median"]):
                    lines.append(f"- {k}: {v['posts']} posts, median {v['median']}. Use less, or change the angle.")
            lines.append("")
            lines.append("## By format")
            for k, v in out["formats"].items():
                lines.append(f"- {k}: {v['posts']} posts, median {v['median']}")
        # A/B tests: pairs with the same title and different version
        tests = {}
        for r, s in scored:
            if r.get("ab"):
                tests.setdefault(r.get("title"), {})[r["ab"]] = (s, r.get("hook"), r.get("pattern"))
        for t, d in tests.items():
            if len(d) >= 2:
                win = max(d.items(), key=lambda kv: kv[1][0])
                out["ab"].append({"title": t, "winner": win[0], "hook": win[1][1], "pattern": win[1][2], "scores": {k: v[0] for k, v in d.items()}})
        if out["ab"]:
            lines.append("")
            lines.append("## Hook tests")
            for t in out["ab"]:
                lines.append(f"- {t['title']}: version {t['winner']} won ({t['scores']}). Winning hook: {t['hook']}")
    out.setdefault("looks", {})
    looks_block(rows_all, out, lines)
    os.makedirs(INS, exist_ok=True)
    open(os.path.join(INS, "learned.md"), "w", encoding="utf-8").write("\n".join(lines) + "\n")
    json.dump(out, open(os.path.join(INS, "learned.json"), "w", encoding="utf-8"), indent=1)
    return lines


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("add")
    for k in ("kind", "title", "hook", "pattern", "script", "ab", "posted", "link", "note", "look", "carousel"):
        a.add_argument("--" + k)
    for k in ("views", "reach", "likes", "comments", "saves", "shares", "follows", "frames", "forward", "back", "exits", "replies"):
        a.add_argument("--" + k, type=int)
    sub.add_parser("learn")
    sub.add_parser("show")
    args = ap.parse_args()
    rows = load()
    if args.cmd == "add":
        r = {k: v for k, v in vars(args).items() if v is not None and k != "cmd"}
        if r.get("carousel") and not r.get("look"):   # the look is read from the carousel she posted
            try:
                fp = os.path.join(ROOT, r["carousel"], "slides.json") if not os.path.isabs(r["carousel"]) else os.path.join(r["carousel"], "slides.json")
                sl = [s for s in json.load(open(fp, encoding="utf-8")).get("slides", []) if s.get("type") == "tpl"]
                if sl:
                    r["look"] = str(sl[0].get("template"))
                r["kind"] = "carousel"
            except Exception:
                pass
        folder = (vars(args).get("carousel") or "").replace(os.sep, "/").strip("/") if vars(args).get("carousel") else ""
        if folder:
            r["folder"] = folder
        r.pop("carousel", None)
        old = next((x for x in rows if r.get("folder") and x.get("folder") == r["folder"]), None)
        if old is None:
            r.setdefault("kind", "reel")
            r.setdefault("posted", datetime.date.today().isoformat())
        os.makedirs(INS, exist_ok=True)
        if old is not None:   # the same carousel again (for example saves and shares added on Sunday): update that row, never double count
            for k, v in r.items():
                if v is not None:
                    old[k] = v
            with open(LOG, "w", encoding="utf-8") as f:
                for x in rows:
                    f.write(json.dumps(x) + "\n")
            r = old
        else:
            with open(LOG, "a", encoding="utf-8") as f:
                f.write(json.dumps(r) + "\n")
            rows.append(r)
        write_md(rows)
        learn(rows)
        sc = score(r)
        print(f"Logged. Score {sc if sc is not None else 'unknown'}. {len(rows)} posts so far.")
        print(open(os.path.join(INS, "learned.md"), encoding="utf-8").read())
    elif args.cmd == "learn":
        write_md(rows)
        print("\n".join(learn(rows)))
    else:
        print(open(os.path.join(INS, "results-log.md"), encoding="utf-8").read() if rows else "No posts logged yet.")


main()
