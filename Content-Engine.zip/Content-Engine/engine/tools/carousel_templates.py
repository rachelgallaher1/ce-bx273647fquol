#!/usr/bin/env python3
"""Six original carousel templates. Every one is drawn here from scratch (no one's artwork) and reads the customer's own
brand colors and font from her look. A slide uses:  {"type": "tpl", "template": 1..6, "kind": "cover|point|cta|...", ...words...}

  1 Scrapbook      handwritten lettering, tilted photo, doodles          kinds: cover, point, list, quote, cta
  2 Numbered tips  big number + mixed-font title, sticker photo, note    kinds: cover, point, list, quote, cta
  3 Bold editorial huge condensed headline, highlight bars, word pills   kinds: cover, point, list, quote, cta
  4 Photo statement full photo under a dark veil, thin serif, giant word kinds: cover, point, split, cta
  5 Warm flat color flat brand color, photo row, comment bubble, grid    kinds: cover, point, row, comment, grid, cta
  6 Photo story    photo, words low and left, italic accent word         kinds: cover, point, bigword, cta
  7 Notebook caps  cover: full photo; later: framed photo + note; bright words         kinds: cover, point, list, quote, cta
  8 Face and contrast  face photo under a dark layer, old/new split, proof card, italic call to action  kinds: cover, point, split2, proof, cta

Fields: headline, hi (the word to highlight), body, n (number), note (small handwritten line), keyword (comment word),
photo (path, optional), photos (list, for row/grid/split), comments (REAL comments only, for the comment kind), stickers (true/false).
Real proof only: comment and grid slides draw nothing that was not given. Defaults are used only when no brand colors exist.
"""
import json, math, os, random, re
from PIL import Image, ImageDraw, ImageFilter, ImageFont

CW, CH = 1080, 1350
M = 96
HAND = tuple(int(x) if x.isdigit() else x for x in os.environ.get("CE_HAND", "Fredoka:300").split(":"))   # the handwriting-style lettering for notes and lead-ins (her pick)

# ---------------------------------------------------------------- movable pieces
# Everything a template draws on the slide is noted (where, how big). Pieces that touch are grouped into one movable piece
# (a headline with its highlight bars, a photo with its frame and shadow...). The editor shows those pieces so she can drag them,
# and a move is saved on the slide as {"at": [original center], "d": [dx, dy]}. With no moves nothing changes: output is identical.
class _Tracker:
    def __init__(self):
        self.active = False
        self.calls = []        # one entry per drawing call on the slide: {"bbox", "label", "pic"} (bbox None = not movable)
        self.depth = 0
        self.fixed = 0         # inside the footer (handle and slide number stay put)
        self.texty = 0         # inside a helper that draws words one letter or word at a time
        self.hide = set()      # call indexes not to draw (used to cut one piece out of the slide)
        self.shift = {}        # call index -> (dx, dy)

    def begin(self, shift=None, hide=None):
        self.active = True
        self.calls = []
        self.depth = 0
        self.fixed = 0
        self.texty = 0
        self.shift = shift or {}
        self.hide = set(hide or ())

    def end(self):
        self.active = False


TR = _Tracker()
LAST_BLOCKS = []
_GAP = 4


def _flat(xy):
    out = []
    for v in xy:
        if isinstance(v, (tuple, list)):
            out.extend(v)
        else:
            out.append(v)
    return out


def _bb_from(xy):
    f = _flat(xy)
    xs, ys = f[0::2], f[1::2]
    return (min(xs), min(ys), max(xs), max(ys))


def _tp(x, y, tr):
    """Move and resize a point: grow or shrink around the piece's center, then slide it."""
    dx, dy, s, cx, cy = tr[:5]
    X, Y = (x - cx) * s, (y - cy) * s
    r = tr[5] if len(tr) > 5 else 0
    if r:
        c_, s_ = math.cos(math.radians(r)), math.sin(math.radians(r))
        X, Y = X * c_ - Y * s_, X * s_ + Y * c_
    return (cx + X + dx, cy + Y + dy)


def _tr_xy(xy, tr):
    if xy and isinstance(xy[0], (tuple, list)):
        return [_tp(p[0], p[1], tr) for p in xy]
    f = list(xy)
    out = []
    for k in range(0, len(f), 2):
        out.extend(_tp(f[k], f[k + 1], tr))
    return tuple(out) if isinstance(xy, tuple) else out


def _scaled_font(font, s):
    if font is None or abs(s - 1) < 1e-3:
        return font
    try:
        nf = ImageFont.truetype(font.path, max(6, int(round(font.size * s))))
        ax = getattr(font, "_ce_axes", None)
        if ax:
            nf.set_variation_by_axes(ax)
            nf._ce_axes = ax
        return nf
    except Exception:
        return font


_orig_sva = ImageFont.FreeTypeFont.set_variation_by_axes


def _sva(self, axes):
    self._ce_axes = list(axes)
    return _orig_sva(self, axes)


ImageFont.FreeTypeFont.set_variation_by_axes = _sva


def _note(img, bbox, label="", pic=False):
    """Record one drawing call; returns how to move and resize it: (dx, dy, scale, cx, cy), or None for no change."""
    idx = len(TR.calls)
    if TR.fixed or bbox is None:
        TR.calls.append({"bbox": None, "label": label, "pic": pic})
        return None
    w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
    if w >= CW * 0.98 or h >= CH * 0.98 or w <= 0 or h <= 0:   # full-page backgrounds, veils, grid lines: not movable
        TR.calls.append({"bbox": None, "label": label, "pic": pic})
        return None
    if TR.texty:
        label, pic = (label or "x"), False
    TR.calls.append({"bbox": tuple(bbox), "label": label, "pic": pic})
    if idx in TR.hide:
        return "hide"
    return TR.shift.get(idx)


def _wrap_draw(name):
    orig = getattr(ImageDraw.ImageDraw, name)

    def w(self, xy, *a, **k):
        if not TR.active or TR.depth > 0:
            return orig(self, xy, *a, **k)
        im = getattr(self, "_image", None)
        if im is None or im.size != (CW, CH):
            return orig(self, xy, *a, **k)
        TR.depth += 1
        try:
            label = ""
            try:
                if name == "text":
                    txt = a[0] if a else k.get("text", "")
                    label = str(txt)
                    bb = self.textbbox(xy, txt, font=k.get("font"), stroke_width=k.get("stroke_width", 0), anchor=k.get("anchor"))
                else:
                    bb = _bb_from(xy)
            except Exception:
                bb = None
            tr = _note(im, bb, label)
            if tr == "hide":
                return None
            if tr:
                s, rot = tr[2], (tr[5] if len(tr) > 5 else 0)
                xy = _tr_xy(xy, tr[:5] + (0,))   # moved and resized; turning is done below
                if name == "text":
                    if k.get("font") is not None:
                        k["font"] = _scaled_font(k["font"], s)
                    if k.get("stroke_width"):
                        k["stroke_width"] = max(1, int(round(k["stroke_width"] * s)))
                else:
                    if k.get("width"):
                        k["width"] = max(1, int(round(k["width"] * s)))
                    if k.get("radius"):
                        k["radius"] = k["radius"] * s
                if rot:
                    layer = Image.new("RGBA", (CW, CH), (0, 0, 0, 0))
                    orig(ImageDraw.Draw(layer), xy, *a, **k)
                    layer = layer.rotate(-rot, resample=Image.BICUBIC, center=(tr[3] + tr[0], tr[4] + tr[1]))
                    im.paste(layer, (0, 0), layer)
                    return None
            return orig(self, xy, *a, **k)
        finally:
            TR.depth -= 1
    return w


def _scale_img(im, s):
    if abs(s - 1) < 1e-3:
        return im
    return im.resize((max(1, int(round(im.size[0] * s))), max(1, int(round(im.size[1] * s)))), Image.BICUBIC)


def _place_img(im, mask, dest, tr):
    """A picture moved, resized and turned: returns (picture, mask, top-left) so its center lands where the piece's center goes."""
    cen = _tp(dest[0] + im.size[0] / 2, dest[1] + im.size[1] / 2, tr)
    im = _scale_img(im, tr[2])
    mask = _scale_img(mask, tr[2]) if mask is not None else None
    rot = tr[5] if len(tr) > 5 else 0
    if rot:
        im = im.rotate(-rot, resample=Image.BICUBIC, expand=True)
        if mask is not None:
            mask = mask.rotate(-rot, resample=Image.BICUBIC, expand=True)
    return im, mask, (int(round(cen[0] - im.size[0] / 2)), int(round(cen[1] - im.size[1] / 2)))


def _wrap_composite():
    orig_ac, orig_paste = Image.Image.alpha_composite, Image.Image.paste

    def ac(self, im, dest=(0, 0), source=(0, 0)):
        if not TR.active or TR.depth > 0 or self.size != (CW, CH):
            return orig_ac(self, im, dest, source)
        TR.depth += 1
        try:
            bb = (dest[0], dest[1], dest[0] + im.size[0], dest[1] + im.size[1])
            tr = _note(self, bb, "", im.size[0] >= 120 and im.size[1] >= 120)
            if tr == "hide":
                return None
            if tr:
                im, _m, dest = _place_img(im, None, dest, tr)
            return orig_ac(self, im, dest, source)
        finally:
            TR.depth -= 1

    def paste(self, im, box=None, mask=None):
        if not TR.active or TR.depth > 0 or self.size != (CW, CH) or not hasattr(im, "size"):
            return orig_paste(self, im, box, mask)
        TR.depth += 1
        try:
            b = box if box is not None else (0, 0)
            bb = (b[0], b[1], b[0] + im.size[0], b[1] + im.size[1])
            tr = _note(self, bb, "", im.size[0] >= 120 and im.size[1] >= 120)
            if tr == "hide":
                return None
            if tr and len(b) == 2:
                im, mask, b = _place_img(im, mask if (mask is not None and hasattr(mask, "size")) else None, b, tr)
                return orig_paste(self, im, b, mask)
            return orig_paste(self, im, box, mask)
        finally:
            TR.depth -= 1
    Image.Image.alpha_composite, Image.Image.paste = ac, paste


for _n in ("text", "rectangle", "rounded_rectangle", "ellipse", "line", "polygon", "arc", "pieslice"):
    setattr(ImageDraw.ImageDraw, _n, _wrap_draw(_n))
_wrap_composite()


def _clusters():
    """Group the noted calls that touch each other into movable pieces."""
    items = [(k, c) for k, c in enumerate(TR.calls) if c["bbox"]]
    parent = list(range(len(items)))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a
    def area(b):
        return max(1, (b[2] - b[0]) * (b[3] - b[1]))

    def inside(small, big):   # how much of the smaller box lies inside the bigger one
        w = min(small[2], big[2]) - max(small[0], big[0]); h = min(small[3], big[3]) - max(small[1], big[1])
        return (max(0, w) * max(0, h)) / area(small)
    for a in range(len(items)):
        ca, ba = items[a][1], items[a][1]["bbox"]
        for b in range(a + 1, len(items)):
            cb, bb = items[b][1], items[b][1]["bbox"]
            ta, tb = bool(ca["label"].strip()), bool(cb["label"].strip())
            if ca["pic"] or cb["pic"]:
                if (ta or tb):
                    pb_, tb_ = (ba, bb) if ca["pic"] else (bb, ba)
                    if (pb_[2] - pb_[0]) > CW * 0.7 and (pb_[3] - pb_[1]) < CH * 0.4 and inside(tb_, pb_) >= 0.85:
                        parent[find(a)] = find(b)    # words on a paper strip stay with the strip
                    continue                     # otherwise words are their own piece, even on top of a picture
                small, big = (ba, bb) if area(ba) <= area(bb) else (bb, ba)
                if inside(small, big) >= 0.6:    # a picture with its frame, shadow or tape
                    parent[find(a)] = find(b)
                continue
            g_ = 34 if (ta and tb) else _GAP     # lines of text join into one paragraph
            if ba[0] - g_ <= bb[2] and bb[0] - g_ <= ba[2] and ba[1] - g_ <= bb[3] and bb[1] - g_ <= ba[3]:
                parent[find(a)] = find(b)
    groups = {}
    for a in range(len(items)):
        groups.setdefault(find(a), []).append(items[a])
    out = []
    for g in groups.values():
        xs0 = min(c["bbox"][0] for _, c in g); ys0 = min(c["bbox"][1] for _, c in g)
        xs1 = max(c["bbox"][2] for _, c in g); ys1 = max(c["bbox"][3] for _, c in g)
        words = [c["label"] for _, c in g if c["label"].strip() and c["label"] != "x"]
        has_pic = any(c["pic"] for _, c in g)
        joined = ("".join(words) if all(len(w_.strip()) <= 1 for w_ in words) else " ".join(words)) if words else ""
        label = ("Picture" if has_pic else (joined[:34] if joined else ("Text" if any(c["label"] == "x" for _, c in g) else "Shape")))
        if has_pic and words:
            label = "Picture"
        out.append({"label": label, "bbox": [int(xs0), int(ys0), int(xs1), int(ys1)], "members": [k for k, _ in g]})
    out.sort(key=lambda c: (c["bbox"][1], c["bbox"][0]))
    for n_, c in enumerate(out):
        c["id"] = n_
        c["at"] = [(c["bbox"][0] + c["bbox"][2]) // 2, (c["bbox"][1] + c["bbox"][3]) // 2]
    return out


def _as_text(fn):
    def f(*a, **k):
        TR.texty += 1
        try:
            return fn(*a, **k)
        finally:
            TR.texty -= 1
    return f


def _small_footer_fixed(fn):
    def f(*a, **k):
        TR.fixed += 1
        try:
            return fn(*a, **k)
        finally:
            TR.fixed -= 1
    return f


NAMES = {7: "Notebook caps", 8: "Face and contrast", 1: "Scrapbook", 2: "Numbered tips", 3: "Bold editorial", 4: "Photo statement", 5: "Warm flat color", 6: "Photo story"}
WORDS = ["ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN"]
DEFAULTS = {1: ("#F4EDE0", "#3A2F2A", "#D9573F"), 2: ("#F7F3EC", "#2B2B2B", "#E8A33D"), 3: ("#F6D6D9", "#5A1F2B", "#D8432F"),
            4: ("#1D1D20", "#FFFFFF", "#F3E7A1"), 5: ("#F2D675", "#4A2E1B", "#D2492A"), 6: ("#1B1B1B", "#FFFFFF", "#F0B979")}


def hexrgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def lum(c):
    return (0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]) / 255


def brand_cols(mc, look, tid):
    """(paper, ink, accent) from her look; the template defaults only if the look has no colors of its own."""
    fe = mc.fe
    if look.get("id") == "brand" or look.get("fromBrand"):
        cols = [fe.hex2rgb(look[k]["bg"])[:3] for k in ("hook", "accent", "caption", "highlight")]
        light = [c for c in cols if lum(c) > 0.6]
        dark = [c for c in cols if lum(c) < 0.35]
        mid = [c for c in cols if 0.35 <= lum(c) <= 0.6]
        paper = light[0] if light else cols[0]
        if lum(paper) > 0.9 and fe.font_set():
            # a picked look with a near-white page: a soft beige, so it never reads as plain white
            paper = tuple(int(paper[k] * 0.3 + (238, 226, 205)[k] * 0.7) for k in range(3))
        elif lum(paper) > 0.9:
            # a near-white page looks blank: tint her warmest mid color softly instead (cream stays as an extra)
            warm = [c for c in cols if 0.3 <= lum(c) <= 0.85]
            if warm:
                paper = tuple(int(c * 0.4 + 255 * 0.6) for c in warm[0])
        ink = dark[0] if dark else ((25, 25, 28) if lum(paper) > 0.5 else (255, 255, 255))
        acc = (mid + [c for c in cols if c not in (paper, ink)] + [cols[-1]])[0]
        if abs(lum(acc) - lum(paper)) < 0.2:
            acc = ink
        return paper, ink, acc
    d = DEFAULTS[tid]
    return hexrgb(d[0]), hexrgb(d[1]), hexrgb(d[2])


_wide = {}


HEAD_NAMES = ("ArchivoBlack", "Gloock", "InstrumentSerif", "Anton", "PlayfairDisplay", "Oswald", "BebasNeue")   # headline lettering that becomes her brand font


def F(mc, name, size, weight=700, italic=False, role=None):
    fs = mc.fe.font_set()
    if fs:   # a picked look: its headline, easy-to-read and script fonts replace the matching lettering everywhere
        if role is None:
            if name in HEAD_NAMES or name == "brand" or (name == "Fredoka" and weight >= 500):
                role = "headline"
            elif name in ("GochiHand-Regular", "InstrumentSerif-Italic") or name == "Fredoka":
                role = "script"
            else:
                role = "body"
        pick = fs.get(role)
        if pick:
            return mc.fe.load_font(pick, size, 700 if (role == "headline" and weight >= 600) else 400 if role == "script" else weight, False)
    if name in HEAD_NAMES or name == "brand":
        bf = mc.fe.brand_font_name()
        if bf:
            return mc.fe.load_font(bf, size, 700 if weight >= 600 else weight, False)
        if name == "brand":
            name = "ArchivoBlack"
    if name == "Fredoka":
        # the thin, wide cut of Fredoka (the lettering she picked): lightest weight, widest width
        key = (size, weight)
        if key not in _wide:
            from PIL import ImageFont
            f = ImageFont.truetype(os.path.join(mc.fe.__file__ and os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(mc.fe.__file__)))) or ".", "engine", "fonts", "Fredoka[wdth,wght].ttf"), size)
            f.set_variation_by_axes([max(300, min(700, weight)), 125])
            _wide[key] = f
        return _wide[key]
    return mc.fe.load_font(name, size, weight, italic)


def disp(mc, look, size):
    return mc.fe.display_font(look, size)


def fit(mc, d, text, fontfn, start, maxw, maxlines, floor=54):
    size = start
    while size > floor:
        f = fontfn(size)
        ls = mc.wrap(d, text, f, maxw)
        if len(ls) <= maxlines and all(d.textlength(l, font=f) <= maxw for l in ls):
            return f, ls
        size -= 6
    f = fontfn(floor)
    ls = mc.wrap(d, text, f, maxw)
    while (len(ls) > maxlines or any(d.textlength(l, font=f) > maxw for l in ls)) and floor > 28:   # last resort: smaller than the floor, so words never run off the slide
        floor -= 4
        f = fontfn(floor)
        ls = mc.wrap(d, text, f, maxw)
    return f, ls


def _key_word(text):
    """The strongest single word in her line (the longest one that is not a filler word)."""
    ws = [w.strip(" ,.?!:;\"'()-") for w in str(text).split()]
    ws = [w for w in ws if len(w) > 2 and w.lower() not in _STOP and not w.isdigit()]
    return max(ws, key=len) if ws else "READ"


def fit_box(mc, d, text, fontfn, start, maxw, maxh, lh=1.1, floor=40):
    """Largest size (down from start) where the wrapped words fit inside maxw by maxh. Returns the font and lines."""
    size = start
    while size > floor:
        f = fontfn(size)
        ls = mc.wrap(d, text, f, maxw)
        if len(ls) * int(f.size * lh) <= maxh and all(d.textlength(l, font=f) <= maxw for l in ls):
            return f, ls
        size -= 4
    f = fontfn(floor)
    return f, mc.wrap(d, text, f, maxw)


def photo_of(mc, s, img, w, h, up=0.5):
    p = s.get("photo")
    im = Image.open(p).convert("RGB") if p and os.path.exists(p) else img
    if im is None:
        return None
    return mc.cover_crop(im, w, h, 0.5).convert("RGBA")   # centered, so the placeholder icon (and a centered subject) sits in the middle


def photo_list(mc, s, img, w, h, count):
    out = []
    for p in (s.get("photos") or [])[:count]:
        if os.path.exists(p):
            out.append(mc.cover_crop(Image.open(p).convert("RGB"), w, h, 0.5).convert("RGBA"))
    while len(out) < count and img is not None:
        out.append(mc.cover_crop(img, w, h, 0.5).convert("RGBA"))
    return out


def rounded(im, r):
    m = Image.new("L", im.size, 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, im.width - 1, im.height - 1), radius=r, fill=255)
    out = im.copy()
    out.putalpha(m)
    return out


def shadow(base, pic, xy, blur=18, dy=14, alpha=110):
    if TR.active and TR.depth == 0 and base.size == (CW, CH):   # a picture and its shadow move and resize as one piece
        tr = _note(base, (xy[0], xy[1], xy[0] + pic.size[0], xy[1] + pic.size[1]), "", True)
        if tr == "hide":
            return
        if tr:
            pic, _m, xy = _place_img(pic, None, xy, tr)
            blur, dy = blur * tr[2], int(round(dy * tr[2]))
    TR.depth += 1
    try:
        _shadow(base, pic, xy, blur, dy, alpha)
    finally:
        TR.depth -= 1


def _shadow(base, pic, xy, blur=18, dy=14, alpha=110):
    sh = Image.new("RGBA", base.size, (0, 0, 0, 0))
    a = pic.getchannel("A").point(lambda v: int(v * alpha / 255))
    sh.paste((0, 0, 0, 255), (xy[0], xy[1] + dy), a)
    base.alpha_composite(sh.filter(ImageFilter.GaussianBlur(blur)))
    base.alpha_composite(pic, xy)


def tilt(pic, deg):
    return pic.rotate(deg, expand=True, resample=Image.BICUBIC)


def framed(pic, border, color=(255, 255, 255), round_=26):
    """A picture with a thick even border (a sticker or print)."""
    out = Image.new("RGBA", (pic.width + 2 * border, pic.height + 2 * border), (0, 0, 0, 0))
    ImageDraw.Draw(out).rounded_rectangle((0, 0, out.width - 1, out.height - 1), radius=round_ + border // 2, fill=color + (255,))
    out.alpha_composite(rounded(pic, round_), (border, border))
    return out


def wavy_sticker(pic, color, border=22, outline=8):
    """A die-cut style sticker: wavy white edge with a thin colored outline."""
    pad = border + outline + 4
    W, H = pic.width + 2 * pad, pic.height + 2 * pad
    mask = Image.new("L", (W, H), 0)
    md = ImageDraw.Draw(mask)
    cx, cy = W / 2, H / 2
    pts = []
    for k in range(180):
        t = 2 * math.pi * k / 180
        # a rounded rectangle path with a gentle wave
        ex, ey = (pic.width / 2 + border), (pic.height / 2 + border)
        c, s_ = math.cos(t), math.sin(t)
        p = 6.0
        r = 1 / (abs(c / ex) ** p + abs(s_ / ey) ** p) ** (1 / p)
        r += math.sin(t * 14) * 4
        pts.append((cx + r * c, cy + r * s_))
    md.polygon(pts, fill=255)
    outer = mask.filter(ImageFilter.MaxFilter(2 * outline + 1))
    out = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    out.paste(color + (255,), (0, 0), outer)
    out.paste((255, 255, 255, 255), (0, 0), mask)
    inner = Image.new("L", (W, H), 0)
    ImageDraw.Draw(inner).rounded_rectangle((pad, pad, pad + pic.width, pad + pic.height), radius=30, fill=255)
    pp = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    pp.alpha_composite(pic, (pad, pad))
    out.paste(pp, (0, 0), inner)
    return out


def star(d, cx, cy, r, color, points=5, inner=0.45, rot=-90):
    pts = []
    for k in range(points * 2):
        rr = r if k % 2 == 0 else r * inner
        a = math.radians(rot + k * 180 / points)
        pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    d.polygon(pts, fill=color)


def heart(d, cx, cy, r, color):
    pts = []
    for k in range(60):
        t = 2 * math.pi * k / 60
        x = 16 * math.sin(t) ** 3
        y = -(13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t))
        pts.append((cx + x * r / 17, cy + y * r / 17))
    d.polygon(pts, fill=color)


def squiggle(d, x0, y, x1, color, width=8, amp=9):
    pts = [(x0 + (x1 - x0) * k / 40, y + math.sin(k * 0.9) * amp) for k in range(41)]
    d.line(pts, fill=color, width=width, joint="curve")


def bar(d, x, y, w, h, color):
    d.rounded_rectangle((x, y, x + w, y + h), radius=h // 4, fill=color)


_JIT = [False]


def bounce_text(d, x, y, text, font, fill, seed=0, amp=0.35):
    """Letters that bounce a little: each one tilts and sits a touch higher or lower, like hand-lettering, with a soft offset shadow."""
    r = random.Random(seed + len(text))
    im = d._image
    for ch in text:
        w = d.textlength(ch, font=font)
        if ch.strip():
            pad = int(font.size * 0.5)
            layer = Image.new("RGBA", (int(w) + 2 * pad, int(font.size * 1.6) + 2 * pad), (0, 0, 0, 0))
            ld = ImageDraw.Draw(layer)
            ld.text((pad, pad), ch, font=font, fill=tuple(fill[:3]) + (255,))
            layer = layer.rotate(r.uniform(-8, 8) * amp, resample=Image.BICUBIC, center=(pad + w / 2, pad + font.size * 0.6))
            dy = r.uniform(-9, 9) * amp
            im.alpha_composite(layer, (int(x - pad), int(y - pad + dy)))
        x += w
    return x


def words_with_hi(d, x, y, text, font, ink, hi, hi_fill=None, hi_ink=None, bar_pad=10, bar_color=None):
    """Draw one line; the highlight word gets a colored bar behind it or a color of its own."""
    hi = (hi or "").strip(" ,.?!").lower()
    for part in re.split(r"(\s+)", text):
        pw = d.textlength(part, font=font)
        hit = hi and part.strip(" ,.?!'\"").lower() == hi
        if hit and bar_color:
            bb = font.getbbox(part)
            bar(d, x - bar_pad, y + bb[1] - 6, pw + 2 * bar_pad, (bb[3] - bb[1]) + 12, bar_color)
        col = (hi_ink or hi_fill or ink) if hit else ink
        if _JIT[0]:
            bounce_text(d, x, y, part, font, col, int(x))
        else:
            d.text((x, y), part, font=font, fill=col)
        x += pw
    return x


def small_footer(mc, d, look, handle, i, n, ink, y=CH - 92, face=None):
    f = F(mc, face or look["captionFont"], 28 if face else 30, 400 if face else 700)
    col = tuple(ink[:3]) + (200,)
    if handle:
        d.text((M, y), handle, font=f, fill=col)
    t = f"{i + 1}/{n}"
    d.text((CW - M - d.textlength(t, font=f), y), t, font=f, fill=col)


small_footer = _small_footer_fixed(small_footer)

def paper_texture(im, amount=6, seed=1):
    r = random.Random(seed)
    d = ImageDraw.Draw(im)
    for _ in range(900):
        x, y = r.randint(0, CW), r.randint(0, CH)
        a = r.randint(8, 22)
        d.point((x, y), fill=(120, 100, 80, a))
    return im


# ---------------------------------------------------------------- 1 Scrapbook
def grid_paper(im, paper, step=54):
    d = ImageDraw.Draw(im)
    line = tuple(int(c * 0.93) for c in paper) + (255,) if lum(paper) > 0.5 else tuple(min(255, int(c * 1.12) + 6) for c in paper) + (255,)
    for x in range(0, CW, step):
        d.line((x, 0, x, CH), fill=line, width=2)
    for y in range(0, CH, step):
        d.line((0, y, CW, y), fill=line, width=2)


def torn_strip(im, color, x0, y0, x1, y1, seed=4, deg=-3):
    """A torn strip of paper (rough edges), laid across the page a little crooked."""
    r = random.Random(seed)
    w, h = x1 - x0, y1 - y0
    strip = Image.new("RGBA", (w + 80, h + 80), (0, 0, 0, 0))
    top = [(40 + k * w / 40, 40 + r.uniform(-7, 7)) for k in range(41)]
    bot = [(40 + k * w / 40, 40 + h + r.uniform(-7, 7)) for k in range(40, -1, -1)]
    ImageDraw.Draw(strip).polygon(top + bot, fill=color + (255,))
    strip = strip.rotate(deg, expand=True, resample=Image.BICUBIC)
    shadow(im, strip, (int(x0 - 40), int(y0 - 40)), 10, 6, 60)


def tape(im, cx, cy, deg=-8, color=(255, 255, 255)):
    t = Image.new("RGBA", (190, 62), color + (170,))
    t = t.rotate(deg, expand=True, resample=Image.BICUBIC)
    im.alpha_composite(t, (int(cx - t.width / 2), int(cy - t.height / 2)))


def circle_note(d, x, y, text, font, ink, acc):
    """A clean oval drawn around the words, sized so every letter sits inside it."""
    tw = d.textlength(text, font=font)
    bb = font.getbbox(text)
    th = bb[3] - bb[1]
    cx, cy = x + tw / 2, y + (bb[1] + bb[3]) / 2
    a = tw / 2 * 1.3 + 28
    b = th / 2 * 1.7 + 18
    d.ellipse((cx - a, cy - b, cx + a, cy + b), outline=acc + (255,), width=5)
    bounce_text(d, x, y, text, font, ink + (255,), amp=0.2)


def t1(mc, look, s, img, i, n, handle):
    _JIT[0] = True
    try:
        return _t1(mc, look, s, img, i, n, handle)
    finally:
        _JIT[0] = False


def _t1(mc, look, s, img, i, n, handle):
    paper, ink, acc = brand_cols(mc, look, 1)
    kind = s.get("kind", "point")
    im = Image.new("RGBA", (CW, CH), paper + (255,))
    grid_paper(im, paper)
    d = ImageDraw.Draw(im)
    script = lambda z: F(mc, HAND[0], z, HAND[1])
    stick = s.get("stickers", True)
    kraft = tuple(int(c * 0.82 + acc[k] * 0.18) for k, c in enumerate(paper))
    kraft = tuple(max(0, min(255, int(c * 0.9))) for c in kraft) if lum(paper) > 0.5 else tuple(min(255, c + 25) for c in kraft)
    if kind == "cover":
        # the headline sits on a torn paper strip, a little crooked
        f, ls = fit(mc, d, s["headline"], lambda z: script(z), 120, CW - 2 * M - 40, 3, 70)
        hh = len(ls) * int(f.size * 0.98) + 50
        torn_strip(im, kraft, 40, 60, CW - 40, 60 + hh, 3, -2)
        d = ImageDraw.Draw(im)
        y = 85
        for ln in ls:
            words_with_hi(d, M, y, ln, f, ink, s.get("hi"), hi_fill=acc)
            y += int(f.size * 0.98)
        top = 60 + hh + 60
        two = len(s.get("photos") or []) >= 2
        ph = 470 if two else 640
        if two:
            ps = photo_list(mc, s, img, 400, ph, 2)
            a_ = tilt(framed(rounded(ps[0], 30), 14), -2)
            b_ = tilt(framed(rounded(ps[1], 30), 14), 3)
            shadow(im, a_, (M - 30, top))
            shadow(im, b_, (CW - b_.width - M + 30, top + 90))
            mc.hand_arrow(d, M + 400, top + 250, CW - M - 360, top + 330, ink + (255,), 6)
            lb = script(70)
            bounce_text(d, M + 70, top + ph + 40, s.get("label_a") or "before", lb, ink)
            bounce_text(d, CW - M - 200, top + ph + 150, s.get("label_b") or "after", lb, ink)
        else:
            pic = photo_of(mc, s, img, 560, ph, 0.3)
            if pic is not None:
                fr = tilt(framed(pic, 18), -3)
                shadow(im, fr, (M, top))
                tape(im, M + 160, top + 20, -10)
                tape(im, M + fr.width - 120, top + 40, 8)
            if stick and pic is not None:
                mc.hand_arrow(d, CW - 220, top + 160, CW - 330, top + 330, ink + (255,), 6)
        if s.get("note"):
            circle_note(d, M + 60, CH - 190, s["note"], script(54), ink, acc)
    elif kind == "point":
        num = s.get("n") or ""
        if num:
            bounce_text(d, M, 90, str(num), script(200), acc)
        f, ls = fit(mc, d, s["headline"], lambda z: script(z), 118, CW - 2 * M - (180 if num else 0), 3)
        y = 120 if num else 110
        for ln in ls:
            words_with_hi(d, M + (170 if num else 0), y, ln, f, ink, s.get("hi"), hi_fill=acc)
            y += int(f.size * 0.98)
        y = max(y, 330)
        fb = F(mc, "Fredoka", 44, 600)
        yb = mc.text_block(d, M, y + 50, s.get("body", ""), fb, ink + (255,), CW - 2 * M - 40, lh=64)
        pic = photo_of(mc, s, img, 460, 460, 0.3) if s.get("photo") else None
        if pic is not None:
            fr = tilt(framed(pic, 16), 4)
            shadow(im, fr, (CW - fr.width - 50, CH - fr.height - 130))
            tape(im, CW - 50 - fr.width // 2, CH - fr.height - 120, -6)
        if s.get("note"):
            circle_note(d, M + 50, yb + 70, s["note"], script(44), ink, acc)
    else:  # cta: everything centered; the lead sits in the middle of the paper strip
        sy0, sy1 = 200, 420
        torn_strip(im, kraft, 40, sy0, CW - 40, sy1, 6, 2)
        d = ImageDraw.Draw(im)
        lf = script(110)
        lead = s.get("lead") or "want mine?"
        bb = lf.getbbox(lead)
        lw = d.textlength(lead, font=lf)
        bounce_text(d, (CW - lw) / 2, (sy0 + sy1) / 2 - (bb[1] + bb[3]) / 2 + 22, lead, lf, ink)
        kw = "COMMENT " + (s.get("keyword") or "WORD").upper()
        fk, _ = fit(mc, d, kw, lambda z: F(mc, "Fredoka", z, 700), 150, CW - 2 * M, 1, 50)
        kb = fk.getbbox(kw)
        ky = 560
        kx = (CW - d.textlength(kw, font=fk)) / 2
        d.text((kx, ky), kw, font=fk, fill=ink)
        uy = ky + kb[3] + 34
        d.line((kx, uy, kx + d.textlength(kw, font=fk), uy), fill=acc + (255,), width=10)
        lf2 = script(50)
        yy = uy + 90
        for ln in mc.wrap(d, s.get("line") or "and I'll send it to you", lf2, CW - 2 * M - 60):
            bounce_text(d, (CW - d.textlength(ln, font=lf2)) / 2, yy, ln, lf2, ink)
            yy += 72
        if stick:
            mc.hand_arrow(d, CW // 2 - 40, yy + 50, CW // 2 + 20, yy + 190, acc + (255,), 8)
    small_footer(mc, d, look, handle, i, n, ink, face="Fredoka")
    return im


# ---------------------------------------------------------------- 2 Numbered tips
def t2(mc, look, s, img, i, n, handle):
    _JIT[0] = True
    try:
        return _t2(mc, look, s, img, i, n, handle)
    finally:
        _JIT[0] = False


def hollow(d, x, y, text, font, line, inside, w=4):
    """Outlined letters: a colored line around clear (paper-colored) letters."""
    d.text((x, y), text, font=font, fill=line, stroke_width=w, stroke_fill=line)
    d.text((x, y), text, font=font, fill=inside)


def speech_bubble(im, x, y, w, h, fill, outline, tail_to=None):
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((x, y, x + w, y + h), radius=h // 2, fill=fill, outline=outline, width=5)
    tx = x + w * 0.22
    d.polygon([(tx, y + h - 3), (tx + 50, y + h - 3), (tx + 10, y + h + 55)], fill=fill)
    d.line((tx, y + h, tx + 10, y + h + 55, tx + 50, y + h), fill=outline, width=5, joint="curve")


def _t2(mc, look, s, img, i, n, handle):
    paper, ink, acc = brand_cols(mc, look, 2)
    kind = s.get("kind", "point")
    im = Image.new("RGBA", (CW, CH), paper + (255,))
    paper_texture(im, seed=2)
    d = ImageDraw.Draw(im)
    script = lambda z: F(mc, HAND[0], z, HAND[1])
    bold = lambda z, w=700: F(mc, "Fredoka", z, w)
    stick = s.get("stickers", True)
    hc = acc
    for k in range(1, 9):   # darken the accent until it is easy to read on the paper
        if mc.contrast(hc, paper) >= 3.0:
            break
        hc = tuple(int(acc[j] * (1 - 0.1 * k) + ink[j] * 0.1 * k) for j in range(3))
    if kind in ("cover", "point"):
        num = (s.get("n") or "") if "n" in s else ("" if kind == "cover" else "1")   # "n": false means no number on this slide
        if num:
            d.text((M, 70), str(num), font=bold(260), fill=acc)
        parts = s["headline"].split(" ", 1)
        colw = 500 if (kind == "point" or s.get("photo") or s.get("photos") or img is not None) else CW - 2 * M
        # first word bold, the rest in the thin handwriting
        f1, _ = fit(mc, d, parts[0].upper(), lambda z: bold(z), 120 if kind == "point" else 150, colw, 1, 50)
        y = 380 if num else 140
        d.text((M, y), parts[0].upper(), font=f1, fill=ink)
        y += int(f1.size * 1.15)
        if len(parts) > 1:
            f2, ls = fit(mc, d, parts[1], lambda z: bold(z, 600), 80, colw, 4, 44)
            for ln in ls:   # outlined letters: paper-colored inside, a clean dark line around
                if mc.fe.font_set():   # a picked look's heavier lettering stays clean as solid color, not outlined
                    d.text((M, y), ln, font=f2, fill=acc)
                else:
                    hollow(d, M, y, ln, f2, acc, paper)
                y += int(f2.size * 1.25)
        if s.get("note"):
            nf = script(44)
            bounce_text(d, M, y + 10, s["note"], nf, ink, amp=0.2)
            d.line((M, y + 70, M + d.textlength(s["note"], font=nf), y + 70), fill=acc + (255,), width=5)
            y += 100
        fb = bold(40, 600)
        mc.text_block(d, M, y + 30, s.get("body", ""), fb, ink + (255,), colw, lh=58)
        if kind == "cover":   # two sticker photos
            ps = photo_list(mc, s, img, 330, 460, 2)
            if len(ps) == 2:   # stacked: one sticker partly on top of the other
                st2 = tilt(wavy_sticker(ps[1], acc), -6)
                st1 = tilt(wavy_sticker(ps[0], acc), 5)
                x2 = CW - st2.width - 290
                shadow(im, st2, (x2, 650), 14, 10, 90)
                shadow(im, st1, (CW - st1.width - 60, 470), 14, 10, 90)
        else:
            pic = photo_of(mc, s, img, 330, 470, 0.3)
            if pic is not None:
                st = tilt(wavy_sticker(pic, acc), 4)
                shadow(im, st, (CW - st.width - 20, 480), 14, 10, 90)
        if stick:
            if kind == "point":   # three stars in the top corner
                for sx, sy, sr in ((CW - 200, 150, 30), (CW - 130, 110, 44), (CW - 90, 195, 26)):
                    star(d, sx, sy, sr, acc, 4, 0.4)
            else:
                star(d, CW - 150, 170, 44, acc, 4, 0.4)
                star(d, 150, CH - 230, 40, acc, 4, 0.4)   # one more, bottom left
    else:  # cta: a speech bubble, the comment word and a line, centered on the page
        lead = s.get("lead") or "want mine?"
        lf = bold(70, 600)
        lw = d.textlength(lead, font=lf)
        bw, bh = int(lw + 120), 150
        kw = "COMMENT " + (s.get("keyword") or "WORD").upper()
        fk, _ = fit(mc, d, kw, lambda z: bold(z, 700), 110, CW - 2 * M, 1, 48)
        lf2 = script(50)
        lines = mc.wrap(d, s.get("line") or "and I'll send it to you", lf2, CW - 2 * M - 60)
        k_h = int(fk.size * 1.2)
        block = bh + 55 + 70 + k_h + 30 + len(lines) * 70
        pic = photo_of(mc, s, img, 300, 400, 0.3)
        st = tilt(wavy_sticker(pic, acc), -4) if pic is not None else None
        by = (CH - 120 - block - (st.height + 30 if st is not None else 0)) // 2 + 20   # block and picture sit together, picture fully on the page
        bx = (CW - bw) // 2
        speech_bubble(im, bx, by, bw, bh, paper, ink)
        d = ImageDraw.Draw(im)
        bb = lf.getbbox(lead)
        d.text((bx + 60, by + bh / 2 - (bb[1] + bb[3]) / 2), lead, font=lf, fill=acc)
        yk = by + bh + 55 + 70
        d.text(((CW - d.textlength(kw, font=fk)) / 2, yk), kw, font=fk, fill=ink)
        yy = yk + k_h + 30
        for ln in lines:
            bounce_text(d, (CW - d.textlength(ln, font=lf2)) / 2, yy, ln, lf2, ink)
            yy += 70
        if st is not None:
            shadow(im, st, ((CW - st.width) // 2, min(yy + 30, CH - st.height - 110)), 14, 10, 90)
    if kind == "cta" and stick:
        for k, (sx, sy, sr) in enumerate(((M + 20, CH - 170, 26), (M + 110, CH - 190, 34), (M + 200, CH - 170, 26))):
            star(d, sx, sy, sr, acc, 4, 0.4)
    small_footer(mc, d, look, handle, i, n, ink, face="Fredoka")
    return im


# ---------------------------------------------------------------- 3 Bold editorial
SQUEEZE = 0.74   # makes the serif tall and narrow, like a condensed headline


def cond_len(d, text, font):
    return d.textlength(text, font=font) * SQUEEZE


def cond_text(d, x, y, text, font, fill):
    """Tall, narrow serif letters: drawn normally, then squeezed sideways."""
    im = d._image
    w = int(d.textlength(text, font=font)) + 20
    h = int(font.size * 1.6)
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(layer).text((0, 0), text, font=font, fill=tuple(fill[:3]) + (255,))
    layer = layer.resize((max(1, int(w * SQUEEZE)), h), Image.LANCZOS)
    im.alpha_composite(layer, (int(x), int(y)))
    return x + cond_len(d, text, font)


def cond_fit(mc, d, text, start, maxw, maxlines, floor=70):
    if SQUEEZE >= 1.0:   # her own (wider) font: fewer lines, so the words never push into the picture or note below
        maxlines = min(maxlines, 3)
    size = start
    while size > floor:
        f = F(mc, "Gloock", size, 400)
        lines, cur = [], ""
        for w in text.split():
            tt = (cur + " " + w).strip()
            if cond_len(d, tt, f) > maxw and cur:
                lines.append(cur)
                cur = w
            else:
                cur = tt
        if cur:
            lines.append(cur)
        if len(lines) <= maxlines and all(cond_len(d, l, f) <= maxw for l in lines):
            return f, lines
        size -= 6
    sz = floor
    while True:   # last resort: keep shrinking (and breaking a giant word) until it fits, so nothing runs off the slide
        f = F(mc, "Gloock", sz, 400)
        lines = mc.wrap(d, text, f, maxw / SQUEEZE)
        if (len(lines) <= max(maxlines, 6) and all(cond_len(d, l, f) <= maxw for l in lines)) or sz <= 30:
            return f, lines
        sz -= 6


def stamp(im, cx, cy, r, line, text, font, ink_text=None):
    """A round stamp, tilted a little, with fun red handwriting inside."""
    size = r * 2 + 40
    layer = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    c = size // 2
    ld.ellipse((c - r, c - r, c + r, c + r), outline=line, width=6)
    ld.ellipse((c - r + 12, c - r + 12, c + r - 12, c + r - 12), outline=line, width=2)
    words = [w_ for w_ in re.split(r"[\s_]+", text) if w_][:3] or [text]
    y = c - (len(words) * int(font.size * 1.05)) / 2
    for w_ in words:
        ld.text((c - ld.textlength(w_, font=font) / 2, y), w_, font=font, fill=ink_text or line)
        y += int(font.size * 1.05)
    layer = layer.rotate(10, resample=Image.BICUBIC)
    im.alpha_composite(layer, (int(cx - size / 2), int(cy - size / 2)))


def t3(mc, look, s, img, i, n, handle):
    _JIT[0] = True
    try:
        return _t3(mc, look, s, img, i, n, handle)
    finally:
        _JIT[0] = False


def _t3(mc, look, s, img, i, n, handle):
    paper, ink, acc = brand_cols(mc, look, 3)
    kind = s.get("kind", "point")
    # the cover and last slide use the brand paper color; the middle slides are a lighter, creamier version of it
    page = paper if kind in ("cover", "cta") else tuple(int(c * 0.35 + 255 * 0.65) for c in paper)
    im = Image.new("RGBA", (CW, CH), page + (255,))
    d = ImageDraw.Draw(im)
    script = lambda z: F(mc, "GochiHand-Regular", z, 400)   # fun, cursive-style lettering in the accent color
    bold = lambda z, w=700: F(mc, "Fredoka", z, w)
    is_brand = look.get("id") == "brand" or look.get("fromBrand")
    bar_col = (acc if mc.contrast(acc, page) < 6 else tuple(int(c * 0.5 + 255 * 0.5) for c in acc)) if is_brand else (250, 222, 110)
    hc = acc
    for k in range(1, 9):
        if mc.contrast(hc, page) >= 3.2:
            break
        hc = tuple(int(acc[j] * (1 - 0.1 * k) + ink[j] * 0.1 * k) for j in range(3))
    word = s.get("word") or (WORDS[int(s["n"]) - 1] if str(s.get("n", "")).isdigit() and 1 <= int(s["n"]) <= 10 else "")
    y = 80 if kind == "point" else 100
    if word:   # the small number pill
        pf = bold(34, 700)
        tw = d.textlength(word, font=pf)
        d.rounded_rectangle((M, y, M + tw + 56, y + 62), radius=31, fill=bar_col)
        d.text((M + 28, y + 12), word, font=pf, fill=ink)
        y += 82 if kind == "point" else 100
    head = s.get("headline") or ("Want mine?" if kind == "cta" else "")
    start = (190 if kind == "cover" else 230) if kind in ("cover", "cta") else 130
    f, ls = cond_fit(mc, d, head, start, CW - 2 * M - (60 if kind == "cover" else 0), 5)
    # highlighted words get a fat soft bar behind them, like a marker; a second phrase gets a second color
    raw = s.get("hi") or ""
    phrases = raw if isinstance(raw, list) else [p_.strip() for p_ in raw.split("|") if p_.strip()]
    bar2 = (214, 200, 245) if not is_brand else tuple(int(c * 0.45 + 255 * 0.55) for c in ink)
    bar_cols = [bar_col, bar2]
    plain = lambda w_: w_.strip(" ,.?!'\"").lower()
    hi_map = {}
    for pi, ph_ in enumerate(phrases):
        for w_ in ph_.split():
            hi_map[plain(w_)] = pi % 2
    lh = int(f.size * (1.06 if phrases else 0.95))
    box = f.getbbox("Hg")
    for ln in ls:
        x = M
        toks = re.split(r"(\s+)", ln)
        for ti, part in enumerate(toks):
            pw = cond_len(d, part, f)
            key = plain(part)
            if part.strip() and key in hi_map:
                x_end = x + pw
                # carry the bar across the space to the next highlighted word of the same phrase
                if ti + 2 < len(toks) and plain(toks[ti + 2]) in hi_map and hi_map[plain(toks[ti + 2])] == hi_map[key]:
                    x_end += cond_len(d, toks[ti + 1], f)
                d.rounded_rectangle((x - 12, y + box[1] + (box[3] - box[1]) * 0.30, x_end + 12, y + box[3] + 2), radius=12, fill=bar_cols[hi_map[key]])
            cond_text(d, x, y, part, f, ink)
            x += pw
        y += lh
    if kind == "cover":
        top = y + 40   # the photo sits below the headline, never over it
        ph = max(200, min(440, CH - 150 - top - 30))
        pic = photo_of(mc, s, img, int(ph * 0.82), int(ph), 0.3)
        if pic is not None:
            fr = tilt(framed(pic, 12, (255, 255, 255), 24), -3)
            shadow(im, fr, (CW - fr.width - 70, top), 12, 8, 80)
        if s.get("note"):
            nf = script(66)
            yy = CH - 450
            for ln in mc.wrap(d, s["note"], nf, 420):
                bounce_text(d, M, yy, ln, nf, hc)
                yy += 78
    elif kind == "point":
        y += 40
        pic = photo_of(mc, s, img, CW - 2 * M, 470, 0.3) if (s.get("photo") or img is not None) and y < 560 else None
        if pic is not None:   # the photo lines up with the text on both sides
            shadow(im, rounded(pic, 28), (M, y), 12, 8, 70)
            y += 470 + 50
        fb = bold(40, 600)
        y = mc.text_block(d, M, y, s.get("body", ""), fb, ink + (255,), CW - 2 * M, lh=58)
        if s.get("note"):
            bounce_text(d, M, y + 36, s["note"], script(60), hc)
    else:
        kw = "COMMENT " + (s.get("keyword") or "WORD").upper()
        fk, _ = fit(mc, d, kw, lambda z: bold(z, 700), 100, CW - 2 * M, 1, 44)
        d.text((M, y + 60), kw, font=fk, fill=ink)
        lf2 = script(60)
        yy = y + 60 + int(fk.size * 1.3)
        for ln in mc.wrap(d, s.get("line") or "and I'll send it to you", lf2, CW - 2 * M):
            bounce_text(d, M, yy, ln, lf2, hc)
            yy += 76
    if s.get("stamp", True) and kind in ("cover", "cta"):
        stamp(im, CW - 165, 150 if kind == "cover" else CH - 330, 92, ink, s.get("stamp") if isinstance(s.get("stamp"), str) else ((handle or "").lstrip("@") or "stamp"), script(30), ink_text=ink)
        d = ImageDraw.Draw(im)
    small_footer(mc, d, look, handle, i, n, ink, face="Fredoka")
    return im


# ---------------------------------------------------------------- 4 Photo statement
def veil(im, alpha=0.55):
    im.alpha_composite(Image.new("RGBA", im.size, (8, 8, 10, int(255 * alpha))))


def brush_stroke(d, x0, x1, y, color, width=14, seed=5):
    """A hand-brushed underline: a thick, slightly uneven stroke."""
    r = random.Random(seed)
    pts = [(x0 + (x1 - x0) * k / 30, y + math.sin(k * 0.7) * 5 + r.uniform(-3, 3)) for k in range(31)]
    d.line(pts, fill=color, width=width, joint="curve")
    d.line([(px, py + 9) for px, py in pts[3:-3]], fill=color, width=max(4, width // 3), joint="curve")


def t4(mc, look, s, img, i, n, handle):
    paper, ink, acc = brand_cols(mc, look, 4)
    kind = s.get("kind", "point")
    white = (255, 255, 255, 255)
    serif = lambda z: F(mc, "InstrumentSerif", z, 400)
    bold = lambda z: F(mc, "ArchivoBlack", z, 400)   # heavy, solid giant words (her pick)

    def center_in(d, cy, text, font, fill, lh=1.12, maxw=CW - 2 * M):
        """Words centered both ways around the height cy."""
        lines = mc.wrap(d, text, font, maxw)
        h = int(font.size * lh) * len(lines)
        y = cy - h / 2
        for ln in lines:
            d.text(((CW - d.textlength(ln, font=font)) / 2, y), ln, font=font, fill=fill, stroke_width=2, stroke_fill=(0, 0, 0, 255))
            y += int(font.size * lh)

    def giant(d, y, word, size=300, mid=None):
        """The giant word. With mid, its letters are centered on that height; returns the font, width and bottom edge."""
        fk, _ = fit(mc, d, word, lambda z: bold(z), size, CW - 2 * M, 1, 80)
        wd = d.textlength(word, font=fk)
        bb = fk.getbbox(word)
        if mid is not None:
            y = mid - (bb[1] + bb[3]) / 2
        d.text(((CW - wd) / 2, y), word, font=fk, fill=acc + (255,), stroke_width=3, stroke_fill=(0, 0, 0, 255))
        return fk, wd, y + bb[3]

    if kind != "cta":   # every page but the last: one photo on top, one on the bottom, a statement centered in each
        ps = photo_list(mc, s, img, CW, CH // 2, 2)
        im = Image.new("RGBA", (CW, CH), (10, 10, 12, 255))
        for k, p_ in enumerate(ps):
            im.alpha_composite(p_, (0, k * CH // 2))
        veil(im, 0.55)
        for cy_ in (CH // 4, 3 * CH // 4):   # a soft dark band behind each statement so busy photos never fight the words
            band = Image.new("RGBA", (CW, 300), (0, 0, 0, 0))
            bd_ = ImageDraw.Draw(band)
            for yy_ in range(300):
                bd_.line((0, yy_, CW, yy_), fill=(8, 8, 10, int(110 * (1 - abs(yy_ - 150) / 150))))
            im.alpha_composite(band, (0, cy_ - 150))
        d = ImageDraw.Draw(im)
        top = s.get("top") or s.get("headline") or ""
        bottom = s.get("bottom") or s.get("body") or ""
        size = 70 if kind == "cover" else 66
        center_in(d, CH // 4, top, serif(size), white)
        center_in(d, 3 * CH // 4, bottom, serif(size), white)
        word = (s.get("keyword") or s.get("hi") or _key_word(top + " " + bottom)).upper()
        fk, wd, bot = giant(d, 0, word, 260, mid=CH // 2)
        if kind == "cover":   # a straight line under the giant word
            uy = bot + 22
            d.rounded_rectangle(((CW - wd) / 2, uy, (CW + wd) / 2, uy + 12), radius=6, fill=white)
        small_footer(mc, d, look, handle, i, n, white, face="Fredoka")
        return im
    pic = photo_of(mc, s, img, CW, CH, 0.5)
    im = pic if pic is not None else Image.new("RGBA", (CW, CH), (30, 30, 34, 255))
    veil(im, 0.55)
    d = ImageDraw.Draw(im)
    heights = []
    y = 440   # centered on the page
    for part in ("COMMENT", (s.get("keyword") or "WORD").upper()):
        fk, wd, bot = giant(d, y, part, 170 if part == "COMMENT" else 230)
        y = bot + 30
    center_in(d, y + 60, s.get("line") or "and I'll send it to you", serif(64), white)
    small_footer(mc, d, look, handle, i, n, white, face="Fredoka")
    return im


# ---------------------------------------------------------------- 5 Warm flat color
def t5(mc, look, s, img, i, n, handle):
    _JIT[0] = True
    try:
        return _t5(mc, look, s, img, i, n, handle)
    finally:
        _JIT[0] = False


def _t5(mc, look, s, img, i, n, handle):
    paper, ink, acc = brand_cols(mc, look, 5)
    kind = s.get("kind", "point")
    im = Image.new("RGBA", (CW, CH), paper + (255,))
    d = ImageDraw.Draw(im)
    script = lambda z: F(mc, "GochiHand-Regular", z, 400)
    bold = lambda z, w=700: F(mc, "Fredoka", z, w)
    if look.get("id") == "brand" or look.get("fromBrand"):
        cols = [mc.fe.hex2rgb(look[k]["bg"])[:3] for k in ("hook", "accent", "caption", "highlight")]
    else:
        cols = [(190, 205, 250), (82, 20, 40), (186, 140, 120)]
    circ = [c for c in cols if c != tuple(paper)][:3] or [ink]

    def head(text, y, start=170, maxlines=4):
        f, ls = cond_fit(mc, d, text, start, CW - 2 * M, maxlines)
        for ln in ls:
            cond_text(d, (CW - cond_len(d, ln, f)) / 2, y, ln, f, ink)
            y += int(f.size * 0.98)
        return y

    if kind in ("cover", "row"):
        y = 110
        text = s["headline"]
        if s.get("pov", True) and kind == "cover":
            text = "POV: " + text
        y = head(text, y, 150, 4)
        pics = photo_list(mc, s, img, 300, 400, 3)
        base = max(y + 50, 600)
        for k, p_ in enumerate(pics):
            x = M - 10 + k * 330
            shadow(im, rounded(p_, 14), (x, base), 8, 6, 50)
            c = circ[k % len(circ)]
            d.ellipse((x + 70, base + 430, x + 230, base + 590), fill=c)   # brand color dots under each photo
    elif kind == "grid":
        # a feed grid made only from pictures she gave (never invented)
        y = head(s.get("headline") or "your feed after two weeks", 110, 120, 2)
        ps = photo_list(mc, s, img, 300, 300, 9) if (s.get("photos") or img is not None) else []
        top = y + 40
        cell = 276
        x0 = (CW - (3 * cell + 12)) // 2
        for k, p_ in enumerate(ps[:9]):
            im.alpha_composite(p_.resize((cell, cell)), (x0 + (k % 3) * (cell + 6), top + (k // 3) * (cell + 6)))
    elif kind == "comment":
        # real comments only: if she has none, this slide is left out
        y = head(s.get("headline") or "the comments...", 110, 120, 2)
        cs = [c for c in (s.get("comments") or []) if c][:3]
        fb = bold(40, 600)
        yb = y + 50
        for k, c in enumerate(cs):
            lines = mc.wrap(d, c, fb, CW - 2 * M - 120)
            h = len(lines) * 56 + 80
            bub = Image.new("RGBA", (CW - 2 * M, h), (0, 0, 0, 0))
            bd = ImageDraw.Draw(bub)
            bd.rounded_rectangle((0, 0, bub.width - 1, h - 1), radius=26, fill=(255, 255, 255, 255))
            bd.text((30, 22), s.get("names", ["@name"] * 3)[k] if s.get("names") else "@name", font=bold(30, 700), fill=(40, 40, 44, 255))
            for j, ln in enumerate(lines):
                bd.text((30, 62 + j * 56), ln, font=fb, fill=(30, 30, 34, 255))
            bub = tilt(bub, [-3, 2, -2][k % 3])
            shadow(im, bub, (M - 20, yb), 8, 6, 60)
            yb += h + 36
        if s.get("lead"):
            ls = mc.wrap(d, s["lead"], script(54), CW - 2 * M)
            yy = max(yb + 40, CH - 330)
            for ln in ls:
                bounce_text(d, (CW - d.textlength(ln, font=script(54))) / 2, yy, ln, script(54), acc)
                yy += 70
    elif kind == "cta":
        lead = s.get("lead") or "want mine?"
        kw = "COMMENT " + (s.get("keyword") or "WORD").upper()
        fk, _ = fit(mc, d, kw, lambda z: bold(z, 700), 110, CW - 2 * M, 1, 44)
        lf = script(60)
        lines = mc.wrap(d, s.get("line") or "and I'll send it to you", lf, CW - 2 * M)
        block = 150 + int(fk.size * 1.3) + len(lines) * 76
        y = (CH - block) // 2
        bounce_text(d, (CW - d.textlength(lead, font=script(100))) / 2, y, lead, script(100), acc)
        y += 150
        d.text(((CW - d.textlength(kw, font=fk)) / 2, y), kw, font=fk, fill=ink)
        y += int(fk.size * 1.3)
        for ln in lines:
            bounce_text(d, (CW - d.textlength(ln, font=lf)) / 2, y, ln, lf, acc)
            y += 76
    else:  # point
        has_pic = bool(s.get("photo") and os.path.exists(s["photo"])) or img is not None
        y0_ = 110
        if not has_pic and not s.get("body"):   # words alone: sit them in the middle of the page, not stuck at the top
            _f, _ls = cond_fit(mc, d, s["headline"], 130, CW - 2 * M, 4)
            y0_ = max(110, (CH - len(_ls) * int(_f.size * 0.98)) // 2 - 60)
        y = head(s["headline"], y0_, 130 if not has_pic else 104, 3 if has_pic else 4)
        fb = bold(42, 600)
        y = mc.text_block(d, M, y + 40, s.get("body", ""), fb, ink + (255,), CW - 2 * M, lh=60)
        if has_pic:   # a picture fills the space under the words
            ph_ = max(240, min(620, CH - 150 - (int(y) + 40)))
            pic = photo_of(mc, s, img, CW - 2 * M, ph_, 0.3)
            if pic is not None:
                shadow(im, rounded(pic, 30), (M, int(y) + 40), 12, 8, 60)
    if handle:
        hf = F(mc, "Fredoka", 30, 400)
        d.text(((CW - d.textlength(handle, font=hf)) / 2, CH - 100), handle, font=hf, fill=ink + (255,))
    return im


# ---------------------------------------------------------------- 6 Photo story
def t6(mc, look, s, img, i, n, handle):
    paper, ink, acc = brand_cols(mc, look, 6)
    kind = s.get("kind", "point")
    white = (255, 255, 255, 255)
    pic = photo_of(mc, s, img, CW, CH, 0.3)
    im = pic if pic is not None else Image.new("RGBA", (CW, CH), (28, 28, 30, 255))
    im.alpha_composite(mc.fe.gradient(CW, int(CH * 0.7), (8, 8, 8), 215, from_top=False), (0, CH - int(CH * 0.7)))
    if kind in ("cover", "point", "bigword"):
        veil(im, 0.28)   # a little more dark layer so the words stand out
    d = ImageDraw.Draw(im)
    script = lambda z: F(mc, "GochiHand-Regular", z, 400)   # the fun cursive lettering (her pick)
    serif = lambda z: disp(mc, look, z)
    ital = lambda z: F(mc, "GochiHand-Regular", z, 400)   # accent words use the cursive lettering too
    # a tiny sparkle in the top corner
    star(d, CW - 120, 130, 30, white, 4, 0.3)
    if kind == "bigword":
        kw = s.get("keyword") or s.get("hi") or "yes"
        fk, _ = fit(mc, d, kw, lambda z: ital(z), 330, CW - 2 * M, 1, 120)
        y = CH - 780
        d.text((M, y + 30), kw, font=fk, fill=acc + (255,))
        f, ls = fit(mc, d, s.get("headline", ""), lambda z: F(mc, look["captionFont"], z, 600), 52, CW - 2 * M, 3, 36)
        y += int(fk.size * 1.0)
        for ln in ls:
            d.text((M, y), ln, font=f, fill=white)
            y += int(f.size * 1.3)
    elif kind == "cta":
        d.text((M, CH - 640 + 28), s.get("lead") or "and honestly?", font=script(70), fill=acc + (255,))
        kw = "COMMENT " + (s.get("keyword") or "WORD").upper()
        fk, _ = fit(mc, d, kw, lambda z: serif(z), 150, CW - 2 * M, 1, 60)
        d.text((M, CH - 560), kw, font=fk, fill=white)
        d.text((M, CH - 560 + int(fk.size * 1.2)), s.get("line") or "and I'll send it to you", font=ital(54), fill=white)
    else:
        sizebase = 96 if kind == "cover" else 76
        f, ls = fit(mc, d, s["headline"], serif, sizebase, CW - 2 * M, 4, 48)
        body = s.get("body", "")
        fb = F(mc, look["captionFont"], 40, 500)
        body_lines = mc.wrap(d, body, fb, CW - 2 * M) if body else []
        total = (80 if s.get("lead") else 0) + len(ls) * int(f.size * 1.12) + (len(body_lines) * 56 + 30 if body else 0)
        y = CH - 170 - total
        if s.get("lead"):
            d.text((M, y + 26), s["lead"], font=script(64), fill=acc + (255,))
            y += 80
        hi = (s.get("hi") or "").strip(" ,.?!").lower()
        for ln in ls:
            x = M
            for part in re.split(r"(\s+)", ln):
                if hi and part.strip(" ,.?!'\"").lower() == hi:
                    fi = ital(int(f.size * 1.05))
                    d.text((x, y + 24), part, font=fi, fill=acc + (255,))
                    x += d.textlength(part, font=fi)
                else:
                    d.text((x, y), part, font=f, fill=white)
                    x += d.textlength(part, font=f)
            y += int(f.size * 1.12)
        y += 30
        for ln in body_lines:
            d.text((M, y), ln, font=fb, fill=(255, 255, 255, 225))
            y += 56
    small_footer(mc, d, look, handle, i, n, white, face="Fredoka")
    return im


# ---------------------------------------------------------------- 7 Notebook caps
def t7(mc, look, s, img, i, n, handle):
    paper, ink, acc = brand_cols(mc, look, 1)
    kind = s.get("kind", "point")
    import colorsys
    r_, g_, b_ = [c / 255 for c in acc]
    hh, ll, ss = colorsys.rgb_to_hls(r_, g_, b_)
    bright = tuple(int(c * 255) for c in colorsys.hls_to_rgb(hh, max(ll, 0.62), max(ss, 0.85))) + (255,)   # the bright, distinct word color
    white = (255, 255, 255, 255)
    script = lambda z: F(mc, "InstrumentSerif-Italic", z, 400)   # thin elegant italic (her pick)   # the fun cursive lettering (her pick)
    stick = s.get("stickers", True)
    edge = (20, 20, 20, 170)
    def hi_word(im, d, text, cx, top, maxw, start):
        """The big italic word, in whichever bright color contrasts most with the picture right behind it."""
        fi, _ = fit(mc, d, text, lambda z: script(z), start, maxw, 1, 80)
        tw = int(d.textlength(text, font=fi))
        x = int(cx - tw / 2)
        box = im.crop((max(0, x), max(0, top), min(CW, x + tw), min(CH, top + fi.size))).convert("RGB").resize((1, 1), Image.BOX).getpixel((0, 0))
        def rl(c):
            v = [(u / 255) / 12.92 if u / 255 <= 0.04045 else (((u / 255) + 0.055) / 1.055) ** 2.4 for u in c[:3]]
            return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2]
        def ratio(c):
            hi_, lo_ = max(rl(c), rl(box)), min(rl(c), rl(box))
            return (hi_ + 0.05) / (lo_ + 0.05)
        pool = [bright, (255, 226, 110, 255), (255, 255, 255, 255)]
        pick = next((c for c in pool[:2] if ratio(c) >= 4.5), None) or max(pool + [(25, 25, 28, 255)], key=ratio)
        d.text((x + 3, top + 3), text, font=fi, fill=(0, 0, 0, 110))
        d.text((x, top), text, font=fi, fill=pick)
        return fi

    if kind == "cover":   # the cover: the photo fills the whole page
        pic = photo_of(mc, s, img, CW, CH, 0.3)
        im = pic if pic is not None else Image.new("RGBA", (CW, CH), (28, 28, 30, 255))
        veil(im, 0.38)
        d = ImageDraw.Draw(im)
        hw = CW - 2 * M - (110 if stick else 0)
        f, ls = fit(mc, d, (s.get("headline") or "WANT MINE?").upper(), lambda z: F(mc, "ArchivoBlack", z, 400), 92, hw, 3, 44)
        hi_top = CH // 2 - 60
        fi = None
        if s.get("hi"):
            fi, _ = fit(mc, d, s["hi"], lambda z: script(z), 210, CW - 2 * M, 1, 80)
            hi_top = CH // 2 - fi.size // 2
        y = hi_top - len(ls) * int(f.size * 1.16) + 60   # the headline sits right on top of the script word, as one block
        y0 = y
        for ln in ls:
            d.text((M, y), ln, font=f, fill=white, stroke_width=2, stroke_fill=edge)
            y += int(f.size * 1.16)
        if stick:
            ax, ay = CW - M - 70, y0 + int(f.size * 0.55)
            mc.hand_arrow(d, ax, ay, ax + 70, ay, bright, 9)
        if fi:
            hi_word(im, d, s["hi"], CW / 2, hi_top, CW - 2 * M, 210)
        small_footer(mc, d, look, handle, i, n, white[:3], face="Fredoka")
        return im
    im = Image.new("RGBA", (CW, CH), paper + (255,))
    d = ImageDraw.Draw(im)
    if kind == "point":   # later slides: headline, a framed photo with her words on it, a little note at the bottom
        hw = CW - 2 * M - (110 if stick else 0)
        f, ls = fit(mc, d, (s.get("headline") or "WANT MINE?").upper(), lambda z: F(mc, "ArchivoBlack", z, 400), 64, hw, 2, 40)
        y = 96
        for ln in ls:
            d.text((M, y), ln, font=f, fill=ink)
            y += int(f.size * 1.18)
        if stick:
            ax, ay = CW - M - 70, 96 + int(f.size * 0.55)
            mc.hand_arrow(d, ax, ay, ax + 70, ay, bright, 8)
        top = y + 36
        body = s.get("body")
        bf = F(mc, look["captionFont"], 38, 700)
        blines = mc.wrap(d, body, bf, CW - 2 * M - 80) if body else []
        bh = len(blines) * 52 + 56 if body else 0
        h = CH - 150 - top - (bh + 40 if body else 40)
        pic = photo_of(mc, s, img, CW - 2 * M, h, 0.3)
        if pic is not None:
            fr = rounded(pic, 18)
            shadow(im, fr, (M, top), 12, 8, 60)
            if s.get("hi"):
                hi_word(im, d, s["hi"], CW / 2, top + h // 2 - 70, CW - 2 * M - 60, 160)
        if body:   # the note is blocked in, like the comment word on the last slide
            by = top + h + 36
            d.rectangle((M, by, CW - M, by + bh), fill=bright)
            tc = (255, 255, 255, 255) if lum(bright[:3]) < 0.6 else (25, 25, 28, 255)
            yy = by + 28
            for ln in blines:
                d.text(((CW - d.textlength(ln, font=bf)) / 2, yy), ln, font=bf, fill=tc)
                yy += 52
    else:   # cta: her comment word in a bright box, centered
        kw = (s.get("keyword") or "WORD").upper()
        lf = F(mc, look["captionFont"], 56, 800)
        lab = "Comment: " + kw
        tw = d.textlength(lab, font=lf)
        lf2 = script(54)
        lines = mc.wrap(d, s.get("line") or "and I'll send it to you", lf2, CW - 2 * M)
        block = 110 + 50 + len(lines) * 72
        y0 = (CH - block) // 2
        d.rectangle(((CW - tw - 90) / 2, y0, (CW + tw + 90) / 2, y0 + 110), fill=bright)
        d.text(((CW - tw) / 2, y0 + 20), lab, font=lf, fill=(255, 255, 255, 255) if lum(bright[:3]) < 0.6 else (25, 25, 28, 255))
        yy = y0 + 128
        for ln in lines:
            d.text(((CW - d.textlength(ln, font=lf2)) / 2, yy), ln, font=lf2, fill=ink)
            yy += 72
    small_footer(mc, d, look, handle, i, n, ink, face="Fredoka")
    return im


# ---------------------------------------------------------------- 8 Face and contrast
def t8(mc, look, s, img, i, n, handle):
    paper, ink, acc = brand_cols(mc, look, 6)
    kind = s.get("kind", "point")
    white = (255, 255, 255, 255)
    pic = photo_of(mc, s, img, CW, CH, 0.25)
    im = pic if pic is not None else Image.new("RGBA", (CW, CH), (28, 28, 30, 255))
    veil(im, 0.62 if kind == "split2" else 0.52)
    d = ImageDraw.Draw(im)
    sans = lambda z: disp(mc, look, z)
    ital = lambda z: F(mc, "InstrumentSerif-Italic", z, 400)   # accent words: the same thin italic as Template 7 (her pick)
    lead_f = F(mc, look["captionFont"], 34, 600)

    def lead(y, text):
        text = text.upper()
        x = (CW - sum(d.textlength(c, font=lead_f) + 5 for c in text)) / 2
        for c in text:
            d.text((x, y), c, font=lead_f, fill=acc + (255,))
            x += d.textlength(c, font=lead_f) + 5

    def centered(y, text, f, fill, lh=1.12, bold=False):
        for ln in mc.wrap(d, text, f, CW - 2 * M):
            d.text(((CW - d.textlength(ln, font=f)) / 2, y), ln, font=f, fill=fill, stroke_width=0)
            y += int(f.size * lh)
        return y

    if kind == "split2":
        d.line((CW // 2, 140, CW // 2, CH - 260), fill=(255, 255, 255, 90), width=3)
        hf = sans(66)
        for k, (title, items) in enumerate(((s.get("left_title") or "THE OLD WAY", s.get("left") or []), (s.get("right_title") or "THE NEW WAY", s.get("right") or []))):
            x0, w = (M - 40 if k == 0 else CW // 2 + 40), CW // 2 - M
            y = 150
            for ln in mc.wrap(d, title.upper(), hf, w):
                d.text((x0, y), ln, font=hf, fill=white)
                y += 66
            y += 40
            bf = F(mc, look["captionFont"], 40, 500)
            for it in items[:6]:
                for j, ln in enumerate(mc.wrap(d, it, bf, w - 30)):
                    if j == 0:
                        d.ellipse((x0, y + 14, x0 + 10, y + 24), fill=white)
                    d.text((x0 + 26, y), ln, font=bf, fill=(255, 255, 255, 235))
                    y += 54
                y += 20
        if s.get("footer"):
            f, ls = fit(mc, d, s["footer"].upper(), lambda z: F(mc, look["captionFont"], z, 700), 46, CW - 2 * M, 2, 30)
            y = CH - 250
            for ln in ls:
                d.text(((CW - d.textlength(ln, font=f)) / 2, y), ln, font=f, fill=acc + (255,))
                y += int(f.size * 1.2)
    elif kind == "cover":
        if s.get("lead"):
            lead(250, s["lead"])
        f, ls = fit(mc, d, s["headline"].upper(), lambda z: sans(z), 120, CW - 2 * M, 3, 60)
        y = 290
        for ln in ls:
            d.text(((CW - d.textlength(ln, font=f)) / 2, y), ln, font=f, fill=white)
            y += int(f.size * 1.05)
        if s.get("hi"):
            fi, _ = fit(mc, d, s["hi"], lambda z: ital(z), 200, CW - 2 * M, 1, 80)
            y = centered(y - 20, s["hi"], fi, acc + (255,), 0.95, True)
        if s.get("body"):
            centered(CH - 330, s["body"], F(mc, look["captionFont"], 46, 500), white)
    elif kind == "proof":
        f, ls = fit(mc, d, s["headline"].upper(), lambda z: sans(z), 80, CW - 2 * M, 3, 48)
        y = 200
        for ln in ls:
            d.text(((CW - d.textlength(ln, font=f)) / 2, y), ln, font=f, fill=white)
            y += int(f.size * 1.1)
        if s.get("body"):
            y = centered(y + 20, s["body"], F(mc, look["captionFont"], 40, 500), (255, 255, 255, 235), 1.3)
        sp = s.get("proof_image")
        if sp and os.path.exists(sp):  # a REAL screenshot she gave us; nothing is drawn without one
            card = Image.open(sp).convert("RGBA")
            k = min(560 / card.width, 380 / card.height)
            card = rounded(card.resize((int(card.width * k), int(card.height * k))), 24)
            shadow(im, card, ((CW - card.width) // 2, y + 40), 14, 10, 110)
        if s.get("lead"):
            centered(CH - 330, s["lead"], ital(72), acc + (255,), 1.12, True)
    elif kind == "cta":
        kw = s.get("keyword") or "WORD"
        f, _ = fit(mc, d, f"Comment {kw}", lambda z: ital(z), 150, CW - 2 * M, 1, 80)
        ln_f = ital(84)
        n_line = len(mc.wrap(d, s.get("line") or "to get it", ln_f, CW - 2 * M))
        total = (60 if s.get("lead") else 0) + int(f.size * 1.05) + 10 + int(84 * 1.1) * n_line
        y = (CH - total) // 2   # the whole block sits in the middle of the page
        if s.get("lead"):
            lead(y, s["lead"])
            y += 60
        yc = centered(y, f"Comment {kw}", f, white, 1.05, True)
        centered(yc, s.get("line") or "to get it", ln_f, white, 1.1, True)
    else:  # point
        if s.get("lead"):
            lead(260, s["lead"])
        f, ls = fit(mc, d, s["headline"].upper(), lambda z: sans(z), 96, CW - 2 * M, 4, 52)
        y = 340
        for ln in ls:
            x = M
            d.text(((CW - d.textlength(ln, font=f)) / 2, y), ln, font=f, fill=white)
            y += int(f.size * 1.08)
        if s.get("hi"):
            y = centered(y + 6, s["hi"], ital(150), acc + (255,), 1.0)
        if s.get("body"):
            centered(y + 30, s["body"], F(mc, look["captionFont"], 42, 500), (255, 255, 255, 235), 1.3)
    small_footer(mc, d, look, handle, i, n, white, face="Fredoka")
    return im


# ---------------------------------------------------------------- extra middle slides: "list" and "quote"
# Looks 1, 2, 3 and 7 had one middle layout, so a long carousel repeated itself. These two add variety in the same style.
#   list  : a title and up to 5 short lines (fields: headline, items)
#   quote : one big statement (fields: headline, who, hi)
EXTRA_KINDS = ("list", "quote", "stat", "photo")


def _extra(mc, look, s, img, i, n, handle, tid):
    paper, ink, acc = brand_cols(mc, look, 1 if tid == 7 else tid)
    kind = s.get("kind")
    if tid == 3:
        paper = tuple(int(c * 0.35 + 255 * 0.65) for c in paper)   # the lighter paper of the middle slides
    im = Image.new("RGBA", (CW, CH), paper + (255,))
    if tid == 1:
        grid_paper(im, paper)
    elif tid in (2, 3):
        paper_texture(im, seed=tid)
    d = ImageDraw.Draw(im)
    items = [str(x) for x in (s.get("items") or []) if str(x).strip()][:5]
    head = s.get("headline") or ""
    who = s.get("who") or ""
    hand = lambda z: F(mc, HAND[0], z, HAND[1])
    bold = lambda z, w=700: F(mc, "Fredoka", z, w)
    hc = acc
    for k in range(1, 9):
        if mc.contrast(hc, paper) >= 3.0:
            break
        hc = tuple(int(acc[j] * (1 - 0.1 * k) + ink[j] * 0.1 * k) for j in range(3))
    W = CW - 2 * M
    if tid == 7:
        import colorsys
        h_, l_, s_ = colorsys.rgb_to_hls(*[c / 255 for c in acc])
        bright = tuple(int(c * 255) for c in colorsys.hls_to_rgb(h_, max(l_, 0.62), max(s_, 0.85)))
        onb = (255, 255, 255) if lum(bright) < 0.6 else (25, 25, 28)
        ital = lambda z: F(mc, "InstrumentSerif-Italic", z, 400)
    if kind == "photo":   # a big picture with a short caption under it
        pic = photo_of(mc, s, img, W - (40 if tid == 1 else 0), 800, 0.3)
        if pic is None:   # no real picture: say it as a quote instead (never an invented picture)
            return _extra(mc, look, dict(s, kind="quote"), img, i, n, handle, tid)
        if tid == 1:
            fr = tilt(framed(pic, 16), -2)
            shadow(im, fr, ((CW - fr.width) // 2, 120))
            tape(im, CW // 2, 128, 6)
            cy = 120 + fr.height + 50
        elif tid == 2:
            st_ = tilt(wavy_sticker(pic, acc), 2)
            shadow(im, st_, ((CW - st_.width) // 2, 100), 14, 10, 90)
            cy = 100 + st_.height + 40
        elif tid == 3:
            shadow(im, rounded(pic, 28), (M, 120), 12, 8, 70)
            cy = 120 + pic.height + 60
        else:
            fr = rounded(pic, 18)
            shadow(im, fr, (M, 120), 12, 8, 60)
            cy = 120 + pic.height + 60
        if tid == 1:
            f, ls = fit(mc, d, head, lambda z: hand(z), 70, W, 2, 44)
            for ln in ls:
                d.text(((CW - d.textlength(ln, font=f)) / 2, cy), ln, font=f, fill=ink)
                cy += int(f.size * 1.05)
        elif tid == 2:
            f, ls = fit(mc, d, head, lambda z: bold(z, 700), 64, W, 2, 36)
            for ln in ls:
                d.text((M, cy), ln, font=f, fill=ink)
                cy += int(f.size * 1.2)
        elif tid == 3:
            f, ls = cond_fit(mc, d, head, 100, W, 2)
            for ln in ls:
                cond_text(d, M, cy, ln, f, ink)
                cy += int(f.size * 1.0)
        else:
            f, ls = fit(mc, d, head.upper(), lambda z: F(mc, "ArchivoBlack", z, 400), 54, W, 2, 34)
            for ln in ls:
                d.text((M, cy), ln, font=f, fill=ink)
                cy += int(f.size * 1.2)
    elif kind == "stat":   # one big number and what it means (use only a real number)
        numtxt = head or "73%"
        y = 220
        if tid == 1:
            nf, _ = fit(mc, d, numtxt, lambda z: hand(z), 440, W, 1, 160)
            d.text((M, y), numtxt, font=nf, fill=hc)
            uw = d.textlength(numtxt, font=nf)
            d.line((M, y + int(nf.size * 1.02), M + uw, y + int(nf.size * 1.0)), fill=ink + (255,), width=8)
            y += int(nf.size * 1.25)
        elif tid == 2:
            nf, _ = fit(mc, d, numtxt, lambda z: bold(z, 700), 400, W, 1, 160)
            d.text((M, y - 40), numtxt, font=nf, fill=acc)
            y += int(nf.size * 1.1)
            if s.get("stickers", True):
                star(d, CW - 150, 170, 44, acc, 4, 0.4)
        elif tid == 3:
            nf, ls_ = cond_fit(mc, d, numtxt, 460, W, 1)
            tw_ = cond_len(d, ls_[0], nf)
            bb_ = nf.getbbox("Hg")
            d.rounded_rectangle((M - 14, y + bb_[1] + (bb_[3] - bb_[1]) * 0.32, M + tw_ + 14, y + bb_[3] + 4), radius=14, fill=(250, 222, 110))
            cond_text(d, M, y, ls_[0], nf, ink)
            y += int(nf.size * 1.0)
        else:
            nf, _ = fit(mc, d, numtxt, lambda z: F(mc, "ArchivoBlack", z, 400), 380, W, 1, 140)
            d.text((M, y), numtxt, font=nf, fill=ink)
            y += int(nf.size * 1.2)
        body = s.get("body") or ""
        if body:
            bf = bold(56, 600) if tid in (1, 2, 3) else F(mc, look["captionFont"], 52, 600)
            y = mc.text_block(d, M, y + 20, body, bf, ink + (255,), W, lh=74)
        if who:
            if tid == 7:
                wf = F(mc, look["captionFont"], 38, 700)
                tw = d.textlength(who.upper(), font=wf)
                d.rectangle((M, y + 40, M + tw + 50, y + 118), fill=bright)
                d.text((M + 25, y + 56), who.upper(), font=wf, fill=onb)
            else:
                d.text((M, y + 40), who, font=hand(48) if tid == 1 else bold(40, 600), fill=hc)
    elif kind == "list":
        y = 120
        if tid == 1:   # a torn strip with the title in handwriting
            f, ls = fit(mc, d, head or "A few things", lambda z: hand(z), 96, W - 40, 2, 56)
            hh = len(ls) * int(f.size * 0.98) + 50
            kraft = tuple(max(0, min(255, int(c * 0.9))) for c in tuple(int(c * 0.82 + acc[k] * 0.18) for k, c in enumerate(paper))) if lum(paper) > 0.5 else tuple(min(255, c + 25) for c in paper)
            torn_strip(im, kraft, 40, 80, CW - 40, 80 + hh, 3, -2)
            d = ImageDraw.Draw(im)
            yy = 105
            for ln in ls:
                d.text((M, yy), ln, font=f, fill=ink)
                yy += int(f.size * 0.98)
            y = 80 + hh + 70
        elif tid == 2:   # a big bold first word, the rest in bold
            parts = (head or "A few things").split(" ", 1)
            f1, _ = fit(mc, d, parts[0].upper(), lambda z: bold(z), 130, W, 1, 50)
            d.text((M, y), parts[0].upper(), font=f1, fill=ink)
            y += int(f1.size * 1.2)
            if len(parts) > 1:
                f2, ls = fit(mc, d, parts[1], lambda z: bold(z, 600), 70, W, 2, 40)
                for ln in ls:
                    d.text((M, y), ln, font=f2, fill=hc)
                    y += int(f2.size * 1.15)
            y += 60
        elif tid == 3:   # tall narrow serif title with a marker bar under the key word
            f, ls = cond_fit(mc, d, head or "A few things", 150, W, 3)
            for ln in ls:
                cond_text(d, M, y, ln, f, ink)
                y += int(f.size * 0.98)
            y += 50
        else:   # notebook caps
            f, ls = fit(mc, d, (head or "A few things").upper(), lambda z: F(mc, "ArchivoBlack", z, 400), 80, W, 2, 44)
            for ln in ls:
                d.text((M, y), ln, font=f, fill=ink)
                y += int(f.size * 1.18)
            y += 50
        gap = max(130, min(270, (CH - 210 - y) // max(1, len(items)))) if items else 150
        for k, it in enumerate(items):
            if tid == 1:
                d.ellipse((M, y + 12, M + 70, y + 82), outline=ink + (255,), width=5)
                d.text((M + 19, y + 16), str(k + 1), font=hand(56), fill=hc)
                fi, ls2 = fit(mc, d, it, lambda z: hand(z), 84, W - 110, 2, 44)
                yy = y
                for ln in ls2:
                    d.text((M + 105, yy), ln, font=fi, fill=ink)
                    yy += int(fi.size * 1.05)
            elif tid == 2:
                d.text((M, y - 20), str(k + 1), font=bold(130), fill=acc)
                fi, ls2 = fit(mc, d, it, lambda z: bold(z, 600), 66, W - 150, 2, 40)
                yy = y + 6
                for ln in ls2:
                    d.text((M + 140, yy), ln, font=fi, fill=ink)
                    yy += int(fi.size * 1.2)
            elif tid == 3:
                nb = bold(44, 700)
                d.rounded_rectangle((M, y + 4, M + 80, y + 76), radius=36, fill=(250, 222, 110))
                d.text((M + 40 - d.textlength(str(k + 1), font=nb) / 2, y + 14), str(k + 1), font=nb, fill=ink)
                fi, ls2 = fit(mc, d, it, lambda z: bold(z, 600), 62, W - 120, 2, 38)
                yy = y + 4
                for ln in ls2:
                    d.text((M + 110, yy), ln, font=fi, fill=ink)
                    yy += int(fi.size * 1.2)
            else:
                fi, ls2 = fit(mc, d, it, lambda z: F(mc, look["captionFont"], z, 700), 58, W - 60, 2, 34)
                hgt = len(ls2) * int(fi.size * 1.25) + 36
                d.rectangle((M, y, CW - M, y + hgt), fill=bright)
                yy = y + 18
                for ln in ls2:
                    d.text((M + 30, yy), ln, font=fi, fill=onb)
                    yy += int(fi.size * 1.25)
                y += hgt - gap + 30
            y += gap
    else:   # quote: one big statement
        mark = "“"
        if tid == 1:
            d.text((M, 120), mark, font=hand(400), fill=hc)
            f, ls = fit_box(mc, d, head or "Say it here", lambda z: hand(z), 110, W, CH - 420 - (260 if who else 170), 1.0)
            y = 420
            for ln in ls:
                words_with_hi(d, M, y, ln, f, ink, s.get("hi"), hi_fill=acc)
                y += int(f.size * 1.0)
            if who:
                circle_note(d, M + 20, min(y + 50, CH - 230), who, hand(50), ink, acc)
        elif tid == 2:
            d.text((M, 40), mark, font=bold(420), fill=acc)
            f, ls = fit_box(mc, d, head or "Say it here", lambda z: bold(z, 700), 96, W, CH - 430 - (230 if who else 170), 1.15)
            y = 430
            for ln in ls:
                d.text((M, y), ln, font=f, fill=ink)
                y += int(f.size * 1.15)
            if who:
                d.text((M, min(y + 40, CH - 220)), who, font=bold(44, 600), fill=hc)
            if s.get("stickers", True):
                star(d, CW - 150, 170, 44, acc, 4, 0.4)
        elif tid == 3:
            d.text((M, 60), mark, font=cond_fit(mc, d, mark, 500, 400, 1)[0], fill=hc)
            f, ls = cond_fit(mc, d, head or "Say it here", 150, W, 5)
            while len(ls) * int(f.size * 1.0) > CH - 400 - (230 if who else 170) and f.size > 60:
                f, ls = cond_fit(mc, d, head or "Say it here", f.size - 8, W, 7)
            y = 400
            raw = s.get("hi") or ""
            for ln in ls:
                cond_text(d, M, y, ln, f, ink)
                y += int(f.size * 1.0)
            if who:
                d.text((M, y + 50), who, font=bold(46, 700), fill=hc)
        else:
            d.text((M, 60), mark, font=ital(420), fill=bright)
            f, ls = fit_box(mc, d, head or "Say it here", lambda z: ital(z), 120, W, CH - 420 - (250 if who else 170), 1.05)
            y = 420
            for ln in ls:
                d.text((M, y), ln, font=f, fill=ink)
                y += int(f.size * 1.05)
            if who:
                wf = F(mc, look["captionFont"], 40, 700)
                tw = d.textlength(who.upper(), font=wf)
                d.rectangle((M, min(y + 50, CH - 230), M + tw + 50, min(y + 50, CH - 230) + 78), fill=bright)
                d.text((M + 25, min(y + 50, CH - 230) + 16), who.upper(), font=wf, fill=onb)
    small_footer(mc, d, look, handle, i, n, ink, face="Fredoka")
    return im


def _extra_dark(mc, look, s, img, i, n, handle, tid):
    """list, quote and stat for the photo looks (4, 6, 8): her words over a darkened photo, or a dark brand color with no photo."""
    paper, ink, acc = brand_cols(mc, look, {4: 4, 6: 6, 8: 6}[tid])
    pic = photo_of(mc, s, img, CW, CH, 0.3)
    im = pic if pic is not None else Image.new("RGBA", (CW, CH), (28, 28, 30, 255))
    veil(im, 0.66)
    d = ImageDraw.Draw(im)
    white = (255, 255, 255, 255)
    kind = s.get("kind")
    head, who = s.get("headline") or "", s.get("who") or ""
    items = [str(x) for x in (s.get("items") or []) if str(x).strip()][:5]
    W = CW - 2 * M
    if tid == 4:
        title = lambda z: F(mc, "InstrumentSerif", z, 400)
        big = lambda z: F(mc, "ArchivoBlack", z, 400)
        body = lambda z: F(mc, "InstrumentSerif", z, 400)
    elif tid == 6:
        title = lambda z: disp(mc, look, z)
        big = lambda z: disp(mc, look, z)
        body = lambda z: F(mc, look["captionFont"], z, 600)
    else:
        title = lambda z: disp(mc, look, z)
        big = lambda z: disp(mc, look, z)
        body = lambda z: F(mc, look["captionFont"], z, 600)
    accent = acc + (255,)
    if kind == "list":
        f, ls = fit(mc, d, head or "A few things", title, 96, W, 2, 52)
        y = 170
        for ln in ls:
            d.text((M, y), ln, font=f, fill=white)
            y += int(f.size * 1.1)
        y += 50
        gap = max(130, min(250, (CH - 220 - y) // max(1, len(items)))) if items else 150
        for k, it in enumerate(items):
            d.ellipse((M, y + 4, M + 76, y + 80), outline=accent, width=6)
            nf = big(44)
            d.text((M + 38 - d.textlength(str(k + 1), font=nf) / 2, y + 14), str(k + 1), font=nf, fill=accent)
            fi, ls2 = fit(mc, d, it, body, 58, W - 120, 2, 36)
            yy = y + 4
            for ln in ls2:
                d.text((M + 110, yy), ln, font=fi, fill=white, stroke_width=2 if tid == 4 else 0, stroke_fill=(0, 0, 0, 255))
                yy += int(fi.size * 1.2)
            y += gap
    elif kind == "stat":
        numtxt = head or "73%"
        nf, _ = fit(mc, d, numtxt, big, 420, W, 1, 160)
        d.text((M, 230), numtxt, font=nf, fill=accent, stroke_width=3 if tid == 4 else 0, stroke_fill=(0, 0, 0, 255))
        y = 230 + int(nf.size * 1.15)
        if s.get("body"):
            y = mc.text_block(d, M, y + 20, s["body"], body(58), white, W, lh=76)
        if who:
            d.text((M, y + 40), who.upper(), font=F(mc, look["captionFont"], 34, 700), fill=accent)
    else:   # quote
        d.text((M, 120), "“", font=big(380), fill=accent)
        f, ls = fit_box(mc, d, head or "Say it here", title, 112, W, CH - 470 - (230 if who else 170), 1.08)
        y = 470
        for ln in ls:
            d.text((M, y), ln, font=f, fill=white, stroke_width=2 if tid == 4 else 0, stroke_fill=(0, 0, 0, 255))
            y += int(f.size * 1.08)
        if who:
            d.text((M, y + 40), who.upper(), font=F(mc, look["captionFont"], 36, 700), fill=accent)
    small_footer(mc, d, look, handle, i, n, white[:3], face="Fredoka")
    return im


def _flat_photo(mc, look, s, img, i, n, handle):
    """Warm flat color: one big rounded picture with a short caption under it."""
    paper, ink, acc = brand_cols(mc, look, 5)
    pic = photo_of(mc, s, img, CW - 2 * M, 860, 0.3)
    if pic is None:   # no real picture: say it as a quote instead (never an invented picture)
        return _extra_flat(mc, look, dict(s, kind="quote"), img, i, n, handle)
    im = Image.new("RGBA", (CW, CH), paper + (255,))
    paper_texture(im, seed=5)
    d = ImageDraw.Draw(im)
    shadow(im, rounded(pic, 36), (M, 110), 14, 10, 70)
    d = ImageDraw.Draw(im)
    f, ls = cond_fit(mc, d, s.get("headline") or "", 120, CW - 2 * M, 2)
    y = 110 + pic.height + 50
    for ln in ls:
        cond_text(d, (CW - cond_len(d, ln, f)) / 2, y, ln, f, ink)
        y += int(f.size * 0.98)
    small_footer(mc, d, look, handle, i, n, ink, face="Fredoka")
    return im


def _extra_flat(mc, look, s, img, i, n, handle):
    """list, quote and stat for Warm flat color (look 5): a flat color page, tall condensed serif, friendly cards."""
    paper, ink, acc = brand_cols(mc, look, 5)
    im = Image.new("RGBA", (CW, CH), paper + (255,))
    paper_texture(im, seed=5)
    d = ImageDraw.Draw(im)
    kind = s.get("kind")
    head, who = s.get("headline") or "", s.get("who") or ""
    items = [str(x) for x in (s.get("items") or []) if str(x).strip()][:5]
    W = CW - 2 * M
    bold = lambda z, w=700: F(mc, "Fredoka", z, w)
    script = lambda z: F(mc, "GochiHand-Regular", z, 400)
    if look.get("id") == "brand" or look.get("fromBrand"):
        cols = [mc.fe.hex2rgb(look[k]["bg"])[:3] for k in ("hook", "accent", "caption", "highlight")]
    else:
        cols = [(190, 205, 250), (82, 20, 40), (186, 140, 120)]
    circ = [c for c in cols if c != tuple(paper)][:3] or [ink]

    def centered_cond(y, text, start, maxlines):
        f, ls = cond_fit(mc, d, text, start, W, maxlines)
        for ln in ls:
            cond_text(d, (CW - cond_len(d, ln, f)) / 2, y, ln, f, ink)
            y += int(f.size * 0.98)
        return y
    if kind == "list":
        y = centered_cond(120, head or "A few things", 130, 2) + 40
        gap = max(150, min(260, (CH - 220 - y) // max(1, len(items)))) if items else 160
        for k, it in enumerate(items):
            fi, ls2 = fit(mc, d, it, lambda z: bold(z, 600), 52, W - 190, 2, 34)
            hh = max(120, len(ls2) * int(fi.size * 1.2) + 50)
            d.rounded_rectangle((M, y, CW - M, y + hh), radius=36, fill=(255, 255, 255, 245))
            c = circ[k % len(circ)]
            d.ellipse((M + 24, y + hh / 2 - 38, M + 100, y + hh / 2 + 38), fill=c)
            nf = bold(44, 700)
            d.text((M + 62 - d.textlength(str(k + 1), font=nf) / 2, y + hh / 2 - 28), str(k + 1), font=nf, fill=(255, 255, 255) if lum(c) < 0.6 else (30, 30, 30))
            yy = y + (hh - len(ls2) * int(fi.size * 1.2)) / 2 + 2
            for ln in ls2:
                d.text((M + 130, yy), ln, font=fi, fill=ink)
                yy += int(fi.size * 1.2)
            y += max(hh + 30, gap if len(items) <= 3 else hh + 30)
    elif kind == "stat":
        y = centered_cond(230, head or "73%", 440, 1)
        y += 30
        for k_, c in enumerate(circ):
            d.ellipse((CW / 2 - 130 + k_ * 100, y, CW / 2 - 70 + k_ * 100, y + 60), fill=c)
        y += 110
        if s.get("body"):
            for ln in mc.wrap(d, s["body"], bold(56, 600), W):
                d.text(((CW - d.textlength(ln, font=bold(56, 600))) / 2, y), ln, font=bold(56, 600), fill=ink)
                y += 74
        if who:
            wf = script(54)
            d.text(((CW - d.textlength(who, font=wf)) / 2, y + 30), who, font=wf, fill=acc if mc.contrast(acc, paper) >= 3 else ink)
    else:   # quote
        d.text((CW / 2 - 90, 70), "“", font=cond_fit(mc, d, "“", 420, 400, 1)[0], fill=circ[0] if lum(circ[0]) < 0.8 else ink)
        cf_, cl_ = cond_fit(mc, d, head or "Say it here", 150, W, 5)
        sz_ = cf_.size
        while len(cl_) * int(sz_ * 0.98) > CH - 430 - (230 if who else 170) and sz_ > 60:
            sz_ -= 8
            cf_, cl_ = cond_fit(mc, d, head or "Say it here", sz_, W, 7)
        y = centered_cond(430, head or "Say it here", sz_, 7)
        if who:
            wf = script(56)
            d.text(((CW - d.textlength(who, font=wf)) / 2, y + 40), who, font=wf, fill=acc if mc.contrast(acc, paper) >= 3 else ink)
    small_footer(mc, d, look, handle, i, n, ink, face="Fredoka")
    return im


bounce_text = _as_text(bounce_text)
words_with_hi = _as_text(words_with_hi)
cond_text = _as_text(cond_text)
circle_note = _as_text(circle_note)

MAKE = {1: t1, 2: t2, 3: t3, 4: t4, 5: t5, 6: t6, 7: t7, 8: t8}


# ---------------------------------------------------------------- her own looks ("learn this carousel look")
# A look she adds is a set of choices (background, lettering, where the picture goes, highlight style, little decorations)
# saved in customer/profile/looks/look-N.json, filled in from her screenshots. This draws ANY such look, in her brand colors
# unless the screenshots call for others. Slides use "template": "custom:N". Kinds: cover, point, list, quote, stat, photo, cta.
CUSTOM_DEFAULT = {"bg": "flat", "bg_color": None, "ink": None, "accent": None, "align": "left", "head_font": "ArchivoBlack", "head_case": "normal",
                  "head_size": 1.0, "body_font": "Poppins", "highlight": "bar", "photo": "rounded", "photo_pos": "top", "decor": "stars",
                  "number": "pill", "veil": 0.5}
CUSTOM_CHOICES = {"bg": ("flat", "paper", "grid", "gradient", "photo"), "align": ("left", "center"), "head_case": ("normal", "upper"),
                  "highlight": ("none", "bar", "underline"), "photo": ("none", "frame", "rounded", "circle", "full"), "photo_pos": ("top", "bottom"),
                  "decor": ("none", "stars", "arrows", "tape", "dots"), "number": ("none", "big", "pill", "circle")}
CUSTOM_FONTS = ("brand", "ArchivoBlack", "Anton", "BebasNeue", "Oswald", "InstrumentSerif", "Gloock", "PlayfairDisplay", "Lora", "Fredoka", "Poppins", "Montserrat",
                "Nunito", "Outfit", "Caveat", "GochiHand-Regular", "PermanentMarker", "Kalam-Bold", "SpecialElite", "CourierPrime")
CUSTOM_BODY_FONTS = ("Poppins", "Fredoka", "Lora", "Inter", "Montserrat", "Nunito", "Outfit", "Quicksand", "OpenSans")


def custom_clean(P):
    """Keeps only choices the engine can draw (anything else falls back to the default)."""
    out = dict(CUSTOM_DEFAULT)
    for k, v in (P or {}).items():
        if k in CUSTOM_CHOICES and v in CUSTOM_CHOICES[k]:
            out[k] = v
        elif k == "head_font" and v in CUSTOM_FONTS:
            out[k] = v
        elif k == "body_font" and v in CUSTOM_BODY_FONTS:
            out[k] = v
        elif k in ("bg_color", "ink", "accent") and (v is None or re.fullmatch(r"#[0-9a-fA-F]{6}", str(v))):
            out[k] = v
        elif k == "head_size":
            try:
                out[k] = max(0.7, min(1.3, float(v)))
            except Exception:
                pass
        elif k == "veil":
            try:
                out[k] = max(0.2, min(0.8, float(v)))
            except Exception:
                pass
    return out


def custom_load(ident):
    p = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "customer", "profile", "looks", f"look-{ident}.json")
    try:
        return custom_clean(json.load(open(p, encoding="utf-8")).get("params"))
    except Exception:
        return dict(CUSTOM_DEFAULT)


def _custom(mc, look, s, img, i, n, handle, P):
    P = custom_clean(P)
    paper, ink0, acc0 = brand_cols(mc, look, 1)
    kind = s.get("kind", "point")
    if not s.get("photo") and s.get("photos"):
        s = dict(s, photo=s["photos"][0])
    full = P["photo"] == "full" or P["bg"] == "photo"
    bgpic = photo_of(mc, s, img, CW, CH, 0.3) if (full and kind in ("cover", "point", "photo", "cta", "quote", "list", "stat")) else None
    pcol = hexrgb(P["bg_color"]) if P["bg_color"] else paper
    ink = hexrgb(P["ink"]) if P["ink"] else ink0
    acc = hexrgb(P["accent"]) if P["accent"] else acc0
    if bgpic is not None:
        im = bgpic
        veil(im, P["veil"] + (0.1 if kind in ("list", "quote", "stat") else 0))
        ink = (255, 255, 255)
    else:
        im = Image.new("RGBA", (CW, CH), pcol + (255,))
        if P["bg"] == "grid":
            grid_paper(im, pcol)
        elif P["bg"] == "paper":
            paper_texture(im, seed=9)
        elif P["bg"] == "gradient":
            top = pcol
            bot = tuple(int(c * 0.78) for c in pcol) if lum(pcol) > 0.4 else tuple(min(255, int(c * 1.5) + 12) for c in pcol)
            for yy in range(CH):
                f_ = yy / CH
                ImageDraw.Draw(im).line((0, yy, CW, yy), fill=tuple(int(top[k] * (1 - f_) + bot[k] * f_) for k in range(3)) + (255,))
        if lum(pcol) < 0.35 and lum(ink) < 0.5:
            ink = (255, 255, 255)
        elif lum(pcol) > 0.65 and lum(ink) > 0.7:
            ink = (30, 30, 34)
    if mc.contrast(acc, pcol if bgpic is None else (30, 30, 30)) < 2.2:
        acc = tuple(int(acc[k] * 0.6 + ink[k] * 0.4) for k in range(3))
    d = ImageDraw.Draw(im)
    W = CW - 2 * M
    ctr = P["align"] == "center"
    hs = P["head_size"]
    upper = P["head_case"] == "upper"
    hf = lambda z: F(mc, P["head_font"], z, 700, role="headline")
    bf = lambda z, w=500: F(mc, P["body_font"], z, w, role="body")
    txt = lambda v: (str(v).upper() if upper else str(v))
    hi = [x.strip().lower() for x in re.split(r"[|,]", str(s.get("hi") or "")) if x.strip()]

    def lx(text, font):
        return (CW - d.textlength(text, font=font)) / 2 if ctr else M

    def line(y, text, font, fill):
        """One line of words, with her highlighted words marked (bar behind, or an underline)."""
        x = lx(text, font)
        ws = text.split(" ")
        sp = d.textlength(" ", font=font)
        for k, w_ in enumerate(ws):
            ww = d.textlength(w_, font=font)
            if hi and P["highlight"] != "none" and re.sub(r"[^\w']", "", w_).lower() in hi:
                bb = font.getbbox("Hg")
                if P["highlight"] == "bar":
                    d.rounded_rectangle((x - 8, y + bb[1] + (bb[3] - bb[1]) * 0.3, x + ww + 8, y + bb[3] + 2), radius=10, fill=acc + (255,))
                else:
                    d.line((x, y + bb[3] + 6, x + ww, y + bb[3] + 6), fill=acc + (255,), width=max(5, font.size // 14))
            d.text((x, y), w_, font=font, fill=fill)
            x += ww + sp
        return y + int(font.size * 1.12)

    def para(y, text, fn, start, maxh, floor=36, fill=None, lh=1.12, hi_on=True):
        f, ls = fit_box(mc, d, text, fn, start, W, maxh, lh, floor)
        for ln in ls:
            if hi_on:
                y = line(y, ln, f, fill or ink + (255,))
            else:
                d.text((lx(ln, f), y), ln, font=f, fill=fill or ink + (255,))
                y += int(f.size * lh)
        return y

    def shaped(pic, shape):
        if shape == "circle":
            sz = min(pic.size)
            pic = pic.crop(((pic.width - sz) // 2, (pic.height - sz) // 2, (pic.width + sz) // 2, (pic.height + sz) // 2))
            m = Image.new("L", pic.size, 0)
            ImageDraw.Draw(m).ellipse((0, 0, sz - 1, sz - 1), fill=255)
            pic = pic.copy()
            pic.putalpha(m)
            return pic
        if shape == "frame":
            return tilt(framed(pic, 16), -2)
        return rounded(pic, 30)

    def place_pic(y, h):
        """The picture in her chosen shape, centered or at the left; returns the space it used."""
        if bgpic is not None or P["photo"] in ("none", "full"):
            return 0
        pic = photo_of(mc, s, img, W if P["photo"] != "circle" else h, h, 0.3)
        if pic is None:
            return 0
        sh = shaped(pic, P["photo"])
        x = (CW - sh.width) // 2 if (ctr or P["photo"] == "circle") else M
        shadow(im, sh, (x, int(y)), 12, 8, 70)
        if P["decor"] == "tape" and P["photo"] == "frame":
            tape(im, x + sh.width // 2, int(y) + 12, -4)
        return sh.height + 36

    def marker(y, num, size=70):
        """Her number style next to a point or a list line; returns how far to indent."""
        if P["number"] == "none" or not num:
            return 0
        nf = hf(int(size * 0.7))
        if P["number"] == "pill":
            wd = int(d.textlength(str(num), font=nf)) + 40
            d.rounded_rectangle((M, y, M + wd, y + size), radius=size // 2, fill=acc + (255,))
            d.text((M + 20, y + size * 0.08), str(num), font=nf, fill=(255, 255, 255) if lum(acc) < 0.6 else (25, 25, 28))
            return wd + 24
        if P["number"] == "circle":
            d.ellipse((M, y, M + size, y + size), outline=acc + (255,), width=6)
            d.text((M + size / 2 - d.textlength(str(num), font=nf) / 2, y + size * 0.1), str(num), font=nf, fill=acc + (255,))
            return size + 24
        d.text((M, y - 14), str(num), font=hf(int(size * 1.9)), fill=acc + (255,))
        return int(size * 1.7)

    def decor():
        if P["decor"] == "stars":
            star(d, CW - 100, 80, 30, acc, 4, 0.4)
            if kind in ("cover", "cta"):
                star(d, 150, CH - 230, 36, acc, 4, 0.4)
        elif P["decor"] == "dots" and kind in ("cover", "cta", "quote", "stat"):
            for k in range(3):
                d.ellipse((CW - 250 + k * 60, 120, CW - 210 + k * 60, 160), fill=acc + (255 if k == 0 else 150,))
        elif P["decor"] == "arrows" and kind in ("cover", "point"):
            mc.hand_arrow(d, CW - 190, 130, CW - 90, 130, acc + (255,), 7)

    head = txt(s.get("headline") or s.get("top") or "")
    y = 120
    if kind == "cover":
        if full or P["photo"] in ("none",) or (not (s.get("photo") or s.get("photos") or img is not None)):
            if bgpic is not None:
                f_, ls_ = fit_box(mc, d, head, hf, int(150 * hs), W, 700, 1.1, 54)
                y = CH - 210 - len(ls_) * int(f_.size * 1.12)
            else:
                y = 150 if not ctr else 300
            y = para(y, head, hf, int(150 * hs), CH - y - 220)
        elif P["photo_pos"] == "top":
            used = place_pic(110, 560)
            y = para(110 + used + 10, head, hf, int(130 * hs), CH - 110 - used - 220)
        else:
            y = para(130, head, hf, int(130 * hs), 520)
            place_pic(y + 30, min(560, CH - int(y) - 290))
    elif kind == "point":
        num = s.get("n")
        if num not in (None, False, "") and P["number"] != "none":
            marker(y, num)
            y += 150 if P["number"] == "big" else 100
        y = para(y, head, hf, int(104 * hs), 420)
        body = s.get("body") or ""
        if body:
            y = para(y + 24, body, bf, 44, 330, 30, lh=1.35, hi_on=False)
        pic_ok = bgpic is None and P["photo"] not in ("none", "full") and (s.get("photo") or img is not None)
        if pic_ok:
            hh = max(260, min(560, CH - 190 - int(y) - 30))
            place_pic(y + 30, hh)
    elif kind == "list":
        y = para(y, head or "A few things", hf, int(100 * hs), 300)
        items = [str(x) for x in (s.get("items") or []) if str(x).strip()][:5]
        gap = max(130, min(250, (CH - 210 - int(y)) // max(1, len(items)))) if items else 150
        y += 40
        for k, it in enumerate(items):
            ind = marker(y, k + 1, 66) if P["number"] != "none" else 0
            if not ind and P["number"] == "none":
                d.ellipse((M, y + 22, M + 22, y + 44), fill=acc + (255,))
                ind = 50
            f_, ls_ = fit(mc, d, it, bf if False else (lambda z: bf(z, 600)), 56, W - ind, 2, 34)
            yy = y + 4
            for ln in ls_:
                d.text((M + ind, yy), ln, font=f_, fill=ink + (255,))
                yy += int(f_.size * 1.2)
            y += gap
    elif kind == "quote":
        d.text((M if not ctr else CW / 2 - 70, 70), "“", font=hf(420), fill=acc + (255,))
        who = s.get("who") or ""
        y = para(430, head, hf, int(112 * hs), CH - 430 - (250 if who else 170), 40)
        if who:
            d.text((lx(txt(who), bf(40, 700)), y + 30), txt(who), font=bf(40, 700), fill=acc + (255,))
    elif kind == "stat":
        f_, _ = fit(mc, d, head, hf, int(420 * hs), W, 1, 150)
        d.text((lx(head, f_), 230), head, font=f_, fill=acc + (255,))
        y = 230 + int(f_.size * 1.15)
        if s.get("body"):
            y = para(y + 20, s["body"], bf, 56, 420, 34, lh=1.3, hi_on=False)
        if s.get("who"):
            d.text((lx(txt(s["who"]), bf(36, 700)), y + 30), txt(s["who"]), font=bf(36, 700), fill=acc + (255,))
    elif kind == "photo":
        pic_ = photo_of(mc, s, img, W, 860, 0.3)
        if pic_ is None:
            return _custom(mc, look, dict(s, kind="quote"), img, i, n, handle, P)
        if bgpic is not None:
            para(CH - 330, head, hf, int(90 * hs), 220)
        else:
            sh = shaped(pic_, "rounded" if P["photo"] in ("none", "circle") else P["photo"])
            shadow(im, sh, ((CW - sh.width) // 2 if ctr or P["photo"] == "frame" else M, 110), 12, 8, 70)
            para(110 + sh.height + 50, head, hf, int(80 * hs), 240)
    else:   # cta
        kw = txt("Comment " + (s.get("keyword") or "WORD"))
        f_, _ = fit(mc, d, kw, hf, int(120 * hs), W, 1, 56)
        block = int(f_.size * 1.5) + 140
        y = (CH - block) // 2
        if P["highlight"] == "bar":
            tw = d.textlength(kw, font=f_)
            x0 = lx(kw, f_)
            d.rounded_rectangle((x0 - 30, y - 10, x0 + tw + 30, y + int(f_.size * 1.25)), radius=18, fill=acc + (255,))
            d.text((x0, y), kw, font=f_, fill=(255, 255, 255) if lum(acc) < 0.6 else (25, 25, 28))
        else:
            d.text((lx(kw, f_), y), kw, font=f_, fill=acc + (255,))
            if P["highlight"] == "underline":
                d.line((lx(kw, f_), y + int(f_.size * 1.2), lx(kw, f_) + d.textlength(kw, font=f_), y + int(f_.size * 1.2)), fill=ink + (255,), width=6)
        para(y + int(f_.size * 1.5), s.get("line") or "and I'll send it to you", bf, 52, 200, 34, lh=1.25, hi_on=False)
    decor()
    small_footer(mc, d, look, handle, i, n, ink, face="Fredoka")
    return im


def _with_extras(fn, tid):
    def g(mc, look, s, img, i, n, handle):
        if s.get("kind") in EXTRA_KINDS:
            if tid in (1, 2, 3, 7):
                return _extra(mc, look, s, img, i, n, handle, tid)
            if s.get("kind") == "photo" and tid != 5:
                s = dict(s, kind="point")   # the photo looks already are photo slides
                return fn(mc, look, s, img, i, n, handle)
            if tid == 5:
                if s.get("kind") == "photo":
                    return _flat_photo(mc, look, s, img, i, n, handle)
                return _extra_flat(mc, look, s, img, i, n, handle)
            return _extra_dark(mc, look, s, img, i, n, handle, tid)
        return fn(mc, look, s, img, i, n, handle)
    return g


for _t in (1, 2, 3, 4, 5, 6, 7, 8):
    MAKE[_t] = _with_extras(MAKE[_t], _t)


def _custom_maker(ident):
    def g(mc, look, s, img, i, n, handle):
        return _custom(mc, look, s, img, i, n, handle, custom_load(ident))
    return g


def _resolve_tid(s):
    tv = s.get("template", 1)
    if isinstance(tv, str) and tv.startswith("custom:"):   # one of her own looks
        MAKE[tv] = _custom_maker(tv.split(":", 1)[1])
        return tv
    return int(tv)


def _set_squeeze(mc):
    """Her own font is never squeezed narrow (that is only for the engine's condensed headline serif)."""
    global SQUEEZE
    SQUEEZE = 1.0 if mc.fe.brand_font_name() else 0.74


def render(mc, look, s, img, i, n, handle):
    _set_squeeze(mc)
    tid = _resolve_tid(s)
    if tid not in MAKE:
        raise SystemExit(f"Template {tid} does not exist. Choose 1 to 8.")
    TR.begin()
    im = MAKE[tid](mc, look, s, img, i, n, handle)
    blocks = _clusters()
    TR.end()
    moves = [m for m in (s.get("moves") or []) if m.get("at") and (m.get("d") or m.get("s") or m.get("r"))]
    if moves and blocks:
        shift, used = {}, set()
        for m in moves:   # each saved move goes to the piece whose original center is nearest (within 160px)
            best = min((b for b in blocks if b["id"] not in used), key=lambda b: (b["at"][0] - m["at"][0]) ** 2 + (b["at"][1] - m["at"][1]) ** 2, default=None)
            if best is None or (best["at"][0] - m["at"][0]) ** 2 + (best["at"][1] - m["at"][1]) ** 2 > 160 ** 2:
                continue
            used.add(best["id"])
            d_ = m.get("d") or [0, 0]
            sc_ = max(0.3, min(3.0, float(m.get("s") or 1)))
            rot_ = max(-180.0, min(180.0, float(m.get("r") or 0)))
            best["d"], best["s"], best["r"] = [int(d_[0]), int(d_[1])], sc_, rot_
            for k in best["members"]:
                shift[k] = (int(d_[0]), int(d_[1]), sc_, best["at"][0], best["at"][1], rot_)
        if shift:
            TR.begin(shift)
            im = MAKE[tid](mc, look, s, img, i, n, handle)
            TR.end()
    out_ = []
    for b in blocks:
        ob, d_, s_, r_ = b["bbox"], b.get("d", [0, 0]), b.get("s", 1.0), b.get("r", 0.0)
        cx_, cy_ = b["at"]
        hw_, hh_ = (ob[2] - ob[0]) / 2 * s_, (ob[3] - ob[1]) / 2 * s_
        if r_:
            ca, sa = abs(math.cos(math.radians(r_))), abs(math.sin(math.radians(r_)))
            hw_, hh_ = hw_ * ca + hh_ * sa, hw_ * sa + hh_ * ca
        cur = [int(cx_ + d_[0] - hw_), int(cy_ + d_[1] - hh_), int(cx_ + d_[0] + hw_), int(cy_ + d_[1] + hh_)]
        out_.append({"id": b["id"], "label": b["label"], "ob": ob, "bbox": cur, "at": b["at"], "d": d_, "s": s_, "r": r_})
    LAST_BLOCKS[:] = out_
    return im


def render_pieces(mc, look, s, img, i, n, handle, out_base):
    """Cuts every movable piece out of the finished slide so the move editor can show them exactly, overlaps and all.
    Writes <out_base>.piece-K.png (the piece alone) and <out_base>.patch-K.png (what is under it), and adds the crop box ("pb") to the blocks."""
    _set_squeeze(mc)
    tid = _resolve_tid(s)
    TR.begin()
    MAKE[tid](mc, look, s, img, i, n, handle)
    blocks = _clusters()
    TR.end()
    shift = {}
    for m in (s.get("moves") or []):
        if not (m.get("at") and (m.get("d") or m.get("s") or m.get("r"))):
            continue
        best = min(blocks, key=lambda b: (b["at"][0] - m["at"][0]) ** 2 + (b["at"][1] - m["at"][1]) ** 2, default=None)
        if best is None or (best["at"][0] - m["at"][0]) ** 2 + (best["at"][1] - m["at"][1]) ** 2 > 160 ** 2 or "_mv" in best:
            continue
        best["_mv"] = m
        d_ = m.get("d") or [0, 0]
        for k in best["members"]:
            shift[k] = (int(d_[0]), int(d_[1]), max(0.3, min(3.0, float(m.get("s") or 1))), best["at"][0], best["at"][1], float(m.get("r") or 0))
    TR.begin(shift)
    full = MAKE[tid](mc, look, s, img, i, n, handle).convert("RGB")
    TR.end()
    pb_all = {}
    for b in blocks:
        TR.begin(shift, hide=b["members"])
        bg = MAKE[tid](mc, look, s, img, i, n, handle).convert("RGB")
        TR.end()
        from PIL import ImageChops
        diff = ImageChops.difference(full, bg).convert("L").point(lambda v: 255 if v > 6 else 0)
        box = diff.getbbox()
        if not box:
            continue
        pad = 14
        pb = (max(0, box[0] - pad), max(0, box[1] - pad), min(CW, box[2] + pad), min(CH, box[3] + pad))
        mask = diff.crop(pb).filter(ImageFilter.GaussianBlur(0.8))
        piece = full.crop(pb).convert("RGBA")
        piece.putalpha(mask)
        piece.save(f"{out_base}.piece-{b['id']}.png")
        bg.crop(pb).save(f"{out_base}.patch-{b['id']}.png")
        pb_all[b["id"]] = list(pb)
    return pb_all


# ---------------------------------------------------------------- bring older carousels into the looks
_HEAD = ("headline", "text", "word", "quote", "term", "name", "verdict", "question", "myth", "top", "title", "label")
_BODY = ("body", "sub", "definition", "answer", "fact", "line", "bottom", "feel")


def convert_old(slides):
    """Turns a carousel made before the looks existed into look slides (words and photos kept), so it can use Change style and Move things around.
    Returns the new slide list. Every slide keeps its words; a layout the looks do not have becomes a normal slide."""
    def pick(s, keys):
        for k in keys:
            v = s.get(k)
            if isinstance(v, str) and v.strip():
                return v.strip()
        return ""

    def lines(s):
        out = []
        for k in ("items", "lines", "options", "parts", "steps", "rows"):
            for x in s.get(k, []) or []:
                out.append(" : ".join(str(y) for y in x) if isinstance(x, (list, tuple)) else str(x))
        return out[:5]
    new, last = [], len(slides) - 1
    for i, s in enumerate(slides):
        ty = s.get("type")
        if ty == "tpl":
            new.append(s)
            continue
        if ty in ("panoR", "videoclip"):
            continue
        keep = {k: s[k] for k in ("source", "post", "photo", "frame", "bg_frame") if k in s}
        head, body = pick(s, _HEAD), pick(s, _BODY)
        if ty in ("cover", "sticker", "negcover", "panoL") or (i == 0):
            sl = dict(kind="cover", headline=head or body)
            if s.get("hi"):
                sl["hi"] = s["hi"]
        elif ty == "cta" or (i == last and s.get("keyword")):
            sl = dict(kind="cta", keyword=s.get("keyword") or "WORD", line=s.get("line") or "and I'll send it to you")
        elif ty == "stat":
            sl = dict(kind="stat", headline=str(s.get("number") or head or ""), body=body or str(s.get("label") or ""))
            if s.get("label") and body:
                sl["who"] = str(s["label"]).capitalize()
        elif ty in ("list", "recap", "framework", "timeline", "stopstart", "quiz", "glossary") and lines(s):
            sl = dict(kind="list", headline=head or "A few things", items=lines(s))
        elif ty in ("quote", "bigtext", "convo"):
            sl = dict(kind="quote", headline=head or body)
            if s.get("who") or s.get("name"):
                sl["who"] = s.get("who") or s.get("name")
        else:
            sl = dict(kind="point", headline=head or body)
            if body and body != sl["headline"]:
                sl["body"] = body
            if s.get("n"):
                sl["n"] = s["n"]
        d = dict(type="tpl", template=0)
        d.update(sl)
        d.update(keep)
        new.append(d)
    return new
