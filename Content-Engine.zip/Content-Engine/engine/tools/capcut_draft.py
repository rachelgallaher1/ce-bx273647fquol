#!/usr/bin/env python3
"""Make a CapCut project from an edited video, so it opens in CapCut as a real project.
  python capcut_draft.py build VIDEO.mp4 --name "My reel" [--out FOLDER]     builds the project folder (touches nothing in CapCut)
  python capcut_draft.py install DRAFT_FOLDER                                 puts it in CapCut's projects folder (CapCut must be closed)
How it works: CapCut stores a project as plain JSON files. We copy a real, clean CapCut project (engine/templates/capcut-draft/)
and fill in her video. Tested against CapCut 9.5 on Mac. CapCut updates can change the format, so always run a test first.
Only the video track is filled in so far (layers for captions, graphics and sounds come next).
"""
import argparse, glob, json, os, re, shutil, subprocess, sys, time, uuid

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
TPL = os.path.join(ROOT, "engine", "templates", "capcut-draft")
UUID = re.compile(r"[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}")


def capcut_root():
    cands = [os.path.expanduser("~/Movies/CapCut/User Data/Projects/com.lveditor.draft"),
             os.path.expanduser("~/AppData/Local/CapCut/User Data/Projects/com.lveditor.draft")]
    for c in cands:
        if os.path.isdir(c):
            return c
    return None


def probe(video):
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,r_frame_rate:format=duration",
                        "-of", "json", video], capture_output=True, text=True, encoding="utf-8", errors="replace")
    j = json.loads(r.stdout)
    st = j["streams"][0]
    return int(st["width"]), int(st["height"]), float(j["format"]["duration"])


def build(video, name, out):
    video = os.path.abspath(video)
    w, h, dur = probe(video)
    if (w, h) != (1080, 1920):
        print("Note: this template is 1080x1920 (vertical). Your video is %dx%d; CapCut will still open it but may crop." % (w, h))
    dur_us = int(round(dur * 1_000_000))
    dur_ms = int(dur_us / 1000) * 1000
    size = os.path.getsize(video)
    dest = os.path.join(out, name)
    if os.path.exists(dest):
        sys.exit("A folder named '%s' already exists in %s. Pick another name." % (name, out))
    shutil.copytree(TPL, dest)
    # fresh ids everywhere
    ids = {}
    def newid(m):
        s = m.group(0)
        key = s.lower()
        if key not in ids:
            ids[key] = str(uuid.uuid4())
        n = ids[key]
        return n.upper() if s.upper() == s else n
    now_us = int(time.time() * 1_000_000)
    fill = {"@@VIDEO_PATH@@": video, "@@VIDEO_NAME@@": os.path.basename(video), "@@DUR_US@@": str(dur_us), "@@DUR_MS@@": str(dur_ms),
            "@@FILE_SIZE@@": str(size), "@@NAME@@": name}
    for dp, _, fs in os.walk(dest):
        for f in fs:
            p = os.path.join(dp, f)
            t = open(p, encoding="utf-8").read()
            for k, v in fill.items():
                t = t.replace(k, json.dumps(v)[1:-1] if k in ("@@VIDEO_PATH@@", "@@VIDEO_NAME@@", "@@NAME@@") else v)
            t = UUID.sub(newid, t)
            open(p, "w", encoding="utf-8").write(t)
    # timeline folder must be named with the (new) timeline id
    old_tl = [d for d in os.listdir(os.path.join(dest, "Timelines")) if os.path.isdir(os.path.join(dest, "Timelines", d))][0]
    meta = json.load(open(os.path.join(dest, "Timelines", "project.json"), encoding="utf-8"))
    new_tl = meta["main_timeline_id"]
    if old_tl != new_tl:
        os.rename(os.path.join(dest, "Timelines", old_tl), os.path.join(dest, "Timelines", new_tl))
    # same draft_info at the top, and a cover picture from the first frame
    shutil.copy2(os.path.join(dest, "Timelines", new_tl, "draft_info.json"), os.path.join(dest, "draft_info.json"))
    cover = os.path.join(dest, "draft_cover.jpg")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", "0.5", "-i", video, "-frames:v", "1", "-vf", "scale=-2:540", cover])
    if os.path.exists(cover):
        shutil.copy2(cover, os.path.join(dest, "Timelines", new_tl, "draft_cover.jpg"))
    # timestamps in the meta file
    mp = os.path.join(dest, "draft_meta_info.json")
    m = json.load(open(mp, encoding="utf-8"))
    m["tm_draft_create"] = m["tm_draft_modified"] = now_us
    for grp in m.get("draft_materials", []):
        for it in grp.get("value", []):
            it["import_time"] = int(now_us / 1e6)
            it["import_time_ms"] = now_us
            it["create_time"] = int(now_us / 1e6)
    json.dump(m, open(mp, "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
    print("Built:", dest)
    return dest


def install(draft):
    root = capcut_root()
    if not root:
        sys.exit("I can't find CapCut's projects folder. Is CapCut installed and opened once?")
    try:
        running = subprocess.run(["pgrep", "-x", "CapCut"], capture_output=True).returncode == 0 if sys.platform == "darwin" else \
            "capcut.exe" in subprocess.run(["tasklist"], capture_output=True, encoding="utf-8", errors="replace").stdout.lower()
    except Exception:
        running = False
    if running:
        sys.exit("CapCut is open. Quit CapCut first (CapCut menu, Quit), then run this again.")
    draft = os.path.abspath(draft)
    name = os.path.basename(draft)
    dest = os.path.join(root, name)
    if os.path.exists(dest):
        sys.exit("CapCut already has a project folder named %s." % name)
    rootmeta = os.path.join(root, "root_meta_info.json")
    shutil.copy2(rootmeta, rootmeta + ".engine-backup-" + time.strftime("%Y%m%d-%H%M%S"))
    shutil.copytree(draft, dest)
    # fix paths inside the copied project, then add it to CapCut's list
    for dp, _, fs in os.walk(dest):
        for f in fs:
            if f.endswith((".json", ".tmp", ".bak")) or f == "draft_settings":
                p = os.path.join(dp, f)
                t = open(p, encoding="utf-8").read()
                t = t.replace("@@DRAFT_DIR@@", dest).replace("@@ROOT@@", root)
                open(p, "w", encoding="utf-8").write(t)
    m = json.load(open(os.path.join(dest, "draft_meta_info.json"), encoding="utf-8"))
    m["draft_fold_path"], m["draft_root_path"] = dest, root
    json.dump(m, open(os.path.join(dest, "draft_meta_info.json"), "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
    r = json.load(open(rootmeta, encoding="utf-8"))
    ref = r["all_draft_store"][-1] if r["all_draft_store"] else {}
    entry = dict(ref)
    entry.update({"draft_cover": os.path.join(dest, "draft_cover.jpg"), "draft_fold_path": dest, "draft_id": m["draft_id"],
                  "draft_json_file": os.path.join(dest, "draft_info.json"), "draft_name": m["draft_name"],
                  "draft_timeline_materials_size": m.get("draft_timeline_materials_size_", 0), "draft_root_path": root,
                  "tm_draft_create": m["tm_draft_create"], "tm_draft_modified": m["tm_draft_modified"], "tm_duration": m["tm_duration"]})
    r["all_draft_store"].insert(0, entry)
    if "draft_ids" in r:
        r["draft_ids"] = (r["draft_ids"] + 1) if isinstance(r["draft_ids"], int) else r["draft_ids"] + [m["draft_id"]]
    json.dump(r, open(rootmeta, "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
    print("Installed. Open CapCut and look for the project called", name)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build"); b.add_argument("video"); b.add_argument("--name", required=True)
    b.add_argument("--out", default=os.path.join(ROOT, "customer", "videos", "capcut"))
    i = sub.add_parser("install"); i.add_argument("draft")
    a = ap.parse_args()
    if a.cmd == "build":
        os.makedirs(a.out, exist_ok=True)
        build(a.video, a.name, a.out)
    else:
        install(a.draft)


main()
