#!/usr/bin/env python3
"""Pretend social account with a MIX of content (reels, before/after, photo posts, text posts, carousels), as a scroll video.
Usage:  python3 engine/tools/make_mock_account.py SPEC.json
Photos come from Pexels or Pixabay (both free for commercial use): key saved at ~/.cache/content-engine/pexels.key or pixabay.key.
Without a key it draws plain placeholders. Everything on the account is an invented example, labeled "example account".

SPEC: {"out": "folder", "look": "7", "handle": "@sample.x", "name": "...", "category": "...", "bio": [..], "highlights": [..],
  "tiles": [ {"kind": "reel", "photo": "query", "hook": ["LINE *HI*", "LINE"]},
             {"kind": "ba", "before": "query", "after": "query", "label": "text"},
             {"kind": "photo", "photo": "query", "text": "OVERLAY", "sub": "small line"},
             {"kind": "car", "headline": "...", "hi": "WORD", "items": ["..","..",".."], "photo": "query"},
             {"kind": "text", "headline": "...", "hi": "WORD"} ... 12 in all ],
  "open": {"reel": 0, "ba": 1, "car": 2},          # which tiles the video taps into
  "reel_words": [["THREE", 0.3], ...],  "reel_chunks": [[0, 4], [4, 7]] }
"""
import hashlib, json, math, os, shutil, subprocess, sys, urllib.parse, urllib.request
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import make_mock_profile as mp

ROOT = mp.ROOT
PY = sys.executable
W, H = 1080, 1920
DARK, WHITE = (24, 24, 26), (255, 255, 255)


def pexels_key():
    k = os.environ.get("PEXELS_API_KEY")
    if k:
        return k.strip()
    p = os.path.expanduser("~/.cache/content-engine/pexels.key")
    return open(p, encoding="utf-8").read().strip() if os.path.exists(p) else None


def pixabay_key():
    k = os.environ.get("PIXABAY_API_KEY")
    if k:
        return k.strip()
    p = os.path.expanduser("~/.cache/content-engine/pixabay.key")
    return open(p, encoding="utf-8").read().strip() if os.path.exists(p) else None


def run(a):
    subprocess.run(a, check=True, capture_output=True)


def photo(query, cache, orient="portrait", idx=0):
    """A real stock photo (Pexels), cropped later. Returns a PIL image or None."""
    key = pexels_key()
    pkey = pixabay_key()
    if (not key and not pkey) or not query:
        return None
    os.makedirs(cache, exist_ok=True)
    tag = hashlib.md5(f"{query}|{orient}|{idx}".encode()).hexdigest()
    path = os.path.join(cache, tag + ".jpg")
    if not os.path.exists(path):
        try:
            if key:
                u = f"https://api.pexels.com/v1/search?query={urllib.parse.quote(query)}&orientation={orient}&per_page=8"
                data = json.loads(urllib.request.urlopen(urllib.request.Request(u, headers={"Authorization": key, "User-Agent": "content-engine"}), timeout=30).read())
                ph = data.get("photos", [])
                if not ph:
                    return None
                src = ph[min(idx, len(ph) - 1)]["src"]["large2x"]
            else:
                o = "vertical" if orient == "portrait" else "horizontal"
                u = f"https://pixabay.com/api/?key={pkey}&q={urllib.parse.quote(query)}&image_type=photo&orientation={o}&safesearch=true&per_page=8"
                data = json.loads(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "content-engine"}), timeout=30).read())
                ph = data.get("hits", [])
                if not ph:
                    return None
                src = ph[min(idx, len(ph) - 1)]["largeImageURL"]
            open(path, "wb").write(urllib.request.urlopen(urllib.request.Request(src, headers={"User-Agent": "content-engine"}), timeout=60).read())
        except Exception as e:
            print("  (photo search failed:", e, ")")
            return None
    return Image.open(path).convert("RGB")


def fill(im, w, h, up=0.4):
    if im is None:
        return None
    r = max(w / im.width, h / im.height)
    im = im.resize((int(im.width * r + 1), int(im.height * r + 1)))
    x = (im.width - w) // 2
    y = int((im.height - h) * up)
    return im.crop((x, y, x + w, y + h))


def scrim(im, a0=40, a1=150, top=False):
    ov = Image.new("RGBA", im.size)
    d = ImageDraw.Draw(ov)
    for y in range(im.height):
        k = y / im.height
        k = 1 - k if top else k
        d.line((0, y, im.width, y), fill=(0, 0, 0, int(a0 + (a1 - a0) * k)))
    return Image.alpha_composite(im.convert("RGBA"), ov).convert("RGB")


def grad(w, h, c1, c2):
    g = Image.new("RGB", (w, h))
    d = ImageDraw.Draw(g)
    for y in range(h):
        k = y / h
        d.line((0, y, w, y), fill=tuple(int(c1[i] * (1 - k) + c2[i] * k) for i in range(3)))
    return g


def main():
    spec = json.load(open(sys.argv[1], encoding="utf-8"))
    out = spec["out"] if os.path.isabs(spec["out"]) else os.path.join(ROOT, spec["out"])
    work = os.path.join(out, "_work")
    cache = os.path.expanduser("~/.cache/content-engine/stock")
    shutil.rmtree(work, ignore_errors=True)
    os.makedirs(work)
    os.makedirs(os.path.join(out, "tiles", "slides"), exist_ok=True)
    handle = spec["handle"]
    ac = mp.accent(spec["look"])
    navy = tuple(int(c * 0.35) for c in ac)
    anton = lambda s: ImageFont.truetype(os.path.join(ROOT, "engine", "fonts", "Anton-Regular.ttf"), s)
    stock = bool(pexels_key() or pixabay_key())

    def carousel(name, slides):
        d = os.path.join(work, name)
        os.makedirs(d)
        json.dump({"title": "slides", "look": spec["look"], "handle": handle, "slides": slides}, open(d + "/slides.json", "w", encoding="utf-8"))
        subprocess.run([PY, os.path.join(HERE, "make_carousel.py"), d + "/slides.json"], capture_output=True)
        return [Image.open(f"{d}/slides/slide-{i + 1:02d}.png").convert("RGB") for i in range(len(slides))]

    def hook_box(im, y, lines):
        d = ImageDraw.Draw(im)
        f = anton(78)
        bw, bh = 960, 40 + len(lines) * 92
        d.rounded_rectangle((60, y, 60 + bw, y + bh), 34, fill=navy, outline=ac, width=6)
        for i, ln in enumerate(lines):
            parts = ln.split("*")
            tw = sum(d.textlength(p, font=f) for p in parts)
            x = 60 + (bw - tw) / 2
            for j, p in enumerate(parts):
                d.text((x, y + 20 + i * 92), p, font=f, fill=ac if j % 2 else (244, 240, 232))
                x += d.textlength(p, font=f)

    def bg_photo(q, h, up=0.35, idx=0):
        p = fill(photo(q, cache, "portrait", idx), W, h, up)
        return scrim(p, 20, 120) if p else grad(W, h, ac, navy)

    def with_text(im, text, sub=None):
        d = ImageDraw.Draw(im)
        f = anton(104)
        words, lines, cur = text.split(), [], ""
        for w in words:
            if d.textlength((cur + " " + w).strip(), font=f) > W - 120:
                lines.append(cur); cur = w
            else:
                cur = (cur + " " + w).strip()
        lines.append(cur)
        y = im.height - 160 - len(lines) * 110 - (60 if sub else 0)
        for ln in lines:
            d.text((60, y), ln, font=f, fill=WHITE, stroke_width=6, stroke_fill=DARK)
            y += 110
        if sub:
            d.text((60, y + 10), sub, font=mp.font(44, 600), fill=WHITE, stroke_width=4, stroke_fill=DARK)
        d.text((60, im.height - 90), handle, font=mp.font(34, 700), fill=WHITE, stroke_width=3, stroke_fill=DARK)

    def ba_img(t, frac=0.5):
        b = fill(photo(t["before"], cache, "portrait", t.get("before_idx", 0)), W, 1350, 0.5) or grad(W, 1350, (190, 170, 150), (150, 120, 92))
        a = fill(photo(t["after"], cache, "portrait", t.get("after_idx", 0)), W, 1350, 0.5) or grad(W, 1350, (222, 232, 238), (196, 160, 118))
        cut = int(W * frac)
        im = a.copy()
        im.paste(b.crop((0, 0, cut, 1350)), (0, 0))
        d = ImageDraw.Draw(im)
        d.line((cut, 0, cut, 1350), fill=WHITE, width=8)
        d.ellipse((cut - 34, 675 - 34, cut + 34, 675 + 34), fill=WHITE)
        for txt, x, fl in (("BEFORE", 40, DARK), ("AFTER", W - 270, navy)):
            tw = d.textlength(txt, font=anton(56))
            d.rounded_rectangle((x, 40, x + tw + 50, 130), 16, fill=fl)
            d.text((x + 25, 50), txt, font=anton(56), fill=WHITE)
        if t.get("label"):
            d.text((W // 2, 1230), t["label"], font=anton(54), fill=WHITE, anchor="mm", stroke_width=6, stroke_fill=DARK)
        return im

    tiles, extra = [], {}
    for i, t in enumerate(spec["tiles"]):
        k = t["kind"]
        if k == "reel":
            im = bg_photo(t["photo"], 1350, 0.25, t.get("idx", 0))
            hook_box(im, 130, t["hook"])
        elif k == "ba":
            im = ba_img(t)
        elif k == "photo":
            im = bg_photo(t["photo"], 1350, 0.5, t.get("idx", 0))
            with_text(im, t["text"], t.get("sub"))
        elif k == "car":
            base = bg_photo(t["photo"], 1350, 0.5, t.get("idx", 0)) if t.get("photo") else None
            if base is not None:
                im = base.copy()
                with_text(im, t["headline"].upper(), "Swipe")
            else:
                im = carousel(f"c{i}", [{"type": "bigtext", "headline": t["headline"].upper(), "hi": t.get("hi", ""), "lines": ["Swipe."], "source": "invented example"}])[0]
            more = carousel(f"cm{i}", [
                {"type": "list", "headline": t.get("list_title", "KEEP THESE IN MIND"), "items": t["items"], "source": "invented example"},
                {"type": "bigtext", "headline": t.get("end", "SAVE THIS FOR LATER").upper(), "hi": t.get("end_hi", "SAVE"), "lines": [t.get("end_line", "Send it to a friend.")], "source": "invented example"}])
            extra[i] = [im] + more
        else:
            im = carousel(f"t{i}", [{"type": "bigtext", "headline": t["headline"].upper(), "hi": t.get("hi", ""), "lines": [t.get("line", "")] if t.get("line") else [], "source": "invented example"}])[0]
        tiles.append((k, im))

    def badge(im, kind):
        im = im.copy()
        d = ImageDraw.Draw(im)
        if kind == "reel":
            d.rounded_rectangle((950, 30, 1040, 120), 18, outline=WHITE, width=8)
            d.polygon([(975, 50), (975, 100), (1018, 75)], fill=WHITE)
        elif kind == "car":
            d.rectangle((960, 50, 1030, 110), outline=WHITE, width=8)
            d.rectangle((945, 38, 1015, 98), outline=WHITE, width=8)
        return im

    for i, (k, im) in enumerate(tiles):
        badge(im, k).resize((358, 448)).save(f"{out}/tiles/slides/slide-{i + 1:02d}.png")
    pspec = {"look": spec["look"], "handle": handle, "name": spec["name"], "category": spec["category"], "bio": spec["bio"],
             "highlights": spec["highlights"], "tiles": [k for k, _ in tiles]}
    mp.profile_image(pspec, out).save(work + "/profile.png")
    ih = Image.open(work + "/profile.png").height

    def post_view(img, caption):
        f = Image.new("RGB", (W, H), WHITE)
        d = ImageDraw.Draw(f)
        d.text((60, 85), "<", font=mp.font(60, 500), fill=(20, 20, 22), anchor="mm")
        d.text((540, 85), "Posts", font=mp.font(44, 700), fill=(20, 20, 22), anchor="mm")
        d.ellipse((40, 190, 130, 280), fill=ac)
        d.text((150, 215), handle.lstrip("@"), font=mp.font(34, 700), fill=(20, 20, 22))
        f.paste(img.resize((W, 1350)), (0, 320))
        y = 1710
        d.ellipse((50, y, 110, y + 56), outline=(20, 20, 22), width=5)
        d.ellipse((140, y, 200, y + 56), outline=(20, 20, 22), width=5)
        d.polygon([(250, y + 28), (320, y), (300, y + 56)], outline=(20, 20, 22), width=5)
        fc = mp.font(32, 500)
        cap = handle.lstrip("@") + "  " + caption
        while d.textlength(cap, font=fc) > 980:
            cap = cap[:-4].rstrip() + "..."
        d.text((50, y + 90), cap, font=fc, fill=(20, 20, 22))
        return f

    words = [(w, t) for w, t in spec["reel_words"]]
    chunks = spec["reel_chunks"]
    rt = tiles[spec["open"]["reel"]]
    rspec = spec["tiles"][spec["open"]["reel"]]
    rbg = bg_photo(rspec["photo"], H, 0.25, rspec.get("idx", 0))

    def reel_frame(t):
        im = rbg.copy()
        hook_box(im, 330, rspec["hook"])
        d = ImageDraw.Draw(im)
        cf = anton(112)
        act = [c for c in chunks if t >= words[c[0]][1]]
        if act:
            a, b = act[-1]
            ws = [w for w, _ in words[a:b]]
            cur = max(i for i, (w, tt) in enumerate(words[a:b]) if t >= tt)
            lines = [ws[:2], ws[2:]] if len(ws) > 2 else [ws]
            y, idx = 1290, 0
            for toks in lines:
                if not toks:
                    continue
                x = (W - d.textlength(" ".join(toks), font=cf)) / 2
                for tk in toks:
                    if idx <= cur:
                        d.text((x, y), tk, font=cf, fill=ac if idx == cur else WHITE, stroke_width=9, stroke_fill=DARK)
                    x += d.textlength(tk + " ", font=cf)
                    idx += 1
                y += 130
        d.rectangle((0, 1900, int(W * min(t / (words[-1][1] + 1.0), 1)), 1912), fill=ac)
        for yy in (1250, 1380, 1510):
            d.ellipse((960, yy - 38, 1036, yy + 38), outline=WHITE, width=5)
        d.text((50, 1700), handle.lstrip("@"), font=mp.font(40, 700), fill=WHITE, stroke_width=3, stroke_fill=DARK)
        d.text((50, 1760), (lambda x: x[:1].upper() + x[1:].lower())(" ".join(h.replace("*", "") for h in rspec["hook"])), font=mp.font(34, 500), fill=WHITE, stroke_width=3, stroke_fill=DARK)
        return im

    def frames_to_mp4(gen, n, path, fps=30):
        wd = work + "/fr"
        shutil.rmtree(wd, ignore_errors=True)
        os.makedirs(wd)
        for i in range(n):
            gen(i / fps).save(f"{wd}/f{i:04d}.png")
        run(["ffmpeg", "-y", "-loglevel", "error", "-framerate", str(fps), "-i", wd + "/f%04d.png", "-vf", "format=yuv420p", path])

    def still(img, secs, path):
        img.save(path + ".png")
        run(["ffmpeg", "-y", "-loglevel", "error", "-loop", "1", "-t", str(secs), "-i", path + ".png", "-vf", "fps=30,format=yuv420p", path])

    scroll = work + "/a.mp4"
    run(["ffmpeg", "-y", "-loglevel", "error", "-loop", "1", "-t", "7.5", "-i", work + "/profile.png", "-vf",
         f"crop={W}:{H}:0:'({ih}-{H})*(1-cos(PI*clip((t-0.8)/5.8,0,1)))/2',fps=30,format=yuv420p", scroll])
    reel = work + "/b.mp4"
    frames_to_mp4(reel_frame, int((words[-1][1] + 1.0) * 30), reel)
    rlen = int((words[-1][1] + 1.0) * 30) / 30
    bat = spec["tiles"][spec["open"]["ba"]]
    ba = work + "/c.mp4"
    frames_to_mp4(lambda t: post_view(ba_img(bat, 0.08 + 0.84 * (0.5 - 0.5 * math.cos(math.pi * min(max(t - 0.4, 0) / 2.6, 1)))), bat.get("caption", "Which look would you pick?")), 105, ba)
    ci = spec["open"]["car"]
    c1, c2 = work + "/d1.mp4", work + "/d2.mp4"
    cap = spec["tiles"][ci].get("caption", "Save it for later.")
    still(post_view(extra[ci][0], cap), 1.8, c1)
    still(post_view(extra[ci][1], cap), 1.8, c2)
    parts = [(scroll, 7.5), (reel, rlen), (ba, 3.5), (c1, 1.8), (c2, 1.8)]
    cur, curlen = parts[0]
    for i, (p, ln) in enumerate(parts[1:]):
        nxt = work + f"/x{i}.mp4"
        run(["ffmpeg", "-y", "-loglevel", "error", "-i", cur, "-i", p, "-filter_complex",
             f"xfade=transition={'fade' if i < 2 else 'slideleft'}:duration=0.45:offset={curlen - 0.45:.2f},format=yuv420p", nxt])
        cur, curlen = nxt, curlen - 0.45 + ln
    final = os.path.join(out, "account.mp4")
    shutil.copy(cur, final)
    shutil.rmtree(work, ignore_errors=True)
    print(final, "(real photos)" if stock else "(placeholders: no photo key found)")


if __name__ == "__main__":
    main()
