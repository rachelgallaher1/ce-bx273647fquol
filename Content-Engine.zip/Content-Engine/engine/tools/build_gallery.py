#!/usr/bin/env python3
"""Makes the add-in gallery: a short animated preview of every add-in, drawn by the real code.
Run with the engine's speech environment: python -I engine/tools/build_gallery.py [LOOK] [effect keys to (re)make, default all]"""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import first_edit as fe
import effects
from PIL import Image

out = os.path.join(HERE, "gallery")
os.makedirs(out, exist_ok=True)
look = fe.load_look(sys.argv[1] if len(sys.argv) > 1 else "1")
lib = fe.Lib(look)
W, H = fe.W, fe.H
bg = Image.new("RGBA", (W, H))
top, bot = (150, 160, 172), (96, 106, 118)
px = bg.load()
for y in range(H):
    t = y / H
    c = tuple(int(top[i] + (bot[i] - top[i]) * t) for i in range(3)) + (255,)
    for x in range(W):
        px[x, y] = c
from PIL import ImageDraw
d = ImageDraw.Draw(bg)
d.ellipse((W * 0.30, H * 0.46, W * 0.70, H * 0.46 + W * 0.40), fill=(86, 96, 108, 255))
d.pieslice((W * 0.10, H * 0.66, W * 0.90, H * 1.10), 180, 360, fill=(86, 96, 108, 255))
FPS_G = 12
meta = []
only = set(sys.argv[2:])
for key, spec in effects.EFFECTS.items():
    if only and key not in only:
        continue
    secs = spec["seconds"]
    n = int((secs + 0.7) * FPS_G)
    frames = []
    for i in range(n):
        t = i / FPS_G
        p = min(1.0, t / secs)
        fr = bg.copy()
        im = fe.shadowed(spec["fn"](lib, spec["default"], p), blur=14, dy=10, alpha=110)
        env = fe.env(min(t, secs - 0.05), 0, secs, tin=0.25, tout=0.25)
        fe.paste_center(fr, im, W // 2, int(H * 0.34), scale=spec.get("scale", fe.FXSCALE), alpha=env[1] if env else 1.0)
        frames.append(fr.resize((300, 533), Image.LANCZOS).convert("P", palette=Image.ADAPTIVE))
    frames[0].save(os.path.join(out, key + ".gif"), save_all=True, append_images=frames[1:], duration=int(1000 / FPS_G), loop=0, optimize=True)
    meta.append({"key": key, "label": spec["label"], "about": spec["about"], "default": spec["default"]})
    print("made", key, len(frames), "frames")
gp = os.path.join(out, "gallery.json")
old = {m["key"]: m for m in (json.load(open(gp, encoding="utf-8")) if os.path.exists(gp) else [])}
for m in meta:
    old[m["key"]] = m
json.dump([old[k] for k in effects.EFFECTS if k in old], open(gp, "w", encoding="utf-8"), indent=1)
