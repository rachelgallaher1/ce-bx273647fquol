#!/usr/bin/env python3
"""Text reel: a reel with no footage. Her words on her brand colors or her own photos, a few frames, gentle motion, her voice or music under it.
  python make_text_reel.py SPEC.json [--voice VOICE.m4a] [--music MUSIC.mp3] [--out NAME]
SPEC.json: {"title": "short-name", "frames": [{"text": "I spent 6 months planning posts", "hi": "6 months", "bg": "brand|photo|#RRGGBB|path/to/pic.jpg", "secs": 3.2}, ...],
            "caption": "the post caption", "font": "Poppins-ExtraBold.ttf"}
3 to 8 frames. The first frame is the hook. `hi` is the part of the words shown in her accent color. `bg` is optional: by default frames use her brand colors in turn;
"photo" uses her brand photos in turn. With a voice recording, frame lengths follow how many words each frame has. Result: customer/content/text-reels/NAME.mp4 and NAME.caption.txt.
Keeps words out of the top, the bottom and the right edge, where Instagram puts its own buttons. Her photos and recordings are never changed.
"""
import json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
FONTS = os.path.join(ROOT, "engine", "fonts")
W, H, FPS = 1080, 1920, 30
XF = 0.3   # crossfade seconds


def sh(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        raise RuntimeError((r.stderr or r.stdout).strip().splitlines()[-1] if (r.stderr or r.stdout).strip() else "ffmpeg failed")
    return r


def hex_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def luminance(c):
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]


def brand():
    p = os.path.join(ROOT, "customer", "profile", "brand.json")
    d = json.load(open(p, encoding="utf-8")) if os.path.exists(p) else {}
    cols = [hex_rgb(c["hex"] if isinstance(c, dict) else c) for c in d.get("colors", [])] or [(42, 110, 111), (214, 140, 100), (31, 31, 31)]
    photos = [os.path.join(ROOT, "customer", "profile", "brand", "photos", f) for f in d.get("photos", [])]
    photos = [x for x in photos if os.path.exists(x)]
    return cols, photos, hex_rgb(d.get("dark", "#1F1F1F"))


def font(size, name):
    from PIL import ImageFont
    path = os.path.join(FONTS, name)
    if not os.path.exists(path):
        path = os.path.join(FONTS, "Poppins-ExtraBold.ttf")
    return ImageFont.truetype(path, size)


def wrap(draw, words, f, maxw):
    lines, cur = [], []
    for w in words:
        t = " ".join(cur + [w])
        if draw.textlength(t, font=f) <= maxw or not cur:
            cur.append(w)
        else:
            lines.append(cur)
            cur = [w]
    if cur:
        lines.append(cur)
    return lines


def make_frame(i, fr, cols, photos, dark, fontname, outdir):
    from PIL import Image, ImageDraw, ImageFilter
    bg = (fr.get("bg") or "brand").strip()
    if bg.startswith("#"):
        base = Image.new("RGB", (W, H), hex_rgb(bg))
        bgc = hex_rgb(bg)
    elif bg == "photo" and photos or (bg not in ("brand", "photo") and os.path.exists(bg)):
        src = photos[i % len(photos)] if bg == "photo" else bg
        im = Image.open(src).convert("RGB")
        k = max(W / im.width, H / im.height)
        im = im.resize((int(im.width * k) + 1, int(im.height * k) + 1))
        im = im.crop(((im.width - W) // 2, (im.height - H) // 2, (im.width - W) // 2 + W, (im.height - H) // 2 + H))
        veil = Image.new("RGB", (W, H), (0, 0, 0))
        base = Image.blend(im, veil, 0.45)
        bgc = None
    else:
        bgc = cols[i % len(cols)] if i else cols[0]
        base = Image.new("RGB", (W, H), bgc)
    light_bg = bgc is not None and luminance(bgc) > 150
    ink = (25, 25, 28) if light_bg else (255, 255, 255)
    accent = next((c for c in cols if bgc is None or abs(luminance(c) - luminance(bgc)) > 70), (255, 220, 120))
    if bgc is not None and accent == bgc:
        accent = (255, 255, 255) if not light_bg else (25, 25, 28)
    d = ImageDraw.Draw(base)
    text = fr["text"].strip()
    size = 132 if i == 0 else 120
    maxw = 840   # keeps clear of the right-hand buttons
    f = font(size, fontname)
    words = text.split()
    lines = wrap(d, words, f, maxw)
    while len(lines) > 6 and size > 60:
        size -= 6
        f = font(size, fontname)
        lines = wrap(d, words, f, maxw)
    hi = [h.lower().strip(".,!?") for h in re.split(r"\s+", fr.get("hi", "") or "") if h]
    lh = int(size * 1.28)
    total = lh * len(lines)
    y = 330 + (1260 - total) // 2   # centered in the safe middle (top 330 and bottom 330 stay clear)
    x0 = 90
    for ln in lines:
        lw = sum(d.textlength(w + " ", font=f) for w in ln) - d.textlength(" ", font=f)
        x = x0 + (maxw - lw) / 2
        for w in ln:
            hit = w.lower().strip(".,!?") in hi
            if hit:
                pad = 12
                tw = d.textlength(w, font=f)
                d.rounded_rectangle((x - pad, y + 4, x + tw + pad, y + lh - 8), radius=18, fill=accent)
                col = (25, 25, 28) if luminance(accent) > 150 else (255, 255, 255)
            else:
                col = ink
            d.text((x, y), w, font=f, fill=col)
            x += d.textlength(w + " ", font=f)
        y += lh
    path = os.path.join(outdir, f"frame{i + 1:02d}.png")
    base.save(path)
    return path


def audio_len(p):
    return float(sh(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p]).stdout.strip())


def main():
    a = sys.argv[1:]
    if not a or a[0].startswith("-"):
        sys.exit(__doc__)
    spec = json.load(open(a[0], encoding="utf-8"))
    frames = spec["frames"]
    if not 2 <= len(frames) <= 10:
        sys.exit("A text reel needs 2 to 10 frames (3 to 8 works best).")
    voice = a[a.index("--voice") + 1] if "--voice" in a else None
    music = a[a.index("--music") + 1] if "--music" in a else None
    name = a[a.index("--out") + 1] if "--out" in a else re.sub(r"[^A-Za-z0-9_-]+", "-", spec.get("title", "text-reel"))
    outdir = os.path.join(ROOT, "customer", "content", "text-reels")
    work = os.path.join(outdir, f".{name}_work")
    os.makedirs(work, exist_ok=True)
    cols, photos, dark = brand()
    fontname = spec.get("font", "Poppins-ExtraBold.ttf")
    secs = [max(1.6, float(fr.get("secs", 3.0))) for fr in frames]
    if voice:
        dur = audio_len(voice)
        wc = [max(2, len(fr["text"].split())) for fr in frames]
        secs = [max(1.6, dur * c / sum(wc)) for c in wc]
    imgs = [make_frame(i, fr, cols, photos, dark, fontname, work) for i, fr in enumerate(frames)]
    cmd = ["ffmpeg", "-y", "-loglevel", "error"]
    for im, s in zip(imgs, secs):
        cmd += ["-loop", "1", "-t", f"{s + XF:.3f}", "-i", im]
    parts, last = [], None
    for k, s in enumerate(secs):
        frames_n = int((s + XF) * FPS)
        zin = k % 2 == 0
        z = "min(zoom+0.0006,1.07)" if zin else "if(eq(on,1),1.07,max(zoom-0.0006,1.0))"
        parts.append(f"[{k}:v]scale=2160:3840,zoompan=z='{z}':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d={frames_n}:s={W}x{H}:fps={FPS},setsar=1,format=yuv420p[v{k}]")
    cur, t = "v0", 0.0
    for k in range(1, len(secs)):
        t += secs[k - 1]
        parts.append(f"[{cur}][v{k}]xfade=transition=fade:duration={XF}:offset={t:.3f}[x{k}]")
        cur = f"x{k}"
    total = sum(secs)
    fc = ";".join(parts)
    out = os.path.join(outdir, name + ".mp4")
    n_in = len(imgs)
    cmd2 = cmd[:]
    if voice:
        cmd2 += ["-i", voice]
    if music:
        cmd2 += ["-stream_loop", "-1", "-i", music]
    amap = []
    if voice and music:
        fc += f";[{n_in}:a]apad[va];[{n_in + 1}:a]volume=0.14[ma];[va][ma]amix=inputs=2:duration=first:normalize=0[aout]"
        amap = ["-map", "[aout]"]
    elif voice:
        fc += f";[{n_in}:a]apad[aout]"
        amap = ["-map", "[aout]"]
    elif music:
        fc += f";[{n_in}:a]volume=0.5,afade=t=out:st={max(0, total - 1):.2f}:d=1[aout]"
        amap = ["-map", "[aout]"]
    else:
        cmd2 += ["-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo"]
        amap = ["-map", f"{n_in}:a"]
    cmd2 += ["-filter_complex", fc, "-map", f"[{cur}]"] + amap + ["-t", f"{total:.2f}", "-r", str(FPS), "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
                                                               "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out]
    sh(cmd2)
    cap = spec.get("caption", "")
    if cap:
        open(os.path.join(outdir, name + ".caption.txt"), "w", encoding="utf-8").write(cap + "\n")
    for f in os.listdir(work):
        os.remove(os.path.join(work, f))
    os.rmdir(work)
    print(f"Made {out} ({total:.1f} seconds, {len(frames)} frames).")
    if not voice and not music:
        print("NOTE: no voice or music, so it is silent. Add her voice with --voice, or pick sound in Instagram when you post.")


main()
