#!/usr/bin/env python3
"""Help packet: one plain file that shows what is going on with her setup, so support can fix it without a back-and-forth.
  python help_packet.py ["what she was trying to do"]
Collects: her computer and Python, the engine version, the setup check, tool versions, the last lines of her newest build logs, and the engine's refresh check.
Never includes her voice profile, scripts, videos, plans or captions. Her home folder name is hidden. Saves customer/help-packet.md. She reads it, then sends it."""
import datetime, glob, os, platform, shutil, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
HOME = os.path.expanduser("~")


def clean(t):
    return (t or "").replace(HOME, "~").replace(os.path.basename(HOME), "USER")


def run(cmd, n=12):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60)
        return clean("\n".join(((r.stdout or "") + (r.stderr or "")).strip().splitlines()[-n:]))
    except Exception as e:
        return f"(could not run: {e})"


def main():
    what = " ".join(sys.argv[1:]).strip()
    out = ["# Help packet", "", f"Made: {datetime.datetime.now().isoformat(timespec='seconds')}", ""]
    if what:
        out += ["## What she was trying to do", what, ""]
    try:   # the problems Claude already tried to fix on this computer (short plain lines only, never her words)
        import help_log
        rows = help_log.recent(10)
        if rows:
            out += ["## Recent problems and what happened", ""]
            out += [f"- {r['date']} [{r['area']}] {r['problem']} (tried: {r['tried']}) -> {r['result']}" for r in rows]
            out += [""]
    except Exception:
        pass
    ver = os.path.join(ROOT, "engine", "VERSION")
    out += ["## Her computer", f"- System: {platform.system()} {platform.release()} ({platform.machine()})", f"- Python running this: {platform.python_version()}",
            f"- Engine version: {open(ver, encoding='utf-8').read().strip() if os.path.exists(ver) else 'unknown'}",
            f"- ffmpeg: {(run(['ffmpeg', '-version'], 40).splitlines() or ['?'])[0] if shutil.which('ffmpeg') else 'NOT FOUND'}", ""]
    out += ["## Setup check", "```", run([sys.executable, os.path.join(HERE, "check_setup.py")], 30), "```", ""]
    logs = sorted(glob.glob(os.path.join(ROOT, "customer", "videos", "edited", "*_build.log")), key=os.path.getmtime)[-2:]
    for lg in logs:
        try:
            tail = "\n".join(open(lg, encoding="utf-8", errors="replace").read().strip().splitlines()[-15:])
        except Exception:
            tail = "(could not read)"
        out += [f"## Last lines of {os.path.basename(lg)}", "```", clean(tail), "```", ""]
    rc = os.path.join(ROOT, "customer", "insights", "refresh-check.md")
    if os.path.exists(rc):
        out += ["## Sunday refresh check", open(rc, encoding="utf-8").read().strip(), ""]
    out += ["---", "This file has no scripts, videos, plans, captions or voice profile in it. Read it before you send it."]
    dest = os.path.join(ROOT, "customer", "help-packet.md")
    open(dest, "w", encoding="utf-8").write("\n".join(out) + "\n")
    print("Saved", dest)


main()
