"""Pre-flight check: is everything the video tools need installed?
Run with any Python 3:  python3 engine/tools/check_setup.py
Prints one plain line per item and a final line: READY or NOT READY (with the fix code).
"""
import os, shutil, subprocess, sys, platform

VENV = os.path.expanduser("~/.cache/content-engine/whisper-venv")
PY = os.path.join(VENV, "Scripts" if platform.system() == "Windows" else "bin",
                  "python.exe" if platform.system() == "Windows" else "python")

def line(ok, name, fix=""):
    print(("OK      " if ok else "MISSING ") + name + ("" if ok else "  [" + fix + "]"))
    return ok

def main():
    results = []
    results.append(line(shutil.which("ffmpeg") is not None, "ffmpeg (video tool)", "F1"))
    results.append(line(shutil.which("ffprobe") is not None, "ffprobe (video info)", "F1"))
    venv_ok = os.path.exists(PY)
    results.append(line(venv_ok, "helper Python space", "F2"))
    if venv_ok:
        checks = [("faster_whisper", "speech-to-text", "F3"),
                  ("cv2", "face finder", "F3"),
                  ("mediapipe", "person cutout (GIFs behind her)", "F3"),
                  ("PIL", "image drawing", "F3"),
                  ("av", "video reader", "F3"),
                  ("numpy", "number tool", "F3")]
        for mod, name, fix in checks:
            r = subprocess.run([PY, "-X", "utf8", "-I", "-c", "import " + mod], capture_output=True)
            results.append(line(r.returncode == 0, name, fix))
        r = subprocess.run([PY, "-X", "utf8", "-I", "-c", "import cv2,sys;sys.exit(0 if cv2.__version__.startswith('4.') else 1)"], capture_output=True)
        results.append(line(r.returncode == 0, "face finder is the right version (4.x)", "F4"))
        r = subprocess.run([PY, "-X", "utf8", "-I", "-c", "import numpy,sys;sys.exit(0 if int(numpy.__version__.split('.')[0])<2 else 1)"], capture_output=True)
        results.append(line(r.returncode == 0, "number tool is the right version (1.x)", "F4"))
    here = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
    low = here.lower()
    synced = [w for w in ("/desktop", "/documents", "icloud", "onedrive", "dropbox", "google drive", "\\desktop", "\\documents") if w in low]
    results.append(line(not synced, "engine folder is in a safe place (not Desktop, Documents, or a synced folder)", "F6"))
    results.append(line(os.path.isdir(os.path.join(here, "inbox")), "inbox folder found", "F7"))
    free_gb = shutil.disk_usage(os.path.expanduser("~")).free / 1e9
    results.append(line(free_gb >= 5, "free disk space (%.0f GB, need 5 or more)" % free_gb, "F5"))
    print("READY" if all(results) else "NOT READY")
    sys.exit(0 if all(results) else 1)

main()
