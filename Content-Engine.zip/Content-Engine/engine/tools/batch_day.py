#!/usr/bin/env python3
"""Batch day: film a whole week in one sitting, drop every clip in at once, get every video edited and ONE page to review them.
  python3 batch_day.py guide [--week N] [--locations "desk,couch"] [--outfits 4]     the one-page batch day guide for the week (customer/plans/batch-day.html and .md)
  python3 batch_day.py serve [--outfits 4]   the batch page with a drop box (drop clips, it does the rest). Prints the link to give her
  python3 batch_day.py match                match every new clip in customer/videos/recorded/ to the script it was filmed from
  python3 batch_day.py assign CLIP POST     she confirms which post a clip was filmed for (when I was not sure)
  python3 batch_day.py edit-all             edit every matched clip (her saved look), file each one in the plan, and write the review page
  python3 batch_day.py review               rewrite the review page only (customer/plans/batch-review.html)
Matching listens to each clip and compares the words with the week's scripts. If it is not sure, it says so and asks her to confirm.
Nothing is posted, deleted or renamed. Her original recordings are never touched.
"""
import time, shutil, datetime, difflib, glob, html, json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import make_calendar as mc
import plan as pl

ROOT = pl.ROOT
PLANS = os.path.join(ROOT, "customer", "plans")
REC = os.path.join(ROOT, "customer", "videos", "recorded")
EDIT = os.path.join(ROOT, "customer", "videos", "edited")
MAP = os.path.join(PLANS, "batch-map.json")
PY = os.path.join(os.path.expanduser("~"), ".cache", "content-engine", "whisper-venv", *(("Scripts", "python.exe") if sys.platform.startswith("win") else ("bin", "python")))
VIDEO_EXT = (".mov", ".mp4", ".m4v")


def norm_words(t):
    return [w for w in re.findall(r"[a-z0-9']+", t.lower())]


def script_parts(path):
    """(hook_said, spoken_text) from a script file. Stage cues in [brackets] are removed."""
    txt = open(path, encoding="utf-8").read()
    m = re.search(r"^## Script[^\n]*\n(.*?)(?=^## |\Z)", txt, re.S | re.M)
    spoken = m.group(1) if m else ""
    spoken = re.sub(r"\[[^\]]*\]", " ", spoken)
    h = re.search(r"\*\*Said:\*\*\s*(.+)", txt)
    return (h.group(1).strip() if h else ""), re.sub(r"\s+", " ", spoken).strip()


def week_rows(week=None):
    path = pl.plan_path()
    rows = pl.rows_of(path)
    first = rows[0]["d"] if rows else datetime.date.today()
    today = datetime.date.today()
    if week is None:
        # the first week that still has video posts ready to film
        for r in rows:
            if r["state"] == "ready" and "video" in r["format"].lower() and r["script"]:
                week = pl.week_no(r, first)
                break
    sel = [r for r in rows if week is not None and pl.week_no(r, first) == week and r["state"] == "ready" and r["script"] and os.path.exists(r["script"])
           and any(k in r["format"].lower() for k in ("video", "reel", "b-roll", "broll"))]
    return week, sel


def minutes_for(spoken):
    n = len(spoken.split())
    return max(3, round(n / 2.4 / 60 * 2.2 + 2.5))  # talk time with retakes, plus a reset between videos


DROP_JS = r'''
if(location.protocol==="file:"){document.getElementById("dzFile").style.display="block";document.getElementById("dzLive").style.display="none"}
(function(){var drop=document.getElementById("drop"),pick=document.getElementById("pick"),list=document.getElementById("dzList"),go=document.getElementById("goBtn"),msg=document.getElementById("dzMsg"),ask=document.getElementById("dzAsk");if(!drop)return;
var sent=[];
function up(f){var li=document.createElement("div");li.textContent=f.name+" ... sending";list.appendChild(li);
  return fetch("/api/drop?name="+encodeURIComponent(f.name),{method:"POST",body:f}).then(function(r){return r.json()}).then(function(j){li.textContent=f.name+(j.ok?" ... ready":" ... did not send");if(j.ok){sent.push(f.name);go.style.display="inline-block"}}).catch(function(){li.textContent=f.name+" ... did not send"})}
function take(files){Array.prototype.forEach.call(files,function(f){if(/^video\//.test(f.type)||/\.(mov|mp4|m4v)$/i.test(f.name))up(f)})}
drop.onclick=function(){pick.click()};pick.onchange=function(){take(pick.files)};
drop.ondragover=function(e){e.preventDefault();drop.classList.add("over")};drop.ondragleave=function(){drop.classList.remove("over")};
drop.ondrop=function(e){e.preventDefault();drop.classList.remove("over");take(e.dataTransfer.files)};
function poll(){fetch("/api/status").then(function(r){return r.json()}).then(function(s){msg.textContent=s.message||"";
  if(s.state==="ask"){ask.innerHTML="";s.unsure.forEach(function(u){var d=document.createElement("div");d.style.margin="8px 0";d.appendChild(document.createTextNode(u.file+" is which video? "));var sel=document.createElement("select");u.options.forEach(function(o){var op=document.createElement("option");op.value=o.n;op.textContent=o.idea;sel.appendChild(op)});d.appendChild(sel);var b=document.createElement("button");b.textContent="That one";b.onclick=function(){fetch("/api/assign",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({file:u.file,post:sel.value})}).then(function(){d.remove();if(!ask.children.length){fetch("/api/go",{method:"POST"}).then(poll)}})};d.appendChild(b);ask.appendChild(d)});return}
  if(s.state==="working"){setTimeout(poll,2500)}
  else if(s.state==="done"){ask.innerHTML='<p><b>All done.</b></p><a class="primary" style="display:inline-block;text-decoration:none;padding:12px 20px;border-radius:10px;background:var(--teal);color:#fff;font-weight:700" href="/review">Look at your videos</a>'}
  })}
go.onclick=function(){go.style.display="none";msg.textContent="Starting...";fetch("/api/go",{method:"POST"}).then(function(){poll()})};
})();
'''


GENERIC_SHOTS = [
    ("30 seconds of you typing or working", 30),
    ("Walk-in shot: you walking into the room and sitting down", 6),
    ("Close-up of your hands (writing, holding your phone, a cup)", 5),
    ("Slow pan across your workspace", 6),
    ("You looking at your phone and reacting (smile, eyebrow, laugh)", 5),
    ("A wide shot of you in the space, not talking", 6),
    ("Over-the-shoulder shot of your screen", 6),
    ("A close-up of the thing you sell or use every day", 5),
]


def cue_shots(scripts):
    """Shots the scripts themselves ask for: [b-roll: ...] or [film ...] cues in the spoken part."""
    out = []
    for p in scripts:
        txt = open(p, encoding="utf-8").read()
        for c in re.findall(r"\[((?:b-?roll|film)[^\]]*)\]", txt, re.I):
            c = re.sub(r"^(b-?roll|film)\s*:?\s*", "", c.strip(), flags=re.I)
            if c and c not in [x[0] for x in out]:
                out.append((c[:1].upper() + c[1:], 5))
    return out


NUMWORDS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10, "eleven": 11, "twelve": 12,
            "thirteen": 13, "fourteen": 14, "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19, "twenty": 20}


def field(path, name):
    m = re.search(r"\*\*" + name + r":\*\*\s*([^\n]+)", open(path, encoding="utf-8").read(), re.I)
    return m.group(1).strip() if m else ""


def slate_number(text):
    """If she said a number in her first few words ("seven"), that is the post number (the slate)."""
    toks = norm_words(text)[:4]
    for t in toks:
        if t.isdigit():
            return int(t)
        if t in NUMWORDS:
            return NUMWORDS[t]
    return None


def outfit_plan(items, n_outfits):
    """Cycle outfits by POSTING order so two posting days in a row never wear the same top."""
    by_date = sorted(items, key=lambda i: i["date"])
    for k, i in enumerate(by_date):
        i["outfit"] = (k % n_outfits) + 1


def blocks(items, block_min=45, brk=5):
    out, cur, t = [], [], 0
    for i in items:
        if cur and t + i["mins"] > block_min:
            out.append(cur)
            cur, t = [], 0
        cur.append(i)
        t += i["mins"]
    if cur:
        out.append(cur)
    return out


def guide(week=None, locations=None, outfits=0):
    week, rows = week_rows(week)
    if not rows:
        print("I don't see any ready video scripts to film. Build the week's scripts first, then run this again.")
        return
    items = []
    for r in rows:
        said, spoken = script_parts(r["script"])
        flex = "flex" in (r["idea"] + " " + r["why"] + " " + r["job"]).lower()
        items.append({"n": r["n"], "date": r["date"], "idea": r["idea"], "hook": said, "spoken": spoken, "script": r["script"], "mins": minutes_for(spoken),
                      "setting": field(r["script"], "Setting") or "one spot", "props": [x.strip() for x in re.split(r"[,;]", field(r["script"], "Props")) if x.strip()], "flex": flex})
    flex_items = [i for i in items if i["flex"]]
    items = [i for i in items if not i["flex"]]
    # shoot order is NOT post order: group by setting so setup changes happen as few times as possible, keep post order inside each setting
    order = []
    for st in dict.fromkeys(i["setting"] for i in sorted(items, key=lambda i: i["date"])):
        order += [i for i in sorted(items, key=lambda i: i["date"]) if i["setting"] == st]
    items = order
    if outfits and outfits > 1:
        outfit_plan(items, outfits)
    props = list(dict.fromkeys(p for i in items for p in i["props"]))
    total = sum(i["mins"] for i in items) + 10
    os.makedirs(PLANS, exist_ok=True)
    md = [f"# Batch day: week {week}", "", f"{len(items)} videos, about {total} minutes including setup. Film them in this order. Do not edit as you go.", ""]
    if props:
        md += ["## Put these on the table first", ", ".join(props), ""]
    for bi, blk in enumerate(blocks(items), 1):
        md += [f"## Part {bi}: about {sum(x['mins'] for x in blk)} minutes, then a short break", ""]
        for i in blk:
            k = items.index(i) + 1
            md += [f"### Video {k}: {i['idea']}", f"- [ ] Filmed", f"- Posts on {i['date']}" + (f". Wear top {i['outfit']}." if i.get("outfit") else "."),
                   f"- Where: {i['setting']}" if i["setting"] != "one spot" else "",
                   f"1. Press record. First, say the number: \"{i['n']}\". (That's how I know which video this is.)",
                   f"2. Then start with: \"{i['hook']}\"",
                   f"3. Halfway through, stop talking for one second and look at the camera. That moment becomes your cover picture.",
                   f"4. Finish the script, wait one second, and press stop.",
                   ("5. Now record the next one." if items.index(i) + 1 < len(items) else "5. That was the last one. You are done filming!"), ""]
        md = [x for x in md if x != ""] if False else md
    if flex_items:
        md += ["## Do not film these today", "They film in their own week: " + ", ".join(f"post {i['n']} ({i['idea']})" for i in flex_items), ""]
    locs = [x.strip() for x in (locations or "").split(",") if x.strip()] or ["where you film"]
    shots = cue_shots([i["script"] for i in items]) + GENERIC_SHOTS
    md += ["## While you are set up: extra shots (10 minutes)", "Shot once, used all month in edits, carousels and B-roll reels. Hold the phone steady, vertical."]
    for loc in locs:
        md += ["", f"### {loc}"] + [f"- [ ] {t} ({sec} seconds)" for t, sec in shots]
    md += ["", "Save them in your inbox folder called broll, then tell Claude: label my B-roll.", ""]
    md += ["## When you are done", "Drop every clip in your inbox at once and say: edit my batch."]
    open(os.path.join(PLANS, "batch-day.md"), "w", encoding="utf-8").write("\n".join(md) + "\n")
    cards = ""
    for bi, blk in enumerate(blocks(items), 1):
        cards += f'<h3 class="blk">Part {bi}: about {sum(x["mins"] for x in blk)} minutes, then a short break</h3>'
        for i in blk:
            k = items.index(i) + 1
            where = f' · Where: {html.escape(i["setting"])}' if i["setting"] != "one spot" else ""
            wear = f' · Wear top {i["outfit"]}' if i.get("outfit") else ""
            cards += (f'<section class="card"><label class="chk"><input type="checkbox" data-k="{k}"> <b>Video {k}: {html.escape(i["idea"])}</b></label>'
                      f'<div class="meta"><span class="pill">Posts {i["date"]}</span>' + (f'<span class="pill">Wear top {i["outfit"]}</span>' if i.get("outfit") else "") + (f'<span class="pill">{html.escape(i["setting"])}</span>' if i["setting"] != "one spot" else "") + f'<span class="pill">about {i["mins"]} min</span></div>'
                      f'<ol class="steps"><li>First, say the number <b>{i["n"]}</b> out loud. That is how I know which video this is.</li>'
                      f'<li>Then start with: <b>&ldquo;{html.escape(i["hook"])}&rdquo;</b></li>'
                      f'<li>Halfway through, stop talking for one second and look at the camera. That moment becomes your cover picture.</li>'
                      f'<li>Then finish the script, wait one second, and press stop.</li>'
                      f'<li><b>{"Now record the next one. Go back to the top of the next video and do the same three steps." if k < len(items) else "That was the last one. You are done filming!"}</b></li></ol>'
                      f'<details><summary>Show the whole script</summary><p>{html.escape(i["spoken"])}</p></details></section>')
    if props:
        cards = f'<section class="card"><b style="font-size:19px">Put these on the table first</b><div class="meta" style="margin-left:0">{html.escape(", ".join(props))}</div></section>' + cards
    if flex_items:
        cards += '<section class="card"><b>Do not film these today</b><div class="meta" style="margin-left:0">They film in their own week: ' + html.escape(", ".join(f"post {i['n']} ({i['idea']})" for i in flex_items)) + '</div></section>'
    extra = '<h2>Extra shots while you are set up</h2><p class="sub">About 10 minutes. Shot once, used all month in your edits, carousels and B-roll reels. Hold the phone steady and vertical.</p>'
    for li, loc in enumerate(locs):
        extra += f'<section class="card"><b style="font-size:19px">{html.escape(loc)}</b><div class="shots">' + "".join(
            f'<label class="rdy" style="font-size:16px"><input type="checkbox" data-b="{li}_{si}"><span>{html.escape(t)} <span class="pill">{sec} sec</span></span></label>' for si, (t, sec) in enumerate(shots)) + "</div></section>"
    extra += '<p class="sub">Save these in your inbox folder called <b>broll</b>, then tell Claude: <b>label my B-roll</b>.</p>'
    import base64
    tpl = open(os.path.join(HERE, "batch_day_template.html"), encoding="utf-8").read()
    fp = os.path.join(ROOT, "engine", "fonts", "Anton-Regular.ttf")
    font = base64.b64encode(open(fp, "rb").read()).decode() if os.path.exists(fp) else ""
    page = (tpl.replace("__FONT__", font).replace("__WEEK__", str(week)).replace("__COUNT__", str(len(items))).replace("__TOTAL__", str(total))
            .replace("__CARDS__", cards).replace("__EXTRA__", extra).replace("__DROPJS__", DROP_JS))
    open(os.path.join(PLANS, "batch-day.html"), "w", encoding="utf-8").write(page)
    print(f"Wrote customer/plans/batch-day.html ({len(items)} videos, about {total} minutes).")


def load_map():
    return json.load(open(MAP, encoding="utf-8")) if os.path.exists(MAP) else {}


def save_map(m):
    os.makedirs(PLANS, exist_ok=True)
    json.dump(m, open(MAP, "w", encoding="utf-8"), indent=1)


def clips():
    out = []
    for f in sorted(os.listdir(REC)) if os.path.isdir(REC) else []:
        if f.lower().endswith(VIDEO_EXT) and not f.startswith("."):
            out.append(os.path.join(REC, f))
    return out


def transcript_words(video):
    import first_edit as fe
    name = os.path.splitext(os.path.basename(video))[0]
    work = os.path.join(EDIT, f".{name}_work")
    os.makedirs(work, exist_ok=True)
    data = fe.transcribe(video, os.path.join(work, "words.json"), "")
    return " ".join(w["w"] for w in data["words"])


def score(said_text, spoken):
    a, b = norm_words(said_text), norm_words(spoken)
    if not a or not b:
        return 0.0
    head = " ".join(a[:40])
    s1 = difflib.SequenceMatcher(None, head, " ".join(b[:40])).ratio()
    sa, sb = set(a), set(b)
    s2 = len(sa & sb) / max(1, len(sa | sb))
    return 0.6 * s1 + 0.4 * s2


def match(week=None, only=None):
    week, rows = week_rows(week)
    if not rows:
        print("I don't see this week's video scripts, so I can't match clips yet.")
        return
    scripts = [(r, script_parts(r["script"])[1]) for r in rows]
    scripts_by_n = [(r["n"], sp) for r, sp in scripts]
    m = load_map()
    new = [c for c in clips() if os.path.basename(c) not in m and (only is None or os.path.basename(c) in only)]
    if not new:
        print("No new clips to match.")
    taken = {v["post"] for v in m.values() if v.get("post")}
    for c in new:
        words = transcript_words(c)
        sl = slate_number(words)
        slate_row = next((r for r, sp in scripts if r["n"] == sl), None) if sl else None
        ranked = sorted(((score(words, sp), r) for r, sp in scripts if r["n"] not in taken), key=lambda x: -x[0])
        if not ranked:
            ranked = sorted(((score(words, sp), r) for r, sp in scripts), key=lambda x: -x[0])
        best, r = ranked[0]
        second = ranked[1][0] if len(ranked) > 1 else 0
        sure = best >= 0.35 and best - second >= 0.08
        if slate_row is not None and score(words, dict(scripts_by_n)[slate_row["n"]]) >= 0.2:
            r, best, sure = slate_row, max(best, 0.9), True
        # a second take of the same script: keep the more complete one, never delete the other
        twin = next((k for k, v in m.items() if v.get("post") == r["n"] and v.get("sure") and sure), None)
        entry = {"post": r["n"], "idea": r["idea"], "script": r["script"], "score": round(best, 2), "sure": bool(sure)}
        if twin:
            if best > m[twin]["score"]:
                m[twin]["alt"] = True
                m[twin]["sure"] = False
                m[twin]["score"] = m[twin]["score"]
            else:
                entry["alt"] = True
                entry["sure"] = False
                sure = False
        m[os.path.basename(c)] = entry
        if sure:
            taken.add(r["n"])
        print(f"{os.path.basename(c)} -> post {r['n']} \"{r['idea']}\"" + ("" if sure else "   (not sure: please confirm)"))
    save_map(m)
    have = {v["post"] for v in m.values() if v.get("sure") or v.get("edited")}
    need = [r for r, _ in scripts]
    miss = [r for r in need if r["n"] not in have]
    print(f"\n{len(need) - len(miss)} of {len(need)} filmed." + (" Missing: " + ", ".join(f"post {r['n']} ({r['idea']})" for r in miss) + ". Film them, or I can go ahead without them." if miss else " Nothing missing."))
    alts = [k for k, v in m.items() if v.get("alt")]
    if alts:
        print("Second takes kept aside (nothing deleted): " + ", ".join(alts))


def assign(clip, post):
    """She confirms which script a clip was filmed from."""
    m = load_map()
    _, rows = week_rows(None)
    rows = rows or []
    allrows = pl.rows_of(pl.plan_path())
    r = next((x for x in allrows if x["n"] == int(post)), None)
    if not r or not r["script"]:
        sys.exit(f"I can't find a script for post {post}.")
    name = clip if clip in m else next((k for k in m if k.startswith(os.path.splitext(clip)[0])), clip)
    m[name] = {"post": r["n"], "idea": r["idea"], "script": r["script"], "score": 1.0, "sure": True}
    save_map(m)
    print(f"Matched {name} to post {r['n']}: {r['idea']}.")


def edit_all():
    m = load_map()
    allrows = {r["n"]: r["date"] for r in pl.rows_of(pl.plan_path())}
    todo = sorted([(f, v) for f, v in m.items() if v.get("sure") and not v.get("edited") and not v.get("alt")], key=lambda fv: allrows.get(fv[1]["post"], ""))
    if not todo:
        print("Nothing matched and ready to edit. Run match first, and confirm any clip I was not sure about.")
        return
    look_args = []
    tj = os.path.join(ROOT, "customer", "profile", "templates.json")
    if os.path.exists(tj):
        t = json.load(open(tj, encoding="utf-8"))
        if t.get("look"):
            look_args = ["--look", str(t["look"])]
    for f, v in todo:
        print(f"Editing {f} ...", flush=True)
        cmd = [PY, "-X", "utf8", "-I", os.path.join(HERE, "first_edit.py"), os.path.join(REC, f), "--script", v["script"], "--no-sheet"] + look_args
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        name = os.path.splitext(f)[0]
        outs = sorted(glob.glob(os.path.join(EDIT, f"{name}_edit*.mp4")), key=lambda p: int(re.search(r"_edit(\d+)\.mp4", p).group(1)))
        if r.returncode != 0 or not outs:
            print("   Could not edit this one:", (r.stderr or r.stdout)[-200:])
            v["error"] = True
            continue
        v["edited"] = os.path.relpath(outs[-1], ROOT)
        v.pop("error", None)
        subprocess.run([sys.executable, os.path.join(HERE, "plan.py"), "file", str(v["post"]), outs[-1]], capture_output=True)
        print("   Done.")
    save_map(m)
    review()


def review():
    m = load_map()
    done = [(f, v) for f, v in m.items() if v.get("edited")]
    cards = ""
    for k, (f, v) in enumerate(sorted(done, key=lambda x: x[1]["post"]), 1):
        rel = os.path.relpath(os.path.join(ROOT, v["edited"]), PLANS)
        name = os.path.splitext(f)[0]
        plan_file = glob.glob(os.path.join(EDIT, f"{name}_edit*.plan.json"))
        skipped = ""
        if plan_file:
            try:
                sk = json.load(open(sorted(plan_file)[-1], encoding="utf-8")).get("skipped") or []
                if sk:
                    skipped = '<div class="warn">A small extra did not fit, so I left it out. You can add it back in the editor.</div>'
            except Exception:
                pass
        cards += (f'<section class="card" data-id="{html.escape(name)}"><div class="row"><video src="{html.escape(rel)}" controls playsinline preload="metadata"></video>'
                  f'<div class="side"><h3>Post {v["post"]}: {html.escape(v["idea"])}</h3>{skipped}'
                  f'<label class="ok"><input type="checkbox" class="good"> This one looks good</label>'
                  f'<textarea placeholder="Anything to change? Write it here, then tell Claude."></textarea>'
                  f'<div class="cmd">To change it, tell Claude: <b>edit {html.escape(name)}</b></div></div></div></section>')
    errs = [f for f, v in m.items() if v.get("error")]
    unsure = [f for f, v in m.items() if not v.get("sure")]
    note = ""
    if unsure:
        note += '<p class="warn">I was not sure which script these clips belong to: ' + ", ".join(html.escape(x) for x in unsure) + ". Tell Claude which is which.</p>"
    if errs:
        note += '<p class="warn">I could not edit: ' + ", ".join(html.escape(x) for x in errs) + ".</p>"
    page = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Your batch</title>
<style>:root{{--bg:#F4EDE2;--card:#fff;--ink:#26332C;--muted:#55544B;--line:#DACDB9;--teal:#2A6E6F}}*{{box-sizing:border-box}}
body{{margin:0;background:var(--bg);color:var(--ink);font-family:system-ui,-apple-system,"Segoe UI",sans-serif}}main{{max-width:900px;margin:0 auto;padding:20px 16px 60px}}
h1{{font-size:34px;margin:8px 0 4px}}.sub{{color:var(--muted)}}.card{{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:14px;margin:14px 0}}
.row{{display:flex;gap:16px;flex-wrap:wrap}}video{{width:240px;max-width:100%;border-radius:12px;background:#000}}.side{{flex:1;min-width:240px}}
h3{{margin:0 0 8px}}textarea{{width:100%;height:70px;font:inherit;border:1px solid var(--line);border-radius:10px;padding:8px;margin-top:8px}}
.ok{{display:flex;gap:8px;align-items:center;font-size:17px}}.ok input{{width:22px;height:22px}}.cmd{{color:var(--muted);font-size:14px;margin-top:6px}}
.warn{{background:#FFF4D6;border:1px solid #E8D48B;border-radius:10px;padding:8px 10px;font-size:14px}}#sum{{font-weight:700;margin:10px 0}}</style></head><body><main>
<p style="margin:0"><a href="calendar.html" style="color:var(--teal);font-weight:700">Open my content calendar</a></p><h1>Your batch</h1><p class="sub">Watch each one, check the ones that look good, and write anything you want changed. Nothing is posted for you.</p>{note}<div id="sum"></div>{cards or "<p>No edited videos yet.</p>"}
</main><script>
var cs=document.querySelectorAll(".card");function sum(){{var n=0;cs.forEach(function(c){{if(c.querySelector(".good").checked)n++}});document.getElementById("sum").textContent=n+" of "+cs.length+" approved"}}
cs.forEach(function(c){{var id=c.getAttribute("data-id");var g=c.querySelector(".good"),t=c.querySelector("textarea");
try{{g.checked=localStorage.getItem("br_g_"+id)==="1";t.value=localStorage.getItem("br_t_"+id)||""}}catch(e){{}}
g.onchange=function(){{try{{localStorage.setItem("br_g_"+id,g.checked?"1":"0")}}catch(e){{}}sum()}};t.oninput=function(){{try{{localStorage.setItem("br_t_"+id,t.value)}}catch(e){{}}}}}});sum();
</script></body></html>'''
    open(os.path.join(PLANS, "batch-review.html"), "w", encoding="utf-8").write(page)
    print(f"Wrote customer/plans/batch-review.html ({len(done)} videos).")


# ---------- the drop box: a small local page where she drops her clips and everything else happens ----------
OUTFITS = [0]
STATE = {"state": "idle", "message": "", "unsure": []}
INBOX = os.path.join(ROOT, "inbox")


def safe_name(n):
    n = re.sub(r"[^A-Za-z0-9._ -]", "_", os.path.basename(n)).strip() or "clip.mov"
    base, ext = os.path.splitext(n)
    k = 1
    while os.path.exists(os.path.join(INBOX, n)) or os.path.exists(os.path.join(REC, n)):
        k += 1
        n = f"{base}-{k}{ext}"
    return n


class Tee:
    """Turn the tool's own printed lines into the plain message she sees."""
    def __init__(self):
        self.buf = ""

    def write(self, t):
        self.buf += t
        for ln in t.splitlines():
            ln = ln.strip()
            if ln.startswith("Editing "):
                STATE["message"] = "Editing " + ln[len("Editing "):].replace(" ...", "") + "..."
            elif ln.startswith("Matched") or "->" in ln:
                STATE["message"] = "Matching your videos to your scripts..."

    def flush(self):
        pass


def run_go():
    import contextlib
    try:
        STATE.update(state="working", message="Bringing your videos in...", unsure=[])
        fresh = []
        for f in sorted(os.listdir(INBOX)):
            if f.lower().endswith(VIDEO_EXT) and not os.path.exists(os.path.join(REC, f)):
                subprocess.run([sys.executable, os.path.join(HERE, "inbox.py"), "take", f], capture_output=True)
                fresh.append(f)
        # a clip dropped just now keeps its name; inbox.py may swap spaces for underscores
        fresh_names = set(fresh) | {f.replace(" ", "_") for f in fresh} | {k for k in load_map() if False}
        # clips that arrived from the phone teleprompter are already matched; everything else new in recorded/ counts too
        mapped = set(load_map())
        fresh_names |= {os.path.basename(c) for c in clips() if os.path.basename(c) not in mapped and os.path.getmtime(c) > __import__("time").time() - 3600}
        STATE["message"] = "Listening to each video to match it to its script..."
        with contextlib.redirect_stdout(Tee()):
            match(None, only=fresh_names)
        m = load_map()
        _, rows = week_rows(None)
        unsure = [{"file": f, "options": [{"n": r["n"], "idea": r["idea"]} for r in rows]} for f, v in m.items() if not v.get("sure") and not v.get("edited") and not v.get("alt") and f in fresh_names]
        if unsure:
            STATE.update(state="ask", message="I need your help with these:", unsure=unsure)
            return
        STATE["message"] = "Editing your videos..."
        with contextlib.redirect_stdout(Tee()):
            edit_all()
        STATE.update(state="done", message="Your videos are edited.")
    except Exception as e:
        STATE.update(state="error", message=f"Something went wrong: {str(e)[:150]}")


TELE_HTML = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Teleprompter</title>
<style>*{box-sizing:border-box}body{margin:0;background:#101814;color:#fff;font-family:system-ui,-apple-system,"Segoe UI",sans-serif}
.bar{position:sticky;top:0;z-index:5;background:#1a2620;padding:10px 12px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;border-bottom:1px solid #2c3a33}
.bar button,.bar label.btn{background:#2A6E6F;color:#fff;border:0;border-radius:12px;padding:10px 14px;font-size:16px;font-weight:700}
.bar .ghost{background:#2c3a33}.sel{font-size:15px;padding:8px;border-radius:8px}
#txt{padding:18px 18px 70vh;font-size:__SZ__px;line-height:1.45;font-weight:600;white-space:pre-wrap}
#txt .cue{display:block;color:#E9B949;font-size:.5em;margin:.8em 0}
.top{padding:14px 16px 0;color:#9BC7A0;font-size:15px}
.done{position:fixed;left:0;right:0;bottom:0;background:#1a2620;border-top:1px solid #2c3a33;padding:12px;display:flex;gap:10px;align-items:center}
.done .btn{flex:1;text-align:center;background:#E9B949;color:#26332C;border-radius:14px;padding:14px;font-size:18px;font-weight:800}.done .msg{font-size:14px;color:#9BC7A0;flex:1}
input[type=file]{display:none}</style></head><body>
<div class="bar"><select id="which" class="sel"></select><button id="play">Start scrolling</button><button class="ghost" id="slow">Slower</button><button class="ghost" id="fast">Faster</button><button class="ghost" id="smaller">A-</button><button class="ghost" id="bigger">A+</button></div>
<div class="top" id="top"></div><div id="txt"></div>
<div class="done"><label class="btn" id="recBtn">Done? Add my video<input type="file" id="vf" accept="video/*" capture="user"></label><div class="msg" id="msg"></div></div>
<script>
var ITEMS=__ITEMS__,sz=__SZ__,spd=40,run=false,last=0;
var sel=document.getElementById("which"),txt=document.getElementById("txt"),msg=document.getElementById("msg");
ITEMS.forEach(function(it,i){var o=document.createElement("option");o.value=i;o.textContent="Video "+(i+1)+": "+it.idea;sel.appendChild(o)});
function show(){var it=ITEMS[sel.value];document.getElementById("top").textContent="Say the number "+it.n+" first. Then start. Halfway through, look at the camera for one second.";txt.textContent=it.spoken;window.scrollTo(0,0)}
sel.onchange=function(){run=false;document.getElementById("play").textContent="Start scrolling";show()};show();
function tick(t){if(run){var dt=(t-last)/1000;window.scrollBy(0,spd*dt)}last=t;requestAnimationFrame(tick)}requestAnimationFrame(tick);
document.getElementById("play").onclick=function(){run=!run;this.textContent=run?"Pause":"Start scrolling"};
document.getElementById("slow").onclick=function(){spd=Math.max(10,spd-10)};document.getElementById("fast").onclick=function(){spd+=10};
document.getElementById("bigger").onclick=function(){sz+=4;txt.style.fontSize=sz+"px"};document.getElementById("smaller").onclick=function(){sz=Math.max(20,sz-4);txt.style.fontSize=sz+"px"};
document.getElementById("vf").onchange=function(){var f=this.files[0];if(!f)return;var it=ITEMS[sel.value];msg.textContent="Sending your video... keep this page open.";
 fetch("/api/tele-upload?post="+it.n+"&name="+encodeURIComponent(f.name),{method:"POST",body:f}).then(function(r){return r.json()}).then(function(j){msg.textContent=j.ok?"Got it! Video "+(parseInt(sel.value)+1)+" is in your folder. Pick the next video above.":"That did not send. Try again."}).catch(function(){msg.textContent="That did not send. Try again."})};
</script></body></html>'''


def lan_ip():
    import socket
    try:
        sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sk.connect(("8.8.8.8", 80))
        ip = sk.getsockname()[0]
        sk.close()
        return ip
    except Exception:
        return "127.0.0.1"


def tele_page():
    week, rows = week_rows(None)
    items = []
    for r in rows:
        if "flex" in (r["idea"] + " " + r["why"] + " " + r["job"]).lower():
            continue
        said, spoken = script_parts(r["script"])
        items.append({"n": r["n"], "idea": r["idea"], "spoken": spoken})
    return TELE_HTML.replace("__ITEMS__", json.dumps(items).replace("</", "<\\/")).replace("__SZ__", "34")


def take_upload(post, name):
    """A clip filmed from the teleprompter page already knows which script it is, so it needs no matching."""
    subprocess.run([sys.executable, os.path.join(HERE, "inbox.py"), "take", name], capture_output=True)
    try:
        assign(name, post)
    except SystemExit:
        pass


# ---------- the home: one place with tabs for everything ----------
PAGE_CSS = """<style>@font-face{font-family:AntonLocal;src:url(data:font/ttf;base64,__FONT__) format("truetype")}
:root{--bg:#F4EDE2;--card:#fff;--ink:#26332C;--muted:#55544B;--line:#DACDB9;--forest:#36483E;--teal:#2A6E6F;--light:#6FA7A8;--brown:#885F43;--sun:#E9B949}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;line-height:1.5}
main{max-width:980px;margin:0 auto;padding:18px 16px 60px}h1{font-family:AntonLocal,Impact,sans-serif;font-weight:400;text-transform:uppercase;letter-spacing:.03em;font-size:40px;margin:6px 0 4px}
.sub{color:var(--muted);margin:0 0 16px}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:14px}
.card{background:var(--card);border:1px solid var(--line);border-top:7px solid var(--teal);border-radius:18px;padding:10px;box-shadow:0 5px 14px rgba(54,72,62,.08)}
.card:nth-child(3n+2){border-top-color:var(--brown)}.card:nth-child(3n){border-top-color:var(--light)}
.card img,.card video{width:100%;aspect-ratio:3/4;object-fit:cover;border-radius:12px;background:#EAF3F2;display:block}
.card b{display:block;margin:8px 0 2px;font-size:17px}.card small{color:var(--muted)}
.btn{display:inline-block;background:var(--teal);color:#fff;border:0;border-radius:12px;padding:9px 16px;font-weight:800;font-size:15px;cursor:pointer;text-decoration:none;margin-top:8px}
.btn.ghost{background:#EAF3F2;color:var(--teal)}.pill{display:inline-block;background:#EAF3F2;color:var(--teal);border-radius:12px;padding:1px 9px;font-size:12px;font-weight:700}
.row{display:flex;gap:12px;align-items:center;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px 14px;margin:8px 0;cursor:pointer}.row:hover{border-color:var(--teal)}
.row b{flex:1}.empty{background:var(--card);border:2px dashed var(--line);border-radius:18px;padding:30px;text-align:center;color:var(--muted)}
.md h2,.md h3{font-family:AntonLocal,Impact,sans-serif;font-weight:400;text-transform:uppercase;color:var(--forest)}.md table{border-collapse:collapse;width:100%}.md td,.md th{border:1px solid var(--line);padding:6px 8px;text-align:left;font-size:14px}.md pre,.md blockquote{background:#fff;border:1px solid var(--line);border-radius:12px;padding:10px;white-space:pre-wrap}
.swatch{display:inline-block;width:54px;height:54px;border-radius:14px;border:1px solid var(--line);margin-right:8px}
</style>"""


def _font_b64():
    import base64
    fp = os.path.join(ROOT, "engine", "fonts", "Anton-Regular.ttf")
    return base64.b64encode(open(fp, "rb").read()).decode() if os.path.exists(fp) else ""


COMMON_JS = r"""
function openEditor(title,text,onSave){var o=document.createElement('div');o.style.cssText='position:fixed;inset:0;background:rgba(20,22,30,.5);z-index:100;display:flex;align-items:center;justify-content:center;padding:16px';
 var b=document.createElement('div');b.style.cssText='background:#fff;border-radius:16px;padding:18px;width:min(720px,100%);max-height:90vh;display:flex;flex-direction:column;gap:10px;box-shadow:0 20px 50px rgba(0,0,0,.3)';
 b.innerHTML='<h3 style="margin:0">'+title+'</h3><textarea style="width:100%;min-height:260px;font:16px/1.5 system-ui;padding:12px;border:1px solid #DACDB9;border-radius:12px"></textarea><div style="display:flex;gap:8px;justify-content:flex-end"><span id="edmsg" style="flex:1;color:#2A6E6F;align-self:center;font-size:14px"></span><button class="btn ghost" id="edcancel">Cancel</button><button class="btn" id="edsave">Save</button></div>';
 o.appendChild(b);document.body.appendChild(o);var ta=b.querySelector('textarea');ta.value=text;ta.focus();
 function close(){o.remove()}b.querySelector('#edcancel').onclick=close;o.onclick=function(e){if(e.target===o)close()};
 b.querySelector('#edsave').onclick=function(){b.querySelector('#edmsg').textContent='Saving...';onSave(ta.value,close)}}
function editText(p,title,done){fetch('/api/text/get?p='+encodeURIComponent(p)).then(function(r){return r.json()}).then(function(j){
 openEditor(title,j.text||'',function(t,close){fetch('/api/text/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({p:p,text:t})}).then(function(){close();if(done)done()})})})}
"""


def page(title, sub, body, script=""):
    return ("<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>" + html.escape(title) + "</title>"
            + PAGE_CSS.replace("__FONT__", _font_b64()) + "</head><body><main><h1>" + html.escape(title) + "</h1><p class=\"sub\">" + sub + "</p>" + body + "</main><script>" + COMMON_JS + script + "</script></body></html>")


def md_html(text):
    out, lst, tbl = [], False, []
    def flush_tbl():
        if tbl:
            rows = [r for r in tbl if not set(r.replace("|", "").strip()) <= set("-: ")]
            out.append("<table>" + "".join("<tr>" + "".join("<td>" + html.escape(c.strip()) + "</td>" for c in r.strip().strip("|").split("|")) + "</tr>" for r in rows) + "</table>")
            tbl.clear()
    for ln in text.splitlines():
        if ln.strip().startswith("|"):
            tbl.append(ln)
            continue
        flush_tbl()
        e = html.escape(ln)
        e = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", e)
        e = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\1", e)
        if ln.startswith("# "):
            if lst: out.append("</ul>"); lst = False
            out.append("<h2>" + e[2:] + "</h2>")
        elif ln.startswith("## ") or ln.startswith("### "):
            if lst: out.append("</ul>"); lst = False
            out.append("<h3>" + e.lstrip("# ") + "</h3>")
        elif ln.lstrip().startswith(("- ", "* ")):
            if not lst: out.append("<ul>"); lst = True
            out.append("<li>" + e.lstrip()[2:] + "</li>")
        elif not ln.strip():
            if lst: out.append("</ul>"); lst = False
            out.append("<br>")
        else:
            if lst: out.append("</ul>"); lst = False
            out.append("<p style=\"margin:4px 0\">" + e + "</p>")
    flush_tbl()
    if lst:
        out.append("</ul>")
    return "<div class=\"md\">" + "".join(out) + "</div>"


EDITORS = {}



def regen_calendar():
    try:
        subprocess.run([sys.executable, "-X", "utf8", "-I", os.path.join(HERE, "make_calendar.py")], cwd=ROOT, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120)
    except Exception:
        pass


EDITABLE_TEXT = ("customer/scripts/", "customer/videos/edited/", "customer/content/")


def editable_text_path(rel):
    """Only caption and script text files inside her customer folder can be edited from the hub."""
    full = os.path.abspath(os.path.join(ROOT, rel))
    base = os.path.join(ROOT, "customer")
    ok = full.startswith(base) and any(rel.replace(os.sep, "/").startswith(x) for x in EDITABLE_TEXT) and full.endswith((".md", ".txt"))
    return full if ok else None


def save_script_section(date, heading, text):
    _, rows = mc.read_plan(pl.plan_path())
    r = next((x for x in rows if x["date"] == date), None)
    if not r or not r.get("script") or not os.path.exists(r["script"]):
        return False
    lines = open(r["script"], encoding="utf-8").read().split("\n")
    out, i, done = [], 0, False
    while i < len(lines):
        ln = lines[i]
        if ln.startswith("## ") and ln[3:].strip() == heading and not done:
            out.append(ln)
            i += 1
            while i < len(lines) and not lines[i].startswith("## "):
                i += 1
            out += text.rstrip("\n").split("\n") + [""]
            done = True
            continue
        out.append(ln)
        i += 1
    if not done:
        return False
    shutil.copy(r["script"], r["script"] + ".before-edit")
    open(r["script"], "w", encoding="utf-8").write("\n".join(out))
    return True



def fill_script_blank(date, blank, answer):
    _, rows = mc.read_plan(pl.plan_path())
    r = next((x for x in rows if x["date"] == date), None)
    if not r or not r.get("script") or not os.path.exists(r["script"]):
        return "I can't find that script."
    text = open(r["script"], encoding="utf-8").read()
    if blank not in text:
        return "That spot isn't in the script anymore. Reload the page."
    shutil.copy(r["script"], r["script"] + ".before-edit")
    open(r["script"], "w", encoding="utf-8").write(text.replace(blank, answer.strip()))
    return ""



def confirm_script_blank(date, blank, claim, action, text):
    _, rows = mc.read_plan(pl.plan_path())
    r = next((x for x in rows if x["date"] == date), None)
    if not r or not r.get("script") or not os.path.exists(r["script"]):
        return "I can't find that script."
    t = open(r["script"], encoding="utf-8").read()
    if blank not in t:
        return "That spot isn't in the script anymore. Reload the page."
    with_claim = (claim + " " + blank) if claim and (claim + " " + blank) in t else None
    if action == "yes":
        new = t.replace((" " + blank) if (" " + blank) in t else blank, "", 1) if True else t
        new = new if new != t else t.replace(blank, "")
    else:
        if with_claim:
            new = t.replace(with_claim, text.strip(), 1)
        else:
            new = t.replace(blank, text.strip(), 1)
    shutil.copy(r["script"], r["script"] + ".before-edit")
    open(r["script"], "w", encoding="utf-8").write(new)
    return ""



def banked_ideas():
    path = pl.plan_path()
    out, on = [], False
    for ln in open(path, encoding="utf-8").read().splitlines():
        if ln.startswith("## "):
            on = ln.lower().startswith("## banked ideas")
            continue
        if on and ln.lstrip().startswith("- "):
            t = re.sub(r"\s*\((?:from|was|swapped)[^)]*\)\s*$", "", ln.lstrip()[2:]).strip()
            if t and "wants less" not in t.lower():
                out.append(t)
    return out



def idea_pool():
    """Post ideas she can pick without asking Claude: her waiting ideas, then her own audience words and topics, then her best posts to bring back. Never invented: each one comes from her files."""
    ideas = list(banked_ideas())
    try:
        existing = " ".join(r["idea"].lower() for r in pl.rows_of(pl.plan_path()))
    except BaseException:
        existing = ""
    ap = os.path.join(ROOT, "customer", "profile", "audience.md")
    if os.path.exists(ap):
        sec = ""
        for ln in open(ap, encoding="utf-8").read().splitlines():
            if ln.startswith("## "):
                sec = ln[3:].strip().lower()
                continue
            if not ln.lstrip().startswith("- "):
                continue
            q = re.findall(r"[\"\u201c]([^\"\u201d]{12,110})[\"\u201d]", ln)
            if sec.startswith("their words") and q:
                ideas.append("Answer this question: \u201c" + q[0].strip().rstrip("?.!") + "\u201d")
            elif sec.startswith("my topics") and q:
                ideas.append(q[0].strip().rstrip("?.!"))
    wp = os.path.join(ROOT, "customer", "insights", "winners.jsonl")
    if os.path.exists(wp):
        for ln in open(wp, encoding="utf-8").read().splitlines()[:3]:
            try:
                w = json.loads(ln)
                h = (w.get("hook") or w.get("title") or "").strip()
                if h:
                    ideas.append("Bring back a top post with a new hook: \u201c" + h[:80] + "\u201d")
            except Exception:
                pass
    out, seen = [], set()
    for i in ideas:
        k = re.sub(r"[^a-z0-9 ]", "", i.lower())[:60]
        core = re.sub(r"[^a-z0-9 ]", "", re.sub(r"^(answer this question|bring back a top post with a new hook):?\s*", "", i.lower()))[:40]
        if k in seen or (core and core in existing):
            continue
        seen.add(k)
        out.append(i)
    return out


def take_banked(idea):
    path = pl.plan_path()
    lines = open(path, encoding="utf-8").read().split("\n")
    on, done = False, False
    out = []
    for ln in lines:
        if ln.startswith("## "):
            on = ln.lower().startswith("## banked ideas")
        if on and not done and ln.lstrip().startswith("- ") and idea and idea in ln:
            done = True
            continue
        out.append(ln)
    if done:
        open(path, "w", encoding="utf-8").write("\n".join(out))


def save_plan_row(n, idea, why):
    idea = (idea or "").replace("|", "/").replace("\n", " ").strip()
    why = (why or "").replace("|", "/").replace("\n", " ").strip()
    path = pl.plan_path()

    def fn(num, c):
        if num != n:
            return None
        c = list(c)
        if idea:
            c[5] = " " + idea + " "
        if why:
            c[6] = " " + why + " "
        return c
    shutil.copy(path, path + ".before-edit")
    shutil.copy(path, path + ".undo")
    pl.edit_lines(path, fn)
    return True


def edit_list():
    names = {}
    for f in sorted(os.listdir(EDIT)) if os.path.isdir(EDIT) else []:
        m = re.match(r"(.+)_edit(\d+)\.mp4$", f)
        if m:
            names.setdefault(m.group(1), []).append((int(m.group(2)), f))
    cards = ""
    for nm, vs in sorted(names.items(), key=lambda kv: -os.path.getmtime(os.path.join(EDIT, kv[1][-1][1]))):
        v, f = sorted(vs)[-1]
        cp = os.path.join(EDIT, nm + ".caption.txt")
        cap_prev = ""
        if os.path.exists(cp):
            ct = open(cp, encoding="utf-8").read().strip()
            cap_prev = '<span style="display:block;font-size:13px;color:#55544B;margin:6px 0">' + html.escape(ct[:110]) + ("..." if len(ct) > 110 else "") + "</span>"
        cards += (f'<div class="card"><video src="/media/{html.escape(f)}" preload="metadata" muted playsinline onmouseover="this.play()" onmouseout="this.pause()"></video>'
                  f'<b>{html.escape(nm)}</b><small>Version {v}</small>{cap_prev}<br><button class="btn" onclick="openEd(\'{html.escape(nm)}\',this)">Edit</button> <a class="btn ghost" href="/dl?p=customer/videos/edited/{html.escape(f)}">Download</a> <button class="btn ghost" onclick="reveal(\'customer/videos/edited/{html.escape(f)}\')">Show in folder</button> <button class="btn ghost" onclick="editText(\'customer/videos/edited/{html.escape(nm)}.caption.txt\',\'Caption for {html.escape(nm)}\',function(){{location.reload()}})">Edit caption</button> <button class="btn ghost" onclick="askCap(\'{html.escape(nm)}\',this)">Write my caption</button> <button class="btn ghost" onclick="delEd(\'{html.escape(nm)}\',this)">Delete</button></div>')
    raw = [os.path.splitext(f)[0] for f in sorted(os.listdir(REC)) if f.lower().endswith(VIDEO_EXT)] if os.path.isdir(REC) else []
    hp = os.path.join(ROOT, "customer", "videos", "hidden.json")
    hidden = json.load(open(hp, encoding="utf-8")) if os.path.exists(hp) else []
    mp = os.path.join(ROOT, "customer", "videos", "merged-from.json")
    merged_parts = {x for v in (json.load(open(mp, encoding="utf-8")).values() if os.path.exists(mp) else []) for x in v}
    waiting = [r for r in raw if r not in names and r not in hidden and r not in merged_parts]
    note = ""
    if waiting:
        chips = "".join(f'<span class="pill" style="margin:3px;display:inline-block">{html.escape(r)} <a href="#" title="Take this off the list" onclick="hideRaw(\'{html.escape(r)}\');return false" style="text-decoration:none;font-weight:800">&times;</a></span>' for r in waiting)
        note = '<p class="sub">Not edited yet (click the x to take one off this list. Your recording stays safe):<br>' + chips + "<br>To edit one, tell Claude: <b>edit my video</b>, or drop it on the Batch day page.</p>"
    body = (note + ('<div class="grid">' + cards + "</div>" if cards else '<div class="empty">No edited videos yet. Film a video, drop it in your inbox, and tell Claude to edit it.<br><br><a class="btn" href="#" onclick="parent.postMessage({go:\'batch\'},\'*\');return false">Go to Batch day</a></div>'))
    js = ("function reveal(p){fetch('/api/reveal',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({p:p})})}"
          "function askCap(n,b){var t='Write a caption for '+n;var x=document.createElement('textarea');x.value=t;document.body.appendChild(x);x.select();try{document.execCommand('copy')}catch(e){}x.remove();b.textContent='Copied. Paste it in the chat';setTimeout(function(){b.textContent='Write my caption'},3500)}"
          "function hideRaw(n){fetch('/api/edit/hide',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:n})}).then(function(){location.reload()})}"
          "function delEd(n,b){if(!confirm('Remove all edited versions of '+n+'? Your original recording stays safe, and the edits go to a Removed folder you can restore from.'))return;fetch('/api/edit/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:n})}).then(function(){location.reload()})}"
          "function openEd(n,b){b.textContent='Opening...';fetch('/api/edit/start?name='+encodeURIComponent(n),{method:'POST'}).then(function(r){return r.json()}).then(function(j){if(j.url){location.href=j.url}else{b.textContent='Could not open'}})}")
    return page("Edit", "Pick a video to edit. Hover to preview.", body, js)


def pretty_title(dp, base):
    """A friendly name: the first slide's own words, else the folder name made readable."""
    parent = os.path.basename(dp)
    folder = os.path.basename(os.path.dirname(dp)) if parent in ("slides", "stories", "post", "tiles") else parent
    kind = "Stories" if parent == "stories" or "stories" in folder else "Carousel"
    label = ""
    for cand in (os.path.join(dp, "slides.json"), os.path.join(os.path.dirname(dp), "slides.json"), os.path.join(os.path.dirname(dp), "stories.json")):
        try:
            d = json.load(open(cand, encoding="utf-8"))
            sl = (d.get("slides") or d.get("frames") or [{}])[0]
            if isinstance(d.get("list_name"), str) and d["list_name"].strip():
                return d["list_name"].strip(), kind
            for k in ("headline", "word", "quote", "label", "text", "title"):
                v = sl.get(k)
                if isinstance(v, str) and v.strip():
                    label = v.strip()
                    break
            if not label:
                t = d.get("title", "")
                label = t if t and t not in ("slides", "stories", "carousel") else ""
            if label:
                break
        except Exception:
            pass
    if not label:
        label = re.sub(r"^(day-)?\d+-?", "", folder).replace("-", " ").strip() or folder
    label = re.sub(r"\s+", " ", label)
    if len(label) > 48:
        label = label[:45].rstrip() + "..."
    label = re.sub(r"\bi\b", "I", label[:1] + label[1:].lower()) if label.isupper() else label
    return (label[:1].upper() + label[1:]), kind


LOOK_INFO = {1: ("Scrapbook", "Handwritten words, tilted photos, doodles"), 2: ("Numbered tips", "Big numbers, bouncy mixed fonts"),
             3: ("Bold editorial", "Huge headlines with highlighter marks"), 4: ("Photo statement", "Full photos and one giant word"),
             5: ("Warm flat color", "Flat color, photo grids, comment bubbles"), 6: ("Photo story", "A photo with your words low and left"),
             7: ("Notebook caps", "Full-photo cover, bold caps, thin italic"), 8: ("Face and contrast", "A face photo, old way against new way")}


BRAND_LOCK = __import__("threading").Lock()
EDIT_FIELDS = ("headline", "hi", "body", "note", "who", "items", "keyword", "line", "lead", "top", "bottom", "left_title", "left", "right_title", "right", "footer", "label_a", "label_b", "n")
RUNNING = {}   # carousel folder -> the redraw that is still going


def run_make(spec, full):
    RUNNING[full] = subprocess.Popen([PY, "-X", "utf8", "-I", os.path.join(HERE, "make_carousel.py"), spec, full], cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def backup_spec(spec):
    """Keep the version before this change, so she can go back one step."""
    try:
        if os.path.exists(spec):
            shutil.copy(spec, spec + ".undo")
    except Exception:
        pass


def spec_for(rel):
    full = os.path.abspath(os.path.join(ROOT, rel))
    spec = os.path.join(full, "slides.json") if os.path.exists(os.path.join(full, "slides.json")) else os.path.join(os.path.dirname(full), "slides.json")
    ok = full.startswith(os.path.join(ROOT, "customer")) and os.path.exists(spec)
    return full, spec, ok


def looks_path():
    return os.path.join(ROOT, "customer", "profile", "carousel-looks.json")


def looks_load():
    try:
        d = json.load(open(looks_path(), encoding="utf-8"))
    except Exception:
        d = {}
    d.setdefault("favorites", [])
    d.setdefault("use", None)
    d.setdefault("mine", [])
    d.setdefault("names", {})
    d.setdefault("hidden", [])
    return d


def looks_store(d):
    os.makedirs(os.path.dirname(looks_path()), exist_ok=True)
    json.dump(d, open(looks_path(), "w", encoding="utf-8"), indent=2)


def looks_section():
    """The "My looks" row at the top of the Carousels tab: the eight built-in looks plus every look she adds, with favorites, renaming and a tile to add more."""
    folder = os.path.join(ROOT, "customer", "looks")
    import make_looks as ml
    missing = [n for n in LOOK_INFO if not os.path.exists(os.path.join(folder, f"look-{n}", "slide-01.png"))]
    if not missing and ml.stale():
        missing = list(LOOK_INFO)   # her brand colors changed since the previews were drawn: draw them again
    note = ""
    if len(ml.brand_colors()) < 2:
        note += '<p class="sub">Showing in default colors. Add your <a href="#" onclick="parent.postMessage({go:\'brand\'},\'*\');return false">brand colors</a> and these will redraw in yours.</p>'
    if missing:
        try:
            subprocess.Popen([sys.executable, "-X", "utf8", "-I", os.path.join(HERE, "make_looks.py")], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
        note += '<p class="sub">Drawing your looks. One moment...</p>'
    st = looks_load()
    names = st.get("names") or {}
    mine = {m["id"]: m for m in st["mine"] if m.get("base") in LOOK_INFO and m.get("id") is not None}
    hidden = [h for h in st["hidden"] if h in LOOK_INFO]
    allids = [n for n in list(LOOK_INFO) + list(mine) if n not in hidden]
    favs = [f for f in st["favorites"] if f in allids]
    order = favs + [n for n in allids if n not in favs]

    def tile(uid):
        own = mine.get(uid)
        base = own["base"] if own else uid
        name = (own or {}).get("name") or names.get(str(uid)) or LOOK_INFO[base][0]
        blurb = (("Your own look, learned from your screenshots" if own.get("custom") else "Your own look, based on " + LOOK_INFO[base][0]) if own else LOOK_INFO[uid][1])
        pdir = f"look-{uid}" if (own and os.path.exists(os.path.join(folder, f"look-{uid}", "slide-01.png"))) else f"look-{base}"
        pics = "".join(f'<img loading="lazy" src="/customer/looks/{pdir}/slide-0{k}.png">' for k in (1, 2, 3))
        isfav = uid in favs
        used = st.get("use") == uid
        hidden = ""
        return (f'<div class="card look{hidden}"><button class="hrt" title="Favorite" onclick="lk(\'fav\',{uid})">{"&#9829;" if uid in favs else "&#9825;"}</button><div class="lp" title="Tap to see the whole carousel" onclick="vw(\'{pdir}\',\'{html.escape(name, quote=True)}\')">{pics}</div>'
                f'<div class="ln"><b id="nm{uid}">{html.escape(name)}</b> <button class="pen" title="Rename" onclick="rn({uid})">&#9998;</button></div>'
                f'<small>{html.escape(blurb)}</small>'
                f'<div class="act"><button class="btn{"" if used else " ghost"}" onclick="lk(\'use\',{uid})">{"Using this look" if used else "Use this look"}</button>'
                f'<button class="pen rmv" title="Remove this look" onclick="rm({uid},{1 if own else 0})">Remove</button></div></div>')
    tiles = "".join(tile(n) for n in order)
    ask = "Learn this carousel look"
    tiles += ('<div class="card look add"><div class="plus">+</div><b>Add a look you love</b>'
              '<small id="addmsg">Add screenshots of a carousel you love.</small><br>'
              '<input type="file" id="lkfiles" accept="image/*" multiple style="display:none" onchange="upl(this.files)">'
              '<button class="btn" id="addbtn" onclick="document.getElementById(\'lkfiles\').click()">Choose screenshots</button></div>')
    more = (f'<p class="sub"><a href="#" onclick="lk(\'restore\',0);return false">Bring back removed looks ({len(hidden)})</a></p>' if hidden else "")
    pinned = st.get("use")
    pname = ""
    if pinned is not None:
        pbase = mine[pinned]["base"] if pinned in mine else pinned
        pname = (mine[pinned]["name"] if pinned in mine else names.get(str(pinned))) or LOOK_INFO.get(pbase, ("",))[0]
    if pname:
        intro = f'Every carousel is made in <b>{html.escape(pname)}</b>. <a href="#" onclick="lk(\'auto\',0);return false">Let the engine choose instead</a>'
    else:
        intro = 'The engine picks the best look for each carousel and makes it for you. You can change the style after. Tap <b>Use this look</b> to always use one.'
    css = ('<style>.lp{display:grid;grid-template-columns:2fr 1fr;grid-template-rows:1fr 1fr;gap:6px;margin-bottom:8px}.lp img{width:100%;border-radius:8px;display:block}'
           '.lp{cursor:zoom-in}.lp img:first-child{grid-row:1/3}.look small{display:block;color:var(--muted);margin:2px 0 8px}.look.add{border-style:dashed;border-top-style:dashed;text-align:center;display:flex;flex-direction:column;justify-content:center}'
           '.look .plus{font-size:54px;color:var(--teal);line-height:1}.look.more{display:none}body.allk .look.more{display:block}'
           '.ln{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.pen{background:none;border:0;color:var(--teal);font-size:13px;cursor:pointer;padding:2px 4px;text-decoration:underline}'
           '#vwb{display:none;position:fixed;inset:0;background:rgba(20,26,22,.88);z-index:99;overflow:auto;padding:24px 12px;text-align:center}#vwb h2{color:#fff;font:400 26px AntonLocal,Impact,sans-serif;letter-spacing:.03em;text-transform:uppercase;margin:0 0 4px}#vwb p{color:#ddd;margin:0 0 14px}'
           '#vwb .row{display:flex;gap:14px;justify-content:center;flex-wrap:wrap}#vwb img{width:min(380px,92vw);border-radius:12px;box-shadow:0 8px 28px rgba(0,0,0,.45)}#vwb button{background:#fff;border:0;border-radius:999px;padding:9px 22px;font-weight:700;font-size:16px;cursor:pointer;margin-bottom:14px}'
           '.act{display:flex;align-items:center;justify-content:space-between;gap:8px}.rmv{font-size:14px}.look{position:relative}.hrt{position:absolute;top:16px;left:16px;z-index:2;background:#fff;border:0;border-radius:50%;width:34px;height:34px;font-size:18px;color:var(--teal);cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,.25)}'
           '.ln input{font:inherit;font-weight:700;padding:3px 8px;border:2px solid var(--teal);border-radius:8px;max-width:100%}</style>')
    js = ("function vw(d,n){var b=document.getElementById('vwb');if(!b){b=document.createElement('div');b.id='vwb';b.onclick=function(e){if(e.target===b||e.target.tagName==='BUTTON')b.style.display='none'};document.body.appendChild(b);document.addEventListener('keydown',function(e){if(e.key==='Escape')b.style.display='none'})}"
          "b.innerHTML='<button>Close</button><h2></h2><div class=\"row\">'+[1,2,3].map(function(k){return '<img src=\"/customer/looks/'+d+'/slide-0'+k+'.png\">'}).join('')+'</div>';b.querySelector('h2').textContent=n;b.style.display='block';b.scrollTop=0}"
          "function lk(a,id,extra){var o={act:a,id:id};if(extra)for(var k in extra)o[k]=extra[k];return fetch('/api/looks',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o)}).then(function(){location.reload()})}"
          "function rm(id,own){if(confirm(own?'Remove this look? This cannot be undone.':'Remove this look from your list? You can bring it back any time.'))lk('remove',id)}"
          "function rn(id){var b=document.getElementById('nm'+id),old=b.textContent,i=document.createElement('input');i.value=old;i.maxLength=40;b.replaceWith(i);i.focus();i.select();"
          "var done=false;function save(){if(done)return;done=true;var v=i.value.trim();if(v&&v!==old)lk('rename',id,{name:v});else location.reload()}"
          "i.onkeydown=function(e){if(e.key==='Enter')save();if(e.key==='Escape'){done=true;location.reload()}};i.onblur=save}"
          "function upl(fs){var m=document.getElementById('addmsg'),b=document.getElementById('addbtn'),n=0,k=0;if(!fs.length)return;m.textContent='Adding...';"
          "Array.prototype.forEach.call(fs,function(f){fetch('/api/looks/upload?name='+encodeURIComponent(f.name),{method:'POST',body:f}).then(function(r){if(r.ok)n++}).finally(function(){k++;if(k===fs.length){"
          "if(n){m.textContent='Got '+n+(n===1?' picture.':' pictures.')+' Now paste this to Claude:';b.textContent='Copy: Learn this carousel look';b.onclick=function(){cp(b,'Learn this carousel look')}}else{m.textContent='That did not work. Try a PNG or JPG.'}}})})}"
          "function cp(b,t){function ok(){b.textContent='Copied. Now paste it to Claude.'}try{navigator.clipboard.writeText(t).then(ok,function(){var x=document.createElement('textarea');x.value=t;document.body.appendChild(x);x.select();document.execCommand('copy');x.remove();ok()})}catch(e){ok()}}")
    if missing:
        js += "setTimeout(function(){location.reload()},12000);"   # the pictures are still being drawn: look again in a moment
    return css + "<h3>My looks</h3><p class=\"sub\">" + intro + "</p>" + note + '<div class="grid">' + tiles + "</div>" + more + "<hr style=\"border:0;border-top:1px solid var(--line);margin:22px 0\">", js


def content_list(show_samples=False, stories=False):
    base = os.path.join(ROOT, "customer", "content")
    SAMPLE = ("pretend-accounts", "who-its-for-examples", "carousel-examples", "showcase", "planner-tour")
    found, samples = [], 0
    for dp, dns, fns in os.walk(base):
        dns[:] = [d for d in dns if not d.startswith(".") and d not in ("stills", "phone-preview", "source", "text-reels")]
        if "slide-01.png" in fns:
            if any(x in os.path.relpath(dp, base).split(os.sep) for x in SAMPLE):
                samples += 1
                if not show_samples:
                    continue
            found.append(dp)
    cards = ""
    for dp in sorted(found, key=os.path.getmtime, reverse=True):
        rel = os.path.relpath(dp, ROOT).replace(os.sep, "/")
        n = len([f for f in os.listdir(dp) if re.match(r"slide-\d+\.png$", f)])
        title, kind = pretty_title(dp, base)
        if (kind == "Stories") != stories:
            continue   # carousels and stories each have their own tab
        day = __import__("time").strftime("%b %d", __import__("time").localtime(os.path.getmtime(dp)))
        cards += (f'<div class="card"><a href="/slides?d={html.escape(rel)}"><img loading="lazy" src="/{html.escape(rel)}/slide-01.png"></a><b>{html.escape(title)}</b><small>{kind} &middot; {n} pictures &middot; {day}</small><br>'
                  f'<a class="btn" href="/slides?d={html.escape(rel)}">Open</a> <a class="btn ghost" href="/download?d={html.escape(rel)}">Download</a></div>')
    reels = ""
    rd = os.path.join(base, "text-reels")
    for f in sorted([x for x in os.listdir(rd) if x.endswith(".mp4")] if os.path.isdir(rd) else [], key=lambda x: -os.path.getmtime(os.path.join(rd, x))):
        nm = f[:-4]
        rp = "customer/content/text-reels/" + f
        reels += (f'<div class="card"><video src="/content/text-reels/{html.escape(f)}" preload="metadata" muted playsinline onmouseover="this.play()" onmouseout="this.pause()"></video>'
                  f'<b>{html.escape(nm.replace("-", " "))}</b><small>Text reel</small><br><a class="btn" href="/dl?p={html.escape(rp)}">Download</a> '
                  f'<button class="btn ghost" onclick="reveal(\'{html.escape(rp)}\')">Show in folder</button></div>')
    if stories:
        body = ('<div class="grid">' + cards + "</div>") if cards else '<div class="empty">Your stories will show up here.<br><button class="btn" onclick="cp(this,\'Make my stories\')">Copy: make my stories</button></div>'
        js = "function reveal(p){fetch('/api/reveal',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({p:p})})}" + """function cp(b,t){function ok(){b.textContent='Copied. Now paste it to Claude.'}try{navigator.clipboard.writeText(t).then(ok,function(){var x=document.createElement('textarea');x.value=t;document.body.appendChild(x);x.select();document.execCommand('copy');x.remove();ok()})}catch(e){ok()}}"""
        return page("Stories", "Story sets made from your posts. Tap one to see every picture.", body, js)
    looks_html, looks_js = looks_section()
    reels = ""
    rd = os.path.join(base, "text-reels")
    for f in sorted([x for x in os.listdir(rd) if x.endswith(".mp4")] if os.path.isdir(rd) else [], key=lambda x: -os.path.getmtime(os.path.join(rd, x))):
        nm = f[:-4]
        rp = "customer/content/text-reels/" + f
        reels += (f'<div class="card"><video src="/content/text-reels/{html.escape(f)}" preload="metadata" muted playsinline onmouseover="this.play()" onmouseout="this.pause()"></video>'
                  f'<b>{html.escape(nm.replace("-", " "))}</b><small>Text reel</small><br><a class="btn" href="/dl?p={html.escape(rp)}">Download</a> '
                  f'<button class="btn ghost" onclick="reveal(\'{html.escape(rp)}\')">Show in folder</button></div>')
    body = ('<p style="margin:0 0 14px"><a class="btn" href="#" onclick="parent.postMessage({go:\'brand\'},\'*\');return false">Pick your brand: colors and fonts</a> '
            '<span class="sub" style="margin-left:8px">Your carousels use them.</span></p>') + looks_html
    if reels:
        body += '<h3>Text reels</h3><div class="grid">' + reels + "</div>"
    body += "<h3>Your carousels</h3>"
    body += ('<div class="grid">' + cards + "</div>") if cards else '<div class="empty">Your carousels will show up here.<br><button class="btn" onclick="cp(this,\'Make a carousel\')">Copy: make a carousel</button></div>'
    js = "function reveal(p){fetch('/api/reveal',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({p:p})})}" + looks_js
    return page("Carousels", "Pick a look, then see every carousel you have made.", body, js)


def slides_page(rel):
    full = os.path.abspath(os.path.join(ROOT, rel))
    if not full.startswith(os.path.join(ROOT, "customer")) or not os.path.isdir(full):
        return page("Not found", "", "")
    pics = sorted(f for f in os.listdir(full) if re.match(r"slide-\d+\.png$", f))
    r = html.escape(rel)
    import make_looks as ml
    has_spec = os.path.exists(os.path.join(full, "slides.json")) or os.path.exists(os.path.join(os.path.dirname(full), "slides.json"))
    can_move = False
    try:
        _sp = json.load(open(os.path.join(full, "slides.json") if os.path.exists(os.path.join(full, "slides.json")) else os.path.join(os.path.dirname(full), "slides.json"), encoding="utf-8"))
        can_move = bool(_sp.get("slides")) and all(s.get("type") == "tpl" for s in _sp["slides"]) and os.path.exists(os.path.join(full, "slide-01.blocks.json")) and "stories" not in rel and not any(ch in rel for ch in "'\"\\<>&")
    except Exception:
        pass
    sty = ('<button class="btn" onclick="mv_open()">Move things around</button> <button class="btn ghost" onclick="reshape(\'shorter\')">Make it shorter</button> <button class="btn ghost" onclick="reshape(\'longer\')">Make it longer</button> ' if can_move else "")
    try:
        import pick_look as pk
        sp_ = json.load(open(os.path.join(full, "slides.json") if os.path.exists(os.path.join(full, "slides.json")) else os.path.join(os.path.dirname(full), "slides.json"), encoding="utf-8"))
        sl_ = sp_.get("slides", [])
        if sl_ and not all(s.get("type") == "tpl" for s in sl_) and "stories" not in rel and not any(s.get("type") in ("videoclip", "panoL") for s in sl_):
            stn0 = (looks_load().get("names") or {})
            opts0 = '<option value="0" selected>Choose a look...</option>' + "".join(f'<option value="{n}">{html.escape(stn0.get(str(n)) or nm)}</option>' for n, nm in pk.NAMES.items()) + "".join(f'<option value="custom:{m_["id"]}">{html.escape(m_["name"])}</option>' for m_ in looks_load()["mine"] if m_.get("custom"))
            sty += ('<span class="sub">Make this one in a look: </span><select id="sty" style="font:inherit;padding:6px 8px;border-radius:10px;border:1px solid var(--line)">' + opts0 + '</select> '
                    '<button class="btn" onclick="if(document.getElementById(\'sty\').value!==\'0\')restyle()">Switch</button> ')
        if sl_ and all(s.get("type") == "tpl" for s in sl_) and "stories" not in rel:
            cur = sl_[0].get("template", 0)
            cur = cur if str(cur).startswith("custom:") else int(cur)
            stn = (looks_load().get("names") or {})
            opts = "".join(f'<option value="{n}"{" selected" if n == cur else ""}>{html.escape(stn.get(str(n)) or nm)}</option>' for n, nm in pk.NAMES.items())
            opts += "".join(f'<option value="custom:{m_["id"]}"{" selected" if cur == "custom:" + str(m_["id"]) else ""}>{html.escape(m_["name"])}</option>' for m_ in looks_load()["mine"] if m_.get("custom"))
            sty += ('<span class="sub">Style: </span><select id="sty" style="font:inherit;padding:6px 8px;border-radius:10px;border:1px solid var(--line)">' + opts + '</select> '
                   '<button class="btn ghost" onclick="restyle()">Change style</button> ')
    except Exception:
        sty = ""
    redraw_btn = sty + ('<button class="btn ghost" onclick="redrawBrand()">Redraw in my brand colors</button> ' if (has_spec and len(ml.brand_colors()) >= 2 and "stories" not in rel) else "")
    body = ('<p><a class="btn ghost" href="' + ("/stories" if "stories" in rel else "/content") + '">Back</a> <a class="btn" href="/download?d=' + r + '">Download all (zip)</a> '
            '<button class="btn ghost" id="eds" onclick="editSlides()">Edit the slide words</button> ' + redraw_btn + '<span id="edsm" class="sub"></span></p><div class="grid">'
            + "".join(f'<div class="card"><a href="/{r}/{f}" target="_blank"><img src="/{r}/{f}" loading="lazy"></a><small>{f}</small></div>' for f in pics) + "</div>")
    cap = os.path.join(full, "caption.txt")
    ct = open(cap, encoding="utf-8").read() if os.path.exists(cap) else ""
    body += ('<h3 style="margin-top:20px">Caption <button class="btn ghost" style="font-size:13px;padding:4px 10px" onclick="editText(\'' + r + '/caption.txt\',\'Caption\',function(){location.reload()})">' + ("Edit" if ct else "Add a caption") + '</button></h3>'
             + ('<pre style="white-space:pre-wrap;background:#fff;border:1px solid var(--line);border-radius:12px;padding:12px">' + html.escape(ct) + "</pre>" if ct else '<p class="sub">No caption yet.</p>'))
    mv_js = r"""
var MV={n:%d,i:0,blocks:[],moved:{},undo:%s,D:'%s',spec:null,words:{},dirty:false};
window.addEventListener('beforeunload',function(e){var o=document.getElementById('mvo');if(MV.dirty&&o&&o.style.display==='block'){e.preventDefault();e.returnValue=''}});
function mv_wait(msg){var h=document.getElementById('mvh')||document.getElementById('edsm');if(h)h.textContent=msg||'Redrawing... one moment.';
 var tries=0;(function poll(){fetch('/api/carousel/status?d='+encodeURIComponent(MV.D)).then(function(r){return r.json()}).then(function(j){tries++;if(j.running&&tries<90){setTimeout(poll,2000)}else{location.reload()}}).catch(function(){setTimeout(function(){location.reload()},8000)})})()}
function mv_post(u,o,msg){var h=document.getElementById('mvh')||document.getElementById('edsm');o=o||{};o.d=MV.D;fetch(u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o)}).then(function(x){return x.json()}).then(function(j){if(j.ok){mv_wait(msg)}else if(h){h.textContent=j.error||'That did not work.'}})}
function mv_open(){var o=document.getElementById('mvo');if(!o){o=document.createElement('div');o.id='mvo';o.innerHTML='<div class="mvbar"><b>Move things around</b><span id="mvh">Drag a box to move it. Gold dot resizes, blue dot turns. Edit the words on the right.</span><span class="sp"></span><button onclick="mv_go(-1)">&lsaquo; Back</button><span id="mvn"></span><button onclick="mv_go(1)">Next &rsaquo;</button><button onclick="mv_reset()">Put this slide back</button>'+(MV.undo?'<button onclick="mv_undo()">Undo my last save</button>':'')+'<button onclick="mv_all()">Reset all slides</button><button class="pri" onclick="mv_save()">Save and redraw</button><button onclick="mv_close()">Close</button></div><div class="mvwrap"><div id="mvs"></div><div id="mvp"></div></div>';document.body.appendChild(o);
 ['dragenter','dragover'].forEach(function(ev){o.addEventListener(ev,function(e){if(e.dataTransfer&&Array.prototype.indexOf.call(e.dataTransfer.types||[],'Files')>=0){e.preventDefault();o.classList.add('dropping')}})});
 o.addEventListener('dragleave',function(e){if(!o.contains(e.relatedTarget))o.classList.remove('dropping')});
 o.addEventListener('drop',function(e){e.preventDefault();o.classList.remove('dropping');if(e.dataTransfer&&e.dataTransfer.files.length)mv_drop(e.dataTransfer.files)})}o.style.display='block';MV.i=0;MV.moved={};MV.words={};MV.spec=null;
 fetch('/api/carousel/spec?d='+encodeURIComponent(MV.D)).then(function(r){return r.json()}).then(function(j){MV.spec=j;mv_panel()});mv_load()}
var MVL={headline:'Headline',hi:'Highlight word',body:'Words under it',note:'Little note',who:'Who or source',items:'The lines (one per line)',keyword:'Comment word',line:'Line under it',lead:'Small line above',top:'Top words',bottom:'Bottom words',left_title:'Left title',left:'Left lines',right_title:'Right title',right:'Right lines',footer:'Bottom line'};
function mv_drop(files){var f=Array.prototype.slice.call(files).filter(function(x){return /^image\//.test(x.type)||/\.(jpe?g|png|webp)$/i.test(x.name)})[0];if(!f||!MV.spec)return;var sl=MV.spec.slides[MV.i];if(!sl)return;
 fetch('/api/carousel/photo?d='+encodeURIComponent(MV.D)+'&name='+encodeURIComponent(f.name),{method:'POST',body:f}).then(function(r){return r.json()}).then(function(j){if(j.ok){MV.dirty=true;MV.spec.pics.push({url:j.url,path:j.path});(MV.words[MV.i]=MV.words[MV.i]||{}).photo=j.path;mv_panel();var h=document.getElementById('mvh');if(h)h.textContent='Picture added to slide '+(MV.i+1)+'. Tap Save and redraw to see it.'}else alert(j.error||'That did not work.')})}
function mv_panel(){var p=document.getElementById('mvp');if(!p)return;var sl=MV.spec&&MV.spec.slides&&MV.spec.slides[MV.i];if(!sl){p.innerHTML='';return}
 var keys=['headline','hi','body','note','who','items','keyword','line','lead','top','bottom','left_title','left','right_title','right','footer'],h='<h3>Slide '+(MV.i+1)+': words and picture</h3><p class="mvnote">Change anything, then tap Save and redraw.</p>';
 keys.forEach(function(k){if(sl[k]===undefined)return;var multi=(k==='items'||k==='left'||k==='right'||k==='body');h+='<label>'+MVL[k]+'</label>'+(multi?'<textarea data-k="'+k+'" rows="'+(k==='body'?3:4)+'"></textarea>':'<input data-k="'+k+'">')});
 var showpic=(sl.photo!==undefined||sl.kind==='cover'||sl.kind==='photo');if(!showpic)h+='<p class="mvnote">Drop a picture anywhere on this screen to add one to this slide.</p>';
 if(showpic){h+='<label>Picture</label><div class="mvpics" id="mvpics"></div><label class="mvup">Use a picture from my computer (or drop one here)<input type="file" accept="image/*" id="mvfile" style="display:none"></label>'}
 p.innerHTML=h;
 p.querySelectorAll('[data-k]').forEach(function(el){var k=el.dataset.k,w=MV.words[MV.i]&&MV.words[MV.i][k],v=(w!==undefined)?w:(Array.isArray(sl[k])?sl[k].join('\n'):sl[k]);el.value=v;el.oninput=function(){MV.dirty=true;(MV.words[MV.i]=MV.words[MV.i]||{})[k]=el.value}});
 if(showpic){var cur=(MV.words[MV.i]&&MV.words[MV.i].photo)||sl.photo,box=document.getElementById('mvpics');
  (MV.spec.pics||[]).forEach(function(pc){var im=document.createElement('img');im.src=pc.url;im.title='Use this picture';if(pc.path===cur)im.className='on';im.onclick=function(){MV.dirty=true;(MV.words[MV.i]=MV.words[MV.i]||{}).photo=pc.path;mv_panel()};box.appendChild(im)});
  if(!(MV.spec.pics||[]).length)box.innerHTML='<span class="mvnote">No other pictures yet. Add one below.</span>';
  document.getElementById('mvfile').onchange=function(){var f=this.files[0];if(!f)return;fetch('/api/carousel/photo?d='+encodeURIComponent(MV.D)+'&name='+encodeURIComponent(f.name),{method:'POST',body:f}).then(function(r){return r.json()}).then(function(j){if(j.ok){MV.dirty=true;MV.spec.pics.push({url:j.url,path:j.path});(MV.words[MV.i]=MV.words[MV.i]||{}).photo=j.path;mv_panel()}else{alert(j.error||'That did not work.')}})}}}
function mv_close(){if(MV.dirty&&!confirm('You have changes that are not saved yet. Close without saving?'))return;MV.dirty=false;document.getElementById('mvo').style.display='none'}
function mv_go(k){MV.i=Math.max(0,Math.min(MV.n-1,MV.i+k));mv_load()}
function mv_reset(){MV.dirty=true;MV.moved[MV.i]=MV.blocks.map(function(x){return{at:x.at,d:[0,0],s:1,r:0}});mv_load(true)}
function mv_undo(){if(confirm('Go back to how it was before your last save?'))mv_post('/api/carousel/undo',{},'Going back... one moment.')}
function mv_all(){if(confirm('Put every piece on every slide back where it started?'))mv_post('/api/carousel/resetmoves',{},'Putting everything back... one moment.')}
function mv_load(reset){var s=document.getElementById('mvs'),f='slide-0'+(MV.i+1),base='/'+MV.D+'/';document.getElementById('mvn').textContent=(MV.i+1)+' of '+MV.n;
 function go(b){MV.blocks=b;
  if(MV.moved[MV.i]===undefined){MV.moved[MV.i]=b.map(function(x){return{at:x.at,d:x.d.slice(),s:x.s||1,r:x.r||0}})}
  var sc=Math.min(520,window.innerWidth-40)/1080,T=Date.now();s.style.width=(1080*sc)+'px';s.style.height=(1350*sc)+'px';
  s.innerHTML='<img class="mvbase" src="'+base+f+'.png?t='+T+'">';
  b.forEach(function(x,k){var m=MV.moved[MV.i][k],cb=x.bbox,pb=x.pb||cb,s0=x.s||1,r0=x.r||0,w0=cb[2]-cb[0],h0=cb[3]-cb[1],cx0=(cb[0]+cb[2])/2,cy0=(cb[1]+cb[3])/2;
   function pimg(kind){var im=document.createElement('img');im.className='mvpc';im.src=base+f+'.'+kind+'-'+x.id+'.png?t='+T;im.style.left=(pb[0]*sc)+'px';im.style.top=(pb[1]*sc)+'px';im.style.width=((pb[2]-pb[0])*sc)+'px';im.style.height=((pb[3]-pb[1])*sc)+'px';im.style.display='none';s.appendChild(im);return im}
   var patch=pimg('patch'),piece=pimg('piece');piece.style.transformOrigin=((cx0-pb[0])*sc)+'px '+((cy0-pb[1])*sc)+'px';
   var d=document.createElement('div');d.className='mvb';d.tabIndex=0;d.title=x.label;var hs=document.createElement('i');hs.className='mvh';var hr=document.createElement('i');hr.className='mvr';d.appendChild(hs);d.appendChild(hr);
   function place(){var q=m.s/s0,w=w0*q,h=h0*q,l=x.at[0]+m.d[0]-w/2,t=x.at[1]+m.d[1]-h/2,dr=m.r-r0;
    d.style.left=(l*sc)+'px';d.style.top=(t*sc)+'px';d.style.width=(w*sc)+'px';d.style.height=(h*sc)+'px';d.style.transform='rotate('+dr+'deg)';
    var ch=(m.d[0]!==x.d[0]||m.d[1]!==x.d[1]||Math.abs(q-1)>.001||Math.abs(dr)>.01);
    patch.style.display=piece.style.display=ch?'block':'none';piece.style.transform='translate('+((m.d[0]-x.d[0])*sc)+'px,'+((m.d[1]-x.d[1])*sc)+'px) rotate('+dr+'deg) scale('+q+')';
    d.classList.toggle('on',ch||m.d[0]!==0||m.d[1]!==0||Math.abs(m.s-1)>.001||Math.abs(m.r)>.01)}
   place();var st=null;
   d.onpointerdown=function(e){d.setPointerCapture&&d.setPointerCapture(e.pointerId);var r=s.getBoundingClientRect(),cx=r.left+(x.at[0]+m.d[0])*sc,cy=r.top+(x.at[1]+m.d[1])*sc;
    st={mode:e.target===hs?'size':(e.target===hr?'turn':'move'),sx:e.clientX,sy:e.clientY,d:m.d.slice(),s:m.s,r:m.r,cx:cx,cy:cy,dist:Math.max(8,Math.hypot(e.clientX-cx,e.clientY-cy)),ang:Math.atan2(e.clientY-cy,e.clientX-cx)*180/Math.PI};d.classList.add('drag');e.preventDefault()};
   d.onpointermove=function(e){if(!st)return;MV.dirty=true;if(st.mode==='move'){m.d=[Math.round(st.d[0]+(e.clientX-st.sx)/sc),Math.round(st.d[1]+(e.clientY-st.sy)/sc)]}
    else if(st.mode==='size'){m.s=Math.max(.3,Math.min(3,Math.round(st.s*Math.hypot(e.clientX-st.cx,e.clientY-st.cy)/st.dist*100)/100))}
    else{var a=Math.atan2(e.clientY-st.cy,e.clientX-st.cx)*180/Math.PI,v=st.r+(a-st.ang);v=((v+540)%%360)-180;v=Math.round(v);if(Math.abs(v)<4)v=0;m.r=v}
    place()};
   d.onpointerup=function(){st=null;d.classList.remove('drag')};
   d.onkeydown=function(e){var q=e.shiftKey?40:10,mm={ArrowLeft:[-q,0],ArrowRight:[q,0],ArrowUp:[0,-q],ArrowDown:[0,q]}[e.key];if(mm){MV.dirty=true;m.d=[m.d[0]+mm[0],m.d[1]+mm[1]];place();e.preventDefault()}
    if(e.key==='+'||e.key==='='||e.key==='-'||e.key==='['||e.key===']')MV.dirty=true;
    if(e.key==='+'||e.key==='='){m.s=Math.min(3,Math.round((m.s+.05)*100)/100);place()}if(e.key==='-'){m.s=Math.max(.3,Math.round((m.s-.05)*100)/100);place()}
    if(e.key==='['){m.r=Math.max(-180,m.r-5);place()}if(e.key===']'){m.r=Math.min(180,m.r+5);place()}};
   s.appendChild(d)})}
 fetch(base+f+'.blocks.json?t='+Date.now()).then(function(r){return r.json()}).then(function(b){
  if(b.some(function(x){return !x.pb})&&!MV.fixing){MV.fixing=1;document.getElementById('mvh').textContent='Getting your pieces ready... one moment.';
   fetch('/api/carousel/pieces',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({d:MV.D})}).then(function(){var n=0;(function poll(){fetch('/api/carousel/status?d='+encodeURIComponent(MV.D)).then(function(r){return r.json()}).then(function(j){if(j.running&&n++<60){setTimeout(poll,2000)}else{MV.fixing=0;document.getElementById('mvh').textContent='Drag a box to move it. Drag the gold dot to resize, the blue dot to turn.';mv_load()}})})()});return}
  go(b);mv_panel()}).catch(function(){document.getElementById('mvh').textContent='I could not load this slide.'})}
function mv_save(){MV.dirty=false;var o={};Object.keys(MV.moved).forEach(function(k){o[k]=MV.moved[k]});mv_post('/api/carousel/moves',{slides:o,words:MV.words},'Saving and redrawing... one moment.')}
""" % (len(pics), "true" if os.path.exists((os.path.join(full, "slides.json") if os.path.exists(os.path.join(full, "slides.json")) else os.path.join(os.path.dirname(full), "slides.json")) + ".undo") else "false", rel)
    mv_css = ('<style>#mvo{display:none;position:fixed;inset:0;background:#2b3430;z-index:99;overflow:auto;color:#fff}.mvbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;padding:10px 14px;background:#1f2723;position:sticky;top:0;z-index:3}'
              '.mvbar .sp{flex:1}.mvbar span{font-size:14px;color:#cfd8d3}.mvbar button{border:0;border-radius:999px;padding:8px 14px;font-weight:700;cursor:pointer;background:#fff;color:#26332C}.mvbar button.pri{background:#E9B949}'
              '.mvwrap{display:flex;justify-content:center;padding:18px 0 40px}#mvs{position:relative;touch-action:none}'
              '.mvbase{width:100%;display:block;border-radius:6px;pointer-events:none}.mvpc{position:absolute;pointer-events:none}#mvo.dropping{outline:4px dashed #E9B949;outline-offset:-8px}#mvp{width:300px;margin-left:18px;background:#1f2723;border-radius:12px;padding:12px 14px;color:#fff;align-self:flex-start;max-height:80vh;overflow:auto}#mvp h3{margin:0 0 4px;font-size:16px}#mvp label{display:block;font-size:12px;color:#cfd8d3;margin:10px 0 3px}#mvp input,#mvp textarea{width:100%;border:0;border-radius:8px;padding:7px 9px;font:inherit;font-size:14px;background:#fff;color:#26332C}.mvnote{font-size:12px;color:#cfd8d3}.mvpics{display:flex;gap:6px;flex-wrap:wrap}.mvpics img{width:58px;height:58px;object-fit:cover;border-radius:8px;cursor:pointer;border:3px solid transparent}.mvpics img.on{border-color:#E9B949}.mvup{display:inline-block;background:#fff;color:#26332C!important;border-radius:999px;padding:7px 12px;font-weight:700;cursor:pointer;margin-top:8px}@media(max-width:900px){.mvwrap{flex-direction:column;align-items:center}#mvp{margin:14px 0 0;width:min(520px,92vw)}}.mvr{position:absolute;left:50%;top:-30px;margin-left:-9px;width:18px;height:18px;border-radius:50%;background:#6FA7A8;border:2px solid #fff;cursor:grab;box-shadow:0 1px 4px rgba(0,0,0,.4)}.mvr::before{content:'';position:absolute;left:50%;top:18px;width:2px;height:12px;margin-left:-1px;background:rgba(255,255,255,.8)}.mvh{position:absolute;right:-9px;bottom:-9px;width:18px;height:18px;border-radius:50%;background:#E9B949;border:2px solid #fff;cursor:nwse-resize;box-shadow:0 1px 4px rgba(0,0,0,.4)}.mvb{position:absolute;outline:2px dashed rgba(255,255,255,.75);outline-offset:0;cursor:grab;background-repeat:no-repeat}.mvb:hover{outline-color:#E9B949}.mvb.drag{cursor:grabbing;outline:3px solid #E9B949;z-index:5}.mvb.on{outline-style:solid;outline-color:#6FA7A8}</style>')
    js = mv_js + ("function reshape(d){var m=document.getElementById('edsm');m.textContent='Working on it...';fetch('/api/carousel/length',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({d:'" + r + "',dir:d})}).then(function(x){return x.json()}).then(function(j){if(j.ok){m.textContent=j.message+' Redrawing...';mv_wait(j.message+' Redrawing...')}else{m.textContent=j.error||'That did not work.'}})}"
          "function restyle(){var m=document.getElementById('edsm');m.textContent='Changing the style... about a minute.';fetch('/api/carousel/restyle',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({d:'" + r + "',template:document.getElementById('sty').value})}).then(function(x){return x.json()}).then(function(j){if(j.ok){mv_wait()}else{m.textContent=j.error||'Could not change it.'}})}"
          "function redrawBrand(){var m=document.getElementById('edsm');m.textContent='Redrawing in your brand colors... about a minute.';fetch('/api/carousel/redraw',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({d:'" + r + "'})}).then(function(x){return x.json()}).then(function(j){if(j.ok){mv_wait()}else{m.textContent=j.error||'Could not redraw it.'}})}"
          "function editSlides(){var m=document.getElementById('edsm');m.textContent='Opening the slide editor...';fetch('/api/carousel/edit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({d:'" + rel.replace("'", "") + "'})}).then(function(r){return r.json()}).then(function(j){"
          "if(j.url){m.textContent='Opened in a new tab. Change the words, press Redraw, then come back.';window.open(j.url,'_blank')}else{m.textContent=j.error||'Could not open it.'}})}")
    return page(os.path.basename(full), str(len(pics)) + " pictures.", body + (mv_css if can_move else ""), js)


def scripts_list():
    folder = os.path.join(ROOT, "customer", "scripts")
    rows = ""
    for f in sorted(os.listdir(folder), reverse=True) if os.path.isdir(folder) else []:
        if not f.endswith(".md") or f.startswith("."):
            continue
        t = open(os.path.join(folder, f), encoding="utf-8").readline().lstrip("# ").strip() or f
        rows += f'<div class="row" onclick="location.href=\'/script?f={html.escape(f)}\'"><b>{html.escape(t)}</b><span class="pill">{html.escape(f[:10])}</span></div>'
    return page("Scripts", "Every script written for you. Tap one to read it.", rows or '<div class="empty">Your scripts will show up here.</div>')


def script_page(f):
    p = os.path.join(ROOT, "customer", "scripts", os.path.basename(f))
    if not os.path.exists(p):
        return page("Not found", "", "")
    return page("Script", '<a class="btn ghost" href="/scripts">Back to all scripts</a>', md_html(open(p, encoding="utf-8").read()))


def results_page():
    bank = os.path.join(ROOT, "customer", "insights", "winners.jsonl")
    rows = [json.loads(l) for l in open(bank, encoding="utf-8") if l.strip()] if os.path.exists(bank) else []
    rows.sort(key=lambda r: -(r.get("times") or 0))
    cards = ""
    for r in rows:
        hook = html.escape((r.get("hook") or r.get("title") or "")[:110])
        times = f'<div class="big">{r["times"]}x</div><small>your typical post</small>' if r.get("times") else ""
        nums = " &middot; ".join(f"{v:,} {k}" for k, v in (("views", r.get("views")), ("likes", r.get("likes")), ("comments", r.get("comments")), ("saves", r.get("saves")), ("shares", r.get("shares"))) if isinstance(v, (int, float)))
        used = ("<small>Brought back: " + html.escape(", ".join(u["how"] for u in r["used"])) + "</small><br>") if r.get("used") else ""
        ways = "".join(f'<button class="btn ghost" onclick="copyAsk(this,\'{html.escape(w, quote=True)}: {hook.replace(chr(39), "")}\')">{t}</button> ' for w, t in (("Same idea, new hook", "New hook"), ("Turn into a carousel", "Carousel"), ("Turn into stories", "Stories")))
        link = f' <a href="{html.escape(r["link"])}" target="_blank">See the post</a>' if r.get("link") else ""
        cards += (f'<div class="card hit"><div class="top">{times}</div><b>&ldquo;{hook}&rdquo;</b><small>{html.escape(str(r.get("posted") or ""))} &middot; {html.escape(r.get("kind", "reel"))}{link}</small>'
                  f'<p class="sub" style="margin:6px 0">{nums}</p>{used}<div>{ways}</div></div>')
    css = (".hit .top{background:var(--teal,#2A6E6F);color:#fff;border-radius:12px;padding:12px;margin-bottom:8px;text-align:center}.hit .big{font:800 40px system-ui}.hit .top small{color:#fff;opacity:.85}"
           "#toast{position:fixed;bottom:16px;left:50%;transform:translateX(-50%);background:#1d2330;color:#fff;padding:10px 16px;border-radius:12px;display:none}")
    js = ("function copyAsk(b,t){var x=document.createElement('textarea');x.value=t;document.body.appendChild(x);x.select();try{document.execCommand('copy')}catch(e){}x.remove();"
          "var m=document.getElementById('toast');m.textContent='Copied. Paste it in the chat with Claude.';m.style.display='block';setTimeout(function(){m.style.display='none'},2600)}")
    looks_html = ""
    try:   # which carousel looks do best for her (only after enough of her own results; see results.py)
        lj = json.load(open(os.path.join(ROOT, "customer", "insights", "learned.json"), encoding="utf-8"))
        lb = lj.get("looks_baseline")
        nm_ = {"1": "Scrapbook", "2": "Numbered tips", "3": "Bold editorial", "4": "Photo statement", "5": "Warm flat color", "6": "Photo story", "7": "Notebook caps", "8": "Face and contrast"}
        st_ = looks_load()
        for m_ in st_["mine"]:
            nm_[f"custom:{m_['id']}"] = m_["name"]
        rows_ = [(k, v) for k, v in (lj.get("looks") or {}).items() if v.get("posts", 0) >= 3] if (lj.get("enough") and lb) else []
        if rows_:
            looks_html = "<h3>Which carousel looks work for you</h3>" + "".join(
                f'<p class="sub" style="margin:4px 0"><b>{html.escape(nm_.get(k, k))}</b>: {v["posts"]} carousels, {"better than" if v["median"] > lb * 1.15 else ("below" if v["median"] < lb * 0.85 else "about the same as")} your usual carousel.</p>'
                for k, v in sorted(rows_, key=lambda kv: -kv[1]["median"])) + '<p class="sub">The engine leans toward the looks that do better for you.</p>'
    except Exception:
        looks_html = ""
    pend_ = len([f_ for f_ in (os.listdir(INBOX) if os.path.isdir(INBOX) else []) if f_.startswith("insights-")])
    drop_ = ('<div id="dz" style="border:3px dashed #8E96A3;border-radius:16px;padding:18px;text-align:center;background:#fff;margin:0 0 16px">'
             '<b>Sunday: drop your Instagram Insights screenshots here</b>'
             '<p class="sub" style="margin:6px 0">Open each post in Instagram, tap View insights, take a screenshot, and drag the pictures onto this box. '
             'Saves and shares are private on Instagram, so this is how the engine learns what really works for you.</p>'
             '<button class="btn" onclick="document.getElementById(\'dzf\').click()">Choose screenshots</button> '
             '<input type="file" id="dzf" accept="image/*" multiple style="display:none">'
             f'<p id="dzm" class="sub" style="margin:8px 0 0">{pend_} screenshot{"" if pend_ == 1 else "s"} waiting.</p>'
             '<button class="btn ghost" style="margin-top:6px" onclick="copyAsk(this,\'Read my insights screenshots\')">Copy: read my screenshots</button></div>')
    dzjs_ = ("function dzUp(fs){fs=Array.prototype.slice.call(fs).filter(function(f){return /^image\\//.test(f.type)||/\\.(jpe?g|png|webp|heic)$/i.test(f.name)});var m=document.getElementById('dzm');if(!fs.length){m.textContent='Drop pictures (screenshots).';return}m.textContent='Adding...';var i=0;(function next(){if(i>=fs.length){m.textContent='Added '+fs.length+(fs.length===1?' screenshot.':' screenshots.')+' Now tap Copy and paste it to Claude.';return}var f=fs[i++];fetch('/api/insights/upload?name='+encodeURIComponent(f.name),{method:'POST',body:f}).then(next,next)})()}"
             "var dz=document.getElementById('dz');if(dz){['dragenter','dragover'].forEach(function(e){document.body.addEventListener(e,function(ev){if(ev.dataTransfer&&Array.prototype.indexOf.call(ev.dataTransfer.types||[],'Files')>=0){ev.preventDefault();dz.style.borderColor='#2A6E6F'}})});"
             "document.body.addEventListener('drop',function(ev){if(ev.dataTransfer&&ev.dataTransfer.files.length){ev.preventDefault();dz.style.borderColor='#8E96A3';dzUp(ev.dataTransfer.files)}});document.body.addEventListener('dragleave',function(){dz.style.borderColor='#8E96A3'});"
             "document.getElementById('dzf').onchange=function(){dzUp(this.files)}}")
    js = js + dzjs_
    body = ("<style>" + css + "</style>" + drop_ + looks_html + ('<div class="grid">' + cards + "</div>" if cards else
            '<div class="empty">Your best posts will show up here after the Sunday refresh, with how much better they did than your usual post. Each one can be reused: a new hook, a carousel or stories.</div>')
            + '<div id="toast"></div>')
    return page("Best performing content", "Your posts that beat your usual. Tap one to reuse it.", body, js)


def font_families():
    out = []
    folder = os.path.join(ROOT, "engine", "fonts")
    for f in sorted(os.listdir(folder)) if os.path.isdir(folder) else []:
        if f.lower().endswith((".ttf", ".otf")):
            n = re.sub(r"\[.*?\]|-(Regular|Bold|Medium|SemiBold|ExtraBold|Black|Italic|Light).*$", "", os.path.splitext(f)[0])
            n = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", n).strip()
            if n and n not in out:
                out.append(n)
    return out


def brand_load():
    bj = os.path.join(ROOT, "customer", "profile", "brand.json")
    d = json.load(open(bj, encoding="utf-8")) if os.path.exists(bj) else {}
    d.setdefault("name", "")
    d.setdefault("fonts", [])
    d.setdefault("logo", "")
    d.setdefault("photos", [])
    d.setdefault("colors", [])
    d.setdefault("dark", "#1F1F1F")
    return d


def brand_store(d):
    roles = ["primary", "secondary", "accent", "extra", "extra"]
    d["colors"] = [{"role": roles[i], "hex": c["hex"] if isinstance(c, dict) else c} for i, c in enumerate(d.get("colors", [])[:5])]
    os.makedirs(os.path.join(ROOT, "customer", "profile"), exist_ok=True)
    json.dump(d, open(os.path.join(ROOT, "customer", "profile", "brand.json"), "w", encoding="utf-8"), indent=1)
    with open(os.path.join(ROOT, "customer", "profile", "brand.md"), "w", encoding="utf-8") as f:
        f.write("# Her brand\n\n" + f"Name: {d.get('name', '')}\nFonts: {', '.join(d.get('fonts', []))}\n\n" + "\n".join(f"- {c['role']}: {c['hex']}" for c in d["colors"]) + "\n")


def doc_sections(raw):
    """Split a markdown file into its parts: the top (title and intro), then one part per '## ' heading."""
    parts, cur = [], []
    for ln in raw.splitlines(True):
        if ln.startswith("## ") and cur:
            parts.append("".join(cur))
            cur = []
        cur.append(ln)
    if cur:
        parts.append("".join(cur))
    return parts


def brand_page():
    import brand_colors as bc
    d = brand_load()
    fams = font_families()
    body = ("<style>" + bc.CARD_CSS + """
.bcard input.nm{font:800 26px system-ui;color:#1d2330;background:transparent;border:2px dashed #8E96A3;background:#fff;border-radius:10px;padding:6px 10px;width:100%}.bcard input.nm:hover,.bcard input.nm:focus{border-color:#8E96A3;background:#fff;outline:0}
.bcard .logo{position:relative;cursor:pointer}.bcard .logo small,.bcard .tools{font-size:12px;color:#55544B}.bcard .rm{position:absolute;right:6px;top:6px;border:0;background:#fff;border-radius:50%;width:24px;height:24px;cursor:pointer;font-size:15px;line-height:1;box-shadow:0 1px 4px rgba(0,0,0,.25)}
.bcard .font select,.bcard .font input{font:inherit;border:0;border-top:1px solid #D4D7DD;padding:9px 6px;width:100%;text-align:center;background:#fff}
.bcard .pal{position:relative}.bcard .pal label{flex:1;position:relative;cursor:pointer;display:block}.bcard .pal input[type=color]{position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:pointer}.bcard .pal label i{position:absolute;inset:0}
.bcard .pal button.x{box-shadow:0 1px 4px rgba(0,0,0,.35);position:absolute;top:4px;left:50%;transform:translateX(-50%);border:0;background:rgba(255,255,255,.9);border-radius:50%;width:22px;height:22px;cursor:pointer;z-index:3;font-size:14px;line-height:1}
.bcard .addc{flex:none;width:44px;border:0;background:#fff;font-size:28px;cursor:pointer;color:#2A6E6F}
.bcard .ph{position:relative}.bcard .ph button{position:absolute;right:6px;top:6px;border:0;background:#fff;border-radius:50%;width:24px;height:24px;cursor:pointer;font-size:15px;line-height:1;box-shadow:0 1px 4px rgba(0,0,0,.25)}
.bcard .add{display:flex;align-items:center;justify-content:center;border:3px dashed #8E96A3;font-weight:800;color:#55544B;cursor:pointer;background:transparent;font-size:15px;text-align:center;padding:6px}
#saved{height:22px;color:#2A6E6F;font-weight:700;margin-top:6px}</style>""")
    cols = [c["hex"] if isinstance(c, dict) else c for c in d["colors"]]
    pal = "".join(f'<label><i style="background:{c}"></i><input type="color" value="{c}" data-ci="{k}"><button class="x" data-rm="{k}" title="Remove this color">&times;</button></label>' for k, c in enumerate(cols))
    if len(cols) < 5:
        pal += '<button class="addc" id="addc" title="Add a color">+</button>'
    font = (d["fonts"] or [""])[0]
    logo = (f'<img src="/customer/profile/brand/{d["logo"]}?t={int(__import__("time").time())}" alt="logo"><button class="rm" id="rmlogo" title="Remove the logo">&times;</button><small style="display:block;color:#2A6E6F;font-weight:700;text-align:center">Change logo</small>' if d["logo"]
            else "<small style=\'font-weight:700;color:#2A6E6F\'>+ Add your logo</small>")
    photos = "".join(f'<div class="ph"><img src="/customer/profile/brand/photos/{p}?t={int(__import__("time").time())}" alt=""><button data-rp="{p}" title="Remove this photo">&times;</button></div>' for p in d["photos"])
    photos += '<div class="ph add" id="addph">+ Add a photo</div>'
    import first_edit as fe_
    mine_ = sorted(os.listdir(fe_.BRAND_FONTS)) if os.path.isdir(fe_.BRAND_FONTS) else []
    for f_ in mine_:   # her uploaded fonts show up by name in the picker too
        n_ = re.sub(r"-[A-Za-z]+$", "", os.path.splitext(f_)[0])
        n_ = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", n_).strip()
        if n_ and n_ not in fams:
            fams.append(n_)
    face_css = "".join(f"@font-face{{font-family:'{re.sub(r'(?<=[a-z])(?=[A-Z])', ' ', re.sub(r'-[A-Za-z]+$', '', os.path.splitext(f_)[0]))}';src:url(/customer/profile/brand/fonts/{f_})}}" for f_ in mine_ if f_.lower().endswith((".ttf", ".otf")))
    body = ("<style>" + face_css + "</style>") + body
    have_ = fe_._has_font(font) if font else True
    font_note = ("" if have_ else '<small style="display:block;color:#B4531A;font-weight:700;text-align:center;padding:2px 6px">That font is not installed yet, so your carousels and videos cannot use it. Upload the font file below.</small>')
    opts = "".join(f'<option value="{html.escape(f_)}"></option>' for f_ in fams)
    import brand_picker as bp_
    body += bp_.picker_html(os.path.join(ROOT, "engine", "fonts"), {"colors": cols, "fonts": d.get("fontSet")} if d.get("fontSet") else None)
    body += (f'<div class="bcard" id="card"><input class="nm" id="nm" value="{html.escape(d["name"])}" placeholder="Your brand name">'
             f'<div class="brow"><div class="logo" id="logo">{logo}</div>'
             f'<div class="font"><div class="aa" id="aa" style="font-family:\'{html.escape(font)}\',system-ui,sans-serif">Aa</div><input id="fn" list="fams" value="{html.escape(font)}" placeholder="Pick or type a font"><small style="display:block;color:#2A6E6F;font-weight:700;text-align:center;padding:2px 0 2px">Change font</small>{font_note}<button class="btn ghost" id="upfont" style="margin:4px auto 8px;display:block;font-size:13px;padding:4px 12px">Upload my font file</button><input type="file" id="ff" accept=".ttf,.otf" style="display:none"><datalist id="fams">{opts}</datalist></div>'
             f'<div class="pal" id="pal">{pal}</div></div>'
             f'<p class="sub" style="margin:10px 0 4px"><b>Colors:</b> click a color to change it. <b>Photos:</b> x removes one, + adds one.</p><div class="brow2" style="grid-template-columns:repeat(4,1fr)">{photos}</div></div>'
             '<input type="file" id="lf" accept="image/*" style="display:none"><input type="file" id="pf" accept="image/*" multiple style="display:none">'
             '<div id="saved"></div><p class="sub"><b>Drag and drop:</b> drop photos (or a font file) anywhere on this page. Everything on the card is yours to change. Click the name to rename it, the logo to replace it, the font to pick another, a color to change it, or a photo&#39;s x to remove it. It saves as you go.</p>')
    body += ('<div style="margin:16px 0"><input id="u" placeholder="yourwebsite.com" style="font:inherit;padding:10px 12px;border:1px solid var(--line);border-radius:12px;width:min(360px,100%)"> '
             '<button class="btn" onclick="site()">Pull my brand from my website</button> <span id="m" class="sub"></span></div>')
    for nm, t in (("voice-profile.md", "Your voice"), ("audience.md", "Who you are talking to")):
        p = os.path.join(ROOT, "customer", "profile", nm)
        if os.path.exists(p):
            raw = open(p, encoding="utf-8").read()
            key = nm.replace(".md", "")
            body += f"<h3>{t}</h3>"
            for n, chunk in enumerate(doc_sections(raw)):
                sid = f"{key}-{n}"
                body += (f'<div class="sec" id="v-{sid}" style="overflow:auto"><div class="sbar" style="float:right;margin:2px 0 4px 12px"><button class="btn ghost" style="font-size:13px;padding:3px 10px" onclick="editDoc(\'{sid}\')">Edit this part</button></div>{md_html(chunk)}</div>'
                         f'<div id="e-{sid}" style="display:none;margin:10px 0"><textarea id="t-{sid}" style="width:100%;min-height:{max(120, min(420, 26 * (chunk.count(chr(10)) + 3)))}px;font:15px/1.5 system-ui;padding:12px;border:1px solid var(--line);border-radius:12px">{html.escape(chunk.rstrip(chr(10)))}</textarea>'
                         f'<p><button class="btn" onclick="saveDoc(\'{key}\',{n},\'{sid}\')">Save this part</button> <button class="btn ghost" onclick="location.reload()">Cancel</button></p></div>')
    js = r"""
function editDoc(k){document.getElementById('v-'+k).style.display='none';document.getElementById('e-'+k).style.display='block'}
function saveDoc(k,n,sid){fetch('/api/brand/doc',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({doc:k,idx:n,text:document.getElementById('t-'+sid).value})}).then(function(){location.reload()})}
var B=__DATA__;
function saved(t){var e=document.getElementById('saved');e.textContent=t||'Saved';clearTimeout(saved.t);saved.t=setTimeout(function(){e.textContent=''},1800)}
function save(){fetch('/api/brand/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(B)}).then(function(){saved()})}
document.getElementById('nm').oninput=function(){B.name=this.value;clearTimeout(save.t);save.t=setTimeout(save,500)};
document.getElementById('fn').onchange=function(){B.fonts=[this.value].concat((B.fonts||[]).slice(1)).filter(Boolean);document.getElementById('aa').style.fontFamily="'"+this.value+"',system-ui,sans-serif";save()};
document.querySelectorAll('input[data-ci]').forEach(function(i){i.onchange=function(){B.colors[+i.getAttribute('data-ci')]=this.value;i.parentNode.querySelector('i').style.background=this.value;save()}});
document.querySelectorAll('button[data-rm]').forEach(function(b){b.onclick=function(e){e.preventDefault();e.stopPropagation();B.colors.splice(+b.getAttribute('data-rm'),1);fetch('/api/brand/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(B)}).then(function(){location.reload()})}});
var ac=document.getElementById('addc');if(ac)ac.onclick=function(){B.colors.push('#2A6E6F');fetch('/api/brand/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(B)}).then(function(){location.reload()})};
document.getElementById('logo').onclick=function(e){if(e.target.id==='rmlogo')return;document.getElementById('lf').click()};
var rl=document.getElementById('rmlogo');if(rl)rl.onclick=function(e){e.stopPropagation();fetch('/api/brand/logo/remove',{method:'POST'}).then(function(){location.reload()})};
document.getElementById('lf').onchange=function(){var f=this.files[0];if(!f)return;saved('Adding your logo...');fetch('/api/brand/logo?name='+encodeURIComponent(f.name),{method:'POST',body:f}).then(function(){location.reload()})};
document.getElementById('upfont').onclick=function(){document.getElementById('ff').click()};
document.getElementById('ff').onchange=function(){var f=this.files[0];if(!f)return;saved('Adding your font...');fetch('/api/brand/font?name='+encodeURIComponent(f.name),{method:'POST',body:f}).then(function(r){return r.json()}).then(function(j){if(j.ok){location.reload()}else{saved(j.error||'That did not work.')}})};
document.getElementById('addph').onclick=function(){document.getElementById('pf').click()};
function addPhotos(fs){fs=Array.prototype.slice.call(fs).filter(function(f){return /^image\//.test(f.type)||/\.(jpe?g|png|webp|heic)$/i.test(f.name)});if(!fs.length){saved('Drop pictures (JPG or PNG).');return}saved('Adding photos...');var i=0;(function next(){if(i>=fs.length){location.reload();return}var f=fs[i++];fetch('/api/brand/photo?name='+encodeURIComponent(f.name),{method:'POST',body:f}).then(next,next)})()}
document.getElementById('pf').onchange=function(){addPhotos(this.files)};
function dropFiles(files){var fs=Array.prototype.slice.call(files),fonts=fs.filter(function(f){return /\.(ttf|otf)$/i.test(f.name)}),imgs=fs.filter(function(f){return !/\.(ttf|otf)$/i.test(f.name)});
 if(fonts.length){saved('Adding your font...');fetch('/api/brand/font?name='+encodeURIComponent(fonts[0].name),{method:'POST',body:fonts[0]}).then(function(r){return r.json()}).then(function(j){if(j.ok){if(imgs.length)addPhotos(imgs);else location.reload()}else saved(j.error||'That did not work.')});return}
 addPhotos(imgs)}
(function(){var card=document.getElementById('card'),ph=document.getElementById('addph');
 ['dragenter','dragover'].forEach(function(ev){document.body.addEventListener(ev,function(e){if(e.dataTransfer&&Array.prototype.indexOf.call(e.dataTransfer.types||[],'Files')>=0){e.preventDefault();card.style.outline='3px dashed #2A6E6F'}})});
 ['dragleave','drop'].forEach(function(ev){document.body.addEventListener(ev,function(e){if(ev==='drop'||e.target===document.body||!card.contains(e.relatedTarget))card.style.outline=''})});
 document.body.addEventListener('drop',function(e){if(e.dataTransfer&&e.dataTransfer.files&&e.dataTransfer.files.length){e.preventDefault();dropFiles(e.dataTransfer.files)}});
 ph.textContent='+ Add a photo (or drop files here)'})();
document.querySelectorAll('button[data-rp]').forEach(function(b){b.onclick=function(){fetch('/api/brand/photo/remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({file:b.getAttribute('data-rp')})}).then(function(){location.reload()})}});
function site(){var u=document.getElementById('u').value.trim();if(!u)return;document.getElementById('m').textContent='Looking...';fetch('/api/brand/site',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:u})}).then(function(r){return r.json()}).then(function(j){if(j.error){document.getElementById('m').textContent=j.error}else{location.reload()}}).catch(function(){document.getElementById('m').textContent='That did not work. Try again.'})}
""".replace("__DATA__", json.dumps({"name": d["name"], "fonts": d["fonts"], "colors": cols, "dark": d["dark"]}))
    return page("My brand", "Your brand: your logo, your font, your colors and your photos. Change anything here.", body, js)


def start_editor(name):
    import time
    e = EDITORS.get(name)
    if e and e["proc"].poll() is None:
        return e["port"]
    port = 8830
    import socket
    while True:
        with socket.socket() as sk:
            if sk.connect_ex(("127.0.0.1", port)) != 0:
                break
        port += 1
    proc = subprocess.Popen([PY, "-X", "utf8", "-I", os.path.join(HERE, "edit_sheet.py"), EDIT, name, "--port", str(port), "--no-open"], cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    EDITORS[name] = {"proc": proc, "port": port}
    for _ in range(40):
        time.sleep(0.25)
        with socket.socket() as sk:
            if sk.connect_ex(("127.0.0.1", port)) == 0:
                break
    return port


def hub_shell():
    tpl = open(os.path.join(HERE, "hub_template.html"), encoding="utf-8").read()
    return tpl.replace("__FONT__", _font_b64())


def serve():
    try:  # a calendar made before an engine update still has the old layout: redraw it when the template is newer
        cal = os.path.join(PLANS, "calendar.html")
        tpl = os.path.join(HERE, "calendar_template.html")
        if os.path.exists(cal) and os.path.exists(tpl) and os.path.getmtime(tpl) > os.path.getmtime(cal):
            regen_calendar()
    except Exception:
        pass
    import threading
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    last = [__import__("time").time()]

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def send_json(self, o, code=200):
            b = json.dumps(o).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)

        def send_file(self, path, ctype=None, download=None):
            import mimetypes
            if not os.path.isfile(path):
                return self.send_json({"error": "not found"}, 404)
            size = os.path.getsize(path)
            ctype = ctype or mimetypes.guess_type(path)[0] or "application/octet-stream"
            rng = self.headers.get("Range")
            start, end = 0, size - 1
            code = 200
            if rng and rng.startswith("bytes="):
                a, _, b = rng[6:].partition("-")
                start = int(a or 0)
                end = int(b) if b else size - 1
                code = 206
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(end - start + 1))
            if code == 206:
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            if download:
                self.send_header("Content-Disposition", 'attachment; filename="' + re.sub(r"[^A-Za-z0-9._ -]", "_", download) + '"')
            self.end_headers()
            with open(path, "rb") as f:
                f.seek(start)
                left = end - start + 1
                while left > 0:
                    chunk = f.read(min(1 << 20, left))
                    if not chunk:
                        break
                    try:
                        self.wfile.write(chunk)
                    except Exception:
                        break
                    left -= len(chunk)

        def remote_ok(self, u):
            """Anything on her Wi-Fi may only use the teleprompter page and its upload. The rest is only for this computer."""
            return self.client_address[0] in ("127.0.0.1", "::1") or u in ("/tele", "/api/tele-upload")

        def do_GET(self):
            last[0] = __import__("time").time()
            u = self.path.split("?")[0]
            if not self.remote_ok(u):
                return self.send_json({"error": "not allowed"}, 403)
            if u == "/tele":
                b = tele_page().encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)
                return
            if u == "/api/info":
                return self.send_json({"tele": f"http://{lan_ip()}:{PORT[0]}/tele"})
            q = __import__("urllib.parse", fromlist=["parse"]).parse_qs(self.path.partition("?")[2])
            def html_out(t):
                b = t.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)
            if u in ("/", "/index.html"):
                return html_out(hub_shell())
            if u == "/batch":
                try:
                    guide(None, None, OUTFITS[0])
                except SystemExit:
                    pass
                if not os.path.exists(os.path.join(PLANS, "batch-day.html")):
                    return html_out(page("Batch day", "This is where you film a whole week in one sitting.", '<div class="empty">Your batch day appears after your month plan and your first scripts are made.<br>Tell Claude: <b>plan my month</b>.</div>'))
                return self.send_file(os.path.join(PLANS, "batch-day.html"), "text/html; charset=utf-8")
            if u == "/edit":
                return html_out(edit_list())
            if u == "/content":
                return html_out(content_list("samples" in q))
            if u == "/stories":
                return html_out(content_list("samples" in q, True))
            if u == "/api/looks":
                return self.send_json(looks_load())
            if u == "/api/carousel/spec":
                full_, spec_, ok_ = spec_for((q.get("d") or [""])[0])
                if not ok_:
                    return self.send_json({"error": "not found"}, 404)
                sp_ = json.load(open(spec_, encoding="utf-8"))
                pics_ = []
                for sub_ in ("", "photos", "stills"):
                    dd_ = os.path.join(full_, sub_)
                    if os.path.isdir(dd_):
                        for f_ in sorted(os.listdir(dd_)):
                            if f_.lower().endswith((".jpg", ".jpeg") if not sub_ else (".jpg", ".jpeg", ".png", ".webp")) and not f_.startswith(("pinterest", "repost", "bg-")):
                                pics_.append({"url": "/" + os.path.relpath(os.path.join(dd_, f_), ROOT).replace(os.sep, "/"), "path": os.path.join(dd_, f_)})
                return self.send_json({"slides": [{k: v for k, v in s_.items() if k in EDIT_FIELDS or k in ("type", "kind", "template", "photo")} for s_ in sp_.get("slides", [])], "pics": pics_})
            if u == "/api/carousel/status":
                full_ = os.path.abspath(os.path.join(ROOT, (q.get("d") or [""])[0]))
                pr = RUNNING.get(full_)
                return self.send_json({"running": bool(pr and pr.poll() is None)})
            if u == "/slides":
                return html_out(slides_page((q.get("d") or [""])[0]))
            if u == "/api/plan/last-removed":
                try:
                    lp = os.path.join(PLANS, "last-removed.json")
                    ok = os.path.exists(lp) and os.path.exists(pl.plan_path() + ".undo")
                    return self.send_json(json.load(open(lp, encoding="utf-8")) if ok else {})
                except BaseException:
                    return self.send_json({})
            if u == "/api/plan/banked":
                try:
                    return self.send_json({"ideas": idea_pool()[:15]})
                except BaseException:
                    return self.send_json({"ideas": []})
            if u == "/api/plan/notes":
                import plan_notes as pn
                return self.send_json({"notes": pn.load()})
            if u == "/api/text/get":
                full = editable_text_path((q.get("p") or [""])[0])
                if not full:
                    return self.send_json({"error": "not allowed"}, 403)
                return self.send_json({"text": open(full, encoding="utf-8").read() if os.path.exists(full) else "", "exists": os.path.exists(full)})
            if u == "/dl":
                rel = (q.get("p") or [""])[0]
                full = os.path.abspath(os.path.join(ROOT, rel))
                if not full.startswith(os.path.join(ROOT, "customer")) or not os.path.isfile(full):
                    return self.send_json({"error": "not found"}, 404)
                return self.send_file(full, download=os.path.basename(full))
            if u == "/download":
                import zipfile, io
                rel = (q.get("d") or [""])[0]
                full = os.path.abspath(os.path.join(ROOT, rel))
                if not full.startswith(os.path.join(ROOT, "customer")) or not os.path.isdir(full):
                    return self.send_json({"error": "not found"}, 404)
                buf = io.BytesIO()
                with zipfile.ZipFile(buf, "w", zipfile.ZIP_STORED) as z:
                    for f in sorted(os.listdir(full)):
                        if re.match(r"slide-\d+\.(png|mp4)$", f) or f in ("caption.txt", "alt-text.txt"):
                            z.write(os.path.join(full, f), f)
                b = buf.getvalue()
                self.send_response(200)
                self.send_header("Content-Type", "application/zip")
                self.send_header("Content-Disposition", 'attachment; filename="' + re.sub(r"[^A-Za-z0-9._-]", "_", os.path.basename(os.path.dirname(full) if os.path.basename(full) in ("slides", "stories") else full)) + "-" + os.path.basename(full) + '.zip"')
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)
                return
            if u == "/scripts":
                return html_out(scripts_list())
            if u == "/script":
                return html_out(script_page((q.get("f") or [""])[0]))
            if u == "/results":
                return html_out(results_page())
            if u == "/brand":
                return html_out(brand_page())
            if u.startswith("/media/"):
                return self.send_file(os.path.join(EDIT, os.path.basename(__import__("urllib.parse", fromlist=["parse"]).unquote(u[7:]))), "video/mp4")
            if u == "/calendar.html":
                if not os.path.exists(os.path.join(PLANS, "calendar.html")):
                    return html_out(page("Calendar", "Your content calendar lives here.", '<div class="empty">Your calendar appears after your month plan is made.<br>Tell Claude: <b>plan my month</b>.</div>'))
                return self.send_file(os.path.join(PLANS, "calendar.html"), "text/html; charset=utf-8")
            if u == "/review":
                review()
                return self.send_file(os.path.join(PLANS, "batch-review.html"), "text/html; charset=utf-8")
            if u == "/api/hub/status":
                import datetime as _dt, shutil as _sh
                out = {"plan": None, "problems": [], "notes": []}
                try:
                    rows = pl.rows_of(pl.plan_path())
                    end = max(r["d"] for r in rows)
                    out["plan"] = {"end": end.isoformat(), "days_left": (end - _dt.date.today()).days}
                except BaseException:
                    pass
                venv = os.path.join(os.path.expanduser("~"), ".cache", "content-engine", "whisper-venv")
                if not _sh.which("ffmpeg") or not os.path.isdir(venv):
                    out["problems"].append("Video tools are not set up yet. Tell Claude: check my setup.")
                ins = os.path.join(ROOT, "customer", "insights")
                lr, lp = os.path.join(ins, "last-refresh.txt"), os.path.join(ins, "last-refresh-problem.txt")
                if os.path.exists(lp) and (not os.path.exists(lr) or os.path.getmtime(lp) > os.path.getmtime(lr)):
                    out["problems"].append("The last Sunday refresh could not pull your numbers. Tell Claude: paste my numbers.")
                elif os.path.exists(lr) and (_dt.datetime.now().timestamp() - os.path.getmtime(lr)) > 9 * 86400:
                    out["problems"].append("Your Sunday refresh has not run in over a week. Open Claude so it can catch up.")
                try:
                    rc = json.load(open(os.path.join(ins, "refresh-check.json"), encoding="utf-8"))
                    if rc.get("failed") and (_dt.datetime.now() - _dt.datetime.fromisoformat(rc["checked"])).days < 4:
                        out["problems"].append("The Sunday refresh did not finish everything: " + rc["failed"][0]["why"][:140] + (f" (and {len(rc['failed']) - 1} more)" if len(rc["failed"]) > 1 else "") + ". Tell Claude: weekly refresh.")
                except Exception:
                    pass
                if not os.path.exists(os.path.join(os.path.expanduser("~"), ".cache", "content-engine", "giphy.key")):
                    out["notes"].append("GIFs are off (optional). Tell Claude: connect Giphy.")
                return self.send_json(out)
            if u == "/api/status":
                return self.send_json(STATE)
            if u.startswith("/engine-fonts/"):
                fn_ = os.path.basename(__import__("urllib.parse", fromlist=["parse"]).unquote(u[14:]))
                fp_ = os.path.join(ROOT, "engine", "fonts", fn_)
                if fn_.lower().endswith((".ttf", ".otf")) and os.path.isfile(fp_):
                    return self.send_file(fp_)
            rel = __import__("urllib.parse", fromlist=["parse"]).unquote(u.lstrip("/"))
            for full in (os.path.abspath(os.path.join(ROOT, "customer", rel)), os.path.abspath(os.path.join(ROOT, rel))):
                if full.startswith(os.path.join(ROOT, "customer")) and os.path.isfile(full):
                    return self.send_file(full)
            self.send_json({"error": "not found"}, 404)

        def do_POST(self):
            last[0] = __import__("time").time()
            u = self.path.split("?")[0]
            n = int(self.headers.get("Content-Length", 0))
            if not self.remote_ok(u):
                return self.send_json({"error": "not allowed"}, 403)
            if u == "/api/looks":
                try:
                    req = json.loads(self.rfile.read(n) or b"{}")
                    st = looks_load()
                    i_ = req.get("id")
                    known = list(LOOK_INFO) + [m.get("id") for m in st["mine"]]
                    if req.get("act") == "fav" and i_ in known:
                        if i_ in st["favorites"]:
                            st["favorites"].remove(i_)
                        else:
                            st["favorites"].append(i_)
                    elif req.get("act") == "use" and i_ in known:
                        st["use"] = None if st.get("use") == i_ else i_
                    elif req.get("act") == "remove" and i_ in known:
                        if i_ in LOOK_INFO:
                            if i_ not in st["hidden"]:
                                st["hidden"].append(i_)
                        else:
                            st["mine"] = [m for m in st["mine"] if m.get("id") != i_]
                            for pth_ in (os.path.join(ROOT, "customer", "profile", "looks", f"look-{i_}.json"), os.path.join(ROOT, "customer", "looks", f"look-{i_}")):
                                try:
                                    shutil.rmtree(pth_) if os.path.isdir(pth_) else os.remove(pth_)
                                except OSError:
                                    pass
                        st["favorites"] = [f for f in st["favorites"] if f != i_]
                        if st.get("use") == i_:
                            st["use"] = None
                    elif req.get("act") == "auto":
                        st["use"] = None
                    elif req.get("act") == "restore":
                        st["hidden"] = []
                    elif req.get("act") == "rename" and i_ in known:
                        nm_ = re.sub(r"\s+", " ", str(req.get("name") or "")).strip()[:40]
                        own_ = next((m for m in st["mine"] if m.get("id") == i_), None)
                        if own_ is not None:
                            own_["name"] = nm_ or own_.get("name")
                        elif nm_:
                            st["names"][str(i_)] = nm_
                        else:
                            st["names"].pop(str(i_), None)
                    looks_store(st)
                    return self.send_json(st)
                except Exception as e:
                    return self.send_json({"error": str(e)}, 400)
            if u in ("/api/brand/logo", "/api/brand/photo"):
                with BRAND_LOCK:   # one picture at a time, so two dropped photos both get saved
                    from PIL import Image
                    import io
                    raw = self.rfile.read(n)
                    try:
                        im = Image.open(io.BytesIO(raw))
                        im.load()
                    except Exception:
                        return self.send_json({"error": "That is not a picture I can read."}, 400)
                    folder = os.path.join(ROOT, "customer", "profile", "brand")
                    os.makedirs(os.path.join(folder, "photos"), exist_ok=True)
                    d = brand_load()
                    if u.endswith("/logo"):
                        im = im.convert("RGBA")
                        im.thumbnail((600, 400))
                        im.save(os.path.join(folder, "logo.png"))
                        d["logo"] = "logo.png"
                    else:
                        im = im.convert("RGB")
                        im.thumbnail((900, 900))
                        k = 1
                        while os.path.exists(os.path.join(folder, "photos", f"photo{k}.jpg")):
                            k += 1
                        im.save(os.path.join(folder, "photos", f"photo{k}.jpg"), quality=88)
                        d["photos"].append(f"photo{k}.jpg")
                    brand_store(d)
                    return self.send_json({"ok": True})
            if u == "/api/tele-upload":
                qs = __import__("urllib.parse", fromlist=["parse"]).parse_qs(self.path.partition("?")[2])
                post = int((qs.get("post") or ["0"])[0])
                orig = (qs.get("name") or ["clip.mov"])[0]
                name = safe_name(f"post{post}-" + os.path.basename(orig))
                os.makedirs(INBOX, exist_ok=True)
                with open(os.path.join(INBOX, name), "wb") as f:
                    left = n
                    while left > 0:
                        chunk = self.rfile.read(min(1 << 20, left))
                        if not chunk:
                            break
                        f.write(chunk)
                        left -= len(chunk)
                take_upload(post, name)
                return self.send_json({"ok": True})
            if u == "/api/brand/font":
                qs_ = __import__("urllib.parse", fromlist=["parse"]).parse_qs(self.path.partition("?")[2])
                orig_ = os.path.basename((qs_.get("name") or ["font.ttf"])[0])
                ext_ = os.path.splitext(orig_)[1].lower()
                raw_ = self.rfile.read(n) if n < 12_000_000 else b""
                if ext_ not in (".ttf", ".otf") or not raw_:
                    return self.send_json({"error": "Please choose a .ttf or .otf font file."}, 400)
                try:
                    from PIL import ImageFont
                    import io
                    fo_ = ImageFont.truetype(io.BytesIO(raw_), 40)
                    fam_, sty_ = fo_.getname()
                except Exception:
                    return self.send_json({"error": "I could not read that font file."}, 400)
                import first_edit as fe_
                os.makedirs(fe_.BRAND_FONTS, exist_ok=True)
                safe_ = re.sub(r"[^A-Za-z0-9]", "", fam_) or "BrandFont"
                st_ = re.sub(r"[^A-Za-z0-9]", "", sty_ or "Regular") or "Regular"
                open(os.path.join(fe_.BRAND_FONTS, f"{safe_}-{st_}{ext_}"), "wb").write(raw_)
                d_ = brand_load()
                d_["fonts"] = [fam_] + [x for x in d_["fonts"][1:] if x != fam_]
                brand_store(d_)
                return self.send_json({"ok": True, "family": fam_})
            if u == "/api/carousel/photo":
                qs_ = __import__("urllib.parse", fromlist=["parse"]).parse_qs(self.path.partition("?")[2])
                full_, spec_, ok_ = spec_for((qs_.get("d") or [""])[0])
                nm_ = os.path.basename((qs_.get("name") or ["photo.jpg"])[0])
                if not ok_ or os.path.splitext(nm_)[1].lower() not in (".jpg", ".jpeg", ".png", ".webp"):
                    return self.send_json({"error": "That is not a picture I can use."}, 400)
                raw_ = self.rfile.read(n)
                try:
                    from PIL import Image
                    import io
                    im_ = Image.open(io.BytesIO(raw_)); im_.load()
                    im_ = im_.convert("RGB"); im_.thumbnail((2000, 2000))
                except Exception:
                    return self.send_json({"error": "That is not a picture I can read."}, 400)
                os.makedirs(os.path.join(full_, "photos"), exist_ok=True)
                base_ = safe_name(os.path.splitext(nm_)[0]) or "photo"
                k_ = 0
                while os.path.exists(os.path.join(full_, "photos", f"{base_}{'' if not k_ else '-' + str(k_)}.jpg")):
                    k_ += 1
                dest_ = os.path.join(full_, "photos", f"{base_}{'' if not k_ else '-' + str(k_)}.jpg")
                im_.save(dest_, quality=90)
                return self.send_json({"ok": True, "path": dest_, "url": "/" + os.path.relpath(dest_, ROOT).replace(os.sep, "/")})
            if u == "/api/insights/upload":
                qs = __import__("urllib.parse", fromlist=["parse"]).parse_qs(self.path.partition("?")[2])
                orig = os.path.basename((qs.get("name") or ["insights.png"])[0])
                if os.path.splitext(orig)[1].lower() not in (".png", ".jpg", ".jpeg", ".webp", ".heic"):
                    return self.send_json({"error": "That is not a picture."}, 400)
                name = safe_name("insights-" + orig)
                os.makedirs(INBOX, exist_ok=True)
                with open(os.path.join(INBOX, name), "wb") as f:
                    left = n
                    while left > 0:
                        chunk = self.rfile.read(min(1 << 20, left))
                        if not chunk:
                            break
                        f.write(chunk)
                        left -= len(chunk)
                return self.send_json({"ok": True, "name": name})
            if u == "/api/looks/upload":
                qs = __import__("urllib.parse", fromlist=["parse"]).parse_qs(self.path.partition("?")[2])
                orig = os.path.basename((qs.get("name") or ["look.png"])[0])
                if os.path.splitext(orig)[1].lower() not in (".png", ".jpg", ".jpeg", ".webp", ".heic"):
                    return self.send_json({"error": "That is not a picture."}, 400)
                name = safe_name("carousel-look-" + orig)
                os.makedirs(INBOX, exist_ok=True)
                with open(os.path.join(INBOX, name), "wb") as f:
                    left = n
                    while left > 0:
                        chunk = self.rfile.read(min(1 << 20, left))
                        if not chunk:
                            break
                        f.write(chunk)
                        left -= len(chunk)
                return self.send_json({"ok": True, "name": name})
            if u == "/api/drop":
                name = safe_name(__import__("urllib.parse", fromlist=["parse"]).parse_qs(self.path.partition("?")[2]).get("name", ["clip.mov"])[0])
                os.makedirs(INBOX, exist_ok=True)
                with open(os.path.join(INBOX, name), "wb") as f:
                    left = n
                    while left > 0:
                        chunk = self.rfile.read(min(1 << 20, left))
                        if not chunk:
                            break
                        f.write(chunk)
                        left -= len(chunk)
                return self.send_json({"ok": True, "name": name})
            body = json.loads(self.rfile.read(n) or b"{}") if n else {}
            if u == "/api/go":
                if STATE["state"] == "working":
                    return self.send_json({"ok": True})
                threading.Thread(target=run_go, daemon=True).start()
                STATE.update(state="working", message="Starting...")
                return self.send_json({"ok": True})
            if u == "/api/brand/doc":
                if body.get("doc") not in ("voice-profile", "audience"):
                    return self.send_json({"error": "bad doc"}, 400)
                fp = os.path.join(ROOT, "customer", "profile", body["doc"] + ".md")
                if os.path.exists(fp):
                    shutil.copy(fp, fp + ".before-edit")
                old = open(fp, encoding="utf-8").read() if os.path.exists(fp) else ""
                parts = doc_sections(old)
                idx = body.get("idx")
                if isinstance(idx, int) and 0 <= idx < len(parts):
                    parts[idx] = body.get("text", "").rstrip("\n") + "\n" + ("\n" if idx < len(parts) - 1 else "")
                    new = "".join(parts)
                else:
                    new = body.get("text", "")
                open(fp, "w", encoding="utf-8").write(new)
                return self.send_json({"ok": True})
            if u == "/api/brand/look":
                import brand_picker as bp_
                d = brand_load()
                err = bp_.save_look(d, body)
                if err:
                    return self.send_json({"error": err})
                brand_store(d)
                return self.send_json({"ok": True})
            if u == "/api/brand/save":
                d = brand_load()
                for k in ("name", "fonts", "dark"):
                    if k in body:
                        d[k] = body[k]
                if d.get("fontSet") and d.get("fonts") and d["fonts"][0] != d["fontSet"].get("headline"):
                    d["fontSet"]["headline"] = d["fonts"][0]   # she picked another headline font on the card
                if "colors" in body:
                    d["colors"] = [c if isinstance(c, str) else c.get("hex", "#000000") for c in body["colors"]]
                brand_store(d)
                return self.send_json({"ok": True})
            if u == "/api/brand/logo/remove":
                d = brand_load()
                d["logo"] = ""
                brand_store(d)
                return self.send_json({"ok": True})
            if u == "/api/brand/photo/remove":
                d = brand_load()
                f = os.path.basename(body.get("file", ""))
                d["photos"] = [x for x in d["photos"] if x != f]
                brand_store(d)
                return self.send_json({"ok": True})
            if u == "/api/brand/site":
                import brand_colors as bc
                if "instagram.com" in body.get("url", "").lower() or body.get("url", "").strip().startswith("@"):
                    return self.send_json({"error": "Instagram does not let me look from here. Tell me in the chat: pull my brand from my Instagram. I will use your profile picture and your latest posts."})
                try:
                    kit = bc.brand_kit(body.get("url", ""))
                    score = bc.scan(kit["html"], kit["css"])
                    pal, dark = bc.pick(score)
                    if len(pal) < 2:
                        pal2, _ = bc.pick(score + bc.logo_colors(kit["html"], kit["url"]))
                        pal = pal2 or pal
                    if not pal:
                        return self.send_json({"error": "I opened the site but could not find clear brand colors. Add your logo in the editor's Brand colors box."})
                    bc.save_kit(kit, pal, dark)
                    return self.send_json({"ok": True})
                except Exception:
                    return self.send_json({"error": "I could not open that website. Some sites block this. Add your logo or a screenshot in the editor's Brand colors box instead."})
            if u == "/api/text/save":
                full = editable_text_path(body.get("p", ""))
                if not full:
                    return self.send_json({"error": "not allowed"}, 403)
                if os.path.exists(full):
                    shutil.copy(full, full + ".before-edit")
                os.makedirs(os.path.dirname(full), exist_ok=True)
                open(full, "w", encoding="utf-8").write(body.get("text", ""))
                return self.send_json({"ok": True})
            if u == "/api/edit/script-section":
                ok = save_script_section(body.get("date", ""), body.get("heading", ""), body.get("text", ""))
                if ok:
                    regen_calendar()
                return self.send_json({"ok": ok})
            if u in ("/api/plan/notes/add", "/api/plan/notes/delete"):
                import plan_notes as pn
                notes = pn.load()
                if u.endswith("/add"):
                    t = (body.get("text") or "").strip()
                    if t:
                        notes.append({"id": max([x["id"] for x in notes] or [0]) + 1, "text": t[:600], "status": "waiting", "added": datetime.datetime.now().isoformat(timespec="seconds")})
                else:
                    notes = [x for x in notes if x["id"] != int(body.get("id", 0))]
                pn.save(notes)
                return self.send_json({"ok": True, "notes": notes})
            if u == "/api/plan/add-post":
                try:
                    day = body.get("date", "")
                    fmt = {"carousel": "text carousel", "photo-carousel": "carousel", "video": "video"}.get(body.get("format", "carousel"), "text carousel")
                    idea = (body.get("idea") or "").strip() or "New idea (Claude will pick one for this day)"
                    datetime.date.fromisoformat(day)
                    shutil.copy(pl.plan_path(), pl.plan_path() + ".undo")
                    r = subprocess.run([sys.executable, "-X", "utf8", "-I", os.path.join(HERE, "plan.py"), "add", day, fmt, "keep people", idea], cwd=ROOT, capture_output=True, text=True, encoding="utf-8", errors="replace")
                    if r.returncode != 0:
                        return self.send_json({"ok": False, "error": (r.stdout + r.stderr).strip()[-120:]})
                    take_banked(idea)
                    regen_calendar()
                    return self.send_json({"ok": True, "message": r.stdout.strip()})
                except Exception as e:
                    return self.send_json({"ok": False, "error": str(e)[:100]})
            if u == "/api/plan/move":
                try:
                    n = int(body.get("n", 0))
                    tgt = datetime.date.fromisoformat(body.get("date", ""))
                    path = pl.plan_path()
                    rows = pl.rows_of(path)
                    src = next((r for r in rows if r["n"] == n), None)
                    if not src:
                        return self.send_json({"ok": False, "error": "I can't find that post."})
                    if src["state"] == "posted":
                        return self.send_json({"ok": False, "error": "That one is already posted, so it stays where it is."})
                    other = next((r for r in rows if r["d"] == tgt and r["n"] != n), None)
                    if other and other["state"] == "posted":
                        return self.send_json({"ok": False, "error": "A posted day can't be swapped. Pick another day."})

                    def fn(k, c):
                        c = list(c)
                        if k == n:
                            c[2] = " " + pl.label(tgt) + " "
                            return c
                        if other and k == other["n"]:
                            c[2] = " " + pl.label(src["d"]) + " "
                            return c
                        return None
                    shutil.copy(path, path + ".before-edit")
                    shutil.copy(path, path + ".undo")
                    pl.edit_lines(path, fn)
                    regen_calendar()
                    return self.send_json({"ok": True, "swapped": bool(other)})
                except Exception as e:
                    return self.send_json({"ok": False, "error": "That didn't work: " + str(e)[:80]})
            if u == "/api/edit/script-fill":
                err = fill_script_blank(body.get("date", ""), body.get("blank", ""), body.get("answer", ""))
                if not err:
                    regen_calendar()
                return self.send_json({"ok": not err, "error": err})
            if u == "/api/edit/script-confirm":
                err = confirm_script_blank(body.get("date", ""), body.get("blank", ""), body.get("claim", ""), body.get("action", "yes"), body.get("text", ""))
                if not err:
                    regen_calendar()
                return self.send_json({"ok": not err, "error": err})
            if u == "/api/plan/remove-post":
                try:
                    n = int(body.get("n", 0))
                    path = pl.plan_path()
                    rows = pl.rows_of(path)
                    r = next((x for x in rows if x["n"] == n), None)
                    if not r or r["state"] == "posted":
                        return self.send_json({"ok": False, "error": "A post that is already posted stays on your plan."})
                    if not body.get("force") and (not r["why"].startswith("Added by hand") or r["state"] not in ("outline", "missed")):
                        return self.send_json({"ok": False, "error": "Only a post you just added, before it is written, can be taken off this way."})
                    lines = open(path, encoding="utf-8").read().split("\n")
                    keep = [l for l in lines if not re.match(r"\|\s*%d\s*\|" % n, l)]
                    shutil.copy(path, path + ".undo")
                    open(path, "w", encoding="utf-8").write("\n".join(keep))
                    json.dump({"date": r["d"].isoformat(), "idea": r["idea"], "n": n}, open(os.path.join(PLANS, "last-removed.json"), "w", encoding="utf-8"))
                    regen_calendar()
                    return self.send_json({"ok": True})
                except Exception as e:
                    return self.send_json({"ok": False, "error": str(e)[:100]})
            if u == "/api/plan/dismiss-undo":
                for f in (os.path.join(PLANS, "last-removed.json"), pl.plan_path() + ".undo"):
                    try:
                        os.remove(f)
                    except OSError:
                        pass
                return self.send_json({"ok": True})
            if u == "/api/plan/keep-post":
                n = int(body.get("n", 0))
                path = pl.plan_path()

                def fnk(k, c):
                    if k != n:
                        return None
                    c = list(c)
                    c[6] = " " + re.sub(r"^\s*Added by hand for an empty day", "Added for an empty day", c[6]).strip() + " "
                    return c
                pl.edit_lines(path, fnk)
                regen_calendar()
                return self.send_json({"ok": True})
            if u == "/api/plan/undo":
                path = pl.plan_path()
                if os.path.exists(path + ".undo"):
                    shutil.copy(path + ".undo", path)
                    os.remove(path + ".undo")
                    try:
                        os.remove(os.path.join(PLANS, "last-removed.json"))
                    except OSError:
                        pass
                    regen_calendar()
                    return self.send_json({"ok": True})
                return self.send_json({"ok": False, "error": "There is nothing to undo."})
            if u == "/api/edit/script-undo":
                _, rows = mc.read_plan(pl.plan_path())
                r = next((x for x in rows if x["date"] == body.get("date", "")), None)
                bk = (r["script"] + ".before-edit") if r and r.get("script") else ""
                if bk and os.path.exists(bk):
                    shutil.copy(bk, r["script"])
                    os.remove(bk)
                    regen_calendar()
                    return self.send_json({"ok": True})
                return self.send_json({"ok": False, "error": "There is nothing to undo."})
            if u == "/api/edit/plan-row":
                ok = save_plan_row(int(body.get("n", 0)), body.get("idea", ""), body.get("why", ""))
                regen_calendar()
                return self.send_json({"ok": ok})
            if u == "/api/carousel/edit":
                rel = body.get("d", "")
                full = os.path.abspath(os.path.join(ROOT, rel))
                spec = os.path.join(os.path.dirname(full), "slides.json") if not os.path.exists(os.path.join(full, "slides.json")) else os.path.join(full, "slides.json")
                if not full.startswith(os.path.join(ROOT, "customer")) or not os.path.exists(spec):
                    return self.send_json({"error": "I can't find the slide words for this one. Tell Claude: edit this carousel."}, 404)
                import socket
                port_ = 8766
                while True:   # every copy of the engine gets its own free address, so this opens HER carousel and not another one
                    s_ = socket.socket()
                    try:
                        s_.bind(("127.0.0.1", port_))
                        s_.close()
                        break
                    except OSError:
                        s_.close()
                        port_ += 1
                subprocess.Popen([PY, "-X", "utf8", "-I", os.path.join(HERE, "carousel_sheet.py"), spec, "--no-open", "--port", str(port_)], cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                time.sleep(1.5)
                return self.send_json({"url": f"http://127.0.0.1:{port_}/"})
            if u == "/api/carousel/restyle":
                rel = body.get("d", "")
                full = os.path.abspath(os.path.join(ROOT, rel))
                spec = os.path.join(full, "slides.json") if os.path.exists(os.path.join(full, "slides.json")) else os.path.join(os.path.dirname(full), "slides.json")
                import pick_look as pk
                tv_ = str(body.get("template"))
                cust_ids_ = [f"custom:{m_['id']}" for m_ in looks_load()["mine"] if m_.get("custom")]
                if tv_ in cust_ids_:
                    tid = tv_
                else:
                    try:
                        tid = int(tv_)
                    except Exception:
                        tid = 0
                if not full.startswith(os.path.join(ROOT, "customer")) or not os.path.exists(spec) or (tid not in pk.NAMES and tid not in cust_ids_):
                    return self.send_json({"error": "I can't change the style of this one."}, 404)
                try:
                    sp = json.load(open(spec, encoding="utf-8"))
                    if not all(s.get("type") == "tpl" for s in sp.get("slides", [])):
                        import carousel_templates as ct_
                        sp["slides"] = ct_.convert_old(sp["slides"])   # an older carousel: bring its words and photos into a look
                    for s in sp["slides"]:
                        s["template"] = tid
                        s.pop("moves", None)   # a new style puts things in new places
                        if s.get("kind") not in pk.KINDS[tid if tid in pk.KINDS else 1]:
                            s["kind"] = "point"   # a slide type that look does not have becomes a normal slide
                    sp["look_auto"] = False
                    backup_spec(spec)
                    json.dump(sp, open(spec, "w", encoding="utf-8"), indent=1)
                except Exception:
                    return self.send_json({"error": "I could not read the slide words."}, 500)
                run_make(spec, full)
                return self.send_json({"ok": True})
            if u == "/api/carousel/length":
                full_, spec_, ok_ = spec_for(body.get("d", ""))
                dir_ = body.get("dir")
                if not ok_ or dir_ not in ("shorter", "longer"):
                    return self.send_json({"error": "I can't change this one."}, 404)
                before_ = open(spec_, "rb").read()
                pr_ = subprocess.run([PY, "-X", "utf8", "-I", os.path.join(HERE, "reshape_carousel.py"), spec_, dir_], capture_output=True, text=True, encoding="utf-8", errors="replace", cwd=ROOT, timeout=60)
                try:
                    res_ = json.loads((pr_.stdout.strip().splitlines() or ["{}"])[-1])
                except Exception:
                    res_ = {"ok": False, "error": "That did not work."}
                if not res_.get("ok"):   # nothing changed, so Undo is left exactly as it was
                    return self.send_json({"error": res_.get("error") or "That did not work."}, 400)
                open(spec_ + ".undo", "wb").write(before_)
                for f_ in os.listdir(full_):   # the old slide pictures and cutouts go; the redraw makes the new set
                    if re.match(r"slide-\d+\.", f_):
                        try:
                            os.remove(os.path.join(full_, f_))
                        except OSError:
                            pass
                run_make(spec_, full_)
                return self.send_json({"ok": True, "message": res_.get("message")})
            if u == "/api/carousel/auto":
                try:
                    post_ = int(body.get("post"))
                except Exception:
                    return self.send_json({"error": "Which post?"}, 400)
                try:
                    pr_ = subprocess.run([PY, "-X", "utf8", "-I", os.path.join(HERE, "auto_carousel.py"), str(post_)], capture_output=True, text=True, encoding="utf-8", errors="replace", cwd=ROOT, timeout=300)
                    res_ = json.loads((pr_.stdout.strip().splitlines() or ["{}"])[-1])
                except Exception:
                    return self.send_json({"error": "That did not work. Tell Claude: make the carousel for this day."}, 500)
                return self.send_json(res_ if res_.get("ok") else {"error": res_.get("error") or "That did not work."}, 200 if res_.get("ok") else 400)
            if u in ("/api/carousel/undo", "/api/carousel/resetmoves", "/api/carousel/pieces"):
                full, spec, ok = spec_for(body.get("d", ""))
                if not ok:
                    return self.send_json({"error": "I can't find this carousel's slides."}, 404)
                try:
                    if u.endswith("/undo"):
                        if not os.path.exists(spec + ".undo"):
                            return self.send_json({"error": "Nothing to undo."}, 400)
                        open(spec, "wb").write(open(spec + ".undo", "rb").read())
                        os.remove(spec + ".undo")   # one step back; after that there is nothing more to undo
                    elif u.endswith("/resetmoves"):
                        sp = json.load(open(spec, encoding="utf-8"))
                        backup_spec(spec)
                        for s_ in sp.get("slides", []):
                            s_.pop("moves", None)
                        json.dump(sp, open(spec, "w", encoding="utf-8"), indent=1)
                except Exception:
                    return self.send_json({"error": "That did not work."}, 500)
                run_make(spec, full)
                return self.send_json({"ok": True})
            if u == "/api/carousel/moves":
                rel = body.get("d", "")
                full = os.path.abspath(os.path.join(ROOT, rel))
                spec = os.path.join(full, "slides.json") if os.path.exists(os.path.join(full, "slides.json")) else os.path.join(os.path.dirname(full), "slides.json")
                if not full.startswith(os.path.join(ROOT, "customer")) or not os.path.exists(spec):
                    return self.send_json({"error": "I can't find this carousel's slides."}, 404)
                try:
                    sp = json.load(open(spec, encoding="utf-8"))
                    nsl_ = len(sp["slides"])
                    for k_, wd in (body.get("words") or {}).items():   # words and pictures edited in the same editor
                        if not (0 <= int(k_) < nsl_):
                            continue
                        sl_ = sp["slides"][int(k_)]
                        for fk_, fv_ in wd.items():
                            if fk_ == "photo":
                                if fv_ and os.path.abspath(fv_).startswith(os.path.join(ROOT, "customer")) and os.path.exists(fv_):
                                    sl_["photo"] = os.path.abspath(fv_)
                            elif fk_ in EDIT_FIELDS:
                                if fk_ in ("items", "left", "right"):
                                    fv_ = [x.strip() for x in str(fv_).split("\n") if x.strip()]
                                if fv_ in ("", []):
                                    sl_.pop(fk_, None)
                                else:
                                    sl_[fk_] = fv_
                    for k_, mv in (body.get("slides") or {}).items():
                        i_ = int(k_)
                        if not (0 <= i_ < nsl_):
                            continue
                        clean = []
                        for m in mv:
                            if not (m.get("at") and m.get("d")):
                                continue
                            sc_ = max(0.3, min(3.0, float(m.get("s") or 1)))
                            rt_ = max(-180.0, min(180.0, float(m.get("r") or 0)))
                            if int(m["d"][0]) or int(m["d"][1]) or abs(sc_ - 1) > 0.001 or abs(rt_) > 0.01:
                                clean.append({"at": [int(m["at"][0]), int(m["at"][1])], "d": [int(m["d"][0]), int(m["d"][1])], "s": round(sc_, 3), "r": round(rt_, 1)})
                        if clean:
                            sp["slides"][i_]["moves"] = clean
                        else:
                            sp["slides"][i_].pop("moves", None)
                    backup_spec(spec)
                    json.dump(sp, open(spec, "w", encoding="utf-8"), indent=1)
                except Exception:
                    return self.send_json({"error": "I could not save the moves."}, 500)
                run_make(spec, full)
                return self.send_json({"ok": True})
            if u == "/api/carousel/redraw":
                rel = body.get("d", "")
                full = os.path.abspath(os.path.join(ROOT, rel))
                spec = os.path.join(full, "slides.json") if os.path.exists(os.path.join(full, "slides.json")) else os.path.join(os.path.dirname(full), "slides.json")
                if not full.startswith(os.path.join(ROOT, "customer")) or not os.path.exists(spec):
                    return self.send_json({"error": "I can't find the slide words for this one. Tell Claude: redraw this carousel in my brand colors."}, 404)
                import make_looks as ml
                if len(ml.brand_colors()) < 2:
                    return self.send_json({"error": "I don't have your brand colors yet."}, 400)
                try:
                    sp = json.load(open(spec, encoding="utf-8"))
                    sp["look"] = "brand"
                    backup_spec(spec)
                    json.dump(sp, open(spec, "w", encoding="utf-8"), indent=1)
                except Exception:
                    return self.send_json({"error": "I could not read the slide words."}, 500)
                run_make(spec, full)
                return self.send_json({"ok": True})
            if u == "/api/reveal":
                full = os.path.abspath(os.path.join(ROOT, body.get("p", "")))
                if not full.startswith(os.path.join(ROOT, "customer")) or not os.path.exists(full):
                    return self.send_json({"error": "not found"}, 404)
                try:
                    if sys.platform == "darwin":
                        subprocess.Popen(["open", "-R", full])
                    elif sys.platform.startswith("win"):
                        subprocess.Popen(["explorer", "/select,", full])
                    else:
                        subprocess.Popen(["xdg-open", os.path.dirname(full)])
                except Exception:
                    return self.send_json({"error": "could not open"}, 500)
                return self.send_json({"ok": True})
            if u == "/api/edit/hide":
                hp = os.path.join(ROOT, "customer", "videos", "hidden.json")
                h = json.load(open(hp, encoding="utf-8")) if os.path.exists(hp) else []
                if body.get("name") and body["name"] not in h:
                    h.append(body["name"])
                json.dump(h, open(hp, "w", encoding="utf-8"))
                return self.send_json({"ok": True})
            if u == "/api/edit/delete":
                nm = body.get("name", "")
                if not re.fullmatch(r"[A-Za-z0-9._ -]+", nm):
                    return self.send_json({"error": "bad name"}, 400)
                trash = os.path.join(ROOT, "customer", "videos", "removed", nm)
                os.makedirs(trash, exist_ok=True)
                for f in os.listdir(EDIT):
                    if f.startswith(nm + "_"):
                        shutil.move(os.path.join(EDIT, f), os.path.join(trash, f))
                return self.send_json({"ok": True})
            if u == "/api/edit/start":
                nm = (__import__("urllib.parse", fromlist=["parse"]).parse_qs(self.path.partition("?")[2]).get("name") or [""])[0]
                if not re.fullmatch(r"[A-Za-z0-9._ -]+", nm):
                    return self.send_json({"error": "bad name"}, 400)
                port = start_editor(nm)
                return self.send_json({"url": f"http://127.0.0.1:{port}/live?embed=1"})
            if u == "/api/posted":
                r = subprocess.run([sys.executable, os.path.join(HERE, "plan.py"), "posted", str(body.get("n"))], capture_output=True, text=True, encoding="utf-8", errors="replace")
                return self.send_json({"ok": r.returncode == 0, "message": (r.stdout or r.stderr).strip()[:200]})
            if u == "/api/assign":
                assign(body["file"], body["post"])
                return self.send_json({"ok": True})
            self.send_json({"error": "not found"}, 404)

    port = 8780
    PORT = [8780]
    while True:
        try:
            srv = ThreadingHTTPServer(("0.0.0.0", port), H)
            break
        except OSError:
            port += 1
    PORT[0] = port
    print(f"Batch day page: http://127.0.0.1:{port}/", flush=True)

    def idle_exit():
        import time
        while True:
            time.sleep(60)
            if time.time() - last[0] > 6 * 3600:
                os._exit(0)
    threading.Thread(target=idle_exit, daemon=True).start()
    srv.serve_forever()


def main():
    a = sys.argv[1:]
    if not a:
        sys.exit(__doc__)
    wk = int(a[a.index("--week") + 1]) if "--week" in a else None
    if a[0] == "assign" and len(a) >= 3:
        return assign(a[1], a[2])
    loc = a[a.index("--locations") + 1] if "--locations" in a else None
    outf = int(a[a.index("--outfits") + 1]) if "--outfits" in a else 0
    if a[0] == "hub":
        import urllib.request, webbrowser, threading, time
        for port in (8780, 8781, 8782, 8783):
            try:
                urllib.request.urlopen(f"http://127.0.0.1:{port}/api/status", timeout=0.6)
                webbrowser.open(f"http://127.0.0.1:{port}/")
                print("Your Content Engine is already open.")
                return
            except Exception:
                pass
        OUTFITS[0] = int(a[a.index("--outfits") + 1]) if "--outfits" in a else 0
        try:
            guide(None, None, OUTFITS[0])
        except SystemExit:
            pass
        threading.Thread(target=lambda: (time.sleep(1.5), webbrowser.open("http://127.0.0.1:8780/")), daemon=True).start()
        print("Leave this window open while you use your Content Engine. Close it when you are done.")
        return serve()
    if a[0] == "serve":
        OUTFITS[0] = outf
        try:
            guide(wk, loc, outf)
        except SystemExit:
            pass
        return serve()
    {"guide": lambda: guide(wk, loc, outf), "match": lambda: match(wk), "edit-all": edit_all, "review": review}.get(a[0], lambda: sys.exit(__doc__))()


if __name__ == "__main__":
    main()
