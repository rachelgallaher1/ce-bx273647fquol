#!/usr/bin/env python3
"""Chooses the carousel look (template 1 to 8) that makes the most sense for a post, so she never has to.

  python3 pick_look.py --text "the idea, headline or script in her words" [--kind teaching|story|reference] [--job "get found|keep people|get them to act|proof"]
                       [--format "carousel|text carousel"] [--no-photos]

Prints one line of JSON: {"template": N, "name": "...", "reason": "...", "pinned": false}

Her choices come first:
  * If she pinned a look ("Use this look" on the Carousels tab, customer/profile/carousel-looks.json "use"), that look wins.
  * Looks she removed ("hidden") are never chosen. If she has favorites, only favorites are considered.
  * The same look is not used three carousels in a row (it picks the next best one).
"""
import argparse, glob, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
NAMES = {1: "Scrapbook", 2: "Numbered tips", 3: "Bold editorial", 4: "Photo statement", 5: "Warm flat color", 6: "Photo story", 7: "Notebook caps", 8: "Face and contrast"}
NEEDS_PHOTO = {4, 6, 7, 8}   # these lean on a photo; without photos the others look better
KINDS = {1: ("cover", "point", "list", "quote", "stat", "photo", "cta"), 2: ("cover", "point", "list", "quote", "stat", "photo", "cta"),
         3: ("cover", "point", "list", "quote", "stat", "photo", "cta"), 4: ("cover", "point", "split", "list", "quote", "stat", "cta"),
         5: ("cover", "point", "row", "comment", "grid", "list", "quote", "stat", "photo", "cta"), 6: ("cover", "point", "bigword", "list", "quote", "stat", "cta"),
         7: ("cover", "point", "list", "quote", "stat", "photo", "cta"), 8: ("cover", "point", "split2", "proof", "list", "quote", "stat", "cta")}

# (look, reason, words that point to it). Order does not matter; the score decides.
SIGNALS = [
    (2, "it is a list of steps or tips", r"\b(\d+|three|four|five|six|seven|steps?|tips?|ways|things|mistakes|reasons|checklist|list|rules|signs)\b"),
    (6, "it tells a story", r"\b(story|i used to|when i|last week|one day|remember when|journey|how i|my first|i was)\b"),
    (3, "it makes a bold claim", r"\b(myth|stop|never|truth|secret|wrong|hot take|unpopular|actually|real reason|nobody tells|the problem)\b"),
    (1, "it shows a before and after", r"\b(before|after|results?|transformation|makeover|glow up|progress|proof|fixed)\b"),
    (8, "it compares the old way with the new way", r"\b(vs\.?|versus|old way|new way|instead of|compared|difference|worth it)\b"),
    (5, "it is a relatable, friendly post", r"\b(pov|relatable|admit|ever|do you|we all|raise your hand|what to expect|welcome|new here|announcement|update)\b"),
    (4, "it is one strong statement", r"\b(mindset|remember|reminder|quote|truth bomb|permission|note to self)\b"),
    (7, "it is a casual, behind-the-scenes post", r"\b(behind the scenes|day in the life|what i|my favorite|favorites|routine|a day|monday|weekend|menu|today)\b"),
]
KIND_BONUS = {"story": {6: 3, 4: 1}, "teaching": {2: 2, 3: 1, 5: 1}, "reference": {2: 2, 5: 1}}
JOB_BONUS = {"proof": {1: 3, 8: 2}, "get found": {2: 1, 3: 1}, "keep people": {5: 2, 7: 1}, "get them to act": {3: 2, 8: 1}}


def state():
    try:
        d = json.load(open(os.path.join(ROOT, "customer", "profile", "carousel-looks.json"), encoding="utf-8"))
    except Exception:
        d = {}
    d.setdefault("favorites", [])
    d.setdefault("use", None)
    d.setdefault("mine", [])
    d.setdefault("hidden", [])
    d.setdefault("names", {})
    return d


def recent_templates(limit=3):
    """The looks of her last few carousels, newest first (read from the slides.json files she already has)."""
    found = []
    for p in glob.glob(os.path.join(ROOT, "customer", "content", "**", "slides.json"), recursive=True):
        try:
            sp = json.load(open(p, encoding="utf-8"))
            t = next((s.get("template") for s in sp.get("slides", []) if s.get("type") == "tpl"), None)
            if t:
                found.append((os.path.getmtime(p), t if str(t).startswith("custom:") else int(t)))
        except Exception:
            pass
    return [t for _, t in sorted(found, reverse=True)[:limit]]


def _kinds_of(sp):
    return [(s.get("kind") or "point") for s in sp.get("slides", []) if s.get("type") == "tpl"]


def recent_sequences(limit=4, exclude=None):
    """The slide-kind order of her last few carousels, newest first: [["cover","quote",...], ...]."""
    found = []
    for p in glob.glob(os.path.join(ROOT, "customer", "content", "**", "slides.json"), recursive=True):
        if exclude and os.path.abspath(os.path.dirname(p)) == os.path.abspath(exclude):
            continue
        try:
            sp = json.load(open(p, encoding="utf-8"))
            ks = _kinds_of(sp)
            if len(ks) >= 4:
                found.append((os.path.getmtime(p), ks))
        except Exception:
            pass
    return [k for _, k in sorted(found, reverse=True)[:limit]]


def plan_mix(look, beats, photos=0, has_number=False, quotes=1, exclude=None):
    """Recommends how long the carousel is and which kind each slide is, so it does not repeat her recent carousels.
    beats = how many real ideas the post has (never padded: a thin post gets a short carousel).
    Returns {"length": N, "kinds": [...]}. Same input and same recent carousels give the same answer."""
    allowed = set(KINDS.get(look, KINDS[1]))   # one of her own looks (custom) draws every kind a built-in one does
    rec = recent_sequences(4, exclude)
    max_len = max(5, min(10, 2 + int(beats)))
    last_lens = [len(r) for r in rec[:2]]
    length = max_len
    if len(last_lens) == 2 and last_lens[0] == last_lens[1] == length and length > 5:
        length -= 1        # the last two were this long: go one shorter (only ever trimming, never padding)
    elif last_lens and last_lens[0] == length and length > 6 and len(rec) % 2 == 0:
        length -= 1
    n_mid = length - 2
    pool = {"point": 99, "list": 2, "quote": max(2, int(quotes)), "stat": 1 if has_number else 0, "photo": min(3, int(photos)) if "photo" in allowed else 0}
    pool = {k: v for k, v in pool.items() if v and k in allowed}
    seq, used = [], {}
    seed = len(rec) + length
    order = sorted(pool, key=lambda k: (sum(map(ord, k)) % 7 + seed) % 5)
    for pos in range(n_mid):
        best, bp = None, None
        for k in order:
            if seq and seq[-1] == k:
                continue                        # never the same kind twice in a row
            over = used.get(k, 0) >= pool[k]
            pen = used.get(k, 0) * 2 + (6 if over else 0)
            for r in rec[:3]:                   # the same slot in her recent carousels: use something else
                if pos + 1 < len(r) - 1 and r[pos + 1] == k:
                    pen += 3
            if pos == 0 and rec and rec[0][1:2] == [k]:
                pen += 4                        # do not open the same way as the last carousel
            if k == "point":
                pen -= 1                        # her own ideas are the meat of the post: they lead
            if bp is None or pen < bp:
                best, bp = k, pen
        if best is None:
            best = "point"
        seq.append(best)
        used[best] = used.get(best, 0) + 1
    return {"length": length, "kinds": ["cover"] + seq + ["cta"]}


def variety_notes(slides, exclude=None):
    """Plain warnings when this carousel is too much like her recent ones."""
    ks = [(s.get("kind") or "point") for s in slides if s.get("type") == "tpl"]
    if len(ks) < 4:
        return []
    rec = recent_sequences(3, exclude)
    notes = []
    if len(rec) >= 2 and ks[1:2] == rec[0][1:2] == rec[1][1:2]:
        notes.append(f"This carousel opens with a '{ks[1]}' slide, same as your last two. Start with a different kind so it feels fresh.")
    for r in rec[:3]:
        m = sum(1 for a, b in zip(ks, r) if a == b)
        if len(ks) == len(r) and m >= max(5, int(0.7 * len(ks))):
            notes.append("The slide order is almost the same as one of your recent carousels. Shuffle the middle slides.")
            break
    if len(rec) >= 2 and len(ks) == len(rec[0]) == len(rec[1]) and len(ks) >= 8:
        notes.append(f"This is {len(ks)} slides, same as your last two. A shorter one (only if the post is done sooner) keeps your feed varied.")
    return notes


def choose(text="", kind="", job="", fmt="", photos=True):
    st = state()
    mine = {m["id"]: m for m in st["mine"] if m.get("id") is not None and (m.get("base") in NAMES or m.get("custom"))}
    custom = {i: m for i, m in mine.items() if m.get("custom")}
    tmpl = lambda i: (f"custom:{i}" if i in custom else (mine[i]["base"] if i in mine else i))
    if st.get("use") is not None:
        u = st["use"]
        base = tmpl(u)
        if u in custom or base in NAMES:
            nm = (mine[u]["name"] if u in mine else st["names"].get(str(u))) or NAMES.get(base, "My look")
            return {"template": base, "name": nm, "reason": "you picked this look to always use", "pinned": True, "id": u}
    allowed = [n for n in NAMES if n not in st["hidden"]] + list(custom)
    favs = [f for f in st["favorites"] if (f in NAMES and f in allowed) or f in custom]
    pool = favs or allowed or list(NAMES)
    t = (text or "").lower()
    score = {n: 0 for n in list(NAMES) + list(custom)}
    why = {}
    for n, reason, rx in SIGNALS:
        hits = len(re.findall(rx, t))
        if hits:
            score[n] += min(hits, 3) * 2
            why.setdefault(n, reason)
    for n, b in KIND_BONUS.get((kind or "").lower(), {}).items():
        score[n] += b
    for n, b in JOB_BONUS.get((job or "").lower(), {}).items():
        score[n] += b
    for i in custom:
        score[i] += 2               # a look she added herself is one she loves: use it often
        why.setdefault(i, "it is one of your own looks")
    learned = {}   # what her own results say (needs enough carousels; see results.py)
    try:
        lj = json.load(open(os.path.join(ROOT, "customer", "insights", "learned.json"), encoding="utf-8"))
        base_ = lj.get("looks_baseline")
        if lj.get("looks_enough") and base_:
            for k, v in (lj.get("looks") or {}).items():
                if v.get("posts", 0) >= 3:
                    key = int(k) if str(k).isdigit() else (int(str(k).split(":")[1]) if str(k).startswith("custom:") else None)
                    if key in score:
                        if v["median"] > base_ * 1.15:
                            learned[key] = 3
                        elif v["median"] < base_ * 0.85:
                            learned[key] = -2
    except Exception:
        pass
    for n, b in learned.items():
        score[n] += b
        if b > 0:
            why.setdefault(n, "your carousels in this look do better than your usual")
    textonly = (not photos) or "text carousel" in (fmt or "").lower()
    for n in NAMES:
        if textonly and n in NEEDS_PHOTO:
            score[n] -= 6
        if textonly and n in (3, 5, 2):
            score[n] += 2
    rec = recent_templates()
    rid = lambda v: (int(str(v).split(":")[1]) if str(v).startswith("custom:") else v)
    if len(rec) >= 2 and rec[0] == rec[1]:
        score[rid(rec[0])] = score.get(rid(rec[0]), 0) - 5          # never three in a row
    elif rec:
        score[rid(rec[0])] = score.get(rid(rec[0]), 0) - 1          # a little variety
    # Learning on purpose: until each look she is choosing from has been used for 3 carousels, favor the ones used least
    # (only among looks that still fit the post), so there is enough to compare what works for HER audience.
    made = {}
    for rv in recent_templates(1000):
        k_ = rid(rv)
        made[k_] = made.get(k_, 0) + 1
    explore = [n for n in pool if made.get(n, 0) < 3]
    trying = False
    if explore and len(pool) > 1:
        top = max(score.get(n, 0) for n in pool)
        cand = [n for n in explore if score.get(n, 0) >= top - 4]
        if cand and not (len(cand) == len(pool)):
            pool, trying = cand, True
    ranked = sorted(pool, key=lambda n: (-score.get(n, 0), made.get(n, 0), n))
    best = ranked[0]
    if trying:
        why[best] = (why[best] + ", and we are trying each look so we learn what works for you") if best in why else "we are trying each look so we learn what works for you"
    if best in why:
        reason = why[best]
    elif textonly and best in (3, 5, 2):
        reason = "it reads well with no photos"
    else:
        reason = "it suits this post"
    nm = (custom[best]["name"] if best in custom else st["names"].get(str(best))) or NAMES.get(best, "My look")
    return {"template": tmpl(best), "name": nm, "reason": reason, "pinned": False, "id": best}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--text", default="")
    ap.add_argument("--kind", default="")
    ap.add_argument("--job", default="")
    ap.add_argument("--format", default="")
    ap.add_argument("--no-photos", action="store_true")
    ap.add_argument("--mix", action="store_true", help="also plan the slide mix")
    ap.add_argument("--look", type=int, default=0)
    ap.add_argument("--beats", type=int, default=6)
    ap.add_argument("--photos", type=int, default=0)
    ap.add_argument("--number", action="store_true")
    ap.add_argument("--quotes", type=int, default=1)
    a = ap.parse_args()
    if a.mix:
        print(json.dumps(plan_mix(a.look or 2, a.beats, a.photos, a.number, a.quotes)))
        return
    print(json.dumps(choose(a.text, a.kind, a.job, a.format, not a.no_photos)))


if __name__ == "__main__":
    main()
