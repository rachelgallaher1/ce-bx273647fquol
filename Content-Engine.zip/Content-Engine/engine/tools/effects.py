"""
The effects library: pop-in extras people can add to a video.

Each effect is a function that draws ONE frame as a transparent picture.
  fn(lib, text, p)  ->  image
    lib  gives the look (colors, fonts) and font helpers
    text what she typed for it (some effects split it on "|")
    p    how far through the effect we are, 0.0 to 1.0

Everything is drawn in the chosen look's colors, calm (no bounce), and placed away from faces by the editor.
Add a new effect by writing one function and adding one line to EFFECTS.
"""
import math
import re

from PIL import Image, ImageDraw


def ease_out(x):
    x = max(0.0, min(1.0, x))
    return 1 - (1 - x) ** 3


def clip01(x):
    return max(0.0, min(1.0, x))


def card(img, box, radius, fill, outline=None, width=0):
    d = ImageDraw.Draw(img)
    d.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)
    return d


def outline_for(lib):
    return (30, 30, 30, 255) if lib.look["hook"].get("border") else None


# ---------- typing bar ----------
def fx_typing(lib, text, p):
    w, h = 900, 130
    img = Image.new("RGBA", (w + 24, h + 24), (0, 0, 0, 0))
    card(img, (12, 12, 12 + w, 12 + h), h // 2, (255, 255, 255, 255), outline_for(lib), 4)
    d = ImageDraw.Draw(img)
    cx, cy = 12 + h // 2, 12 + h // 2
    d.ellipse((cx - 22, cy - 26, cx + 14, cy + 10), outline=(110, 110, 110, 255), width=6)
    d.line((cx + 10, cy + 8, cx + 30, cy + 30), fill=(110, 110, 110, 255), width=8)
    size = 56
    f = lib.font(lib.look["captionFont"], size, 600)
    maxw = w - h - 40
    while d.textlength(text, font=f) > maxw and size > 28:
        size -= 3
        f = lib.font(lib.look["captionFont"], size, 600)
    n = int(len(text) * clip01(p / 0.65))
    shown = text[:n]
    tx = 12 + h + 6
    d.text((tx, cy - size * 0.62), shown, font=f, fill=(35, 35, 35, 255))
    if n < len(text) or int(p * 6) % 2 == 0:
        x = tx + d.textlength(shown, font=f) + 6
        d.rectangle((x, cy - 32, x + 5, cy + 32), fill=lib.rgb(lib.look["accent"]["bg"]))
    return img


# ---------- comment or message popup ----------
def fx_popup(lib, text, p):
    w, h = 820, 180
    img = Image.new("RGBA", (w + 24, h + 24), (0, 0, 0, 0))
    card(img, (12, 12, 12 + w, 12 + h), 40, (255, 255, 255, 255), outline_for(lib), 4)
    d = ImageDraw.Draw(img)
    cy = 12 + h // 2
    d.ellipse((40, cy - 48, 136, cy + 48), fill=lib.rgb(lib.look["accent"]["bg"]))
    fa = lib.font(lib.look["hookFont"], 56, 700)
    d.text((88 - d.textlength("@", font=fa) / 2, cy - 36), "@", font=fa, fill=lib.rgb(lib.look["accent"]["text"]))
    f1 = lib.font(lib.look["captionFont"], 34, 500)
    d.text((165, 38), "New comment", font=f1, fill=(120, 120, 120, 255))
    size = 58
    f2 = lib.font(lib.look["captionFont"], size, 700)
    while d.textlength(text, font=f2) > w - 190 and size > 30:
        size -= 3
        f2 = lib.font(lib.look["captionFont"], size, 700)
    d.text((165, 86), text, font=f2, fill=(30, 30, 30, 255))
    d.text((w - 70, 40), "now", font=f1, fill=(150, 150, 150, 255))
    return img


# ---------- number that counts up ----------
def fx_count(lib, text, p):
    top, _, label = text.partition("|")
    m = re.match(r"^([^\d]*)([\d][\d,\.]*)(.*)$", top.strip())
    prefix, num, suffix = (m.group(1), m.group(2), m.group(3)) if m else ("", "0", top)
    try:
        val = float(num.replace(",", ""))
    except ValueError:
        val = 0.0
    cur = val * ease_out(p / 0.7)
    shown = f"{cur:,.0f}" if ("." not in num and "," in num) else (f"{cur:.0f}" if "." not in num else f"{cur:.1f}")
    s = f"{prefix}{shown}{suffix}"
    a = lib.look["accent"]
    fn = lib.display(190)
    fl = lib.display(56)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    wn = d0.textlength(s, font=fn)
    wl = d0.textlength(label.upper(), font=fl) if label else 0
    w = int(max(360, wn + 90, wl + 90))
    h = 360 if label else 280
    img = Image.new("RGBA", (w + 24, h + 24), (0, 0, 0, 0))
    card(img, (12, 12, 12 + w, 12 + h), 44, lib.rgb(a["bg"]), outline_for(lib), 4)
    d = ImageDraw.Draw(img)
    d.text((12 + (w - wn) / 2, 40), s, font=fn, fill=lib.rgb(a["text"]))
    if label:
        d.text((12 + (w - wl) / 2, 40 + 200), label.upper(), font=fl, fill=lib.rgb(a["text"]))
    return img


# ---------- calendar filling in ----------
def fx_calendar(lib, text, p):
    title = text or "30 days planned"
    cols, rows, cw, chh, gap = 6, 5, 84, 60, 12
    gw, gh = cols * cw + (cols - 1) * gap, rows * chh + (rows - 1) * gap
    w, h = gw + 80, gh + 160
    img = Image.new("RGBA", (w + 24, h + 24), (0, 0, 0, 0))
    card(img, (12, 12, 12 + w, 12 + h), 44, (255, 255, 255, 255), outline_for(lib), 4)
    d = ImageDraw.Draw(img)
    title = title.upper()
    size = 76
    f = lib.display(size)
    while d.textlength(title, font=f) > w - 60 and size > 36:
        size -= 4
        f = lib.display(size)
    d.text((12 + (w - d.textlength(title, font=f)) / 2, 30), title, font=f, fill=(35, 35, 35, 255))
    filled = int(cols * rows * clip01(p / 0.8))
    acc = lib.rgb(lib.look["accent"]["bg"])
    for i in range(cols * rows):
        r, c = divmod(i, cols)
        x, y = 52 + c * (cw + gap), 12 + 120 + r * (chh + gap)
        if i < filled:
            d.rounded_rectangle((x, y, x + cw, y + chh), radius=14, fill=acc)
            cx, cy = x + cw / 2, y + chh / 2
            d.line((cx - 16, cy + 1, cx - 4, cy + 13, cx + 18, cy - 12), fill=lib.rgb(lib.look["accent"]["text"]), width=8, joint="curve")
        else:
            d.rounded_rectangle((x, y, x + cw, y + chh), radius=14, fill=(238, 234, 230, 255))
    return img


# ---------- hand-drawn swoosh arrow (brush stroke that tapers) ----------
def fx_arrow(lib, text, p):
    w, h = 520, 420
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    n = 60
    pts = []
    for i in range(n + 1):
        t = i / n
        pts.append((40 + 400 * t, 300 - 150 * math.sin(t * math.pi * 0.9) + 40 * t))
    k = int(n * clip01(p / 0.7))
    def stroke(col, grow):
        for i in range(k + 1):
            t = i / n
            r = (4 + 18 * t) + grow
            x, y = pts[i]
            d.ellipse((x - r, y - r, x + r, y + r), fill=col)
    stroke((20, 20, 20, 235), 5)
    stroke((255, 255, 255, 255), 0)
    if p > 0.6 and k >= 3:
        (x1, y1), (x2, y2) = pts[k - 3], pts[k]
        ang = math.atan2(y2 - y1, x2 - x1)
        for da in (2.6, -2.6):
            for grow, col in ((5, (20, 20, 20, 235)), (0, (255, 255, 255, 255))):
                for j in range(14):
                    t = j / 13
                    px_, py_ = x2 + 78 * t * math.cos(ang + da), y2 + 78 * t * math.sin(ang + da)
                    r = 17 - 9 * t + grow
                    d.ellipse((px_ - r, py_ - r, px_ + r, py_ + r), fill=col)
    if text:
        f = lib.font("Gochi Hand", 72, 400)
        d.text((24, 14), text, font=f, fill=(255, 255, 255, 255), stroke_width=7, stroke_fill=(20, 20, 20, 235))
    return img


# ---------- sticky note ----------
def fx_sticky(lib, text, p):
    w, h = 520, 470
    img = Image.new("RGBA", (w + 40, h + 40), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    note = (255, 226, 122, 255)
    d.rectangle((20, 20, 20 + w, 20 + h), fill=note)
    d.polygon([(20 + w - 70, 20 + h), (20 + w, 20 + h - 70), (20 + w, 20 + h)], fill=(235, 200, 90, 255))
    f = lib.font("Caveat", 78, 700)
    words, lines, cur = text.split(), [], ""
    for wd in words:
        t = (cur + " " + wd).strip()
        if d.textlength(t, font=f) > w - 70 and cur:
            lines.append(cur)
            cur = wd
        else:
            cur = t
    if cur:
        lines.append(cur)
    y = 50
    for ln in lines[:4]:
        d.text((20 + 36, y), ln, font=f, fill=(55, 45, 30, 255))
        y += 90
    img = lib.rotated(img, -5)
    s = 1.0 + 0.12 * (1 - ease_out(p / 0.2))
    return lib.scaled(img, s)


# ---------- checklist ----------
def fx_checklist(lib, text, p):
    items = [x.strip() for x in text.split("|") if x.strip()] or ["First", "Second", "Third"]
    w, rowh = 780, 104
    h = 60 + rowh * len(items)
    img = Image.new("RGBA", (w + 24, h + 24), (0, 0, 0, 0))
    card(img, (12, 12, 12 + w, 12 + h), 44, (255, 255, 255, 255), outline_for(lib), 4)
    d = ImageDraw.Draw(img)
    f = lib.font(lib.look["captionFont"], 54, 600)
    acc = lib.rgb(lib.look["accent"]["bg"])
    for i, it in enumerate(items):
        y = 12 + 30 + i * rowh
        done = p > 0.15 + 0.7 * (i + 1) / (len(items) + 0.5) * 0.9
        d.rounded_rectangle((52, y + 12, 52 + 64, y + 12 + 64), radius=16, fill=acc if done else (238, 234, 230, 255))
        if done:
            d.line((70, y + 46, 82, y + 58, 104, y + 32), fill=lib.rgb(lib.look["accent"]["text"]), width=9, joint="curve")
        d.text((148, y + 14), it, font=f, fill=(35, 35, 35, 255))
    return img


# ---------- stamp ----------
def fx_stamp(lib, text, p):
    t = (text or "DONE").upper()
    f = lib.display(200)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    bb = d0.textbbox((0, 0), t, font=f)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]
    w, h = tw + 120, th + 110
    img = Image.new("RGBA", (w + 40, h + 40), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    col = lib.rgb(lib.look["highlight"]["bg"] if lib.lum(lib.look["highlight"]["bg"]) > 0.3 else lib.look["accent"]["bg"])
    d.rounded_rectangle((20, 20, 20 + w, 20 + h), radius=26, outline=(20, 20, 20, 235), width=22)
    d.rounded_rectangle((20, 20, 20 + w, 20 + h), radius=26, outline=col, width=14)
    d.text((20 + 60 - bb[0], 20 + 40 - bb[1]), t, font=f, fill=(20, 20, 20, 235), stroke_width=7, stroke_fill=(20, 20, 20, 235))
    d.text((20 + 60 - bb[0], 20 + 40 - bb[1]), t, font=f, fill=col)
    img = lib.rotated(img, -9)
    s = 1.0 + 0.7 * (1 - ease_out(p / 0.16))
    return lib.scaled(img, s)


# ---------- lower third: name and title ----------
def fx_lowerthird(lib, text, p):
    parts = [x.strip() for x in (text or "").split("|") if x.strip()] or ["Rachel", "Content coach"]
    name, title = parts[0], (parts[1] if len(parts) > 1 else "")
    fn_ = lib.display(84)
    ft = lib.font(lib.look["captionFont"], 44, 700)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    w = int(max(d0.textlength(name.upper(), font=fn_), d0.textlength(title, font=ft)) + 110)
    h = 190 if title else 130
    img = Image.new("RGBA", (w + 40, h + 40), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    acc = lib.rgb(lib.look["accent"]["bg"])
    ink = lib.rgb(lib.look["accent"]["text"])
    reveal = int(w * ease_out(clip01(p / 0.2)))
    d.rounded_rectangle((20, 20, 20 + max(30, reveal), 20 + h), radius=18, fill=(20, 20, 20, 235))
    d.rounded_rectangle((20, 20, 40, 20 + h), radius=8, fill=acc)
    if reveal > w * 0.6:
        d.text((64, 30), name.upper(), font=fn_, fill=(255, 255, 255, 255))
        if title:
            d.text((64, 30 + 98), title, font=ft, fill=acc)
    return img


# ---------- text message chat ----------
def fx_chat(lib, text, p):
    msgs = [m.strip() for m in text.split("|") if m.strip()][:4] or ["hey, quick question", "yes! tell me more"]
    f = lib.font(lib.look["captionFont"], 46, 600)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    rowh, w = 150, 860
    img = Image.new("RGBA", (w + 24, rowh * len(msgs) + 40), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    acc = lib.rgb(lib.look["accent"]["bg"])
    for i, m in enumerate(msgs):
        if p < 0.08 + 0.7 * i / len(msgs):
            break
        tw = d0.textlength(m, font=f)
        bw = int(min(w - 120, tw + 80))
        right = i % 2 == 1
        x0 = 12 + (w - bw if right else 0)
        y0 = 20 + i * rowh
        fill = acc if right else (255, 255, 255, 255)
        d.rounded_rectangle((x0, y0, x0 + bw, y0 + 112), radius=56, fill=fill, outline=outline_for(lib), width=4)
        col = lib.rgb(lib.look["accent"]["text"]) if right else (35, 35, 35, 255)
        d.text((x0 + 40, y0 + 26), m, font=f, fill=col)
    return img


# ---------- progress bar ----------
def fx_progress(lib, text, p):
    w, h = 880, 260
    img = Image.new("RGBA", (w + 24, h + 24), (0, 0, 0, 0))
    card(img, (12, 12, 12 + w, 12 + h), 44, (255, 255, 255, 255), outline_for(lib), 4)
    d = ImageDraw.Draw(img)
    f = lib.display(74)
    d.text((54, 36), (text or "PROGRESS").upper(), font=f, fill=(35, 35, 35, 255))
    v = ease_out(p / 0.75)
    pct = f"{int(round(100 * v))}%"
    fp = lib.display(74)
    d.text((12 + w - 40 - d.textlength(pct, font=fp), 36), pct, font=fp, fill=lib.rgb(lib.look["accent"]["bg"]))
    bx0, bx1, by0, by1 = 54, 12 + w - 42, 150, 222
    d.rounded_rectangle((bx0, by0, bx1, by1), radius=36, fill=(238, 234, 230, 255))
    if v > 0.02:
        d.rounded_rectangle((bx0, by0, bx0 + max(72, int((bx1 - bx0) * v)), by1), radius=36, fill=lib.rgb(lib.look["accent"]["bg"]))
    return img


# ---------- before and after ----------
def fx_beforeafter(lib, text, p):
    a_txt, _, b_txt = text.partition("|")
    w, h = 780, 250
    img = Image.new("RGBA", (w + 24, h * 2 + 110), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    fl, fb = lib.display(46), lib.display(104)
    acc = lib.rgb(lib.look["accent"]["bg"])
    def block(y, label, big, fill, ink, show):
        if not show:
            return
        card(img, (12, y, 12 + w, y + h), 40, fill, outline_for(lib), 4)
        d.text((52, y + 22), label, font=fl, fill=ink)
        d.text((52, y + 86), big.upper(), font=fb, fill=ink)
    block(12, "BEFORE", a_txt or "3 hours", (232, 228, 224, 255), (80, 76, 72, 255), p > 0.05)
    if p > 0.3:
        d.polygon([(12 + w // 2 - 36, 12 + h + 14), (12 + w // 2 + 36, 12 + h + 14), (12 + w // 2, 12 + h + 78)], fill=acc, outline=(20, 20, 20, 235))
    block(12 + h + 92, "AFTER", b_txt or "20 minutes", acc, lib.rgb(lib.look["accent"]["text"]), p > 0.45)
    return img


# ---------- tag sticker ----------
def fx_tag(lib, text, p):
    t = (text or "NEW").upper()
    f = lib.display(130)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    bb = d0.textbbox((0, 0), t, font=f)
    w, h = bb[2] - bb[0] + 110, bb[3] - bb[1] + 80
    img = Image.new("RGBA", (w + 40, h + 40), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    fill = lib.rgb(lib.look["highlight"]["bg"] if lib.lum(lib.look["highlight"]["bg"]) > 0.3 else lib.look["accent"]["bg"])
    d.rounded_rectangle((20, 20, 20 + w, 20 + h), radius=h // 2, fill=fill, outline=(20, 20, 20, 235), width=8)
    ink = (20, 20, 20, 255) if lib.lum(lib.look["highlight"]["bg"]) > 0.3 else (255, 255, 255, 255)
    d.text((20 + 55 - bb[0], 20 + 38 - bb[1]), t, font=f, fill=ink)
    img = lib.rotated(img, 7)
    return lib.scaled(img, 1.0 + 0.1 * (1 - ease_out(p / 0.2)))


# ---------- big word with a drawn underline ----------
def fx_underline(lib, text, p):
    t = (text or "THE KEY").upper()
    size = 190
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    f = lib.display(size)
    while d0.textlength(t, font=f) > 880 and size > 60:
        size -= 8
        f = lib.display(size)
    bb = d0.textbbox((0, 0), t, font=f)
    w, h = bb[2] - bb[0] + 80, bb[3] - bb[1] + 140
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.text((40 - bb[0], 20 - bb[1]), t, font=f, fill=(255, 255, 255, 255), stroke_width=9, stroke_fill=(20, 20, 20, 235))
    col = lib.rgb(lib.look["highlight"]["bg"] if lib.lum(lib.look["highlight"]["bg"]) > 0.45 else lib.look["hook"]["bg"])
    y0 = 20 + (bb[3] - bb[1]) + 40
    pts = [(40 + (w - 80) * i / 30, y0 + 10 * math.sin(i / 30 * math.pi * 2.2)) for i in range(31)]
    k = int(30 * clip01(p / 0.6))
    for sw, c in ((26, (20, 20, 20, 235)), (16, col)):
        if k >= 1:
            d.line(pts[:k + 1], fill=c, width=sw, joint="curve")
    return img



CREAM = (255, 244, 200, 255)
INK = (24, 24, 24, 255)


def wrap(d, text, font, maxw):
    lines, cur = [], ""
    for wd in text.split():
        t = (cur + " " + wd).strip()
        if d.textlength(t, font=font) > maxw and cur:
            lines.append(cur)
            cur = wd
        else:
            cur = t
    if cur:
        lines.append(cur)
    return lines


# ---------- script line over a bold serif headline ----------
def fx_scriptheadline(lib, text, p):
    parts = [x.strip() for x in text.split("|") if x.strip()] or ["It's like Canva,", "but for business owners who need content"]
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    fs = lib.font("Pinyon Script", 150, 400)
    sz = 150
    while d0.textlength(parts[0], font=fs) > 940 and sz > 60:
        sz -= 6
        fs = lib.font("Pinyon Script", sz, 400)
    fb = lib.font("Playfair Display", 118, 800)
    body = wrap(d0, " ".join(parts[1:]) if len(parts) > 1 else "", fb, 940)
    lh = 112
    h = 190 + lh * len(body) + 40
    img = Image.new("RGBA", (1000, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.text(((1000 - d0.textlength(parts[0], font=fs)) / 2, 10), parts[0], font=fs, fill=CREAM, stroke_width=5, stroke_fill=(20, 20, 20, 200))
    if p > 0.18:
        for i, ln in enumerate(body):
            d.text(((1000 - d0.textlength(ln, font=fb)) / 2, 190 + i * lh), ln, font=fb, fill=CREAM, stroke_width=6, stroke_fill=(20, 20, 20, 200))
    return img


# ---------- headline, then a dark box, then a small pill ----------
def fx_stack3(lib, text, p):
    parts = [x.strip() for x in text.split("|")]
    parts += [""] * (3 - len(parts))
    head, box, pill = parts[0] or "BIG HEADLINE", parts[1], parts[2]
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    hl = head.upper().split()
    lines, cur = [], ""
    fh = lib.display(150)
    for wd in hl:
        t = (cur + " " + wd).strip()
        if d0.textlength(t, font=fh) > 940 and cur:
            lines.append(cur)
            cur = wd
        else:
            cur = t
    if cur:
        lines.append(cur)
    while max(d0.textlength(l, font=fh) for l in lines) > 940 and fh.size > 60:
        fh = lib.display(fh.size - 8)
    lh = int(fh.size * 1.0)
    fb = lib.font(lib.look["captionFont"], 56, 600)
    bl = wrap(d0, box, fb, 800) if box else []
    boxh = 60 + 72 * len(bl) if bl else 0
    h = 30 + lh * len(lines) + (30 + boxh if boxh else 0) + (30 + 110 if pill else 0) + 30
    img = Image.new("RGBA", (1000, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    y = 20
    col = lib.rgb(lib.look["highlight"]["bg"] if lib.lum(lib.look["highlight"]["bg"]) > 0.45 else lib.look["hook"]["bg"])
    for ln in lines:
        d.text(((1000 - d0.textlength(ln, font=fh)) / 2, y + 8), ln, font=fh, fill=(0, 0, 0, 110), stroke_width=9, stroke_fill=(0, 0, 0, 110))
        d.text(((1000 - d0.textlength(ln, font=fh)) / 2, y), ln, font=fh, fill=col, stroke_width=9, stroke_fill=INK)
        y += lh
    y += 30
    if bl and p > 0.25:
        bw = int(min(900, max(d0.textlength(l, font=fb) for l in bl) + 100))
        d.rounded_rectangle(((1000 - bw) // 2, y, (1000 - bw) // 2 + bw, y + boxh), radius=48, fill=(0, 0, 0, 240))
        for i, l in enumerate(bl):
            d.text(((1000 - d0.textlength(l, font=fb)) / 2, y + 28 + i * 72), l, font=fb, fill=(255, 255, 255, 255))
    if bl:
        y += boxh + 30
    if pill and p > 0.5:
        fp = lib.font(lib.look["captionFont"], 50, 600)
        tw = d0.textlength(pill, font=fp)
        pw = int(tw + 150)
        x0 = (1000 - pw) // 2
        d.rounded_rectangle((x0, y, x0 + pw, y + 110), radius=55, fill=(255, 255, 255, 255))
        d.text((x0 + 44, y + 26), pill, font=fp, fill=INK)
        ax = x0 + pw - 76
        d.polygon([(ax, y + 40), (ax + 30, y + 40), (ax + 30, y + 26), (ax + 56, y + 55), (ax + 30, y + 84), (ax + 30, y + 70), (ax, y + 70)], fill=lib.rgb(lib.look["accent"]["bg"]))
    return img


# ---------- giant tight serif headline ----------
def fx_serifbig(lib, text, p):
    main, _, small = text.partition("|")
    main = main or "Let me deinfluence you for a second"
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    size = 190
    while True:
        f = lib.font("Playfair Display", size, 700)
        lines = wrap(d0, main, f, 960)
        if len(lines) * size * 0.9 < 1100 or size < 90:
            break
        size -= 10
    lh = int(size * 0.92)
    fsm = lib.font("Playfair Display", 56, 500)
    h = 40 + lh * len(lines) + (150 if small else 20)
    img = Image.new("RGBA", (1040, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for i, ln in enumerate(lines):
        x = (1040 - d0.textlength(ln, font=f)) / 2
        d.text((x, 20 + i * lh + 8), ln, font=f, fill=(0, 0, 0, 110), stroke_width=5, stroke_fill=(0, 0, 0, 110))
        d.text((x, 20 + i * lh), ln, font=f, fill=(255, 255, 255, 255), stroke_width=4, stroke_fill=(20, 20, 20, 170))
    if small and p > 0.3:
        x = (1040 - d0.textlength(small, font=fsm)) / 2
        d.text((x, 80 + lh * len(lines)), small, font=fsm, fill=(255, 255, 255, 255), stroke_width=3, stroke_fill=(20, 20, 20, 170))
    return img


# ---------- picture card (her own screenshot or photo) ----------
def fx_screenshot(lib, text, p):
    path = (text or "").strip()
    img = Image.new("RGBA", (1060, 760), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    pic = None
    try:
        pic = Image.open(path).convert("RGBA")
    except Exception:
        pic = None
    if pic is None:
        d.rounded_rectangle((20, 20, 1040, 740), radius=36, fill=(255, 255, 255, 255), outline=(30, 30, 30, 255), width=6)
        f = lib.display(90)
        t = "YOUR PICTURE"
        d.text(((1060 - d.textlength(t, font=f)) / 2, 330), t, font=f, fill=(120, 120, 120, 255))
        return img
    maxw, maxh = 1000, 700
    r = min(maxw / pic.width, maxh / pic.height)
    pic = pic.resize((int(pic.width * r), int(pic.height * r)), Image.LANCZOS)
    card = Image.new("RGBA", (pic.width + 28, pic.height + 28), (0, 0, 0, 0))
    ImageDraw.Draw(card).rounded_rectangle((0, 0, card.width - 1, card.height - 1), radius=26, fill=(255, 255, 255, 255))
    mask = Image.new("L", pic.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, pic.width - 1, pic.height - 1), radius=16, fill=255)
    card.paste(pic, (14, 14), mask)
    out = Image.new("RGBA", (1060, card.height + 20), (0, 0, 0, 0))
    out.alpha_composite(card, ((1060 - card.width) // 2, 10))
    return out


# ---------- row of emoji ----------
def fx_emojirow(lib, text, p):
    ch = (text or "").strip()[:2] or "\U0001F92F"
    n, size = 8, 112
    img = Image.new("RGBA", (n * size + 40, size + 40), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    shown = int(n * clip01(p / 0.7)) + 1
    one = lib.emoji(ch, size)
    for i in range(min(n, shown)):
        if one is not None:
            img.alpha_composite(one, (20 + i * size, 20))
        else:
            cx, cy = 20 + i * size + size / 2, 20 + size / 2
            pts = [(cx + (size * 0.45 if k % 2 == 0 else size * 0.2) * math.cos(k * math.pi / 5 - math.pi / 2),
                    cy + (size * 0.45 if k % 2 == 0 else size * 0.2) * math.sin(k * math.pi / 5 - math.pi / 2)) for k in range(10)]
            d.polygon(pts, fill=lib.rgb(lib.look["highlight"]["bg"]), outline=INK)
    return img


# ---------- comment reply bubble with a profile picture ----------
def fx_reply(lib, text, p):
    t = text or "The rumors are true!! I signed up"
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    f = lib.font(lib.look["captionFont"], 52, 600)
    lines = wrap(d0, t, f, 560)[:3]
    bw = int(max(d0.textlength(l, font=f) for l in lines) + 90)
    bh = 50 + 70 * len(lines)
    img = Image.new("RGBA", (bw + 220, bh + 230), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((20, 20, 20 + bw, 20 + bh), radius=60, fill=(238, 238, 240, 255))
    d.polygon([(20 + 70, 20 + bh - 4), (20 + 130, 20 + bh - 4), (20 + 60, 20 + bh + 56)], fill=(238, 238, 240, 255))
    for i, l in enumerate(lines):
        d.text((20 + 45, 20 + 25 + i * 70), l, font=f, fill=INK)
    ay = 20 + bh + 40
    d.ellipse((20, ay, 20 + 150, ay + 150), fill=lib.rgb(lib.look["accent"]["bg"]), outline=(255, 255, 255, 255), width=8)
    fa = lib.display(84)
    d.text((20 + 75 - d.textlength("@", font=fa) / 2, ay + 26), "@", font=fa, fill=lib.rgb(lib.look["accent"]["text"]))
    bx, by = 20 + 118, ay + 108
    d.ellipse((bx, by, bx + 56, by + 56), fill=(123, 97, 255, 255), outline=(255, 255, 255, 255), width=5)
    d.arc((bx + 12, by + 12, bx + 44, by + 44), 30, 300, fill=(255, 255, 255, 255), width=5)
    return img


# ---------- paper note with tape and a torn edge ----------
def fx_paper(lib, text, p):
    t = text or "good design was never about looking pretty. it's about the people using it"
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    f = lib.font("Gochi Hand", 62, 400)
    lines = wrap(d0, t, f, 780)[:5]
    w, h = 900, 120 + 78 * len(lines)
    img = Image.new("RGBA", (w + 80, h + 100), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    import random
    rnd = random.Random(7)
    top = [(40, 40), (40 + w, 40)]
    bottom = [(40 + w - i * 30, 40 + h + rnd.randint(-10, 12)) for i in range(0, w // 30 + 1)]
    d.polygon(top + bottom + [(40, 40 + h)], fill=(250, 240, 226, 255))
    d.line([(40, 40 + h - 18), (40 + w, 40 + h - 18)], fill=(222, 196, 170, 255), width=5)
    for i, l in enumerate(lines):
        d.text((90, 80 + i * 78), l, font=f, fill=(35, 30, 28, 255))
    for cx, cy, ang in ((50, 50, -38), (40 + w - 10, 50, 38)):
        tape = Image.new("RGBA", (170, 60), (232, 218, 196, 205))
        tape = tape.rotate(ang, expand=True, resample=Image.BICUBIC)
        img.alpha_composite(tape, (cx - tape.width // 2, cy - tape.height // 2))
    return lib.rotated(img, -2)


# ---------- handwritten title, written on ----------
def fx_handwritten(lib, text, p):
    parts = [x.strip() for x in (text or "10 years in design has taught me...").split("|") if x.strip()]
    f = lib.font("Gochi Hand", 118, 400)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    lines = []
    for pt in parts:
        lines += wrap(d0, pt, f, 960)
    lh = 128
    img = Image.new("RGBA", (1000, lh * len(lines) + 50), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for i, l in enumerate(lines):
        x = (1000 - d0.textlength(l, font=f)) / 2
        d.text((x, 14 + i * lh), l, font=f, fill=(255, 255, 255, 255), stroke_width=8, stroke_fill=(20, 20, 20, 235))
    reveal = int(1000 * ease_out(p / 0.65))
    mask = Image.new("L", img.size, 0)
    ImageDraw.Draw(mask).rectangle((0, 0, reveal, img.height), fill=255)
    out = Image.new("RGBA", img.size, (0, 0, 0, 0))
    out.paste(img, (0, 0), mask)
    return out



# ---------- a pile of comment cards ----------
def fx_notifpile(lib, text, p):
    msgs = [m.strip() for m in (text or "").split("|") if m.strip()] or ["Series", "I need this!", "how do I get it?", "signed up!", "so good", "more please"]
    msgs = (msgs * 3)[:8]
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    f = lib.font(lib.look["captionFont"], 40, 600)
    fs = lib.font(lib.look["captionFont"], 28, 500)
    img = Image.new("RGBA", (1040, 980), (0, 0, 0, 0))
    spots = [(20, 20), (500, 90), (60, 230), (520, 330), (10, 440), (470, 560), (80, 650), (530, 770)]
    shown = int(len(msgs) * clip01(p / 0.8)) + 1
    for i, m in enumerate(msgs[:min(shown, len(msgs))]):
        x, y = spots[i]
        card = Image.new("RGBA", (500, 130), (0, 0, 0, 0))
        d = ImageDraw.Draw(card)
        d.rounded_rectangle((2, 2, 498, 128), radius=36, fill=(255, 255, 255, 245), outline=outline_for(lib), width=3)
        d.ellipse((24, 26, 96, 98), fill=lib.rgb(lib.look["accent"]["bg"]))
        d.text((60 - d.textlength("@", font=f) / 2, 40), "@", font=f, fill=lib.rgb(lib.look["accent"]["text"]))
        d.text((116, 22), "viewer  \u00b7  now", font=fs, fill=(120, 120, 120, 255))
        t = m if d.textlength(m, font=f) < 360 else m[:18] + "..."
        d.text((116, 62), t, font=f, fill=INK)
        card = lib.rotated(card, [-3, 3, 2, -2, 4, -4, 2, -3][i])
        img.alpha_composite(card, (x, y))
    return img


# ---------- phone frame with her screen inside ----------
def fx_phone(lib, text, p):
    w, h = 600, 1060
    img = Image.new("RGBA", (w + 40, h + 40), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((20, 20, 20 + w, 20 + h), radius=84, fill=(12, 12, 14, 255))
    sx0, sy0, sx1, sy1 = 44, 44, 20 + w - 24, 20 + h - 24
    try:
        pic = Image.open((text or "").strip()).convert("RGBA")
        r = max((sx1 - sx0) / pic.width, (sy1 - sy0) / pic.height)
        pic = pic.resize((int(pic.width * r), int(pic.height * r)), Image.LANCZOS)
        cx, cy = (pic.width - (sx1 - sx0)) // 2, 0
        pic = pic.crop((cx, cy, cx + (sx1 - sx0), cy + (sy1 - sy0)))
        mask = Image.new("L", pic.size, 0)
        ImageDraw.Draw(mask).rounded_rectangle((0, 0, pic.width - 1, pic.height - 1), radius=62, fill=255)
        img.paste(pic, (sx0, sy0), mask)
    except Exception:
        d.rounded_rectangle((sx0, sy0, sx1, sy1), radius=62, fill=(236, 236, 240, 255))
        f = lib.display(70)
        t = "YOUR SCREEN"
        d.text(((w + 40 - d.textlength(t, font=f)) / 2, 480), t, font=f, fill=(150, 150, 156, 255))
    d.rounded_rectangle((20 + w / 2 - 80, 56, 20 + w / 2 + 80, 90), radius=17, fill=(12, 12, 14, 255))
    return img


# ---------- scrapbook collage of her pictures ----------
def fx_collage(lib, text, p):
    paths = [x.strip() for x in (text or "").split("|") if x.strip()][:6]
    spots = [(30, 30, -5), (330, 10, 4), (610, 60, -3), (70, 330, 5), (370, 350, -4), (640, 380, 3)]
    img = Image.new("RGBA", (1000, 760), (0, 0, 0, 0))
    n = max(len(paths), 6)
    shown = int(n * clip01(p / 0.8)) + 1
    palette = [lib.look["accent"]["bg"], lib.look["highlight"]["bg"], lib.look["hook"]["bg"]]
    for i in range(min(shown, n)):
        x, y, ang = spots[i]
        card = Image.new("RGBA", (330, 360), (0, 0, 0, 0))
        d = ImageDraw.Draw(card)
        d.rounded_rectangle((0, 0, 329, 359), radius=18, fill=(255, 255, 255, 255))
        try:
            pic = Image.open(paths[i]).convert("RGBA") if i < len(paths) else None
        except Exception:
            pic = None
        if pic is not None:
            r = max(298 / pic.width, 328 / pic.height)
            pic = pic.resize((int(pic.width * r), int(pic.height * r)), Image.LANCZOS)
            card.paste(pic.crop(((pic.width - 298) // 2, (pic.height - 328) // 2, (pic.width + 298) // 2, (pic.height + 328) // 2)), (16, 16))
        else:
            d.rectangle((16, 16, 314, 344), fill=lib.rgb(palette[i % 3]))
        card = lib.rotated(card, ang)
        img.alpha_composite(card, (x, y))
    return img



# ---------- star rating ----------
def _star(d, cx, cy, r, fill, outline):
    pts = [(cx + (r if k % 2 == 0 else r * 0.45) * math.cos(k * math.pi / 5 - math.pi / 2),
            cy + (r if k % 2 == 0 else r * 0.45) * math.sin(k * math.pi / 5 - math.pi / 2)) for k in range(10)]
    d.polygon(pts, fill=fill, outline=outline)


def fx_stars(lib, text, p):
    label = text or "LOVED BY BUSY MOMS"
    w, h = 800, 300
    img = Image.new("RGBA", (w + 24, h + 24), (0, 0, 0, 0))
    card(img, (12, 12, 12 + w, 12 + h), 44, (255, 255, 255, 255), outline_for(lib), 4)
    d = ImageDraw.Draw(img)
    gold = (255, 196, 40, 255)
    on = int(5 * clip01(p / 0.6)) + (1 if p > 0.02 else 0)
    for i in range(5):
        _star(d, 12 + 100 + i * 150, 12 + 105, 62, gold if i < on else (232, 228, 222, 255), (150, 110, 10, 255) if i < on else None)
    f = lib.display(74)
    t = label.upper()
    size = 74
    while d.textlength(t, font=f) > w - 60 and size > 36:
        size -= 4
        f = lib.display(size)
    d.text((12 + (w - d.textlength(t, font=f)) / 2, 12 + 195), t, font=f, fill=INK)
    return img


# ---------- likes counter ----------
def fx_likes(lib, text, p):
    m = re.match(r"^([\d][\d,\.]*)(.*)$", (text or "1,284").strip())
    num, suf = (m.group(1), m.group(2)) if m else ("1,284", "")
    try:
        val = float(num.replace(",", ""))
    except ValueError:
        val = 0.0
    cur = val * ease_out(p / 0.7)
    shown = f"{cur:,.0f}" if ("," in num) else (f"{cur:.1f}" if "." in num else f"{cur:.0f}")
    s_ = shown + suf
    f = lib.display(120)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    tw = d0.textlength(s_, font=f)
    w, h = int(tw + 260), 210
    img = Image.new("RGBA", (w + 24, h + 24), (0, 0, 0, 0))
    card(img, (12, 12, 12 + w, 12 + h), 105, (255, 255, 255, 255), outline_for(lib), 4)
    d = ImageDraw.Draw(img)
    cx, cy, r = 12 + 112, 12 + 100, 40
    red = (255, 56, 96, 255)
    d.ellipse((cx - 56, cy - 50, cx, cy + 6), fill=red)
    d.ellipse((cx, cy - 50, cx + 56, cy + 6), fill=red)
    d.polygon([(cx - 55, cy - 12), (cx + 55, cy - 12), (cx, cy + 58)], fill=red)
    d.text((12 + 200, 12 + 38), s_, font=f, fill=INK)
    return img


# ---------- timer ring ----------
def fx_timer(lib, text, p):
    t = (text or "20 MIN").upper()
    w = 520
    img = Image.new("RGBA", (w + 24, w + 24), (0, 0, 0, 0))
    card(img, (12, 12, 12 + w, 12 + w), 60, (255, 255, 255, 255), outline_for(lib), 4)
    d = ImageDraw.Draw(img)
    box = (12 + 70, 12 + 60, 12 + w - 70, 12 + w - 80)
    d.arc(box, 0, 360, fill=(236, 232, 228, 255), width=34)
    d.arc(box, -90, -90 + 360 * ease_out(p / 0.8), fill=lib.rgb(lib.look["accent"]["bg"]), width=34)
    f = lib.display(110)
    size = 110
    while d.textlength(t, font=f) > w - 150 and size > 40:
        size -= 6
        f = lib.display(size)
    d.text((12 + (w - d.textlength(t, font=f)) / 2, 12 + w / 2 - 80 - size * 0.05), t, font=f, fill=INK)
    return img


# ---------- quote card ----------
def fx_quote(lib, text, p):
    q, _, who = (text or "").partition("|")
    q = q or "This changed how I show up online."
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    f = lib.font("Playfair Display", 70, 600)
    lines = wrap(d0, q, f, 780)[:5]
    h = 250 + 92 * len(lines) + (90 if who else 20)
    w = 940
    img = Image.new("RGBA", (w + 24, h + 24), (0, 0, 0, 0))
    card(img, (12, 12, 12 + w, 12 + h), 44, (251, 245, 234, 255), outline_for(lib), 4)
    d = ImageDraw.Draw(img)
    fq = lib.font("Playfair Display", 340, 800)
    d.text((60, -50), "\u201c", font=fq, fill=lib.rgb(lib.look["accent"]["bg"]))
    for i, l in enumerate(lines):
        d.text((90, 220 + i * 92), l, font=f, fill=INK)
    if who and p > 0.3:
        fw = lib.font(lib.look["captionFont"], 46, 600)
        d.text((90, 240 + 92 * len(lines)), "\u2014 " + who, font=fw, fill=(110, 100, 90, 255))
    return img


# ---------- receipt ----------
def fx_receipt(lib, text, p):
    rows = [x.strip() for x in (text or "").split("|") if x.strip()] or ["Guide $27", "Bonus $0", "TOTAL $27"]
    f = lib.font(lib.look["captionFont"], 50, 700)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    w, rowh = 620, 90
    h = 150 + rowh * len(rows)
    img = Image.new("RGBA", (w + 40, h + 60), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    zig = [(20 + i * 20, 20 + (10 if i % 2 else 0)) for i in range(w // 20 + 1)]
    zig2 = [(20 + w - i * 20, 20 + h - (10 if i % 2 else 0)) for i in range(w // 20 + 1)]
    d.polygon(zig + zig2, fill=(255, 255, 255, 255))
    d.text((20 + (w - d0.textlength("RECEIPT", font=f)) / 2, 54), "RECEIPT", font=f, fill=(130, 130, 130, 255))
    shown = int((len(rows) + 1) * clip01(p / 0.8))
    for i, r in enumerate(rows):
        if i >= shown:
            break
        m = re.match(r"^(.*?)\s*(\$[\d,\.]+|[\d,\.]+)$", r)
        left, right = (m.group(1), m.group(2)) if m else (r, "")
        y = 130 + i * rowh
        d.text((60, y), left.upper(), font=f, fill=INK)
        d.text((20 + w - 40 - d0.textlength(right, font=f), y), right, font=f, fill=INK)
        d.line((60, y + 72, 20 + w - 40, y + 72), fill=(220, 216, 212, 255), width=3)
    return lib.rotated(img, -2)


# ---------- highlighter marker over words ----------
def fx_marker(lib, text, p):
    t = (text or "the part that matters").upper()
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    size = 130
    f = lib.display(size)
    while d0.textlength(t, font=f) > 880 and size > 50:
        size -= 6
        f = lib.display(size)
    bb = d0.textbbox((0, 0), t, font=f)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]
    w, h = tw + 120, th + 120
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    col = lib.rgb(lib.look["highlight"]["bg"] if lib.lum(lib.look["highlight"]["bg"]) > 0.45 else lib.look["hook"]["bg"])
    reveal = int((w - 40) * ease_out(p / 0.5))
    d.polygon([(30, 36), (30 + reveal, 28), (30 + reveal + 10, h - 30), (24, h - 38)], fill=col[:3] + (235,))
    d.text((60 - bb[0], 56 - bb[1]), t, font=f, fill=INK)
    return img



# ---------- shimmer sweep ----------
def fx_shimmer(lib, text, p):
    t = (text or "THE PART THAT MATTERS").upper()
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    size = 150
    f = lib.display(size)
    while d0.textlength(t, font=f) > 860 and size > 50:
        size -= 6
        f = lib.display(size)
    bb = d0.textbbox((0, 0), t, font=f)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]
    w, h = tw + 100, th + 100
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.text((50 - bb[0], 50 - bb[1]), t, font=f, fill=(246, 242, 234, 255), stroke_width=8, stroke_fill=(20, 20, 22, 255))
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).text((50 - bb[0], 50 - bb[1]), t, font=f, fill=255)
    # a soft bright band slides across the letters, left to right, once
    x0 = -0.4 * w + (1.8 * w) * ease_out(clip01(p / 0.8))
    band = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    bp = band.load()
    bw = 0.22 * w
    hi = lib.rgb(lib.look["highlight"]["bg"])[:3]
    for y in range(h):
        for x in range(w):
            xs = x + (y - h / 2) * 0.35
            k = 1 - abs(xs - x0) / bw
            if k > 0:
                bp[x, y] = hi + (int(255 * k * k),)
    band.putalpha(Image.composite(band.getchannel("A"), Image.new("L", (w, h), 0), mask))
    return Image.alpha_composite(img, band)


# ---------- bar chart ----------
def fx_chart(lib, text, p):
    rows = []
    for part in (text or "").split("|"):
        m = re.match(r"^(.*?)[\s:]+(-?\d[\d,\.]*)\s*$", part.strip())
        if m:
            rows.append((m.group(1).strip(), float(m.group(2).replace(",", ""))))
    if not rows:
        rows = [("Week 1", 12), ("Week 2", 28), ("Week 3", 55), ("Week 4", 90)]
    rows = rows[:6]
    W_, H_ = 860, 620
    img = Image.new("RGBA", (W_ + 24, H_ + 24), (0, 0, 0, 0))
    card(img, (12, 12, 12 + W_, 12 + H_), 44, (250, 247, 240, 255), outline_for(lib), 4)
    d = ImageDraw.Draw(img)
    a = lib.rgb(lib.look["accent"]["bg"])
    mx = max(v for _, v in rows) or 1
    n = len(rows)
    bw = (W_ - 120) / n
    base = 12 + H_ - 90
    fl = lib.display(40)
    fv = lib.display(46)
    for i, (lab, v) in enumerate(rows):
        g = ease_out(clip01((p - i * 0.12) / 0.5))
        top = base - (H_ - 220) * (v / mx) * g
        x = 12 + 60 + i * bw
        d.rounded_rectangle((x + 10, top, x + bw - 10, base), 14, fill=a[:3] + (255,), outline=(30, 30, 30, 255), width=4)
        shown = f"{v * g:,.0f}"
        wv = d.textlength(shown, font=fv)
        d.text((x + bw / 2 - wv / 2, top - 58), shown, font=fv, fill=(30, 30, 32, 255))
        wl = d.textlength(lab.upper(), font=fl)
        d.text((x + bw / 2 - wl / 2, base + 18), lab.upper(), font=fl, fill=(30, 30, 32, 255))
    d.line((12 + 40, base, 12 + W_ - 40, base), fill=(30, 30, 32, 255), width=5)
    return img


# ---------- slam words ----------
def fx_slam(lib, text, p):
    lines = [x.strip().upper() for x in (text or "").split("|") if x.strip()] or ["THIS", "CHANGES", "EVERYTHING"]
    lines = lines[:4]
    f = lib.display(170)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    while max(d0.textlength(l, font=f) for l in lines) > 900 and f.size > 70:
        f = lib.display(f.size - 8)
    lh = int(f.size * 1.05)
    w, h = 960, lh * len(lines) + 80
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    hi = lib.rgb(lib.look["highlight"]["bg"])
    for i, ln in enumerate(lines):
        t0 = i * 0.2
        k = clip01((p - t0) / 0.14)
        if k <= 0:
            continue
        sc = 1.9 - 0.9 * ease_out(k)
        wd = d0.textlength(ln, font=f)
        layer = Image.new("RGBA", (int(wd + 80), int(lh + 40)), (0, 0, 0, 0))
        ImageDraw.Draw(layer).text((40, 14), ln, font=f, fill=(hi[:3] if i == len(lines) - 1 else (255, 255, 255)) + (255,), stroke_width=9, stroke_fill=(18, 18, 18, 255))
        layer = layer.resize((max(1, int(layer.width * sc)), max(1, int(layer.height * sc))))
        shake = 0 if k < 1 else int(10 * math.sin((p - t0 - 0.14) * 90) * max(0.0, 1 - (p - t0 - 0.14) / 0.12))
        img.alpha_composite(layer, (max(0, int((w - layer.width) / 2 + shake)), max(0, int(40 + i * lh + (lh - layer.height) / 2))))
    return img


# ---------- glitch text ----------
def fx_glitch(lib, text, p):
    t = (text or "SYSTEM ERROR").upper()
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    size = 160
    f = lib.display(size)
    while d0.textlength(t, font=f) > 860 and size > 50:
        size -= 6
        f = lib.display(size)
    bb = d0.textbbox((0, 0), t, font=f)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]
    w, h = tw + 140, th + 140
    seed = int(p * 6)  # photosensitivity floor: the shake changes about 3 times a second at most
    import random
    rnd = random.Random(seed)
    jit = 0 if p > 0.8 else (18 if seed % 2 else 8)
    base = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    for off, col in ((-jit, (255, 40, 90, 255)), (jit, (40, 230, 255, 255))):
        ImageDraw.Draw(base).text((70 - bb[0] + off, 70 - bb[1]), t, font=f, fill=col)
    ImageDraw.Draw(base).text((70 - bb[0], 70 - bb[1]), t, font=f, fill=(255, 255, 255, 255), stroke_width=3, stroke_fill=(18, 18, 18, 255))
    out = base.copy()
    if p < 0.8:
        for _ in range(5):
            y0 = rnd.randint(0, h - 24)
            hh = rnd.randint(8, 26)
            dx = rnd.randint(-40, 40)
            out.paste(Image.new("RGBA", (w, hh), (0, 0, 0, 0)), (0, y0))
            out.alpha_composite(base.crop((0, y0, w, y0 + hh)), (dx, y0)) if abs(dx) < w else None
    return out


# ---------- orbit carousel ----------
def fx_orbit(lib, text, p):
    paths = [x.strip() for x in (text or "").split("|") if x.strip()][:8]
    n = max(len(paths), 6)
    W_, H_ = 1000, 900
    img = Image.new("RGBA", (W_, H_), (0, 0, 0, 0))
    pics = []
    palette = [lib.look["accent"]["bg"], lib.look["highlight"]["bg"], lib.look["hook"]["bg"]]
    for i in range(n):
        try:
            pic = Image.open(paths[i]).convert("RGBA") if i < len(paths) else None
        except Exception:
            pic = None
        card = Image.new("RGBA", (260, 360), (0, 0, 0, 0))
        d = ImageDraw.Draw(card)
        d.rounded_rectangle((0, 0, 259, 359), radius=22, fill=(255, 255, 255, 255))
        if pic is not None:
            r = max(232 / pic.width, 332 / pic.height)
            pic = pic.resize((int(pic.width * r) + 1, int(pic.height * r) + 1), Image.LANCZOS)
            card.paste(pic.crop(((pic.width - 232) // 2, (pic.height - 332) // 2, (pic.width + 232) // 2, (pic.height + 332) // 2)), (14, 14))
        else:
            d.rounded_rectangle((14, 14, 246, 346), radius=14, fill=lib.rgb(palette[i % 3]))
        pics.append(card)
    grow = ease_out(clip01(p / 0.2))
    spin = 2 * math.pi * 0.8 * ease_out(clip01(p / 0.95))
    cx, cy, rx, ry = W_ / 2, H_ / 2 + 30, 380 * grow, 190 * grow
    items = []
    for i in range(n):
        th = 2 * math.pi * i / n + spin
        z = math.cos(th)
        items.append((z, i, th))
    for z, i, th in sorted(items):
        k = (z + 1) / 2
        sc = (0.55 + 0.5 * k) * (0.4 + 0.6 * grow)
        c = pics[i].resize((max(1, int(260 * sc)), max(1, int(360 * sc))), Image.LANCZOS)
        a = int(255 * (0.55 + 0.45 * k))
        c.putalpha(c.getchannel("A").point(lambda v: v * a // 255))
        x = cx + rx * math.sin(th) - c.width / 2
        y = cy + ry * z - c.height / 2
        img.alpha_composite(c, (int(x), int(y)))
    return img


EFFECTS = {
    "typing":    {"label": "Typing bar",      "default": "how to plan a month of posts", "size": (924, 154), "seconds": 3.6, "fn": fx_typing,
                  "about": "A search bar types out a question, letter by letter."},
    "popup":     {"label": "Comment popup",   "default": "ENGINE", "size": (844, 204), "seconds": 3.0, "fn": fx_popup,
                  "about": "Looks like a new comment or message sliding in."},
    "count":     {"label": "Counting number", "default": "$486|made this month", "size": (540, 354), "seconds": 3.0, "fn": fx_count,
                  "about": "A number counts up from zero. Type it like $486|label."},
    "calendar":  {"label": "Calendar fills",  "default": "30 days planned", "size": (668, 484), "seconds": 3.4, "fn": fx_calendar,
                  "about": "A month grid fills in with check marks."},
    "arrow":     {"label": "Hand-drawn arrow", "default": "look here", "size": (460, 560), "seconds": 2.6, "fn": fx_arrow,
                  "about": "A wobbly hand-drawn arrow with a little note."},
    "sticky":    {"label": "Sticky note",     "default": "nothing left to figure out", "size": (580, 530), "seconds": 3.2, "fn": fx_sticky,
                  "about": "A handwritten sticky note drops in."},
    "checklist": {"label": "Checklist",       "default": "Pick topics|Write scripts|Film in the gaps", "size": (804, 276), "seconds": 3.8, "fn": fx_checklist,
                  "about": "Items tick off one at a time. Separate them with |."},
    "chat":      {"label": "Text messages",   "default": "can I ask you something?|yes! what's up?|how do I plan a month?", "size": (884, 490), "seconds": 4.2, "fn": fx_chat,
                  "about": "Chat bubbles appear one by one. Separate messages with |."},
    "progress":  {"label": "Progress bar",    "default": "Month planned", "size": (904, 284), "seconds": 3.2, "fn": fx_progress,
                  "about": "A bar fills up to 100 percent."},
    "beforeafter": {"label": "Before and after", "default": "3 hours|20 minutes", "size": (804, 610), "seconds": 3.6, "fn": fx_beforeafter,
                  "about": "Two cards: before, then after. Type it like 3 hours|20 minutes."},
    "tag":       {"label": "Tag sticker",     "default": "NEW", "size": (600, 260), "seconds": 2.4, "fn": fx_tag,
                  "about": "A bold tilted sticker, like NEW, TIP or FREE."},
    "underline": {"label": "Underlined word", "default": "the key", "size": (960, 330), "seconds": 2.8, "fn": fx_underline,
                  "about": "A big word with a hand-drawn underline."},
    "scriptheadline": {"label": "Script and serif headline", "default": "It's like Canva,|but for business owners who need content", "size": (1000, 620), "seconds": 4.0, "fn": fx_scriptheadline, "scale": 1.0, "place": "center",
                  "about": "A flowing script line over a tight, bold serif headline. Separate with |."},
    "stack3":    {"label": "Three-tier callout", "default": "I haven't been camera ready since I had kids|so I gave ChatGPT one selfie and my pinterest board|here's what it gave me back", "size": (1000, 760), "seconds": 4.4, "fn": fx_stack3, "scale": 1.0, "place": "center",
                  "about": "A big headline, then a dark box, then a small white pill. Separate with |."},
    "serifbig":  {"label": "Giant serif headline", "default": "Let me deinfluence you for a second|That's still very much trying to get her life together", "size": (1040, 900), "seconds": 4.2, "fn": fx_serifbig, "scale": 1.0, "place": "center",
                  "about": "Huge, tight serif words with a small line under. Separate with |."},
    "screenshot": {"label": "Picture card", "default": "", "size": (1060, 760), "seconds": 4.0, "fn": fx_screenshot, "scale": 1.0, "place": "lower", "upload": True,
                  "about": "Your own screenshot or photo, in a framed card. Choose a file when you add it."},
    "emojirow":  {"label": "Emoji row", "default": "\U0001F92F", "size": (936, 152), "seconds": 3.0, "fn": fx_emojirow, "scale": 1.0, "place": "lower",
                  "about": "A row of one emoji appearing across the screen."},
    "reply":     {"label": "Reply bubble", "default": "The rumors are true!! I signed up", "size": (800, 480), "seconds": 3.4, "fn": fx_reply, "scale": 1.0, "place": "left",
                  "about": "A viewer-reply bubble with a little profile picture."},
    "paper":     {"label": "Paper note", "default": "good design was never about looking pretty. it's about the people using it", "size": (980, 520), "seconds": 4.0, "fn": fx_paper, "scale": 1.0, "place": "lower",
                  "about": "A taped, torn paper note with handwriting."},
    "handwritten": {"label": "Handwritten title", "default": "10 years in design has taught me...", "size": (1000, 330), "seconds": 3.4, "fn": fx_handwritten, "scale": 1.0, "place": "top",
                  "about": "Marker-style handwriting that writes itself on."},
    "notifpile": {"label": "Comment pile", "default": "Series|I need this!|how do I get it?|signed up!|so good|more please", "size": (1040, 980), "seconds": 4.0, "fn": fx_notifpile, "scale": 0.95, "place": "center",
                  "about": "Lots of little comment cards pop up, like people replying. Separate with |."},
    "phone":     {"label": "Phone screen", "default": "", "size": (640, 1100), "seconds": 4.0, "fn": fx_phone, "scale": 0.85, "place": "center", "upload": True,
                  "about": "Your screenshot or screen recording frame inside a phone."},
    "collage":   {"label": "Picture collage", "default": "", "size": (1000, 760), "seconds": 3.6, "fn": fx_collage, "scale": 1.0, "place": "top", "upload": "multi",
                  "about": "A scrapbook cluster of your pictures. Choose up to six files."},
    "stars":     {"label": "Star rating", "default": "LOVED BY BUSY MOMS", "size": (824, 324), "seconds": 3.0, "fn": fx_stars, "scale": 1.15, "place": "center",
                  "about": "Five stars fill in with a little line under."},
    "likes":     {"label": "Likes counter", "default": "1,284 likes", "size": (680, 234), "seconds": 3.0, "fn": fx_likes, "scale": 1.3,
                  "about": "A heart with a number that counts up."},
    "timer":     {"label": "Timer ring", "default": "20 MIN", "size": (544, 544), "seconds": 3.2, "fn": fx_timer, "scale": 1.1,
                  "about": "A ring fills up around a time, like 20 MIN."},
    "quote":     {"label": "Quote card", "default": "This changed how I show up online.|a happy customer", "size": (964, 720), "seconds": 4.2, "fn": fx_quote, "scale": 1.0, "place": "center",
                  "about": "A cream quote card with big quotation marks. Add a name after |."},
    "receipt":   {"label": "Receipt", "default": "Guide $27|Bonus $0|TOTAL $27", "size": (660, 480), "seconds": 3.6, "fn": fx_receipt, "scale": 1.2,
                  "about": "A little receipt that prints line by line."},
    "marker":    {"label": "Highlighter words", "default": "the part that matters", "size": (1000, 260), "seconds": 2.8, "fn": fx_marker, "scale": 1.0, "place": "center",
                  "about": "Big words with a highlighter swiped behind them."},
    "lowerthird": {"label": "Name and title", "default": "Rachel|Content coach", "size": (760, 230), "seconds": 3.4, "fn": fx_lowerthird, "scale": 1.0, "place": "lower",
                  "about": "A name bar slides in with a title under it, like on TV. Type it like Name|Title."},
    "shimmer":   {"label": "Shimmer sweep", "default": "THE PART THAT MATTERS", "size": (960, 300), "seconds": 2.8, "fn": fx_shimmer, "scale": 1.0, "place": "center",
                  "about": "Big words with a shine that sweeps across them."},
    "chart":     {"label": "Bar chart", "default": "Week 1 12|Week 2 28|Week 3 55|Week 4 90", "size": (884, 644), "seconds": 3.6, "fn": fx_chart, "scale": 1.0, "place": "center",
                  "about": "Bars grow up to their numbers. Type it like Week 1 12|Week 2 28|Week 3 55."},
    "slam":      {"label": "Slam words", "default": "THIS|CHANGES|EVERYTHING", "size": (960, 600), "seconds": 2.8, "fn": fx_slam, "scale": 0.8, "place": "lower",
                  "about": "Big words slam onto the screen one at a time and shake. Separate with |."},
    "glitch":    {"label": "Glitch text", "default": "SYSTEM ERROR", "size": (1000, 330), "seconds": 2.2, "fn": fx_glitch, "scale": 1.0, "place": "center",
                  "about": "Words flicker with a red and blue split and jumpy slices."},
    "orbit":     {"label": "Orbit carousel", "default": "", "size": (1000, 900), "seconds": 4.2, "fn": fx_orbit, "scale": 0.8, "place": "lower", "upload": "multi",
                  "about": "Your pictures spin around in a ring. Choose up to eight files."},
    "stamp":     {"label": "Stamp",           "default": "DONE", "size": (700, 330), "seconds": 2.0, "fn": fx_stamp,
                  "about": "A big stamp lands on screen."},
}
