#!/usr/bin/env python3
"""Add, change and remove HER OWN carousel looks ("learn this carousel look").

She drops screenshots of a carousel she loves (the Add a look tile on the Carousels tab saves them in the inbox, named carousel-look-...).
Claude looks at them, says in plain words what it sees, and fills in the choices below. This tool draws a preview, then saves the look.

  python3 learn_look.py choices                              what can be chosen (colors, lettering, picture shape...)
  python3 learn_look.py preview --params '{"head_font":"Anton",...}'     draws 3 sample slides: customer/looks/.preview/slide-01..03.png
  python3 learn_look.py add --name "My look" --params '{...}' [--refs a.png b.png]    saves it as her next look (9, 10, ...) and draws its preview
  python3 learn_look.py edit ID --set key=value [key=value ...] [--name "New name"]
  python3 learn_look.py remove ID
  python3 learn_look.py list

Every look is original drawing; the screenshots are only used to choose settings (never copied). Prints one JSON line.
"""
import json, os, re, shutil, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
ROOT = os.path.dirname(os.path.dirname(HERE))
PROF = os.path.join(ROOT, "customer", "profile")
LOOKS = os.path.join(PROF, "looks")
STATE = os.path.join(PROF, "carousel-looks.json")


def out(o, ok=True):
    print(json.dumps(o))
    sys.exit(0 if ok else 1)


def load_state():
    try:
        d = json.load(open(STATE, encoding="utf-8"))
    except Exception:
        d = {}
    for k, v in (("favorites", []), ("use", None), ("mine", []), ("names", {}), ("hidden", [])):
        d.setdefault(k, v)
    return d


def save_state(d):
    os.makedirs(PROF, exist_ok=True)
    json.dump(d, open(STATE, "w", encoding="utf-8"), indent=2)


def parse_params(s):
    import carousel_templates as ct
    try:
        raw = json.loads(s) if s else {}
    except Exception:
        out({"error": "The settings were not valid JSON."}, False)
    return ct.custom_clean(raw), raw


def draw(ident, name, params, dest):
    """Draws a cover, a middle slide and the ask in this look with her words (or sample words) into dest."""
    import make_looks as ml
    os.makedirs(LOOKS, exist_ok=True)
    lp = os.path.join(LOOKS, f"look-{ident}.json")
    existed = os.path.exists(lp)
    json.dump({"name": name, "params": params}, open(lp, "w", encoding="utf-8"))
    try:
        ph = os.path.join(ROOT, "customer", "looks", ".work")
        os.makedirs(ph, exist_ok=True)
        photo = os.path.join(ph, "placeholder.jpg")
        ml.placeholder(photo)
        base = ml.specs(photo, "")[1]       # the same three slides as built-in look 1, in her words when she has a carousel
        slides = []
        for s in base:
            s = dict(s)
            s["template"] = f"custom:{ident}"
            for k in ("note", "stamp", "label_a", "label_b", "pov"):
                s.pop(k, None)
            if s.get("kind") == "cover":
                s["kind"] = "cover"
            slides.append(s)
        handle = ml.HER.get("handle") or ""
        spec = {"title": "preview", "handle": handle or "@yourhandle", "look": "brand" if len(ml.brand_colors()) >= 2 else "1", "slides": slides}
        sp = os.path.join(ph, f"custom-{ident}.json")
        json.dump(spec, open(sp, "w"))
        tmp = os.path.join(ph, f"custom-out-{ident}")
        shutil.rmtree(tmp, ignore_errors=True)
        r = subprocess.run([sys.executable, "-X", "utf8", "-I", os.path.join(HERE, "make_carousel.py"), sp, tmp], capture_output=True, text=True, encoding="utf-8", errors="replace", cwd=ROOT)
        if not os.path.exists(os.path.join(tmp, "slide-01.png")):
            out({"error": "It did not draw: " + (r.stderr or r.stdout)[-200:]}, False)
        shutil.rmtree(dest, ignore_errors=True)
        os.makedirs(dest)
        for f in sorted(os.listdir(tmp)):
            if re.match(r"slide-0[1-3]\.png$", f):
                shutil.copy(os.path.join(tmp, f), os.path.join(dest, f))
        shutil.rmtree(tmp, ignore_errors=True)
    finally:
        if not existed and ident == "preview":
            try:
                os.remove(lp)
            except OSError:
                pass


def main():
    a = sys.argv[1:]
    if not a:
        out({"error": "Say what to do: choices, preview, add, edit, remove or list."}, False)
    cmd = a[0]
    import carousel_templates as ct
    if cmd == "choices":
        out({"choices": ct.CUSTOM_CHOICES, "head_fonts": ct.CUSTOM_FONTS, "body_fonts": ct.CUSTOM_BODY_FONTS, "defaults": ct.CUSTOM_DEFAULT,
             "colors": "bg_color, ink and accent are #RRGGBB hex or null (null = her brand colors)", "head_size": "0.7 to 1.3", "veil": "0.2 to 0.8 (how dark a full photo is)"})
    st = load_state()
    if cmd == "list":
        out({"looks": [m for m in st["mine"] if m.get("custom")]})
    if cmd == "preview":
        p, _ = parse_params(a[a.index("--params") + 1] if "--params" in a else "{}")
        dest = os.path.join(ROOT, "customer", "looks", ".preview")
        draw("preview", "preview", p, dest)
        out({"ok": True, "folder": os.path.relpath(dest, ROOT).replace(os.sep, "/"), "settings": p})
    if cmd == "add":
        name = a[a.index("--name") + 1] if "--name" in a else "My look"
        p, _ = parse_params(a[a.index("--params") + 1] if "--params" in a else "{}")
        ids = [m.get("id") for m in st["mine"] if isinstance(m.get("id"), int)] + [8]
        ident = max(ids) + 1
        refs = []
        if "--refs" in a:
            rd = os.path.join(LOOKS, "refs", f"look-{ident}")
            os.makedirs(rd, exist_ok=True)
            for f in a[a.index("--refs") + 1:]:
                if f.startswith("--"):
                    break
                if os.path.exists(f):
                    shutil.copy(f, rd)
                    refs.append(os.path.basename(f))
        draw(ident, name, p, os.path.join(ROOT, "customer", "looks", f"look-{ident}"))
        json.dump({"name": name, "params": p, "refs": refs}, open(os.path.join(LOOKS, f"look-{ident}.json"), "w"), indent=1)
        st["mine"].append({"id": ident, "name": name, "base": 1, "custom": True})
        save_state(st)
        out({"ok": True, "id": ident, "name": name, "settings": p})
    if cmd in ("edit", "remove"):
        try:
            ident = int(a[1])
        except Exception:
            out({"error": "Which look number?"}, False)
        m = next((x for x in st["mine"] if x.get("id") == ident and x.get("custom")), None)
        if not m:
            out({"error": "That is not one of your own looks."}, False)
        lp = os.path.join(LOOKS, f"look-{ident}.json")
        if cmd == "remove":
            st["mine"] = [x for x in st["mine"] if x is not m]
            st["favorites"] = [f for f in st["favorites"] if f != ident]
            if st.get("use") == ident:
                st["use"] = None
            save_state(st)
            for pth in (lp, os.path.join(ROOT, "customer", "looks", f"look-{ident}")):
                if os.path.isdir(pth):
                    shutil.rmtree(pth, ignore_errors=True)
                elif os.path.exists(pth):
                    os.remove(pth)
            out({"ok": True})
        cur = json.load(open(lp, encoding="utf-8"))
        params = dict(cur.get("params") or {})
        if "--set" in a:
            for kv in a[a.index("--set") + 1:]:
                if kv.startswith("--"):
                    break
                if "=" in kv:
                    k, v = kv.split("=", 1)
                    params[k] = None if v.lower() in ("null", "none", "") and k in ("bg_color", "ink", "accent") else v
        name = a[a.index("--name") + 1] if "--name" in a else cur.get("name")
        params, _ = parse_params(json.dumps(params))
        draw(ident, name, params, os.path.join(ROOT, "customer", "looks", f"look-{ident}"))
        json.dump({"name": name, "params": params, "refs": cur.get("refs", [])}, open(lp, "w"), indent=1)
        m["name"] = name
        save_state(st)
        out({"ok": True, "id": ident, "name": name, "settings": params})
    out({"error": "I do not know that command."}, False)


if __name__ == "__main__":
    main()
