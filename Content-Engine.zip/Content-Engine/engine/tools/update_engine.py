"""Update the engine without touching customer data.
  python3 engine/tools/update_engine.py            update from the address in engine/UPDATE_URL (what "update" does)
  python3 engine/tools/update_engine.py --check    only say whether a newer version exists
  python3 engine/tools/update_engine.py PATH       update from a folder she already downloaded (the manual way)
Only engine/ and CLAUDE.md are replaced. customer/ and inbox/ are never touched.
The old engine is kept as engine-old-DATE so she can go back.
"""
import datetime, hashlib, json, os, shutil, sys, tempfile, urllib.request, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))


def current_version():
    p = os.path.join(ROOT, "engine", "VERSION")
    return open(p, encoding="utf-8").read().strip() if os.path.exists(p) else "unknown"


def update_url():
    p = os.path.join(ROOT, "engine", "UPDATE_URL")
    if os.path.exists(p):
        for ln in open(p, encoding="utf-8"):
            ln = ln.strip()
            if ln and not ln.startswith("#"):
                return ln.rstrip("/") + "/"
    return ""


def fetch(url, dest=None):
    req = urllib.request.Request(url, headers={"User-Agent": "ContentEngine-Updater/1.0"})
    with urllib.request.urlopen(req, timeout=60) as r:
        if dest is None:
            return r.read()
        with open(dest, "wb") as f:
            shutil.copyfileobj(r, f)


def apply_from(new):
    if not os.path.isdir(os.path.join(new, "engine")) or not os.path.exists(os.path.join(new, "CLAUDE.md")):
        sys.exit("That does not look like the product folder (no engine/ or CLAUDE.md). Nothing was changed.")
    stamp = datetime.date.today().isoformat()
    old = os.path.join(ROOT, "engine-old-" + stamp)
    n = 1
    while os.path.exists(old):
        n += 1
        old = os.path.join(ROOT, "engine-old-%s-%d" % (stamp, n))
    os.rename(os.path.join(ROOT, "engine"), old)
    try:
        shutil.copytree(os.path.join(new, "engine"), os.path.join(ROOT, "engine"))
        shutil.copy2(os.path.join(new, "CLAUDE.md"), os.path.join(ROOT, "CLAUDE.md"))
    except Exception as e:
        # put the old engine back so she is never left without one
        shutil.rmtree(os.path.join(ROOT, "engine"), ignore_errors=True)
        os.rename(old, os.path.join(ROOT, "engine"))
        sys.exit("The update did not finish, so I put your old engine back. Nothing was lost. (%s)" % str(e)[:120])
    return old


def auto(check_only=False):
    base = update_url()
    if not base:
        sys.exit("Updates are not turned on in this copy yet. If you have a new download, tell Claude where you unzipped it.")
    try:
        info = json.loads(fetch(base + "latest.json").decode("utf-8"))
    except Exception:
        sys.exit("I could not reach the update just now. Check your internet and try again.")
    mine, theirs = current_version(), str(info.get("version", "")).strip()
    if not theirs:
        sys.exit("The update information looked wrong, so I did nothing.")
    if theirs == mine:
        print("You are up to date (version %s)." % mine)
        return
    print("A newer version is ready: %s (you have %s)." % (theirs, mine))
    if info.get("notes"):
        print("What is new: " + info["notes"])
    if check_only:
        return
    tmp = tempfile.mkdtemp(prefix="ce-update-")
    try:
        z = os.path.join(tmp, "new.zip")
        fetch(base + info.get("zip", "Content-Engine.zip"), z)
        want = info.get("sha256")
        if want:
            h = hashlib.sha256(open(z, "rb").read()).hexdigest()
            if h != want:
                sys.exit("The download did not match what it should be, so I did nothing. Try again in a minute.")
        with zipfile.ZipFile(z) as zf:
            zf.extractall(os.path.join(tmp, "x"))
        top = [d for d in os.listdir(os.path.join(tmp, "x")) if not d.startswith(".")]
        new = os.path.join(tmp, "x", top[0]) if len(top) == 1 else os.path.join(tmp, "x")
        old = apply_from(new)
        print("Updated to version %s. Your customer/ folder was not touched." % current_version())
        print("Your old engine is saved as " + os.path.basename(old) + " in case anything looks wrong.")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    a = sys.argv[1:]
    if not a:
        return auto(False)
    if a[0] == "--check":
        return auto(True)
    new = os.path.abspath(a[0])
    if os.path.realpath(new) == os.path.realpath(ROOT):
        sys.exit("That is this same folder. Give the NEW downloaded folder.")
    old = apply_from(new)
    print("Updated. Your customer/ folder was not touched.")
    print("Your old engine is saved as " + os.path.basename(old) + ".")


if __name__ == "__main__":
    main()
