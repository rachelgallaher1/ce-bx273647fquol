"""Make a weekly Sunday reminder she can add to her phone calendar.
Usage:  python3 engine/tools/make_reminder.py [HOUR_24]     (default 18 = 6pm her time)
Writes customer/plans/weekly-refresh.ics. Opening that file adds a repeating Sunday event
to Apple Calendar (and Google Calendar by import), which shows up on her phone.
"""
import datetime, os, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
hour = int(sys.argv[1]) if len(sys.argv) > 1 else 18
today = datetime.date.today()
sunday = today + datetime.timedelta(days=(6 - today.weekday()) % 7)
start = datetime.datetime.combine(sunday, datetime.time(hour, 0))
end = start + datetime.timedelta(minutes=20)
f = "%Y%m%dT%H%M%S"
ics = "\r\n".join([
    "BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Content Engine//Weekly refresh//EN",
    "BEGIN:VEVENT", "UID:content-engine-weekly-refresh@local",
    "DTSTAMP:" + datetime.datetime.now().strftime(f),
    "DTSTART:" + start.strftime(f), "DTEND:" + end.strftime(f),
    "RRULE:FREQ=WEEKLY;BYDAY=SU",
    "SUMMARY:Content Engine: weekly refresh",
    "DESCRIPTION:Open Claude in your Content Engine folder and say: weekly refresh. It takes about 10 minutes.",
    "BEGIN:VALARM", "TRIGGER:PT0M", "ACTION:DISPLAY", "DESCRIPTION:Weekly refresh", "END:VALARM",
    "END:VEVENT", "END:VCALENDAR", ""])
out = os.path.join(ROOT, "customer", "plans", "weekly-refresh.ics")
os.makedirs(os.path.dirname(out), exist_ok=True)
open(out, "w", newline="", encoding="utf-8").write(ics)
print(out)
