#!/usr/bin/env python3
"""Trial reels: real re-edits of a finished reel, so she can test which version Instagram's audience likes best.
  python trial_reels.py NAME [--folder customer/videos/edited] [--variants FILE.json] [--dry-run]
Uses the newest edit of NAME as the starting point (same cuts, graphics and look). Each variant changes only a few things.
Default variants (when she gives none): karaoke captions; a calm version (no zoom, no sounds, plain caption lines); and, when the
script lists hooks to test, one version per alternate hook. Variants file: [{"label": "question hook", "hook": "TEXT", "captions": "karaoke|pop|lines",
"options": {"zoom": false, "sound": false, "grain": true}}].
Writes trials/NAME_trial-<label>.mp4 and trials/NAME_trials.md (what changed in each). Her main edit is never touched.
"""
import glob, json, os, re, shutil, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import build_times

ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:28] or "v"


def script_hooks(path):
    """Hooks marked TEST in a script file's 'Ten hooks' list."""
    if not path or not os.path.exists(path):
        return []
    out = []
    for ln in open(path, encoding="utf-8").read().splitlines():
        m = re.match(r"^\s*\d+\.\s*(.+?)\s+TEST\s*$", ln)
        if m:
            out.append(m.group(1).strip())
    return out


def main():
    a = sys.argv[1:]
    if not a:
        sys.exit(__doc__)
    name = a[0]
    folder = os.path.abspath(a[a.index("--folder") + 1]) if "--folder" in a else os.path.join(ROOT, "customer", "videos", "edited")
    plans = sorted(glob.glob(os.path.join(folder, f"{name}_edit*.plan.json")), key=lambda p: int(re.search(r"_edit(\d+)\.plan", p).group(1)))
    if not plans:
        sys.exit("I can't find an edit of %s yet. Build it first." % name)
    plan = json.load(open(plans[-1], encoding="utf-8"))
    base = plan.get("decisions") or {}
    src = plan["source"]
    if "--variants" in a:
        variants = json.load(open(a[a.index("--variants") + 1], encoding="utf-8"))
    else:
        variants = [{"label": "karaoke captions", "captions": "karaoke"},
                    {"label": "calm", "captions": "lines", "options": {"zoom": False, "sound": False}}]
        for h in script_hooks(plan.get("script"))[:2]:
            variants.append({"label": "hook " + slug(h)[:16], "hook": h.upper()})
    est = build_times.estimate_seconds(folder, plan.get("original_seconds") or 30) * len(variants)
    print("Making %d trial versions. About %.0f minutes in all." % (len(variants), max(1, round(est / 60))))
    if "--dry-run" in a:
        for v in variants:
            print(" -", v["label"], {k: v[k] for k in v if k != "label"})
        return
    tdir = os.path.join(folder, "trials")
    os.makedirs(tdir, exist_ok=True)
    py = sys.executable
    notes = []
    for i, v in enumerate(variants):
        d = json.loads(json.dumps(base))
        if v.get("hook"):
            d["hook"] = v["hook"]
        d.setdefault("options", {}).update(v.get("options") or {})
        grain = bool((v.get("options") or {}).get("grain"))
        dpath = os.path.join(tdir, f"_{name}_trial_{i}.json")
        json.dump(d, open(dpath, "w", encoding="utf-8"))
        ver = 90 + i
        cmd = [py, "-X", "utf8", "-I", os.path.join(HERE, "first_edit.py"), src, "--decisions", dpath, "--version", str(ver), "--captions", v.get("captions", "pop"),
               "--no-sheet", "--out", tdir] + (["--grain"] if grain else [])
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        built = os.path.join(tdir, f"{name}_edit{ver}.mp4")
        if not os.path.exists(built):
            notes.append(f"- {v['label']}: did not build ({(r.stdout + r.stderr).strip().splitlines()[-1:] or ['unknown error']})")
            continue
        final = os.path.join(tdir, f"{name}_trial-{slug(v['label'])}.mp4")
        shutil.move(built, final)
        for junk in glob.glob(os.path.join(tdir, f"{name}_edit{ver}.*")) + [dpath]:
            try: os.remove(junk)
            except Exception: pass
        changed = ", ".join(f"{k}: {v[k]}" for k in v if k != "label")
        notes.append(f"- **{v['label']}** ({os.path.basename(final)}): {changed}")
        print("Made", os.path.basename(final))
    md = os.path.join(tdir, f"{name}_trials.md")
    open(md, "w", encoding="utf-8").write(
        f"# Trial reels for {name}\n\nSame words and cuts as your finished reel. Only the things below changed.\n\n" + "\n".join(notes) +
        "\n\n## How to test\nPost each one as its own trial reel (Instagram has a trial reel option when you share a reel, check it in the app) and wait a few days. "
        "Then tell Claude \"I posted it\" for each, with the numbers, so the engine can learn which version your people liked.\n")
    print("Notes:", md)


main()
