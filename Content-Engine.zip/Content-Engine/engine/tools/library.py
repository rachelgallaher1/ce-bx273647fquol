#!/usr/bin/env python3
"""Video library: one list of every video she has recorded, what it is, which script it belongs to, and where it is in the process.
  python library.py scan                       find new recordings in customer/videos/recorded/ and add them
  python library.py label FILE --title "..." [--script customer/scripts/x.md] [--plan-row 5] [--note "..."]
  python library.py status FILE posted|edited|new [--posted 2026-10-17]
  python library.py list                       writes customer/videos/library.md (a readable table) and prints it
Her original recordings are never renamed, moved or deleted. Labels live in customer/videos/library.json.
"""
import argparse, datetime, json, os, re, subprocess, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
VID = os.path.join(ROOT, "customer", "videos")
REC = os.path.join(VID, "recorded")
EDT = os.path.join(VID, "edited")
DB = os.path.join(VID, "library.json")
EXT = (".mov", ".mp4", ".m4v", ".mkv", ".avi", ".webm")


def load():
    return json.load(open(DB, encoding="utf-8")) if os.path.exists(DB) else {}


def save(d):
    os.makedirs(VID, exist_ok=True)
    json.dump(d, open(DB, "w", encoding="utf-8"), indent=1)


def duration(p):
    try:
        r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p], capture_output=True, text=True, encoding="utf-8", errors="replace")
        return round(float(r.stdout.strip()))
    except Exception:
        return None


def edits_for(stem):
    out = []
    if os.path.isdir(EDT):
        for f in sorted(os.listdir(EDT)):
            if f.startswith(stem + "_edit") and f.endswith(".mp4"):
                out.append(f)
    return out


def scan():
    d = load()
    new = []
    if os.path.isdir(REC):
        for f in sorted(os.listdir(REC)):
            if f.lower().endswith(EXT) and f not in d:
                p = os.path.join(REC, f)
                d[f] = {"recorded": datetime.date.fromtimestamp(os.path.getmtime(p)).isoformat(), "seconds": duration(p),
                        "title": "", "script": "", "plan_row": "", "status": "new", "note": ""}
                new.append(f)
    for f, v in d.items():
        stem = os.path.splitext(f)[0]
        e = edits_for(stem)
        if e and v["status"] in ("new", "edited"):
            v["status"] = "edited"
        v["edits"] = e
    save(d)
    return new


def write_md(d):
    lines = ["# My videos", "", "Every recording, what it is, and where it is. Originals are never renamed or moved.", "",
             "| File | Recorded | Length | What it is | Script | Status | Newest edit |", "|---|---|---|---|---|---|---|"]
    for f, v in sorted(d.items(), key=lambda kv: kv[1]["recorded"], reverse=True):
        sec = v.get("seconds")
        ln = f"{sec // 60}:{sec % 60:02d}" if sec else ""
        sc = os.path.basename(v["script"]) if v.get("script") else ""
        e = v.get("edits", [])
        lines.append(f"| {f} | {v['recorded']} | {ln} | {v.get('title', '')} | {sc} | {v['status']} | {e[-1] if e else ''} |")
    open(os.path.join(VID, "library.md"), "w", encoding="utf-8").write("\n".join(lines) + "\n")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("scan")
    sub.add_parser("list")
    l = sub.add_parser("label")
    l.add_argument("file")
    for k in ("title", "script", "plan_row", "note"):
        l.add_argument("--" + k.replace("_", "-"))
    s = sub.add_parser("status")
    s.add_argument("file")
    s.add_argument("state")
    s.add_argument("--posted")
    a = ap.parse_args()
    if a.cmd == "scan":
        new = scan()
        print("NEW: " + ", ".join(new) if new else "No new recordings.")
        print(write_md(load()))
        return
    d = load()
    if a.cmd == "label":
        f = os.path.basename(a.file)
        if f not in d:
            sys.exit("I don't have that file yet. Run scan first.")
        for k in ("title", "script", "plan_row", "note"):
            v = getattr(a, k.replace("_", "-").replace("-", "_"), None) if False else getattr(a, k, None)
        for k, v in (("title", a.title), ("script", a.script), ("plan_row", getattr(a, "plan_row", None)), ("note", a.note)):
            if v:
                d[f][k] = v
        save(d)
    elif a.cmd == "status":
        f = os.path.basename(a.file)
        if f not in d:
            sys.exit("I don't have that file yet. Run scan first.")
        d[f]["status"] = a.state
        if a.posted:
            d[f]["posted"] = a.posted
        save(d)
    print(write_md(load()))


main()
