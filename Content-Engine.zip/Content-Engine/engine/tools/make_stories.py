#!/usr/bin/env python3
"""Story maker: turns story frames (words only) into finished 1080 x 1920 Instagram story pictures, in her look.
  python make_stories.py stories.json
  python make_stories.py --from-script customer/scripts/<script>.md   (reads the script's "Stories" section and makes stories.json next to it)

stories.json: {"title": "stories", "look": "11", "video": "optional video for photo frames", "handle": "@name",
  "frames": [ {"type": "text", "text": "...", "hi": "word"}, {"type": "poll", "question": "...", "options": ["A", "B"]},
              {"type": "question", "text": "..."}, {"type": "countdown", "text": "..."}, {"type": "cta", "keyword": "ENGINE", "line": "..."},
              {"type": "reelshare", "text": "New video is up."}, {"type": "photo", "text": "..."}, {"type": "quote", "quote": "..."} ]}
Instagram's interactive stickers (poll, question, countdown, link, DM) can ONLY be added inside the Instagram app, so the pictures leave a clear space where each sticker goes,
and stickers.txt says exactly which sticker to add and what to type in it. story-preview.png shows those spaces (the pictures themselves stay clean).
Stories are 1080 x 1920. The top 250 px and bottom 340 px are covered by Instagram's own bars, so all words stay between them.
"""
import json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import first_edit as fe
import make_carousel as mc
from PIL import Image, ImageDraw

SW, SH = 1080, 1920
TOP, BOT = 250, SH - 340
M = 100


def parse_script_stories(md):
    """Read the '## Stories' section of a script file into story frames."""
    m = re.search(r"^## Stories[^\n]*\n(.*?)(?=^## |\Z)", md, re.S | re.M)
    if not m:
        return []
    frames = []
    for line in m.group(1).splitlines():
        t = re.sub(r"^\s*\d+\.\s*", "", line).strip()
        if not t:
            continue
        q = re.findall(r"[\"“](.+?)[\"”]", t)
        low = t.lower()
        if low.startswith("poll"):
            opts = []
            tail = t.split("\"")[-1] if "\"" in t else t
            tail = tail.replace("Options:", "").strip(" .")
            opts = [o.strip(" .") for o in re.split(r"\s*[·|/]\s*| or ", tail) if o.strip(" .")][:2]
            frames.append({"type": "poll", "question": q[0] if q else t, "options": opts or ["Yes", "No"]})
        elif "question sticker" in low:
            frames.append({"type": "question", "text": q[0] if q else t})
        elif "countdown" in low:
            frames.append({"type": "countdown", "text": q[0] if q else re.sub(r"countdown sticker.*", "", t, flags=re.I).strip(" :.,")})
        elif "dm sticker" in low:
            kw = re.findall(r"\b([A-Z]{3,})\b", t)
            frames.append({"type": "cta", "keyword": kw[-1] if kw else "ENGINE", "line": "I'll send it right to your DMs."})
        elif low.startswith("the video") or "video is up" in low or low.startswith("a screenshot") or low.startswith("screen recording"):
            frames.append({"type": "reelshare", "text": q[0] if q else "New video is up."})
        else:
            frames.append({"type": "text", "text": q[0] if q else re.sub(r"^[A-Za-z ]+:\s*", "", t)})
    return frames


def solid(look, i):
    bgc, ink, soft, accent = mc.palette(look, i)
    im = Image.new("RGBA", (SW, SH), bgc)
    return im, ImageDraw.Draw(im), bgc, ink, soft, accent


def zone(d, y0, y1, bgc, ink, label):
    """Mark the space for an Instagram sticker. Returns the box; the real picture stays clean (preview draws it)."""
    return (M, y0, SW - M, y1, label)


def big(d, look, text, y, ink, accent, hi=None, start=210, maxlines=5):
    f, lines = mc.fit_lines(d, look, text.upper(), start, SW - 2 * M, maxlines)
    hi_u = (hi or "").upper().strip(" ,.?!")
    for ln in lines:
        x = M
        for part in re.split(r"(\s+)", ln):
            pw = d.textlength(part, font=f)
            d.text((x, y), part, font=f, fill=accent[:3] + (255,) if hi_u and part.strip(" ,.?!") == hi_u else ink)
            x += pw
        y += int(f.size * 0.98)
    return y


def f_text(look, s, img, i, handle):
    im, d, bgc, ink, soft, accent = solid(look, i)
    n = len(s["text"].split())
    start = 260 if n <= 6 else 200 if n <= 12 else 140
    f, lines = mc.fit_lines(d, look, s["text"].upper(), start, SW - 2 * M, 7)
    h = len(lines) * int(f.size * 0.98)
    big(d, look, s["text"], (TOP + BOT) // 2 - h // 2, ink, accent, s.get("hi"), start, 7)
    return im, []


def f_poll(look, s, img, i, handle):
    im, d, bgc, ink, soft, accent = solid(look, i)
    y = big(d, look, s["question"], TOP + 60, ink, accent, s.get("hi"), 150, 5)
    z = zone(d, max(y + 90, 1050), 1450, bgc, ink, "POLL STICKER: " + " / ".join(s.get("options", [])))
    return im, [z]


def f_question(look, s, img, i, handle):
    im, d, bgc, ink, soft, accent = solid(look, i)
    chip = "ASK ME"
    fc = mc.fe.display_font(look, 70)
    d.rounded_rectangle((M, TOP + 40, M + d.textlength(chip, font=fc) + 70, TOP + 150), radius=24, fill=accent[:3] + (255,))
    d.text((M + 35, TOP + 52), chip, font=fc, fill=bgc[:3] + (255,))
    y = big(d, look, s["text"], TOP + 230, ink, accent, s.get("hi"), 150, 5)
    return im, [zone(d, max(y + 90, 1100), 1450, bgc, ink, "QUESTION STICKER: " + s["text"])]


def f_countdown(look, s, img, i, handle):
    im, d, bgc, ink, soft, accent = solid(look, i)
    y = big(d, look, s["text"], TOP + 120, ink, accent, s.get("hi"), 170, 4)
    return im, [zone(d, max(y + 100, 1000), 1400, bgc, ink, "COUNTDOWN STICKER: set the date and time")]


def f_cta(look, s, img, i, handle):
    im, d, bgc, ink, soft, accent = solid(look, i)
    fl = fe.display_font(look, 110)
    d.text((M, TOP + 120), "DM ME", font=fl, fill=ink)
    kw = s["keyword"].upper()
    size = 360
    fk = fe.display_font(look, size)
    while d.textlength(kw, font=fk) > SW - 2 * M - 120 and size > 100:
        size -= 12
        fk = fe.display_font(look, size)
    bb = d.textbbox((0, 0), kw, font=fk)
    bw, bh = bb[2] - bb[0] + 120, bb[3] - bb[1] + 100
    d.rounded_rectangle((M, TOP + 300, M + bw, TOP + 300 + bh), radius=44, fill=accent[:3] + (255,))
    inkon = (255, 255, 255, 255) if mc.contrast((255, 255, 255), accent[:3]) >= mc.contrast((20, 20, 22), accent[:3]) else (20, 20, 22, 255)
    d.text((M + 60 - bb[0], TOP + 300 + 50 - bb[1]), kw, font=fk, fill=inkon)
    y = TOP + 300 + bh + 70
    if s.get("line"):
        y = mc.text_block(d, M, y, s["line"], fe.load_font(look["captionFont"], 54, 700), ink, SW - 2 * M, lh=72)
    return im, [zone(d, max(y + 80, 1150), 1480, bgc, ink, "DM STICKER (or tell them to comment " + kw + ")")]


def photo_full(look, img, strong=True):
    bg = mc.photo_bg.__wrapped__(look, img) if hasattr(mc.photo_bg, "__wrapped__") else None
    im = mc.cover_crop(img, SW, SH, 0.5).convert("RGBA")
    im.alpha_composite(fe.gradient(SW, int(SH * 0.5), (8, 8, 8), 190, from_top=False), (0, SH - int(SH * 0.5)))
    im.alpha_composite(fe.gradient(SW, int(SH * 0.2), (8, 8, 8), 90, from_top=True), (0, 0))
    return im


def f_reelshare(look, s, img, i, handle):
    base = img if img is not None else Image.new("RGB", (SW, SH), mc.fe.hex2rgb(look["caption"]["bg"])[:3])
    im = photo_full(look, base)
    d = ImageDraw.Draw(im)
    chip = "NEW VIDEO"
    fc = fe.display_font(look, 70)
    d.rounded_rectangle((M, 1000, M + d.textlength(chip, font=fc) + 70, 1110), radius=24, fill=fe.hex2rgb(look["highlight"]["bg"])[:3] + (255,))
    d.text((M + 35, 1012), chip, font=fc, fill=(20, 20, 22, 255) if fe.luminance(look["highlight"]["bg"]) > 0.5 else (255, 255, 255, 255))
    f, lines = mc.fit_lines(d, look, s["text"].upper(), 140, SW - 2 * M, 2)
    y = 1135
    for ln in lines:
        d.text((M, y), ln, font=f, fill=(255, 255, 255, 255), stroke_width=6, stroke_fill=(20, 20, 22, 235))
        y += int(f.size * 0.98)
    return im, [zone(d, 1500 - 0, 1500, None, None, "LINK STICKER to the reel (optional)")][:0] or [(M, 1480, SW - M, 1580, "Add the reel with the share button, then place it here")]


def f_photo(look, s, img, i, handle):
    base = img if img is not None else Image.new("RGB", (SW, SH), mc.fe.hex2rgb(look["caption"]["bg"])[:3])
    im = photo_full(look, base)
    d = ImageDraw.Draw(im)
    f, lines = mc.fit_lines(d, look, s["text"].upper(), 160, SW - 2 * M, 4)
    y = BOT - len(lines) * int(f.size * 0.98) - 20
    for ln in lines:
        d.text((M, y), ln, font=f, fill=(255, 255, 255, 255), stroke_width=6, stroke_fill=(20, 20, 22, 235))
        y += int(f.size * 0.98)
    return im, []


def f_quote(look, s, img, i, handle):
    im, d, bgc, ink, soft, accent = solid(look, i)
    d.text((M - 6, TOP + 20), "“", font=fe.display_font(look, 380), fill=accent[:3] + (255,))
    size = 84
    while size > 46:
        fb = fe.load_font(look["captionFont"], size, 800)
        lines = mc.wrap(d, s["quote"], fb, SW - 2 * M)
        if len(lines) * int(size * 1.3) <= 900:
            break
        size -= 4
    y = TOP + 430
    for ln in lines:
        d.text((M, y), ln, font=fb, fill=ink)
        y += int(size * 1.3)
    return im, []


def f_bignumber(look, s, img, i, handle):
    im, d, bgc, ink, soft, accent = solid(look, i)
    num = str(s["number"])
    size = 560
    fn = fe.display_font(look, size)
    while d.textlength(num, font=fn) > SW - 2 * M and size > 160:
        size -= 20
        fn = fe.display_font(look, size)
    bb = d.textbbox((0, 0), num, font=fn)
    y = 520
    d.text(((SW - (bb[2] - bb[0])) / 2 - bb[0], y - bb[1]), num, font=fn, fill=accent[:3] + (255,))
    y += (bb[3] - bb[1]) + 50
    if s.get("label"):
        fl = fe.display_font(look, 110)
        lw = d.textlength(s["label"].upper(), font=fl)
        d.text(((SW - lw) / 2, y), s["label"].upper(), font=fl, fill=ink)
        y += 150
    if s.get("body"):
        mc.text_block(d, M, y, s["body"], fe.load_font(look["captionFont"], 56, 700), ink, SW - 2 * M, align="center")
    zs = [zone(d, 1200, 1480, bgc, ink, s["sticker"])] if s.get("sticker") else []
    return im, zs


def chip_frame(look, s, i, size=150, maxlines=6):
    im, d, bgc, ink, soft, accent = solid(look, i)
    chip = s.get("chip", "")
    y = TOP + 80
    if chip:
        fc = fe.display_font(look, 70)
        d.rounded_rectangle((M, y, M + d.textlength(chip, font=fc) + 70, y + 110), radius=24, fill=accent[:3] + (255,))
        inkon = (255, 255, 255, 255) if mc.contrast((255, 255, 255), accent[:3]) >= mc.contrast((20, 20, 22), accent[:3]) else (20, 20, 22, 255)
        d.text((M + 35, y + 12), chip, font=fc, fill=inkon)
        y += 190
    y = big(d, look, s["text"], y, ink, accent, s.get("hi"), size, maxlines)
    return im, d, bgc, ink, accent, y


def f_reveal(look, s, img, i, handle):
    im, d, bgc, ink, accent, y = chip_frame(look, s, i, 170, 6)
    return im, []


def f_listitem(look, s, img, i, handle):
    im, d, bgc, ink, accent, y = chip_frame(look, s, i, 150, 6)
    zs = [zone(d, max(y + 90, 1150), 1480, bgc, ink, s["sticker"])] if s.get("sticker") else []
    return im, zs


def f_link(look, s, img, i, handle):
    im, d, bgc, ink, accent, y = chip_frame(look, s, i, 150, 5)
    return im, [zone(d, max(y + 90, 1100), 1420, bgc, ink, "LINK STICKER: link to your carousel post")]


def f_coverpromo(look, s, img, i, handle):
    base = img if img is not None else Image.new("RGB", (SW, SH), mc.fe.hex2rgb(look["caption"]["bg"])[:3])
    im = photo_full(look, base)
    d = ImageDraw.Draw(im)
    hl = fe.hex2rgb(look["highlight"]["bg"])[:3]
    if mc.contrast(hl, (30, 30, 30)) < 3:
        hl = (255, 255, 255)
    fc = fe.display_font(look, 76)
    chip = "NEW POST"
    cw = d.textlength(chip, font=fc) + 70
    d.rounded_rectangle((M, TOP + 40, M + cw, TOP + 160), radius=26, fill=hl + (255,))
    d.text((M + 35, TOP + 52), chip, font=fc, fill=(20, 20, 22, 255) if fe.luminance("#%02x%02x%02x" % hl) > 0.5 else (255, 255, 255, 255))
    mc.hand_arrow(d, M + cw + 40, TOP + 150, M + cw + 150, TOP + 30, (255, 255, 255, 255), 9)
    if s.get("label"):
        fl = fe.display_font(look, 64)
        d.text((M, 1000), s["label"].upper(), font=fl, fill=(255, 255, 255, 255), stroke_width=5, stroke_fill=(20, 20, 22, 235))
    f, lines = mc.fit_lines(d, look, s["text"].upper(), 170, SW - 2 * M, 3)
    y = 1090
    for ln in lines:
        d.text((M, y), ln, font=f, fill=(255, 255, 255, 255), stroke_width=6, stroke_fill=(20, 20, 22, 235))
        y += int(f.size * 0.98)
    return im, []


def f_quiz(look, s, img, i, handle):
    im, d, bgc, ink, soft, accent = solid(look, i)
    y = big(d, look, s["question"], TOP + 60, ink, accent, s.get("hi"), 150, 5)
    opts = s.get("options", [])
    right = s.get("answer", "")
    return im, [zone(d, max(y + 90, 1050), 1500, bgc, ink, "QUIZ STICKER: " + " / ".join(opts) + (f". Mark the right answer: {right}. Wrong answers get a kind line." if right else ""))]


def f_slider(look, s, img, i, handle):
    im, d, bgc, ink, soft, accent = solid(look, i)
    y = big(d, look, s["text"], TOP + 80, ink, accent, s.get("hi"), 150, 5)
    return im, [zone(d, max(y + 100, 1150), 1380, bgc, ink, "EMOJI SLIDER: " + s.get("label", "How much do you need this?") + " (a feeling check, not data)")]


def f_addyours(look, s, img, i, handle):
    im, d, bgc, ink, soft, accent = solid(look, i)
    chip = "ADD YOURS"
    fc = mc.fe.display_font(look, 70)
    d.rounded_rectangle((M, TOP + 40, M + d.textlength(chip, font=fc) + 70, TOP + 150), radius=24, fill=accent[:3] + (255,))
    d.text((M + 35, TOP + 52), chip, font=fc, fill=bgc[:3] + (255,))
    y = big(d, look, s["text"], TOP + 230, ink, accent, s.get("hi"), 150, 4)
    return im, [zone(d, max(y + 90, 1150), 1480, bgc, ink, "ADD YOURS STICKER with this prompt: " + s["text"] + ". Post your own first.")]


def f_mailbag(look, s, img, i, handle):
    """A real question, verbatim, in a message bubble. Blur the person's name before posting."""
    im, d, bgc, ink, soft, accent = solid(look, i)
    chip = "YOU ASKED"
    fc = mc.fe.display_font(look, 70)
    d.rounded_rectangle((M, TOP + 40, M + d.textlength(chip, font=fc) + 70, TOP + 150), radius=24, fill=accent[:3] + (255,))
    d.text((M + 35, TOP + 52), chip, font=fc, fill=bgc[:3] + (255,))
    fb = fe.load_font(look["captionFont"], 56, 700)
    lines = mc.wrap(d, s["question"], fb, SW - 2 * M - 110)[:6]
    h = len(lines) * 76 + 80
    y0 = TOP + 260
    d.rounded_rectangle((M, y0, SW - M, y0 + h), radius=48, fill=(255, 255, 255))
    for k, l in enumerate(lines):
        d.text((M + 55, y0 + 40 + k * 76), l, font=fb, fill=(30, 30, 32))
    if s.get("answer"):
        big(d, look, s["answer"], y0 + h + 90, ink, accent, s.get("hi"), 110, 4)
    return im, []


def f_pollresult(look, s, img, i, handle):
    """Show a poll's answer. The percentages are what she reads off Instagram's poll results: never made up."""
    im, d, bgc, ink, soft, accent = solid(look, i)
    chip = "YOU VOTED"
    fc = mc.fe.display_font(look, 70)
    d.rounded_rectangle((M, TOP + 40, M + d.textlength(chip, font=fc) + 70, TOP + 150), radius=24, fill=accent[:3] + (255,))
    d.text((M + 35, TOP + 52), chip, font=fc, fill=bgc[:3] + (255,))
    y = big(d, look, s["question"], TOP + 220, ink, accent, s.get("hi"), 110, 4) + 60
    fb = fe.load_font(look["captionFont"], 52, 800)
    fp = fe.display_font(look, 90)
    res = s.get("results", [])[:4]
    top = max([r[1] for r in res] or [0])
    barw = SW - 2 * M
    for name, pct in res:
        d.text((M, y), str(name), font=fb, fill=ink)
        y += 70
        d.rounded_rectangle((M, y, M + barw, y + 96), radius=30, fill=mix_c(ink, bgc, 0.12))
        w = max(30, int(barw * pct / 100))
        d.rounded_rectangle((M, y, M + w, y + 96), radius=30, fill=accent[:3] + (255,) if pct == top else mix_c(ink, bgc, 0.45))
        d.text((M + barw - 20 - d.textlength(f"{pct}%", font=fp), y - 2), f"{pct}%", font=fp, fill=ink)
        y += 96 + 50
    if s.get("comment"):
        y = mc.text_block(d, M, y + 10, s["comment"], fe.load_font(look["captionFont"], 54, 700), ink, SW - 2 * M, lh=72)
    return im, []


def mix_c(a, b, t):
    a, b = tuple(a[:3]), tuple(b[:3])
    return tuple(int(a[k] * t + b[k] * (1 - t)) for k in range(3))


MAKERS = {"text": f_text, "poll": f_poll, "question": f_question, "countdown": f_countdown, "cta": f_cta,
          "reelshare": f_reelshare, "photo": f_photo, "quote": f_quote, "bignumber": f_bignumber, "reveal": f_reveal,
          "listitem": f_listitem, "link": f_link, "coverpromo": f_coverpromo,
          "pollresult": f_pollresult, "quiz": f_quiz, "slider": f_slider, "addyours": f_addyours, "mailbag": f_mailbag}


def words(t):
    return len(re.findall(r"\S+", t or ""))


def chunks(text, n=15):
    """Split text into pieces of about n words or fewer, at sentence ends where possible."""
    parts = re.split(r"(?<=[.!?])\s+", text.strip())
    out, cur = [], ""
    for p in parts:
        if cur and words(cur + " " + p) > n:
            out.append(cur)
            cur = p
        else:
            cur = (cur + " " + p).strip()
    if cur:
        out.append(cur)
    final = []
    for c in out:
        w = c.split()
        while len(w) > n:
            final.append(" ".join(w[:n]))
            w = w[n:]
        if w:
            final.append(" ".join(w))
    return final


def convert_slide(sl, kw):
    """One carousel slide becomes one or more story frames (one idea per frame, about 15 words or fewer)."""
    t = sl["type"]
    if t in ("cover", "sticker"):
        return [{"type": "photo", "text": sl.get("headline", sl.get("word", ""))}]
    if t == "negcover":
        return [{"type": "text", "text": sl["word"]}]
    if t == "bigtext":
        fr = [{"type": "text", "text": sl["headline"], "hi": sl.get("hi")}]
        extra = " ".join(sl.get("lines", []))
        for c in chunks(extra)[:2]:
            fr.append({"type": "reveal", "text": c})
        return fr
    if t == "point":
        return [{"type": "text", "text": sl["headline"]}]
    if t == "quote":
        return [{"type": "quote", "quote": " ".join(chunks(sl["quote"], 18)[:1])}]
    if t == "quiz":
        return [{"type": "poll", "question": sl["question"], "options": sl.get("options", [])[:2] or ["Yes", "No"]}]
    if t == "myth":
        return [{"type": "poll", "question": sl["myth"], "options": ["True", "False"]},
                {"type": "reveal", "chip": "FACT", "text": sl["fact"]}]
    if t == "stat":
        return [{"type": "bignumber", "number": sl["number"], "label": sl.get("label", ""), "body": sl.get("body", ""),
                 "sticker": "POLL STICKER: Did you know this? Yes / No"}]
    if t == "receipt":
        rows = sl.get("rows")
        if rows:
            return [{"type": "bignumber", "number": rows[1][1] if len(rows) > 1 else rows[0][1], "label": rows[1][0] if len(rows) > 1 else rows[0][0], "body": sl.get("headline", "")}]
        return [{"type": "text", "text": sl.get("headline", "")}]
    if t == "transform":
        fr = [{"type": "reveal", "chip": "BEFORE", "text": sl["before"]}, {"type": "reveal", "chip": "AFTER", "text": sl["after"]}]
        if sl.get("feel"):
            fr.append({"type": "reveal", "chip": "HOW IT FELT", "text": sl["feel"]})
        return fr
    if t in ("list", "recap"):
        items = sl.get("items", [])[:4]
        fr = []
        for k, it in enumerate(items):
            fr.append({"type": "listitem", "chip": f"{k + 1} OF {len(items)}", "text": it,
                       "sticker": "EMOJI SLIDER STICKER: How many do you do?" if k == 0 else None})
        return fr
    if t == "faq":
        return [{"type": "text", "text": sl["question"]}, {"type": "reveal", "chip": "ANSWER", "text": " ".join(chunks(sl["answer"])[:1])}]
    if t == "pov":
        return [{"type": "text", "text": "POV: " + sl["headline"]}]
    if t == "cta":
        return [{"type": "cta", "keyword": sl.get("keyword", kw), "line": "Reply " + sl.get("keyword", kw) + " and I'll send it to you."}]
    return []


def build_sequences(spec):
    slides = spec["slides"]
    kw = next((x.get("keyword") for x in slides if x["type"] == "cta"), "ENGINE")
    cover = slides[0]
    proof = next((x for x in slides if x["type"] in ("receipt", "transform", "stat", "recap", "list", "quote")), slides[min(2, len(slides) - 1)])
    promo = [{"type": "coverpromo", "label": cover.get("label", ""), "text": cover.get("headline", cover.get("word", ""))}]
    promo += convert_slide(proof, kw)[:1]
    promo.append({"type": "link", "text": "The full thing is on my feed."})
    adapt = []
    for sl in slides:
        adapt += convert_slide(sl, kw)
    # too long: drop the extras first (second lines of big text, then list items past the second), then the middle
    def drop(pred):
        for idx in range(len(adapt) - 2, 0, -1):
            if pred(adapt[idx]):
                adapt.pop(idx)
                return True
        return False
    while len(adapt) > 10:
        if drop(lambda f: f["type"] == "reveal" and not f.get("chip")):
            continue
        if drop(lambda f: f["type"] == "listitem" and not str(f.get("chip", "")).startswith(("1 OF", "2 OF"))):
            continue
        adapt.pop(len(adapt) // 2)
    quiz = next((x for x in slides if x["type"] == "quiz"), None)
    myth = next((x for x in slides if x["type"] == "myth"), None)
    stat = next((x for x in slides if x["type"] == "stat"), None)
    inter = []
    if quiz:
        inter += convert_slide(quiz, kw)
    elif myth:
        inter += convert_slide(myth, kw)[:1]
    elif stat:
        inter += convert_slide(stat, kw)
    else:
        inter.append({"type": "poll", "question": cover.get("headline", "Does this sound like you?"), "options": ["Yes", "Not really"]})
    inter += convert_slide(proof, kw)[:1]
    inter.append({"type": "question", "text": (quiz or {}).get("question") or "Which one are you?"})
    inter.append({"type": "link", "text": "The full breakdown is in today's carousel."})
    inter.append({"type": "cta", "keyword": kw, "line": "Reply with your answer, or reply " + kw + "."})
    return {"promo": promo, "adapt": adapt, "interactive": inter}, kw


def check_frames(name, frames, kw):
    notes = []
    for k, f in enumerate(frames, 1):
        n = words(" ".join(str(f.get(x, "")) for x in ("text", "question", "quote", "line", "number", "label", "body")))
        if n > 18:
            notes.append(f"{name} frame {k} has {n} words. About 15 or fewer is easier to read at arm's length.")
    if frames:
        first = frames[0]
        ft = " ".join(str(first.get(x, "")) for x in ("text", "question", "quote", "label"))
        if re.search(r"new (post|video|reel)", ft, re.I) and not re.search(r"\b(why|how|what|never|stop|you)\b", ft, re.I):
            notes.append(f"{name}: frame 1 says \"new post\" with no reason to care. Start with a question, a confession or a tease. The post is the news; frame 1 is the reason to look.")
        if words(ft) > 8 and first["type"] in ("text", "quote"):
            notes.append(f"{name}: frame 1 has {words(ft)} words. A hook frame is 8 words or fewer.")
        if frames[-1]["type"] not in ("cta", "link", "countdown", "poll", "question", "quiz", "addyours", "reelshare"):
            notes.append(f"{name}: the last frame should ask for one action (reply a word, tap the link, vote, see the post). A sequence that just stops teaches people to tap past you.")
    if not (3 <= len(frames) <= 7) and len(frames) not in (1,) and len(frames) < 10:
        notes.append(f"{name}: {len(frames)} frames. Three to seven is the working range.")
    for k, f in enumerate(frames, 1):
        if f["type"] == "pollresult":
            tot = sum(r[1] for r in f.get("results", []))
            if not f.get("results") or not 97 <= tot <= 103:
                notes.append(f"{name} frame {k}: poll results need the real percentages from Instagram (they should add up to about 100). I never make them up.")
        if f["type"] == "question" and re.fullmatch(r"\s*(ask me anything|ama)[.!?]*\s*", str(f.get("text", "")), re.I):
            notes.append(f"{name} frame {k}: a bare \"ask me anything\" gets few answers. Ask one specific thing.")
        if f["type"] in ("text", "listitem") and words(str(f.get("text", ""))) > 25:
            notes.append(f"{name} frame {k}: teaching frames stay at 25 words or fewer.")
        if f["type"] == "cta" and words(str(f.get("line", ""))) > 10:
            notes.append(f"{name} frame {k}: keep the call to action line to 10 words or fewer.")
        if f.get("cf") and re.search(r"(address|phone|password|live location)", json.dumps(f), re.I):
            notes.append(f"{name} frame {k}: a Close Friends frame still gets screenshotted. Take out anything private.")
    if name == "promo" and not any(f["type"] == "link" for f in frames):
        notes.append("The promo set needs a link sticker frame.")
    cta = [f for f in frames if f["type"] == "cta"]
    if cta and cta[-1].get("keyword", "").upper() != kw.upper():
        notes.append(f"{name}: the story CTA word does not match the carousel's ({kw}).")
    return notes


def motion(png, mp4, seconds=5.0):
    """A short video with a slow push in, so no story frame is dead. Instagram plays it like a picture."""
    import subprocess
    d = int(seconds * 30)
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", png, "-vf",
                    f"scale=1188:2112,zoompan=z='1+0.0007*on':x='(iw-iw/zoom)/2':y='(ih-ih/zoom)/2':d={d}:s=1080x1920:fps=30,format=yuv420p",
                    "-c:v", "libx264", "-crf", "20", "-t", str(seconds), mp4], check=True)


def render(frames, spec, out, work):
    look = fe.load_look(spec.get("look", "1"))
    video = spec.get("video")
    stills, tips, prev = [], [], []
    if video and os.path.exists(video):
        import subprocess
        dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", video], capture_output=True, text=True, encoding="utf-8", errors="replace").stdout.strip() or 60)
        stills = mc.pick_stills(video, dur, work)
    k = 0
    for i, s in enumerate(frames):
        img = None
        if s["type"] in ("reelshare", "photo", "coverpromo") and stills:
            img = mc.frame_at(video, stills[k % len(stills)], work)
            k += 1
        im, zones = MAKERS[s["type"]](look, s, img, i, spec.get("handle"))
        pic = mc.grain(im.convert("RGB"), 3 if s["type"] in ("reelshare", "photo", "coverpromo") else 6)
        png = os.path.join(out, f"slide-{i + 1:02d}.png")
        pic.save(png)
        if spec.get("motion", True):
            motion(png, os.path.join(out, f"slide-{i + 1:02d}.mp4"))
        pv = pic.convert("RGBA")
        pd = ImageDraw.Draw(pv)
        for (x0, y0, x1, y1, lab) in zones:
            pd.rounded_rectangle((x0, y0, x1, y1), radius=36, outline=(255, 255, 255, 230), width=6)
            lf = fe.load_font(look["captionFont"], 34, 700)
            lines_ = mc.wrap(pd, lab, lf, (x1 - x0) - 60)[:4]
            yy_ = (y0 + y1) / 2 - len(lines_) * 24
            for ln_ in lines_:
                pd.text(((x0 + x1) / 2, yy_), ln_, font=lf, fill=(255, 255, 255, 240), anchor="mm")
                yy_ += 48
            tips.append(f"Story {i + 1}: {lab}")
        pd.line((0, TOP, SW, TOP), fill=(255, 80, 80, 150), width=3)
        pd.line((0, BOT, SW, BOT), fill=(255, 80, 80, 150), width=3)
        prev.append(pv.convert("RGB"))
        print("made", f"slide-{i + 1:02d}", s["type"])
    cols = min(5, max(1, len(prev)))
    th = [im.resize((324, 576)) for im in prev]
    rows = (len(th) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * 344 + 20, rows * 596 + 20), (24, 24, 24))
    for k2, im in enumerate(th):
        sheet.paste(im, (20 + (k2 % cols) * 344, 20 + (k2 // cols) * 596))
    sheet.save(os.path.join(out, "story-preview.png"))
    with open(os.path.join(out, "story-sheet.md"), "w", encoding="utf-8") as sh:
        sh.write(f"# Story sheet: {spec.get('title', 'stories')}\n\nPost in order. About three minutes. Stickers are added inside Instagram.\n\n")
        for i, s_ in enumerate(frames):
            txt = " ".join(str(s_.get(x, "")) for x in ("text", "question", "quote", "line", "keyword", "number") if s_.get(x))
            mark = "[CF]" if s_.get("cf") else "[PUBLIC]"
            stk = next((t for t in tips if t.startswith(f"Story {i + 1}:")), "")
            stk = stk.split(": ", 1)[1] if stk else "no sticker"
            keep = f" · save to Highlight: {s_['save_to']}" if s_.get("save_to") else ""
            sh.write(f"[frame {i + 1}] {mark} {s_['type']} · slide-{i + 1:02d}.png · \"{txt[:90]}\" · sticker: {stk}{keep}\n")
    with open(os.path.join(out, "stickers.txt"), "w", encoding="utf-8") as f:
        f.write("How to post these stories\n\n1. Post the pictures (or the short videos with the same number) in order.\n2. On each one, add the sticker listed below in the empty space, and type what it says.\n3. Add a trending sound at low volume if you like.\n4. Keep words out of the top and bottom bars (the red lines in story-preview.png are Instagram's covered areas).\n\n")
        f.write("\n".join(tips) + ("\n" if tips else "No stickers needed on these.\n"))


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if "--from-carousel" in sys.argv:
        cp = os.path.abspath(sys.argv[sys.argv.index("--from-carousel") + 1])
        cspec = json.load(open(cp, encoding="utf-8"))
        seqs, kw = build_sequences(cspec)
        base = os.path.join(os.path.dirname(cp), "stories")
        allnotes = []
        for name, frames in seqs.items():
            out = os.path.join(base, name)
            os.makedirs(out, exist_ok=True)
            work = os.path.join(out, ".work")
            os.makedirs(work, exist_ok=True)
            spec = {"look": cspec.get("look", "1"), "video": cspec.get("video"), "handle": cspec.get("handle"), "motion": "--no-motion" not in sys.argv}
            json.dump({**spec, "title": name, "frames": frames}, open(os.path.join(base, name + ".stories.json"), "w", encoding="utf-8"), indent=1)
            render(frames, spec, out, work)
            allnotes += check_frames(name, frames, kw)
            print("Done:", out)
        open(os.path.join(base, "checks.txt"), "w", encoding="utf-8").write("\n".join(allnotes) + ("\n" if allnotes else "All checks passed.\n"))
        for n in allnotes:
            print("CHECK:", n)
        return
    if "--from-script" in sys.argv:
        sp = os.path.abspath(sys.argv[sys.argv.index("--from-script") + 1])
        frames = parse_script_stories(open(sp, encoding="utf-8").read())
        spec = {"title": "stories", "look": os.environ.get("STORY_LOOK", "1"), "frames": frames}
        for a in sys.argv:
            if a.startswith("--look="):
                spec["look"] = a.split("=", 1)[1]
            if a.startswith("--video="):
                spec["video"] = a.split("=", 1)[1]
            if a.startswith("--handle="):
                spec["handle"] = a.split("=", 1)[1]
        spec_path = os.path.splitext(sp)[0] + ".stories.json"
        json.dump(spec, open(spec_path, "w", encoding="utf-8"), indent=1)
        print("Wrote", spec_path)
    else:
        spec_path = os.path.abspath(args[0])
        spec = json.load(open(spec_path, encoding="utf-8"))
        if "--no-motion" in sys.argv:
            spec["motion"] = False
    out = os.path.join(os.path.dirname(spec_path), spec.get("title", "stories"))
    os.makedirs(out, exist_ok=True)
    work = os.path.join(out, ".work")
    os.makedirs(work, exist_ok=True)
    render(spec["frames"], spec, out, work)
    if spec.get("post"):
        try:
            import subprocess
            subprocess.run([sys.executable, os.path.join(HERE, "plan.py"), "file", str(spec["post"]), out], capture_output=True, timeout=60)
            print(f"Filed in your calendar for post {spec['post']}.")
        except Exception:
            pass
    print("Done:", out)


if __name__ == "__main__":
    main()
