#!/usr/bin/env python3
"""Check a caption against a platform's limits.
  python3 platform_check.py <platform> caption.txt [title text]
Prints plain notes: too long, hashtag count, emojis, first line length. Platforms: see engine/templates/platforms.json.
"""
import json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
P = json.load(open(os.path.join(HERE, "..", "templates", "platforms.json"), encoding="utf-8"))
EMOJI = re.compile("[\U0001F300-\U0001FAFF☀-➿]")


def check(platform, text, title=""):
    p = P[platform]
    notes = []
    if len(text) > p["caption_max"]:
        notes.append(f"{p['name']}: the caption is {len(text)} characters. The limit is {p['caption_max']}. Cut {len(text) - p['caption_max']}.")
    tags = re.findall(r"#\w+", text)
    lo, hi = p["hashtags"]
    if len(tags) > hi:
        notes.append(f"{p['name']}: {len(tags)} hashtags. Use {hi} or fewer.")
    if len(tags) < lo:
        notes.append(f"{p['name']}: add {lo - len(tags)} hashtag(s). {lo} to {hi} works best here.")
    first = text.strip().split("\n")[0] if text.strip() else ""
    if len(first) > p["first_line_chars"] * 1.6:
        notes.append(f"{p['name']}: the first line is long ({len(first)} characters). People only see about {p['first_line_chars']} before 'more'. Put the hook first.")
    vp = os.path.join(HERE, "..", "..", "customer", "profile", "voice-profile.md")
    likes_emoji = os.path.exists(vp) and "Emojis are part of her voice" in open(vp, encoding="utf-8", errors="ignore").read()
    if EMOJI.search(text):
        n_em = len(EMOJI.findall(text))
        if not likes_emoji:
            notes.append("There are emojis in the caption. Her rules say none unless her voice profile says she likes them.")
        elif n_em > 14:
            notes.append(f"{n_em} emojis is a lot. Her voice uses a few, on the exciting parts and as bullets.")
    if p.get("title_max") and title and len(title) > p["title_max"]:
        notes.append(f"{p['name']}: the title is {len(title)} characters. The limit is {p['title_max']}.")
    if platform == "linkedin" and re.search(r"link in bio", text, re.I):
        notes.append("LinkedIn: 'link in bio' does not work there. Say what to do in the comments instead.")
    return notes


if __name__ == "__main__":
    if len(sys.argv) < 3 or sys.argv[1] not in P:
        sys.exit(__doc__ + "\nPlatforms: " + ", ".join(P))
    out = check(sys.argv[1], open(sys.argv[2], encoding="utf-8").read(), sys.argv[3] if len(sys.argv) > 3 else "")
    print("\n".join(out) if out else "Looks good for " + P[sys.argv[1]]["name"] + ".")
