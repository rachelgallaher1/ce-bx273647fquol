#!/usr/bin/env python3
"""
The edit sheet: a small page that runs on her own computer.

She watches her edited video, then keeps or cuts lines, fixes caption words, changes full-screen words,
swaps GIFs, picks a look, and presses Build. Everything she does here costs no Claude credits.

Run with the engine's speech environment:
  ~/.cache/content-engine/whisper-venv/bin/python -I engine/tools/edit_sheet.py EDITED_FOLDER VIDEO_NAME
"""
import glob, time, subprocess, argparse, json, os, re, subprocess, sys, threading, urllib.parse, urllib.request, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
ENGINE = os.path.dirname(HERE)
TOOL = os.path.join(HERE, "first_edit.py")
STATE = {"state": "idle", "message": ""}
CFG = {}


def versions():
    d, n = CFG["dir"], CFG["name"]
    vs = []
    for f in os.listdir(d):
        m = re.fullmatch(re.escape(n) + r"_edit(\d+)\.mp4", f)
        if m:
            vs.append(int(m.group(1)))
    return sorted(vs)


def giphy_key():
    p = os.path.expanduser("~/.cache/content-engine/giphy.key")
    return open(p, encoding="utf-8").read().strip() if os.path.exists(p) else None


def effects_list():
    sys.path.insert(0, HERE)
    import effects
    return [{"key": k, "label": v["label"], "about": v["about"], "default": v["default"], "upload": v.get("upload") or False} for k, v in effects.EFFECTS.items()]



ROOT_DIR_ = os.path.abspath(os.path.join(HERE, "..", ".."))
LIVE = {"state": "idle", "message": "", "name": None}


def latest_plan():
    vs = versions()
    v = vs[-1] if vs else 1
    pp = os.path.join(CFG["dir"], f"{CFG['name']}_edit{v}.plan.json")
    return (json.load(open(pp, encoding="utf-8")) if os.path.exists(pp) else {}), v


def proxy_path():
    d = os.path.join(CFG["dir"], ".live")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, f"{CFG['name']}_proxy.mp4")


def build_proxy(src):
    """A small, smooth H.264 copy of her original, just for the live preview (browsers play phone HEVC video badly).
    A wide video gets the same face-following tall crop the build uses, so the preview looks like the finished video."""
    try:
        import first_edit as fe
        out = proxy_path()
        tmp = out + ".part.mp4"
        lift = "eq=contrast=1.08:saturation=1.25:gamma=0.95," if fe.is_hdr(src) else ""
        sw, sh = fe.source_geometry(src)
        if sw / sh > 0.62:
            LIVE.update(state="building", message="Getting your preview ready. A wide video takes a little longer.")
            dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", src], capture_output=True, text=True, encoding="utf-8", errors="replace").stdout.strip() or 0)
            track = fe.face_track(src, dur, sw, sh)
            cw = int(sh * 9 / 16) // 2 * 2
            fc, labels, a, i = [], [], 0.0, 0
            while a < dur - 0.05:
                b = min(dur, a + 12.0)
                x = fe.reframe_x(track, sw, cw, a, b)
                fc.append(f"[0:v]trim=start={a:.3f}:end={b:.3f},setpts=PTS-STARTPTS,{lift}crop=w={cw}:h={sh}:x='{x}':y=0,scale=540:960,setsar=1,fps=30[v{i}]")
                fc.append(f"[0:a]atrim=start={a:.3f}:end={b:.3f},asetpts=PTS-STARTPTS[a{i}]")
                labels.append(f"[v{i}][a{i}]")
                a, i = b, i + 1
            fc.append("".join(labels) + f"concat=n={i}:v=1:a=1[vo][ao]")
            cmd = ["ffmpeg", "-y", "-loglevel", "error", "-i", src, "-filter_complex", ";".join(fc), "-map", "[vo]", "-map", "[ao]",
                   "-c:v", "libx264", "-preset", "veryfast", "-crf", "27", "-pix_fmt", "yuv420p", "-g", "15", "-c:a", "aac", "-b:a", "96k", "-movflags", "+faststart", tmp]
        else:
            cmd = ["ffmpeg", "-y", "-loglevel", "error", "-i", src, "-vf", lift + "scale=-2:960,setsar=1,fps=30,format=yuv420p",
                   "-c:v", "libx264", "-preset", "veryfast", "-crf", "27", "-g", "15", "-c:a", "aac", "-b:a", "96k", "-movflags", "+faststart", tmp]
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if r.returncode == 0 and os.path.exists(tmp):
            os.replace(tmp, out)
            LIVE.update(state="ready", message="")
        else:
            LIVE.update(state="error", message="I couldn't make the preview copy of your video.")
    except Exception as e:
        LIVE.update(state="error", message=str(e)[:160])


def layers_dir():
    plan, v = latest_plan()
    return os.path.join(CFG["dir"], ".live", f"{CFG['name']}_layers_v{v}")


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        global LAST_HIT
        LAST_HIT = time.time()
        pass

    def send_json(self, obj, code=200):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def send_file(self, path, ctype):
        if not os.path.exists(path):
            return self.send_json({"error": "not found"}, 404)
        size = os.path.getsize(path)
        rng = self.headers.get("Range")
        start, end, code = 0, size - 1, 200
        if rng:
            m = re.match(r"bytes=(\d*)-(\d*)", rng)
            if m:
                start = int(m.group(1) or 0)
                end = int(m.group(2)) if m.group(2) else size - 1
                code = 206
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        if code == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        try:
            with open(path, "rb") as f:
                f.seek(start)
                left = end - start + 1
                while left > 0:
                    chunk = f.read(min(1 << 20, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        if u.path == "/":
            return self.send_file(os.path.join(HERE, "edit_sheet.html"), "text/html; charset=utf-8")
        if u.path == "/gallery":
            try:  # rebuild the page so it always matches what the engine can do
                subprocess.run([sys.executable, os.path.join(HERE, "make_effects_page.py")], capture_output=True, timeout=30)
            except Exception:
                pass
            page = os.path.join(HERE, "effects.html")
            return self.send_file(page if os.path.exists(page) else os.path.join(HERE, "gallery.html"), "text/html; charset=utf-8")
        if u.path.startswith("/gallery/"):
            f = os.path.basename(urllib.parse.unquote(u.path[9:]))
            ct = "image/gif" if f.endswith(".gif") else "application/json"
            return self.send_file(os.path.join(HERE, "gallery", f), ct)
        if u.path == "/api/live/hookstyles":
            import first_edit as fe, hook_styles as hs
            plan, v = latest_plan()
            hook = (q.get("text") or [((plan.get("decisions") or {}).get("hook") or "")])[0]
            lines = [x for x in hook.split("|") if x.strip()]
            try:
                hist = json.load(open(os.path.join(ROOT_DIR_, "customer", "profile", "hook-history.json"), encoding="utf-8"))
            except Exception:
                hist = []
            order = hs.suggest(lines, hist) if lines else list(hs.STYLES)
            return self.send_json({"styles": [{"id": k, "name": hs.STYLES[k]["name"], "about": hs.STYLES[k]["about"], "suggested": i < 3} for i, k in enumerate(order)],
                                   "hook": hook, "current": (plan.get("decisions") or {}).get("hook_style")})
        if u.path == "/api/live/layout":
            lp = os.path.join(layers_dir(), "layout.json")
            if not os.path.exists(lp):
                return self.send_json({"pop": [], "hook": None, "note": ""})
            d = json.load(open(lp, encoding="utf-8"))
            plan, v = latest_plan()
            d["look"] = (plan.get("decisions") or {}).get("look") or "1"
            return self.send_json(d)
        if u.path.startswith("/live/layers/"):
            f = os.path.basename(urllib.parse.unquote(u.path[13:]))
            return self.send_file(os.path.join(layers_dir(), f), "image/png")
        if u.path == "/live":
            return self.send_file(os.path.join(HERE, "live_editor.html"), "text/html; charset=utf-8")
        if u.path == "/api/live/state":
            plan, v = latest_plan()
            if not plan:
                return self.send_json({"error": "no plan"}, 404)
            import first_edit as fe
            try:
                gw, gh = fe.source_geometry(plan["source"])
            except Exception:
                gw, gh = 1080, 1920
            wide = False  # wide videos get a face-following tall preview now
            if LIVE.get("name") != CFG["name"]:
                LIVE.update(name=CFG["name"], state="ready" if os.path.exists(proxy_path()) else "building", message="")
                if LIVE["state"] == "building":
                    threading.Thread(target=build_proxy, args=(plan["source"],), daemon=True).start()
            dec = plan.get("decisions") or {}
            draft = None
            try:
                dfp = os.path.join(CFG["dir"], f"{CFG['name']}_draft.json")
                if os.path.exists(dfp) and os.path.getmtime(dfp) > os.path.getmtime(os.path.join(CFG["dir"], f"{CFG['name']}_edit{v}.plan.json")):
                    draft = json.load(open(dfp, encoding="utf-8"))
            except Exception:
                draft = None
            return self.send_json({"draft": draft, "name": CFG["name"], "version": v, "words": [{"i": w["i"], "w": w["w"], "s": w["s"], "e": w["e"], "cut": w.get("cut")} for w in plan.get("words", [])],
                                   "segments": [[g["start"], g["end"]] if isinstance(g, dict) else g[:2] for g in plan.get("segments", [])], "duration": plan.get("original_seconds"), "edited": plan.get("edited_seconds"),
                                   "sentences": plan.get("sentences", []), "graphics": [{k: v for k, v in g.items() if k in ("type", "start", "end", "text", "phrase", "effect", "number", "label", "pick")} for g in plan.get("graphics", [])], "face_checks": plan.get("face_cover_checks", []), "decisions": dec, "fun": plan.get("fun_suggestions", []), "fatigue": plan.get("fatigue", []), "wide": wide, "proxy": LIVE["state"], "message": LIVE.get("message", "")})
        if u.path == "/api/live/captionstyles":
            import first_edit as fe, hashlib
            plan, v = latest_plan()
            dec = plan.get("decisions") or {}
            look = fe.load_look((urllib.parse.parse_qs(u.query).get("look") or [""])[0] or str(dec.get("look") or "1"))
            ws = [w["w"] for w in plan.get("words", []) if not w.get("cut")]
            sample = ws[len(ws) // 3: len(ws) // 3 + 4] or ["Here", "is", "my", "caption"]
            os.makedirs(layers_dir(), exist_ok=True)
            out = []
            for st in fe.CAPTION_STYLES:
                if st["id"] == "pop":
                    img = fe.pop_word_image(look, sample[1], True)
                else:
                    img = fe.render_caption_style(st["id"], look, sample, 1)
                img.thumbnail((300, 120))
                fn = "capstyle_%s.png" % st["id"]
                img.save(os.path.join(layers_dir(), fn))
                out.append(dict(st, file=fn, current=(dec.get("caption_mode") or "pop") == st["id"]))
            return self.send_json({"styles": out, "current": dec.get("caption_mode") or "pop"})
        if u.path == "/api/live/textkinds":
            import text_jobs as tj
            bj = os.path.join(ROOT_DIR_, "customer", "profile", "brand.json")
            return self.send_json({"kinds": [{"id": k, "name": v["name"], "about": v["about"], "secs": v.get("secs")} for k, v in tj.KINDS.items()],
                                   "brand": json.load(open(bj, encoding="utf-8")) if os.path.exists(bj) else None})
        if u.path == "/api/live/music":
            out = []
            for where, folder in (("customer/profile/music", os.path.join(ROOT_DIR_, "customer", "profile", "music")), ("inbox/music", os.path.join(ROOT_DIR_, "inbox", "music"))):
                if os.path.isdir(folder):
                    for f in sorted(os.listdir(folder)):
                        if f.lower().endswith((".mp3", ".m4a", ".wav", ".aac", ".ogg")) and not f.startswith("."):
                            out.append({"name": f, "path": where + "/" + f})
            return self.send_json({"songs": out})
        if u.path.startswith("/live/music/"):
            rel = urllib.parse.unquote(u.path[len("/live/music/"):])
            full = os.path.abspath(os.path.join(ROOT_DIR_, rel))
            if (full.startswith(os.path.join(ROOT_DIR_, "customer", "profile", "music")) or full.startswith(os.path.join(ROOT_DIR_, "inbox", "music"))) and os.path.isfile(full):
                return self.send_file(full, "audio/mpeg" if full.lower().endswith(".mp3") else "audio/mp4" if full.lower().endswith(".m4a") else "audio/wav" if full.lower().endswith(".wav") else "application/octet-stream")
            return self.send_json({"error": "not found"}, 404)
        if u.path.startswith("/live/sfx/"):
            import sounds, io, wave
            nm = os.path.basename(u.path)[:-4]
            fns = {"whoosh": sounds.whoosh, "impact": sounds.impact, "pop": sounds.pop, "notif": sounds.notif, "typing": sounds.typing, "shutter": sounds.shutter, "coin": sounds.coin}
            if nm not in fns:
                return self.send_json({"error": "not found"}, 404)
            import numpy as np
            arr = np.asarray(fns[nm](), dtype="float32")
            pcm = (np.clip(arr, -1, 1) * 32767 * 0.8).astype("<i2").tobytes()
            buf = io.BytesIO()
            with wave.open(buf, "wb") as w:
                w.setnchannels(1); w.setsampwidth(2); w.setframerate(sounds.SR); w.writeframes(pcm)
            data = buf.getvalue()
            self.send_response(200); self.send_header("Content-Type", "audio/wav"); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
            return
        if u.path.startswith("/live/sticker/"):
            import face_cover as fcm, io
            nm = os.path.basename(u.path)[:-4]
            if nm not in fcm.STYLES:
                return self.send_json({"error": "not found"}, 404)
            buf = io.BytesIO()
            fcm.sticker(nm, 128).save(buf, "PNG")
            b = buf.getvalue()
            self.send_response(200); self.send_header("Content-Type", "image/png"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
            return
        if u.path.startswith("/live/facethumb/"):
            f = os.path.basename(urllib.parse.unquote(u.path[len("/live/facethumb/"):]))
            return self.send_file(os.path.join(layers_dir(), "faces", f), "image/jpeg")
        if u.path == "/api/live/caps":
            try:
                import capcut_draft
                cc = bool(capcut_draft.capcut_root())
            except Exception:
                cc = False
            return self.send_json({"capcut": cc})
        if u.path == "/api/live/media":
            groups = (("fav", "customer/profile/gifs"), ("fav", "inbox/gifs"), ("inbox", "inbox/broll"), ("inbox", "customer/videos/broll"), ("inbox", "inbox"))
            out = []
            for grp, rel in groups:
                folder = os.path.join(ROOT_DIR_, rel)
                if not os.path.isdir(folder):
                    continue
                for f in sorted(os.listdir(folder)):
                    full = os.path.join(folder, f)
                    low = f.lower()
                    if not os.path.isfile(full) or f.startswith(".") or rel == "inbox" and low.endswith((".mov", ".mp4", ".m4v")) and os.path.getsize(full) > 60_000_000:
                        continue
                    kind = "gif" if low.endswith(".gif") else "image" if low.endswith((".png", ".jpg", ".jpeg", ".webp")) else "video" if low.endswith((".mov", ".mp4", ".m4v")) else None
                    if kind:
                        out.append({"name": f, "path": rel + "/" + f, "kind": kind, "group": grp})
            return self.send_json({"items": out})
        if u.path == "/api/live/mthumb":
            rel = (urllib.parse.parse_qs(u.query).get("f") or [""])[0]
            full = os.path.abspath(os.path.join(ROOT_DIR_, rel))
            if not full.startswith(ROOT_DIR_) or not os.path.isfile(full):
                return self.send_json({"error": "not found"}, 404)
            import hashlib
            os.makedirs(layers_dir(), exist_ok=True)
            tp = os.path.join(layers_dir(), "mt_" + hashlib.md5(rel.encode()).hexdigest()[:12] + ".jpg")
            if not os.path.exists(tp):
                try:
                    if full.lower().endswith((".mov", ".mp4", ".m4v")):
                        subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", "0.6", "-i", full, "-frames:v", "1", "-vf", "scale=240:-2", tp], check=True, timeout=30)
                    else:
                        from PIL import Image
                        im = Image.open(full)
                        im.seek(0)
                        im = im.convert("RGB")
                        im.thumbnail((240, 240))
                        im.save(tp, quality=82)
                except Exception:
                    return self.send_json({"error": "no thumbnail"}, 404)
            return self.send_file(tp, "image/jpeg")
        if u.path == "/api/live/profile":
            h, logo = "yourhandle", False
            try:
                bj = json.load(open(os.path.join(ROOT_DIR_, "customer", "profile", "brand.json"), encoding="utf-8"))
                m = re.search(r"instagram\.com/([A-Za-z0-9._]+)", bj.get("url", ""))
                if m:
                    h = m.group(1)
                logo = bool(bj.get("logo"))
            except Exception:
                pass
            cap = ""
            try:
                for fn in sorted(os.listdir(os.path.join(ROOT_DIR_, "customer", "content", "before-after")), reverse=True):
                    pass
            except Exception:
                pass
            return self.send_json({"handle": h, "logo": ("/live/brandfile/logo.png" if logo else None), "caption": cap})
        if u.path.startswith("/live/brandfile/"):
            rel = urllib.parse.unquote(u.path[len("/live/brandfile/"):])
            full = os.path.abspath(os.path.join(ROOT_DIR_, "customer", "profile", "brand", rel))
            if full.startswith(os.path.join(ROOT_DIR_, "customer", "profile", "brand")) and os.path.isfile(full):
                return self.send_file(full, "image/png" if full.endswith(".png") else "image/jpeg")
            return self.send_json({"error": "not found"}, 404)
        if u.path == "/api/live/brandcard":
            import brand_colors as bc
            bj = os.path.join(ROOT_DIR_, "customer", "profile", "brand.json")
            if not os.path.exists(bj):
                return self.send_json({"card": ""})
            return self.send_json({"card": bc.card_html(json.load(open(bj, encoding="utf-8")), "/live/brandfile"), "css": bc.CARD_CSS})
        if u.path == "/api/live/proxy":
            return self.send_json({"state": LIVE["state"], "message": LIVE.get("message", "")})
        if u.path == "/api/live/filmstrip":
            fp = os.path.join(os.path.dirname(proxy_path()), f"{CFG['name']}_filmstrip.jpg")
            try:
                if not os.path.exists(fp) and os.path.exists(proxy_path()):
                    dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", proxy_path()], capture_output=True, text=True, encoding="utf-8", errors="replace").stdout.strip())
                    n = 36
                    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", proxy_path(), "-an", "-vf", f"fps={n}/{dur:.3f},scale=-2:120,tile={n}x1", "-frames:v", "1", "-q:v", "5", fp], capture_output=True, timeout=120)
                if os.path.exists(fp):
                    return self.send_json({"url": "/live/filmstrip.jpg?t=" + str(int(os.path.getmtime(fp)))})
            except Exception:
                pass
            return self.send_json({"url": None})
        if u.path == "/live/filmstrip.jpg":
            return self.send_file(os.path.join(os.path.dirname(proxy_path()), f"{CFG['name']}_filmstrip.jpg"), "image/jpeg")
        if u.path == "/live/proxy.mp4":
            return self.send_file(proxy_path(), "video/mp4")
        if u.path == "/api/estimate":
            try:
                import build_times
                vs = sorted(glob.glob(os.path.join(CFG["dir"], f"{CFG['name']}_edit*.plan.json")))
                secs = json.load(open(vs[-1], encoding="utf-8")).get("original_seconds") if vs else None
                return self.send_json({"text": build_times.text(CFG["dir"], secs) if secs else ""})
            except Exception:
                return self.send_json({"text": ""})
        if u.path == "/api/state":
            vs = versions()
            v = vs[-1] if vs else 1
            plan_path = os.path.join(CFG["dir"], f"{CFG['name']}_edit{v}.plan.json")
            plan = json.load(open(plan_path, encoding="utf-8")) if os.path.exists(plan_path) else {}
            looks = json.load(open(os.path.join(ENGINE, "looks", "looks.json"), encoding="utf-8"))["looks"]
            npath = os.path.join(CFG["dir"], f"{CFG['name']}_notes.json")
            notes = json.load(open(npath, encoding="utf-8")) if os.path.exists(npath) else {"general": "", "lines": {}}
            return self.send_json({"name": CFG["name"], "version": v, "versions": vs, "plan": plan, "notes": notes, "effects": effects_list(),
                                   "looks": [{"id": l["id"], "name": l["name"], "mood": l["mood"]} for l in looks],
                                   "giphy": bool(giphy_key())})
        if u.path.startswith("/media/"):
            f = os.path.basename(urllib.parse.unquote(u.path[7:]))
            return self.send_file(os.path.join(CFG["dir"], f), "video/mp4")
        if u.path.startswith("/gif/"):
            f = os.path.basename(urllib.parse.unquote(u.path[5:]))
            return self.send_file(os.path.join(CFG["dir"], f".{CFG['name']}_work", "gifs", f), "image/gif")
        if u.path == "/api/giphy":
            key = giphy_key()
            if not key:
                return self.send_json({"error": "no key", "results": []})
            qq = (q.get("q") or [""])[0]
            url = (f"https://api.giphy.com/v1/gifs/search?api_key={key}&q={urllib.parse.quote(qq)}"
                   f"&limit=9&rating=g&lang=en")
            try:
                data = json.loads(urllib.request.urlopen(url, timeout=30).read())
                res = [{"title": r["title"][:50], "thumb": r["images"]["fixed_width_small"]["url"],
                        "url": r["images"]["fixed_width"]["url"]} for r in data.get("data", [])]
            except Exception as e:
                return self.send_json({"error": str(e), "results": []})
            return self.send_json({"results": res})
        if u.path == "/api/status":
            return self.send_json(STATE)
        self.send_json({"error": "not found"}, 404)

    def do_POST(self):
        if self.path.startswith("/api/upload"):
            name = re.sub(r"[^A-Za-z0-9._-]", "_", (urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("name") or ["picture.png"])[0])
            folder = os.path.abspath(os.path.join(CFG["dir"], "..", "..", "assets"))
            os.makedirs(folder, exist_ok=True)
            path = os.path.join(folder, name)
            n = int(self.headers.get("Content-Length", 0))
            with open(path, "wb") as f:
                f.write(self.rfile.read(n))
            return self.send_json({"ok": True, "path": path})
        if self.path.startswith("/api/live/brandimage"):
            import brand_colors as bc
            n = int(self.headers.get("Content-Length", 0))
            tmp = os.path.join(CFG["dir"], f".{CFG['name']}_brandimg")
            with open(tmp, "wb") as f:
                f.write(self.rfile.read(n))
            try:
                pal, dark = bc.from_image(tmp)
            except Exception:
                pal, dark = [], None
            try:
                os.remove(tmp)
            except OSError:
                pass
            if not pal:
                return self.send_json({"error": "I couldn't find clear colors in that picture. Try your logo or a screenshot of your website."})
            return self.send_json({"swatches": [bc.hexof(c) for c in pal], "dark": bc.hexof(dark)})
        if self.path.startswith("/api/live/music/upload"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            name = re.sub(r"[^A-Za-z0-9._ -]", "_", os.path.basename((q.get("name") or ["song.mp3"])[0])) or "song.mp3"
            folder = os.path.join(ROOT_DIR_, "customer", "profile", "music")
            os.makedirs(folder, exist_ok=True)
            n = int(self.headers.get("Content-Length", 0))
            with open(os.path.join(folder, name), "wb") as f:
                f.write(self.rfile.read(n))
            return self.send_json({"ok": True, "path": "customer/profile/music/" + name, "name": name})
        if self.path.startswith("/api/live/vo/upload"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            ext = re.sub(r"[^a-z0-9]", "", (q.get("ext") or ["webm"])[0].lower())[:5] or "webm"
            n = int(self.headers.get("Content-Length", 0))
            raw = os.path.join(CFG["dir"], f"{CFG['name']}_voiceover_raw.{ext}")
            with open(raw, "wb") as f:
                f.write(self.rfile.read(n))
            VO["raw"] = raw
            return self.send_json({"ok": True, "bytes": n})
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}")
        if self.path == "/api/live/hook":
            import first_edit as fe, hook_styles as hs, hashlib
            plan, v = latest_plan()
            dec = plan.get("decisions") or {}
            look = fe.load_look(str(body.get("look") or dec.get("look") or "1"))
            lines = [x for x in (body.get("text") or dec.get("hook") or "").split("|") if x.strip()]
            if not lines:
                return self.send_json({"error": "no hook text"}, 400)
            lp = os.path.join(layers_dir(), "layout.json")
            lay = json.load(open(lp, encoding="utf-8")) if os.path.exists(lp) else {}
            zone_h = int(lay.get("zone_h", 200))
            top = int(lay.get("top", 255))
            scale = float(body.get("scale", 1.0))
            dy = int(body.get("dy", 0))
            dx = int(body.get("dx", 0))
            style = body.get("style") or "box"
            if body.get("preview"):
                im = hs.render(style, look, lines, zone_h)
                k = min(1.0, 300 / im.width)
                from PIL import Image as _I
                im = im.resize((max(1, int(im.width * k)), max(1, int(im.height * k))), _I.LANCZOS)
                tag = "hp_"
            else:
                im = hs.render(style, look, lines, zone_h, scale=scale)
                tag = "hk_"
            d = layers_dir()
            os.makedirs(d, exist_ok=True)
            fn = tag + hashlib.md5(f"{style}|{'|'.join(lines)}|{scale}|{look['name']}|{body.get('preview')}".encode()).hexdigest()[:12] + ".png"
            im.save(os.path.join(d, fn))
            return self.send_json({"file": fn, "w": im.width, "h": im.height, "cy": max(im.height // 2, min(1920 - im.height // 2, top + dy + im.height // 2)), "cx": max(im.width // 2, min(1080 - im.width // 2, 540 + dx)), "style": style})
        if self.path == "/api/live/word":
            import first_edit as fe, hashlib
            plan, v = latest_plan()
            look = fe.load_look(str(body.get("look") or (plan.get("decisions") or {}).get("look") or "1"))
            txt = (body.get("text") or "").strip(".,?!;:").upper() or (body.get("text") or "")
            im = fe.pop_word_image(look, txt, bool(body.get("hi")))
            d = layers_dir()
            os.makedirs(d, exist_ok=True)
            fn = "wc_" + hashlib.md5(f"{txt}|{bool(body.get('hi'))}|{look['name']}".encode()).hexdigest()[:12] + ".png"
            im.save(os.path.join(d, fn))
            return self.send_json({"file": fn, "w": im.width, "h": im.height})
        if self.path == "/api/live/textjob":
            import first_edit as fe, text_jobs as tj
            plan, v = latest_plan()
            dec = plan.get("decisions") or {}
            look = fe.load_look(str(body.get("look") or dec.get("look") or "1"))
            kind = body.get("kind")
            if kind not in tj.KINDS:
                return self.send_json({"error": "unknown"}, 400)
            img = tj.render(kind, look, body.get("text", ""), body.get("detail", ""), 1.0)
            os.makedirs(layers_dir(), exist_ok=True)
            fn = "tj_%d.png" % int(time.time() * 1000)
            img.save(os.path.join(layers_dir(), fn))
            cx, cy = tj.position(kind, img)
            return self.send_json({"file": fn, "w": img.width, "h": img.height, "cx": cx, "cy": cy, "secs": tj.KINDS[kind].get("secs"), "wm": bool(tj.KINDS[kind].get("wm"))})
        if self.path == "/api/live/brand":
            import brand_colors as bc
            try:
                if body.get("hex"):
                    pal = [bc.to_rgb(x if x.strip().startswith("#") else "#" + x.strip()) for x in body["hex"].split(",")]
                    pal = [c for c in pal if c]
                    url, dark = "", (31, 31, 31)
                    if body.get("dark"):
                        dark = bc.to_rgb(body["dark"]) or dark
                else:
                    kit = bc.brand_kit(body.get("url", ""))
                    score = bc.scan(kit["html"], kit["css"])
                    pal, dark = bc.pick(score)
                    if len(pal) < 2:
                        pal2, _ = bc.pick(score + bc.logo_colors(kit["html"], kit["url"]))
                        pal = pal2 or pal
                    if not pal:
                        return self.send_json({"error": "I couldn't find clear brand colors there. You can type them in, like #2A6E6F."})
                    data = bc.save_kit(kit, pal, dark)
                    return self.send_json(dict(data, card=bc.card_html(data, "/live/brandfile"), css=bc.CARD_CSS))
                if not pal:
                    return self.send_json({"error": "I couldn't find clear brand colors there. You can type them in, like #2A6E6F."})
                return self.send_json(bc.save(url, pal, dark))
            except Exception as e:
                return self.send_json({"error": "I couldn't open that website. You can type your brand colors instead, like #2A6E6F."})
        if self.path == "/api/live/faces":
            import face_cover as fcm
            vs = versions()
            if not vs:
                return self.send_json({"error": "Build the video once first, then I can find the faces in it."}, 400)
            src = os.path.join(CFG["dir"], f"{CFG['name']}_edit{vs[-1]}.mp4")
            out = os.path.join(layers_dir(), "faces")
            try:
                res = fcm.analyze(src, out)
            except Exception as e:
                return self.send_json({"error": "I could not look for faces just now."}, 500)
            return self.send_json({"faces": res})
        if self.path == "/api/live/captions":
            import first_edit as fe
            plan, v = latest_plan()
            dec = plan.get("decisions") or {}
            look = fe.load_look(str(body.get("look") or dec.get("look") or "1"))
            style = body.get("style", "soft")
            words = [{"w": w["w"], "s": w["s"], "e": w["e"]} for w in plan.get("words", [])]
            segs, reasons, kept = fe.plan_cuts(words, dur=plan.get("original_seconds"), cut=body.get("cut", []), keep=body.get("keep", []), trim=dec.get("trim"), edges=body.get("edges") or dec.get("edges"))
            items = [{"w": words[i]["w"], "os": words[i]["s"], "oe": words[i]["e"]} for i in kept]
            chunks, last_hi = [], -9
            os.makedirs(layers_dir(), exist_ok=True)
            tag = "c%d_" % int(time.time())
            for k, ch in enumerate(fe.chunk_words(items)):
                hi = fe.pick_highlight(ch)
                if hi >= 0 and (k - last_hi < 3 or len(fe.norm(ch[hi]["w"])) < 7):
                    hi = -1
                if hi >= 0:
                    last_hi = k
                ws = [c["w"] for c in ch]
                ent = {"s": ch[0]["os"], "e": ch[-1]["oe"] + 0.3, "cy": 1248}
                if style in ("soft", "karaoke"):
                    ent["words"] = []
                    for j, it in enumerate(ch):
                        img = fe.render_caption_style(style, look, ws, j)
                        fn = "%s%s_%d_%d.png" % (tag, style, k, j)
                        img.save(os.path.join(layers_dir(), fn))
                        nxt = ch[j + 1]["os"] if j + 1 < len(ch) else ch[-1]["oe"] + 0.30
                        ent["words"].append({"s": it["os"], "e": max(nxt, it["os"] + 0.15), "file": fn, "w": img.width, "h": img.height})
                else:
                    img = fe.render_caption_style(style, look, ws, hi)
                    fn = "%s%s_%d.png" % (tag, style, k)
                    img.save(os.path.join(layers_dir(), fn))
                    ent.update(file=fn, w=img.width, h=img.height)
                chunks.append(ent)
            for f in glob.glob(os.path.join(layers_dir(), "c*_*.png")):
                if not os.path.basename(f).startswith(tag) and time.time() - os.path.getmtime(f) > 120:
                    try:
                        os.remove(f)
                    except OSError:
                        pass
            return self.send_json({"style": style, "chunks": chunks})
        if self.path == "/api/live/segments":
            import first_edit as fe
            plan, v = latest_plan()
            dec = plan.get("decisions") or {}
            words = [{"w": w["w"], "s": w["s"], "e": w["e"]} for w in plan.get("words", [])]
            segs, reasons, kept = fe.plan_cuts(words, dur=plan.get("original_seconds"), cut=body.get("cut", []), keep=body.get("keep", []), trim=dec.get("trim"), edges=body.get("edges") or dec.get("edges"))
            out = [[round(x[0], 3), round(x[1], 3)] for x in segs]
            return self.send_json({"idx": [[x[2], x[3]] for x in segs], "segments": out, "reasons": {str(k): v_ for k, v_ in reasons.items()}, "seconds": round(sum(b - a for a, b in out), 2)})
        if self.path == "/api/live/vo/build":
            if STATE["state"] == "building":
                return self.send_json({"error": "already building"}, 409)
            if not VO.get("raw") or not os.path.exists(VO["raw"]):
                return self.send_json({"error": "no recording"}, 400)
            STATE.update(state="building", message="Starting...", skipped=[])
            threading.Thread(target=run_voiceover, args=(body,), daemon=True).start()
            return self.send_json({"ok": True})
        if self.path == "/api/live/save":
            json.dump(body, open(os.path.join(CFG["dir"], f"{CFG['name']}_draft.json"), "w", encoding="utf-8"), indent=1)
            return self.send_json({"ok": True})
        if self.path == "/api/build":
            if STATE["state"] == "building":
                return self.send_json({"error": "already building"}, 409)
            vs = versions()
            nv = (vs[-1] if vs else 1) + 1
            dpath = os.path.join(CFG["dir"], f"{CFG['name']}_decisions_v{nv}.json")
            json.dump(body, open(dpath, "w", encoding="utf-8"), indent=1)
            vs_plan = os.path.join(CFG["dir"], f"{CFG['name']}_edit{vs[-1] if vs else 1}.plan.json")
            plan = json.load(open(vs_plan, encoding="utf-8"))
            cmd = [sys.executable, "-X", "utf8", "-I", "-u", TOOL, "--no-sheet", plan["source"], "--out", CFG["dir"], "--version", str(nv),
                   "--decisions", dpath, "--look", str(body.get("look", "1"))]
            if plan.get("script"):
                cmd += ["--script", os.path.abspath(os.path.join(CFG["dir"], plan["script"]))
                        if not os.path.isabs(plan["script"]) else plan["script"]]
            STATE.update(state="building", message="Starting...", skipped=[])
            threading.Thread(target=run_build, args=(cmd, nv), daemon=True).start()
            return self.send_json({"ok": True, "version": nv})
        if self.path == "/api/capcut":
            if STATE["state"] == "building":
                return self.send_json({"error": "already working"}, 409)
            vs = versions()
            dpath = os.path.join(CFG["dir"], f"{CFG['name']}_decisions_capcut.json")
            json.dump(body, open(dpath, "w", encoding="utf-8"), indent=1)
            plan = json.load(open(os.path.join(CFG["dir"], f"{CFG['name']}_edit{vs[-1] if vs else 1}.plan.json"), encoding="utf-8"))
            cmd = [sys.executable, "-X", "utf8", "-I", "-u", TOOL, "--no-sheet", plan["source"], "--out", CFG["dir"], "--decisions", dpath,
                   "--look", str(body.get("look", "1")), "--capcut"]
            if plan.get("script"):
                cmd += ["--script", os.path.abspath(os.path.join(CFG["dir"], plan["script"]))
                        if not os.path.isabs(plan["script"]) else plan["script"]]
            STATE.update(state="building", message="Getting your CapCut folder ready...", skipped=[])
            threading.Thread(target=run_capcut, args=(cmd,), daemon=True).start()
            return self.send_json({"ok": True})
        if self.path == "/api/beforeafter":
            if STATE["state"] == "building":
                return self.send_json({"error": "already working"}, 409)
            cmd = [sys.executable, "-X", "utf8", "-I", "-u", os.path.join(HERE, "make_beforeafter.py"), CFG["dir"], CFG["name"]]
            STATE.update(state="building", message="Making your before and after...", skipped=[])
            threading.Thread(target=run_beforeafter, args=(cmd,), daemon=True).start()
            return self.send_json({"ok": True})
        if self.path == "/api/notes":
            base = os.path.join(CFG["dir"], f"{CFG['name']}_notes")
            json.dump(body, open(base + ".json", "w", encoding="utf-8"), indent=1)
            with open(base + ".txt", "w", encoding="utf-8") as f:
                f.write(f"Notes for Claude about {CFG['name']}\n\n")
                if body.get("general"):
                    f.write("General: " + body["general"].strip() + ("   [REMEMBER THIS AS A RULE]" if body.get("generalRemember") else "") + "\n\n")
                for ln in body.get("list", []):
                    f.write(f"At {ln['time']}  \"{ln['text']}\"\n    Note: {ln['note']}" + ("   [REMEMBER THIS AS A RULE]" if ln.get("remember") else "") + "\n")
            return self.send_json({"ok": True})
        if self.path == "/api/quit":
            self.send_json({"ok": True})
            threading.Thread(target=lambda: (__import__("time").sleep(0.3), os._exit(0)), daemon=True).start()
            return
        self.send_json({"error": "not found"}, 404)


def run_build(cmd, nv):
    log = os.path.join(CFG["dir"], f"{CFG['name']}_build.log")
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
        lines = []
        STATE["skipped"] = []
        for line in p.stdout:
            line = line.rstrip()
            lines.append(line)
            if line.startswith("SKIPPED: "):
                STATE["skipped"].append(line[9:])
            if re.match(r"^\d/5 ", line.strip()):
                STATE["message"] = line.strip()
        p.wait()
        open(log, "w", encoding="utf-8").write("\n".join(lines))
        if p.returncode == 0 and os.path.exists(os.path.join(CFG["dir"], f"{CFG['name']}_edit{nv}.mp4")):
            STATE.update(state="done", message=f"Version {nv} is ready." + (" Some of your changes were skipped. See the note at the top." if STATE.get("skipped") else ""))
        else:
            last = next((l for l in reversed(lines) if l.strip()), "no details")
            STATE.update(state="error", message=f"That build didn't finish. Details: {last[:200]}  (full details saved in {os.path.basename(log)})")
    except Exception as e:
        STATE.update(state="error", message=f"That build didn't start: {e}")


VO = {}


def run_voiceover(body):
    """Cut the picture the way she cut it, lay her recorded voice on it, then run the normal editor on that."""
    try:
        name, d = CFG["name"], CFG["dir"]
        dec = dict(body.get("decisions") or {})
        orig = max(0.0, min(1.0, float(body.get("orig", 0))))
        vs = versions()
        plan = json.load(open(os.path.join(d, f"{name}_edit{vs[-1] if vs else 1}.plan.json"), encoding="utf-8"))
        STATE["message"] = "1/3 Cutting your picture..."
        dpath = os.path.join(d, f"{name}_decisions_vo_cut.json")
        json.dump(dec, open(dpath, "w", encoding="utf-8"), indent=1)
        before = set(os.listdir(d))
        cmd = [sys.executable, "-X", "utf8", "-I", "-u", TOOL, "--no-sheet", "--clean", plan["source"], "--out", d, "--decisions", dpath, "--look", str(dec.get("look", "1"))]
        r = subprocess.run(cmd, text=True, capture_output=True, encoding="utf-8", errors="replace")
        new = sorted(f for f in set(os.listdir(d)) - before if f.endswith(".mp4") and "_cleancut" in f)
        if r.returncode != 0 or not new:
            raise RuntimeError((r.stderr or r.stdout)[-200:] or "the picture cut didn't finish")
        cc = os.path.join(d, new[-1])
        STATE["message"] = "2/3 Putting your voice on it..."

        def dur(p):
            return float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p], capture_output=True, text=True, encoding="utf-8", errors="replace").stdout.strip() or 0)
        vd, ad = dur(cc), dur(VO["raw"])
        total = max(vd, ad)
        vname = f"{name}-voiceover"
        out_src = os.path.join(ROOT_DIR_, "customer", "videos", "recorded", f"{vname}.mp4")
        os.makedirs(os.path.dirname(out_src), exist_ok=True)
        vf = f"tpad=stop_mode=clone:stop_duration={max(0.0, total - vd) + 0.05:.2f}"
        base_a = "aformat=sample_rates=48000:channel_layouts=stereo,highpass=f=80,loudnorm=I=-16:TP=-1.5"
        if orig > 0.01:
            fc = f"[1:a]{base_a}[v];[0:a]volume={orig:.2f},aformat=sample_rates=48000:channel_layouts=stereo[o];[v][o]amix=inputs=2:duration=longest:normalize=0,apad[a]"
        else:
            fc = f"[1:a]{base_a},apad[a]"
        r = subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", cc, "-i", VO["raw"], "-filter_complex", f"[0:v]{vf}[v0];" + fc, "-map", "[v0]", "-map", "[a]",
                            "-t", f"{total:.2f}", "-c:v", "libx264", "-preset", "veryfast", "-crf", "17", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", out_src],
                           text=True, capture_output=True, encoding="utf-8", errors="replace")
        if r.returncode != 0:
            raise RuntimeError(r.stderr[-200:])
        STATE["message"] = "3/3 Captions, hook and sounds..."
        for k in ("cut", "keep", "text", "trim", "fixes"):
            dec.pop(k, None)
        d2 = os.path.join(d, f"{vname}_decisions_v1.json")
        json.dump(dec, open(d2, "w", encoding="utf-8"), indent=1)
        cmd = [sys.executable, "-X", "utf8", "-I", "-u", TOOL, out_src, "--out", d, "--version", "0", "--decisions", d2, "--look", str(dec.get("look", "1"))]
        r = subprocess.run(cmd, text=True, capture_output=True, encoding="utf-8", errors="replace")
        if r.returncode != 0:
            raise RuntimeError((r.stderr or r.stdout)[-200:])
        for f in (cc, cc[:-4] + ".srt"):
            if os.path.exists(f):
                os.remove(f)
        STATE.update(state="done", message=f"Your voiceover video is ready. It opened as its own edit sheet ({vname}).")
    except Exception as e:
        STATE.update(state="error", message=f"The voiceover didn't finish: {e}")


def run_capcut(cmd):
    folder = None
    try:
        pr = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
        lines = []
        for line in pr.stdout:
            line = line.rstrip()
            lines.append(line)
            if line.startswith("CAPCUT: "):
                folder = line[8:]
            if re.match(r"^\d/5 ", line.strip()):
                STATE["message"] = "Getting your CapCut folder ready... " + line.strip()
        pr.wait()
        if pr.returncode == 0 and folder and os.path.isdir(folder):
            opened = False
            try:
                if sys.platform == "darwin" and os.path.exists("/Applications/CapCut.app"):
                    files = [os.path.join(folder, f) for f in ("1-video.mp4", "2-graphics.mov", "3-sounds.wav", "4-captions.srt")
                             if os.path.exists(os.path.join(folder, f))]
                    subprocess.run(["open", "-a", "CapCut"] + files)
                    opened = True
                subprocess.run(["open" if sys.platform == "darwin" else "explorer", folder])
            except Exception:
                pass
            STATE.update(state="done", message=("CapCut is open. " if opened else "") + "Your folder is open too. Select all the files in it and drag them into CapCut (see READ-ME).")
        else:
            last = next((l for l in reversed(lines) if l.strip()), "no details")
            STATE.update(state="error", message="That didn't finish. Details: " + last[:200])
    except Exception as e:
        STATE.update(state="error", message=f"That didn't start: {e}")


def run_beforeafter(cmd):
    out = None
    try:
        pr = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
        lines = []
        for line in pr.stdout:
            line = line.rstrip()
            lines.append(line)
            if line.startswith("BEFOREAFTER: "):
                out = line[13:]
        pr.wait()
        if pr.returncode == 0 and out and os.path.exists(out):
            subprocess.run(["open" if sys.platform == "darwin" else "explorer", out])
            STATE.update(state="done", message="Your before and after is made and open. It's in your proof folder.")
        else:
            last = next((l for l in reversed(lines) if l.strip()), "no details")
            STATE.update(state="error", message="That didn't finish. Details: " + last[:200])
    except Exception as e:
        STATE.update(state="error", message=f"That didn't start: {e}")


LAST_HIT = time.time()


def _idle_exit(hours=6):
    while True:
        time.sleep(300)
        if time.time() - LAST_HIT > hours * 3600:
            os._exit(0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder")
    ap.add_argument("name")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-open", action="store_true")
    a = ap.parse_args()
    CFG.update(dir=os.path.abspath(a.folder), name=a.name)
    threading.Thread(target=_idle_exit, daemon=True).start()
    srv = ThreadingHTTPServer(("127.0.0.1", a.port), H)
    url = f"http://127.0.0.1:{a.port}/"
    print("Edit sheet running at", url, flush=True)
    if not a.no_open:
        webbrowser.open(url)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
