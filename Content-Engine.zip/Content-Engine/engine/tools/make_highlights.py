#!/usr/bin/env python3
"""Highlight covers (and series highlight covers) in her look, one matching set.
  python3 make_highlights.py "Start Here,About,Waitlist,Wins,FAQ" [--look 11] [--out folder] [--motif star|tape|stamp]
Each cover is 1080 x 1920 with the picture in the middle circle Instagram shows. A short word or initial sits in the circle.
Series highlight cover: python3 make_highlights.py --series "One Video Series" --look 11
Names are hers and short (Instagram shows about 15 characters).
"""
import os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import first_edit as fe
import make_carousel as mc
from PIL import Image, ImageDraw


def cover(look, name, i, motif=None):
    bgc, ink, soft, accent = mc.palette(look, i)
    im = Image.new("RGB", (1080, 1920), bgc[:3])
    d = ImageDraw.Draw(im)
    cx, cy, r = 540, 960, 400
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=accent[:3])
    word = name.upper()
    on = (255, 255, 255) if mc.contrast((255, 255, 255), accent[:3]) >= mc.contrast((20, 20, 22), accent[:3]) else (20, 20, 22)
    size = 340
    f = fe.display_font(look, size)
    short = word if len(word) <= 10 else word.split()[0] if len(word.split()[0]) <= 10 else word[0]
    if " " in word and len(word) > 10:
        short = word.split()[0]
    while d.textlength(short, font=f) > 2 * r - 110 and size > 60:
        size -= 12
        f = fe.display_font(look, size)
    bb = d.textbbox((0, 0), short, font=f)
    d.text((cx - (bb[2] - bb[0]) / 2 - bb[0], cy - (bb[3] - bb[1]) / 2 - bb[1]), short, font=f, fill=on)
    if motif == "star":
        mc.doodle(d, "star", cx + 250, cy - 520, 120, 120, accent[:3])
    elif motif == "tape":
        t = Image.new("RGBA", (260, 70), (240, 228, 190, 215)).rotate(-12, expand=True, resample=Image.BICUBIC)
        im.paste(t, (cx - 330, cy - 420), t)
    return im


def main():
    a = sys.argv[1:]
    if not a:
        sys.exit(__doc__)
    look = fe.load_look(a[a.index("--look") + 1] if "--look" in a else "1")
    out = a[a.index("--out") + 1] if "--out" in a else os.path.join(os.getcwd(), "highlight-covers")
    motif = a[a.index("--motif") + 1] if "--motif" in a else None
    os.makedirs(out, exist_ok=True)
    names = [a[a.index("--series") + 1]] if "--series" in a else [x.strip() for x in a[0].split(",") if x.strip()]
    sheet = []
    for i, n in enumerate(names):
        im = cover(look, n, i, motif)
        p = os.path.join(out, f"highlight-{i + 1:02d}-{n.lower().replace(' ', '-')[:20]}.png")
        im.save(p)
        sheet.append(im.resize((270, 480)))
        print("made", os.path.basename(p), "(Instagram shows these as", n[:15] + ")")
    s = Image.new("RGB", (len(sheet) * 290 + 20, 520), (24, 24, 24))
    for k, im in enumerate(sheet):
        s.paste(im, (20 + k * 290, 20))
    s.save(os.path.join(out, "highlights-preview.png"))


if __name__ == "__main__":
    main()
