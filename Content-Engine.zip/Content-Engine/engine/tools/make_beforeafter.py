"""Make a before and after split screen: her raw video next to her finished one, then a big stat card.
Usage:  python make_beforeafter.py EDITED_DIR NAME [--layout side|stacked] [--cta ENGINE] [--seconds 18]
Looks at the newest edit of NAME in EDITED_DIR, reads its plan for the raw video and the numbers, and writes
customer/content/proof/NAME_before-after_<layout>_vN.mp4 (next to the customer's other finished content).
side = raw on the left and finished on the right (a vertical cut down the middle). stacked = raw on top, finished below (a horizontal cut).
"""
import argparse, json, os, re, subprocess, sys
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
FONTS = os.path.join(HERE, "..", "fonts")
LOOKS = os.path.join(HERE, "..", "looks", "looks.json")
W, H = 1080, 1920


def hexrgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def lum(c):
    return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]


def mmss(s):
    s = int(round(s))
    return f"{s // 60}:{s % 60:02d}"


def colors(look_name):
    try:
        looks = json.load(open(LOOKS, encoding="utf-8"))["looks"]
        look = next((l for l in looks if l["name"] == look_name), looks[0])
    except Exception:
        look = {"hook": {"bg": "#2F3D24"}, "highlight": {"bg": "#B7C2A5"}}
    hook = hexrgb(look["hook"]["bg"])
    hl = hexrgb(look["highlight"]["bg"])
    bg = tuple(int(c * 0.55) for c in hook) if lum(hook) < 110 else (24, 26, 25)
    if lum(hl) < 90:
        hl = tuple(min(255, int(c * 1.8) + 40) for c in hl)
    return bg + (255,), hl + (255,)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dir")
    ap.add_argument("name")
    ap.add_argument("--seconds", type=float, default=18)
    ap.add_argument("--layout", choices=["side", "stacked"], default="side")
    ap.add_argument("--cta", default="", help="a comment word for the end card, like ENGINE")
    a = ap.parse_args()
    edited = os.path.abspath(a.dir)
    vs = [int(m.group(1)) for f in sorted(os.listdir(edited), key=lambda f: os.path.getmtime(os.path.join(edited, f)))
          for m in [re.fullmatch(re.escape(a.name) + r"_edit(\d+)\.mp4", f)] if m]
    if not vs:
        sys.exit("I can't find a finished video yet. Make an edit first.")
    v = vs[-1]
    edit_mp4 = os.path.join(edited, f"{a.name}_edit{v}.mp4")
    plan = json.load(open(os.path.join(edited, f"{a.name}_edit{v}.plan.json"), encoding="utf-8"))
    raw = plan["source"]
    if not os.path.exists(raw):
        sys.exit("I can't find the original recording: " + raw)
    raw_s, edit_s = plan["original_seconds"], plan["edited_seconds"]
    cut_words = sum(1 for w in plan["words"] if w.get("cut"))
    bg, hl = colors(plan.get("look", ""))
    sand = (234, 223, 207, 255)
    A = lambda s: ImageFont.truetype(os.path.join(FONTS, "Anton-Regular.ttf"), s)
    out_dir = os.path.abspath(os.path.join(edited, "..", "..", "content", "proof"))
    os.makedirs(out_dir, exist_ok=True)
    n = 1
    while os.path.exists(os.path.join(out_dir, f"{a.name}_before-after_{a.layout}_v{n}.mp4")):
        n += 1
    out = os.path.join(out_dir, f"{a.name}_before-after_{a.layout}_v{n}.mp4")
    work = os.path.join(out_dir, f".{a.name}_ba_work")
    os.makedirs(work, exist_ok=True)

    im = Image.new("RGBA", (W, H), bg)
    d = ImageDraw.Draw(im)
    if a.layout == "side":
        d.text((270, 330), "BEFORE", font=A(96), fill=sand, anchor="mm")
        d.text((810, 330), "AFTER", font=A(96), fill=hl, anchor="mm")
        d.text((540, 170), "raw vs edited", font=A(54), fill=sand, anchor="mm")
        d.rectangle((538, 260, 542, 1500), fill=hl[:3] + (110,))
    else:
        d.rectangle((0, 956, W, 964), fill=hl)
        d.rounded_rectangle((36, 36, 36 + 250, 36 + 92), radius=22, fill=bg[:3] + (230,))
        d.text((36 + 125, 36 + 46), "BEFORE", font=A(62), fill=sand, anchor="mm")
        d.rounded_rectangle((36, 1792, 36 + 230, 1792 + 92), radius=22, fill=hl)
        d.text((36 + 115, 1792 + 46), "AFTER", font=A(62), fill=(20, 24, 22, 255), anchor="mm")
    im.save(os.path.join(work, "bg.png"))
    e = Image.new("RGBA", (W, H), bg)
    d = ImageDraw.Draw(e)
    d.text((540, 480), mmss(raw_s), font=A(300), fill=sand, anchor="mm")
    d.text((540, 680), "RAW", font=A(80), fill=(160, 150, 135, 255), anchor="mm")
    d.text((540, 860), "DOWN TO", font=A(90), fill=(255, 255, 255, 255), anchor="mm")
    d.text((540, 1140), mmss(edit_s), font=A(380), fill=hl, anchor="mm")
    line = f"{cut_words} words of retakes cut" if cut_words >= 10 else "cuts, captions, leveled sound"
    d.text((540, 1400), line, font=A(70), fill=sand, anchor="mm")
    d.text((540, 1540 if a.cta else 1580), "I just hit record.", font=A(70), fill=(255, 255, 255, 255), anchor="mm")
    if a.cta:
        d.text((540, 1690), "COMMENT " + a.cta.upper(), font=A(100), fill=hl, anchor="mm")
    e.save(os.path.join(work, "end.png"))

    dur = min(a.seconds, edit_s)
    total = dur + 4.5
    import sounds
    sounds.build_track([(0.1, "whoosh", 0.7), (0.5, "pop", 0.6), (dur - 0.3, "whoosh", 0.7), (dur + 0.3, "impact", 0.8),
                        (dur + 0.9, "pop", 0.6), (dur + 2.2, "notif", 0.6)], total, os.path.join(work, "sfx.wav"))
    if a.layout == "side":
        vf = (f"[1:v]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},scale=540:960,fps=30,setsar=1[r];"
              f"[2:v]scale=540:960,fps=30,setsar=1[e];[0:v]fps=30,format=yuv420p[b];"
              f"[b][r]overlay=0:480[o1];[o1][e]overlay=540:480,format=yuv420p[main];")
    else:
        # top and bottom: each half is a 1080 x 960 slice around her face and the captions
        vf = (f"[1:v]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},crop={W}:960:0:300,fps=30,setsar=1[r];"
              f"[2:v]scale={W}:{H},crop={W}:960:0:300,fps=30,setsar=1[e];[0:v]fps=30,format=yuv420p[b];"
              f"[b][r]overlay=0:0[o1];[o1][e]overlay=0:960,format=yuv420p[main];")
    fc = (vf + f"[3:v]fps=30,format=yuv420p[end];[main][end]concat=n=2:v=1:a=0[vout];"
          f"[2:a]apad=whole_dur={total}[ea];[4:a]volume=0.8[sx];[ea][sx]amix=inputs=2:duration=first:normalize=0[aout]")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-loop", "1", "-t", str(dur), "-i", os.path.join(work, "bg.png"),
                    "-ss", "0", "-t", str(dur), "-i", raw, "-ss", "0", "-t", str(dur), "-i", edit_mp4,
                    "-loop", "1", "-t", "4.5", "-i", os.path.join(work, "end.png"), "-i", os.path.join(work, "sfx.wav"),
                    "-filter_complex", fc, "-map", "[vout]", "-map", "[aout]", "-c:v", "libx264", "-crf", "18",
                    "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-t", str(total), out], check=True)
    for f in os.listdir(work):
        os.remove(os.path.join(work, f))
    os.rmdir(work)
    print("BEFOREAFTER: " + out)


main()
