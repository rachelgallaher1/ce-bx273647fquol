#!/usr/bin/env python3
"""Content that hit: a bank of her posts that beat her typical post, so she can bring them back.
  python winners.py find POSTS.json     compare posts to her typical post, add new hits to the bank, show them
  python winners.py add --title "..." --views 1200 [--hook --link --posted 2026-10-17 --kind reel --likes --comments --saves --shares]
  python winners.py show                the bank, as a plain list
  python winners.py ideas               winners worth bringing back now, each with ways to rework it
  python winners.py retire ID           take a winner out (for example, it was about something she no longer sells)
  python winners.py used ID HOW         note that a winner was brought back (HOW: repost, new-hook, new-topic, carousel, stories)
POSTS.json is a list of {"title","hook","views","likes","comments","saves","shares","link","posted","kind"}; missing numbers stay missing.
Files (customer/insights/): winners.jsonl (the bank), content-that-hit.md (the readable list).
Nothing is called a hit until at least 5 posts are compared. A missing number is unknown, never zero.
"""
import argparse, datetime, json, os, statistics, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
INS = os.path.join(ROOT, "customer", "insights")
BANK = os.path.join(INS, "winners.jsonl")
MIN_POSTS = 5
HIT = 1.8      # times her typical post
BIG = 3.0
REPOST_AFTER_DAYS = 60
WAYS = {"repost": "Repost it as it is", "new-hook": "Same idea, new hook", "new-topic": "Same hook, new topic",
        "carousel": "Turn it into a carousel", "stories": "Turn it into stories"}


def load():
    if not os.path.exists(BANK):
        return []
    return [json.loads(l) for l in open(BANK, encoding="utf-8") if l.strip()]


def save(rows):
    os.makedirs(INS, exist_ok=True)
    with open(BANK, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    write_md(rows)


def key(p):
    return (p.get("link") or "").strip() or ((p.get("title") or "")[:60] + "|" + (p.get("posted") or ""))


def n(v):
    return "?" if v is None else f"{v:,}"


def line(r):
    big = "  BIG HIT" if (r.get("times") or 0) >= BIG else ""
    nums = f"{n(r.get('views'))} views, {n(r.get('likes'))} likes, {n(r.get('comments'))} comments"
    if r.get("saves") is not None or r.get("shares") is not None:
        nums += f", {n(r.get('saves'))} saves, {n(r.get('shares'))} shares"
    t = f" ({r['times']}x your typical post)" if r.get("times") else ""
    return f"{r['id']}. {r.get('posted') or 'date unknown'} · {r.get('kind', 'reel')} · \"{(r.get('hook') or r.get('title') or '')[:90]}\" · {nums}{t}{big}"


def write_md(rows):
    with open(os.path.join(INS, "content-that-hit.md"), "w", encoding="utf-8") as f:
        f.write("# Content that hit\n\nPosts that did clearly better than your typical post. Bring them back: repost, new hook, new topic, or another format.\n\n")
        if not rows:
            f.write("Nothing here yet. Say \"weekly refresh\" after you have a few posts.\n")
        for r in sorted(rows, key=lambda x: -(x.get("times") or 0)):
            f.write("- " + line(r) + (f" · link: {r['link']}" if r.get("link") else "") + "\n")
            if r.get("used"):
                f.write("  - Brought back: " + ", ".join(f"{u['how']} on {u['on']}" for u in r["used"]) + "\n")


def find(path):
    posts = json.load(open(path, encoding="utf-8"))
    vs = [p["views"] for p in posts if isinstance(p.get("views"), (int, float))]
    if len(vs) < MIN_POSTS:
        print(f"Only {len(vs)} posts with view numbers. I need at least {MIN_POSTS} before I call anything a hit. Nothing added.")
        return
    typical = statistics.median(vs)
    bank = load()
    have = {key(r) for r in bank}
    new = []
    for p in posts:
        v = p.get("views")
        if not isinstance(v, (int, float)) or typical <= 0 or v < HIT * typical:
            continue
        p["times"] = round(v / typical, 1)
        p["typical"] = int(typical)
        if key(p) in have:
            for r in bank:
                if key(r) == key(p):
                    r.update({k: p[k] for k in ("views", "likes", "comments", "saves", "shares", "times", "typical") if k in p})
            continue
        p["id"] = max([r["id"] for r in bank] + [0]) + 1
        p["found"] = datetime.date.today().isoformat()
        bank.append(p)
        new.append(p)
    save(bank)
    print(f"Your typical post: {int(typical):,} views (middle of {len(vs)} posts). A hit is {HIT}x that or more. Judged on views; saves and shares are private, so add them if you have them.")
    print(f"New content that hit ({len(new)}):" if new else "No new hits this time.")
    for r in new:
        print(" " + line(r))
    print(f"Bank now holds {len(bank)}. List: {os.path.join(INS, 'content-that-hit.md')}")


def ideas():
    bank = load()
    today = datetime.date.today()
    out = []
    for r in sorted(bank, key=lambda x: -(x.get("times") or 0)):
        used = r.get("used") or []
        last = max([u["on"] for u in used] + [r.get("posted") or ""]) or None
        try:
            age = (today - datetime.date.fromisoformat(last)).days if last else None
        except ValueError:
            age = None
        options = [w for k, w in WAYS.items() if k != "repost" or age is None or age >= REPOST_AFTER_DAYS]
        out.append((r, age, options))
    if not out:
        print("The bank is empty, so nothing to bring back yet.")
    for r, age, options in out[:5]:
        print(line(r))
        print("   Ways to bring it back: " + " · ".join(options) + (f"  (posted or last brought back {age} days ago)" if age is not None else ""))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("a", nargs="?")
    ap.add_argument("b", nargs="?")
    for k in ("title", "hook", "link", "posted", "kind"):
        ap.add_argument("--" + k)
    for k in ("views", "likes", "comments", "saves", "shares"):
        ap.add_argument("--" + k, type=int)
    a = ap.parse_args()
    if a.cmd == "find":
        find(a.a)
    elif a.cmd == "add":
        bank = load()
        r = {k: v for k, v in vars(a).items() if k not in ("cmd", "a", "b") and v is not None}
        r["id"] = max([x["id"] for x in bank] + [0]) + 1
        r.setdefault("kind", "reel")
        bank.append(r)
        save(bank)
        print("Added.\n" + line(r))
    elif a.cmd == "show":
        bank = load()
        write_md(bank) if os.path.isdir(INS) else None
        print("\n".join(line(r) for r in sorted(bank, key=lambda x: -(x.get("times") or 0))) or "Nothing in the bank yet.")
    elif a.cmd == "ideas":
        ideas()
    elif a.cmd == "retire":
        bank = [r for r in load() if str(r["id"]) != str(a.a)]
        save(bank)
        print("Removed. It stays on Instagram; it just isn't in your bank anymore.")
    elif a.cmd == "used":
        bank = load()
        for r in bank:
            if str(r["id"]) == str(a.a):
                r.setdefault("used", []).append({"how": a.b, "on": datetime.date.today().isoformat()})
        save(bank)
        print("Noted.")
    else:
        sys.exit(__doc__)


main()
