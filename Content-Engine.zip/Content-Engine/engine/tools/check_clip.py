#!/usr/bin/env python3
"""Review a short test clip before she films a month of videos, in plain words.
  python3 check_clip.py clip.mp4          (about 15 seconds of her talking to camera, phone upright)
Looks at: the light on her face, where her face sits, how steady it is, how busy the background is, her colors against her caption color, and her sound.
Never judges her looks. Only what the camera sees.
"""
import json, os, subprocess, sys


def probe(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=width,height,codec_type:format=duration", "-of", "json", path], capture_output=True, text=True, encoding="utf-8", errors="replace")
    return json.loads(r.stdout or "{}")


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    import cv2, numpy as np
    path = sys.argv[1]
    info = probe(path)
    vs = next((s for s in info.get("streams", []) if s.get("codec_type") == "video"), {})
    notes, good = [], []
    cap = cv2.VideoCapture(path)
    try:
        cap.set(cv2.CAP_PROP_ORIENTATION_AUTO, 1)
    except Exception:
        pass
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    cas = cv2.CascadeClassifier(os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml"))
    faces, light, bg_edges, shake, prev = [], [], [], [], None
    for i in range(0, max(n, 1), max(1, int(fps / 2))):
        cap.set(cv2.CAP_PROP_POS_FRAMES, i)
        ok, fr = cap.read()
        if not ok:
            break
        h, w = fr.shape[:2]
        sm = cv2.resize(fr, (360, int(360 * h / w)))
        g = cv2.cvtColor(sm, cv2.COLOR_BGR2GRAY)
        f = cas.detectMultiScale(g, 1.1, 5, minSize=(50, 50))
        if prev is not None:
            shake.append(float(np.mean(np.abs(g.astype("int16") - prev.astype("int16")))))
        prev = g
        if len(f):
            x, y, fw, fh = max(f, key=lambda r: r[2] * r[3])
            faces.append((x / g.shape[1], y / g.shape[0], fw / g.shape[1], fh / g.shape[0]))
            face = g[y:y + fh, x:x + fw]
            left, right = face[:, :fw // 2], face[:, fw // 2:]
            light.append((float(face.mean()), abs(float(left.mean()) - float(right.mean())), float(g.mean())))
            mask = np.ones(g.shape, bool)
            mask[max(0, y - fh // 2):y + fh * 2, max(0, x - fw // 2):x + fw + fw // 2] = False
            edges = cv2.Canny(g, 80, 160)
            bg_edges.append(float(edges[mask].mean() / 255.0))
    if not faces:
        print("I couldn't find your face in the clip. Hold the phone upright, face the camera, and keep your whole face in the picture.")
        return
    fx = np.mean(faces, axis=0)
    cx, cy, fw, fh = fx[0] + fx[2] / 2, fx[1] + fx[3] / 2, fx[2], fx[3]
    # camera height and size
    if cy > 0.45:
        notes.append("Raise the phone so it's at your eye level or a little above. Right now it looks up at you, which is harder to watch.")
    elif cy < 0.18:
        notes.append("Lower the phone a bit so there's space above your head but your face isn't pinned to the top.")
    else:
        good.append("Your camera height is good.")
    if fw < 0.2:
        notes.append("Move closer, or zoom in a touch. Your face is small in the frame.")
    elif fw > 0.5:
        notes.append("Step back a little. Your face fills so much of the frame that captions will have nowhere to sit.")
    else:
        good.append("Your face is a good size.")
    # light
    fl = np.mean([l[0] for l in light])
    side = np.mean([l[1] for l in light])
    bgl = np.mean([l[2] for l in light])
    if fl < 85:
        notes.append("Your face is dark. Turn to face a window, or put a lamp behind the phone. The light should land on your face, not behind you.")
    elif fl > 205:
        notes.append("Your face is very bright and may lose detail. Move a step back from the window or the lamp.")
    else:
        good.append("The light on your face is good.")
    if side > 28:
        notes.append("One side of your face is much darker than the other. Turn a little toward the light so it lands on both sides.")
    if fl < bgl - 25:
        notes.append("The background is brighter than your face. Don't stand with a window behind you. Turn around so the light is in front of you.")
    # background
    if bg_edges and np.mean(bg_edges) > 0.09:
        notes.append("The background is busy. Take 5 seconds to clear the shelf or counter behind you, or move to a plain wall. Busy backgrounds make captions harder to read.")
    else:
        good.append("The background is calm.")
    # steadiness
    if shake and np.mean(shake) > 9.0:
        notes.append("The picture is moving a lot. Lean the phone on something, or use a small tripod. The engine can smooth a little, but steady is better.")
    else:
        good.append("The picture is steady.")
    # resolution and orientation
    w_, h_ = vs.get("width", 0), vs.get("height", 0)
    if w_ and h_ and w_ > h_:
        notes.append("This video is sideways (wide). Film with the phone upright so it fills a reel.")
    # sound
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", path, "-af", "volumedetect", "-f", "null", "-"], capture_output=True, text=True, encoding="utf-8", errors="replace")
    mean = None
    for line in r.stderr.splitlines():
        if "mean_volume" in line:
            mean = float(line.split("mean_volume:")[1].split("dB")[0])
    if mean is not None:
        if mean < -32:
            notes.append("Your sound is quiet. Move closer to the phone, or film in a smaller, softer room.")
        else:
            good.append("Your sound level is fine.")
    print("Here's what I saw in your test clip:\n")
    for g in good:
        print("  Good:", g)
    for nn in notes:
        print("  Fix:", nn)
    print("\nOne more thing, and I can't see this one for you: don't wear the color your captions use as their highlight, so your top doesn't blend into the words.")
    if not notes:
        print("\nNothing to fix. You're ready to film.")


if __name__ == "__main__":
    main()
