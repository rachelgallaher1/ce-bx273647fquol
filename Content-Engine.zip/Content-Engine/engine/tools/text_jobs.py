"""Every extra piece of text that can sit on a reel, drawn in her look (see engine/instructions/reel-font-system.md).

  KINDS[kind] = {"name", "about", "fn": fn(look, text, detail, p) -> picture, "pos": (cx, cy), "anim": "fade" | "type" | "build" | "strike"}
  render(kind, look, text, detail="", p=1.0)  -> transparent picture (p is 0..1 progress for typed, built and struck text)
  position(kind) -> where it sits on the 1080 x 1920 frame (inside Instagram's safe areas)
The build and the live editor both call render(), so they match. Plain, heavy, readable: no thin text on video.
"""
import re

from PIL import Image, ImageDraw

import first_edit as fe

W, H = 1080, 1920
PAD = 14


def _c(look):
    hb = fe.hex2rgb(look["hook"]["bg"])[:3]
    ht = fe.hex2rgb(look["hook"]["text"])[:3]
    hi = tuple(fe.hl_color(look)[:3])
    return hb, ht, hi


def _txt_col_on(rgb):
    return (255, 255, 255) if (0.299 * rgb[0] + 0.587 * rgb[1] + 0.114 * rgb[2]) < 140 else (25, 25, 25)


def _tw(f, t):
    return ImageDraw.Draw(Image.new("RGBA", (10, 10))).textlength(t, font=f)


def _wrap(t, f, maxw):
    out, cur = [], ""
    for w in t.split():
        c = (cur + " " + w).strip()
        if cur and _tw(f, c) > maxw:
            out.append(cur)
            cur = w
        else:
            cur = c
    if cur:
        out.append(cur)
    return out or [""]


def _shadow(img, dy=8, blur=10, alpha=110):
    from PIL import ImageFilter
    pad = 24
    base = Image.new("RGBA", (img.width + pad * 2, img.height + pad * 2), (0, 0, 0, 0))
    sh = Image.new("RGBA", base.size, (0, 0, 0, 0))
    sh.paste((0, 0, 0, alpha), (pad, pad + dy), img.getchannel("A"))
    sh = sh.filter(ImageFilter.GaussianBlur(blur))
    base.alpha_composite(sh)
    base.alpha_composite(img, (pad, pad))
    return base


def _spaced(d, xy, text, font, fill, track=0.0):
    x, y = xy
    for ch in text:
        d.text((x, y), ch, font=font, fill=fill)
        x += d.textlength(ch, font=font) + track


def lower_third(look, text, detail, p):
    hb, ht, hi = _c(look)
    f1, f2 = fe.load_font("Inter", 54, 700), fe.load_font("Inter", 38, 600)
    w = int(max(_tw(f1, text), _tw(f2, detail or " "))) + 80
    h = 54 + 18 + (42 if detail else 0) + 40
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0, 0, w - 1, h - 1), radius=22, fill=(0, 0, 0, 150))
    d.rounded_rectangle((16, 18, 24, h - 18), radius=4, fill=hi)
    d.text((44, 18), text, font=f1, fill=(255, 255, 255, 255))
    if detail:
        d.text((44, 18 + 70), detail, font=f2, fill=(225, 225, 225, 255))
    return _shadow(img)


def chapter(look, text, detail, p):
    hb, ht, hi = _c(look)
    f = fe.load_font("Montserrat", 40, 700)
    t = text.upper()
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    tr = 4.0
    tw = sum(d0.textlength(c, font=f) + tr for c in t)
    w, h = int(tw + 70), 80
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0, 0, w - 1, h - 1), radius=40, fill=hi + (255,))
    _spaced(d, (35, 16), t, f, _txt_col_on(hi) + (255,), tr)
    return _shadow(img, dy=5, blur=7, alpha=90)


def list_card(look, text, detail, p):
    """Items separated by |. They land one at a time and stay (p = how far through the build)."""
    hb, ht, hi = _c(look)
    items = [x.strip() for x in text.split("|") if x.strip()][:5]
    n = max(1, min(len(items), int(p * len(items) + 0.999))) if p < 1 else len(items)
    f, fn = fe.load_font("Inter", 52, 700), fe.load_font("Montserrat", 56, 900)
    lh = 84
    w = int(max(_tw(f, it) for it in items)) + 170
    h = lh * len(items) + 50
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0, 0, w - 1, h - 1), radius=30, fill=(0, 0, 0, 150))
    for i in range(n):
        a = 255 if i == n - 1 else 190
        y = 28 + i * lh
        d.text((34, y - 4), str(i + 1), font=fn, fill=hi + (a,))
        d.text((100, y), items[i], font=f, fill=(255, 255, 255, a))
    return _shadow(img)


def quote(look, text, detail, p):
    hb, ht, hi = _c(look)
    f = fe.load_font("Playfair Display", 78, 800)
    lines = _wrap(text, f, 800)[:4]
    lh = 104
    w, h = 900, lh * len(lines) + 90
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0, 0, w - 1, h - 1), radius=36, fill=(0, 0, 0, 165))
    fg = fe.load_font("Playfair Display", 200, 800)  # ghost echo: one huge faint word behind the line
    big = max(text.split(), key=len) if text.split() else ""
    d.text(((w - _tw(fg, big)) / 2, (h - 240) / 2), big, font=fg, fill=(255, 255, 255, 30))
    y = 45
    for l in lines:
        d.text(((w - _tw(f, l)) / 2, y), l, font=f, fill=(255, 255, 255, 255))
        y += lh
    return _shadow(img)


def question(look, text, detail, p):
    f = fe.load_font("Poppins", 50, 700)
    lines = _wrap(text, f, 720)[:4]
    lh = 70
    w, h = int(max(_tw(f, l) for l in lines)) + 90, lh * len(lines) + 60
    img = Image.new("RGBA", (w, h + 22), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0, 0, w - 1, h - 1), radius=38, fill=(255, 255, 255, 255))
    d.polygon([(60, h - 4), (100, h - 4), (66, h + 20)], fill=(255, 255, 255, 255))
    for i, l in enumerate(lines):
        d.text((45, 28 + i * lh), l, font=f, fill=(35, 35, 35, 255))
    return _shadow(img)


def label(look, text, detail, p):
    f = fe.load_font("Inter", 42, 600)
    w, h = int(_tw(f, text)) + 60, 76
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0, 0, w - 1, h - 1), radius=22, fill=(0, 0, 0, 140))
    d.text((30, 14), text, font=f, fill=(255, 255, 255, 255))
    return img


def mono_label(look, text, detail, p):
    f = fe.load_font("IBM Plex Mono", 40, 600)
    w, h = int(_tw(f, text)) + 60, 76
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0, 0, w - 1, h - 1), radius=18, fill=(0, 0, 0, 140))
    d.text((30, 14), text, font=f, fill=(255, 255, 255, 255))
    return img


def pov(look, text, detail, p):
    hb, ht, hi = _c(look)
    f = fe.load_font("Montserrat", 76, 900)
    f2 = fe.load_font("Montserrat", 76, 800)
    lead = "POV:"
    rest = " " + text
    lines = _wrap(lead + rest, f2, 880)
    lh = 100
    w = int(max(_tw(f2, l) for l in lines)) + 80
    img = Image.new("RGBA", (w, lh * len(lines) + 40), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    sw = 7
    y = 14
    for k, l in enumerate(lines):
        x = (w - _tw(f2, l)) / 2
        if k == 0 and l.startswith(lead):
            d.text((x, y), lead, font=f, fill=hi + (255,), stroke_width=sw, stroke_fill=(18, 18, 18, 255))
            x += _tw(f, lead)
            l = l[len(lead):]
        d.text((x, y), l, font=f2, fill=(255, 255, 255, 255), stroke_width=sw, stroke_fill=(18, 18, 18, 255))
        y += lh
    return img


def cta(look, text, detail, p):
    hb, ht, hi = _c(look)
    f1, f2 = fe.load_font("Montserrat", 84, 900), fe.load_font("Inter", 44, 600)
    parts = text.split()
    key = parts[-1].upper() if len(parts) > 1 else ""
    lead = " ".join(parts[:-1]) + (" " if key else "")
    if not key:
        lead = text
    wl = _tw(f1, lead) + (_tw(f1, key) + 70 if key else 0)
    w = int(max(wl, _tw(f2, detail or " "))) + 120
    h = 110 + (70 if detail else 0) + 60
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0, 0, w - 1, h - 1), radius=40, fill=(0, 0, 0, 165))
    x = (w - wl) / 2
    d.text((x, 40), lead, font=f1, fill=(255, 255, 255, 255))
    if key:
        kx = x + _tw(f1, lead)
        d.rounded_rectangle((kx - 6, 36, kx + _tw(f1, key) + 66, 36 + 110), radius=30, fill=hi + (255,))
        d.text((kx + 30, 40), key, font=f1, fill=_txt_col_on(hi) + (255,))
    if detail:
        d.text(((w - _tw(f2, detail)) / 2, 40 + 120), detail, font=f2, fill=(230, 230, 230, 255))
    return _shadow(img)


def watermark(look, text, detail, p):
    f = fe.load_font("Inter", 32, 600)
    w, h = int(_tw(f, text)) + 20, 52
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.text((10 + 2, 8 + 2), text, font=f, fill=(0, 0, 0, 90))
    d.text((10, 8), text, font=f, fill=(255, 255, 255, 175))
    return img


def disclaimer(look, text, detail, p):
    f = fe.load_font("Inter", 36, 600)
    lines = _wrap(text, f, 860)[:3]
    lh = 50
    w, h = int(max(_tw(f, l) for l in lines)) + 56, lh * len(lines) + 36
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0, 0, w - 1, h - 1), radius=18, fill=(0, 0, 0, 180))
    for i, l in enumerate(lines):
        d.text((28, 18 + i * lh), l, font=f, fill=(255, 255, 255, 255))
    return img


# ---- fun pack ----
def strike(look, text, detail, p):
    """The old way, crossed out with a marker line; the true line lands under it. text = old way, detail = the true line."""
    hb, ht, hi = _c(look)
    f1, f2 = fe.load_font("Montserrat", 60, 800), fe.load_font("Montserrat", 74, 900)
    old = _wrap(text, f1, 800)[:2]
    new = _wrap(detail or "", f2, 860)[:2] if detail else []
    wd = int(max([_tw(f1, l) for l in old] + [_tw(f2, l) for l in new] + [100])) + 90
    h = 84 * len(old) + (100 * len(new) + 30 if new else 0) + 60
    img = Image.new("RGBA", (wd, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0, 0, wd - 1, h - 1), radius=32, fill=(0, 0, 0, 165))
    y = 30
    for l in old:
        x = (wd - _tw(f1, l)) / 2
        d.text((x, y), l, font=f1, fill=(235, 235, 235, 255))
        pr = max(0.0, min(1.0, p / 0.45))
        yy = y + 40
        d.line((x - 8, yy + 6, x - 8 + (_tw(f1, l) + 16) * pr, yy - 6), fill=(220, 60, 50, 255), width=9)
        y += 84
    if new and p > 0.5:
        a = int(255 * min(1.0, (p - 0.5) / 0.3))
        y += 12
        for l in new:
            d.text(((wd - _tw(f2, l)) / 2, y), l, font=f2, fill=hi + (a,), stroke_width=4, stroke_fill=(18, 18, 18, a))
            y += 100
    return _shadow(img)


def signoff(look, text, detail, p):
    f = fe.load_font("Caveat", 74, 700)
    w, h = int(_tw(f, text)) + 40, 100
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.text((22, 8), text, font=f, fill=(0, 0, 0, 100), stroke_width=5, stroke_fill=(0, 0, 0, 100))
    d.text((20, 4), text, font=f, fill=(255, 255, 255, 255), stroke_width=4, stroke_fill=(25, 25, 25, 255))
    return img


def redpen(look, text, detail, p):
    """A friendly margin note with a hand-drawn underline and arrow."""
    f = fe.load_font("Caveat", 70, 700)
    w, h = int(_tw(f, text)) + 130, 150
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    red = (230, 60, 55, 255)
    d.text((100, 14), text, font=f, fill=red, stroke_width=3, stroke_fill=(255, 255, 255, 255))
    pr = max(0.0, min(1.0, p / 0.6))
    ux0, ux1 = 100, 100 + int(_tw(f, text))
    pts = [(ux0 + (ux1 - ux0) * k / 12 * pr, 104 + (4 if k % 2 else -4)) for k in range(13)]
    d.line(pts, fill=red, width=6, joint="curve")
    d.line((14, 40, 80, 70), fill=red, width=6)
    d.polygon([(80, 70), (60, 74), (70, 52)], fill=red)
    return img


def receipt(look, text, detail, p):
    """Lines separated by |, printed one by one, with a total at the bottom. Real numbers only."""
    hb, ht, hi = _c(look)
    lines = [x.strip() for x in text.split("|") if x.strip()][:7]
    f = fe.load_font("IBM Plex Mono", 40, 600)
    n = len(lines) if p >= 1 else max(1, int(p * len(lines) + 0.999))
    lh = 62
    w, h = 760, lh * len(lines) + 150
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0, 0, w - 1, h - 1), radius=14, fill=(252, 250, 244, 255))
    for k in range(0, w, 28):
        d.polygon([(k, h - 1), (k + 14, h - 16), (k + 28, h - 1)], fill=(0, 0, 0, 0))
    d.text((40, 24), "RECEIPT", font=fe.load_font("IBM Plex Mono", 44, 600), fill=(60, 60, 60, 255))
    y = 100
    for i in range(n):
        d.text((40, y), lines[i], font=f, fill=(35, 35, 35, 255))
        y += lh
    if detail and p >= 1:
        d.rounded_rectangle((w - 300, h - 100, w - 30, h - 30), radius=10, fill=hi + (255,))
        d.text((w - 285, h - 92), detail, font=fe.load_font("IBM Plex Mono", 44, 600), fill=_txt_col_on(hi) + (255,))
    return _shadow(img)


def typed(look, text, detail, p):
    """A hook typed into a search bar."""
    f = fe.load_font("Inter", 50, 600)
    full = text
    n = len(full) if p >= 1 else int(len(full) * min(1.0, p / 0.8))
    shown = full[:n] + ("|" if (p < 1 and int(p * 12) % 2 == 0) else "")
    lines = _wrap(full, f, 760)
    w, h = 900, 80 * len(lines) + 70
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0, 0, w - 1, h - 1), radius=h // 2 if len(lines) == 1 else 40, fill=(255, 255, 255, 255), outline=(200, 200, 200, 255), width=3)
    d.ellipse((34, h // 2 - 16, 62, h // 2 + 12), outline=(120, 120, 120, 255), width=5)
    d.line((58, h // 2 + 8, 72, h // 2 + 22), fill=(120, 120, 120, 255), width=5)
    sl = _wrap(shown, f, 760) if shown.strip("|") else [""]
    for i, l in enumerate(sl[:len(lines)]):
        d.text((92, 34 + i * 80), l, font=f, fill=(35, 35, 35, 255))
    return _shadow(img)


def costume(look, text, detail, p):
    """One word that acts out its meaning. detail = tiny, grow, fast, stuck or free."""
    hb, ht, hi = _c(look)
    b = (detail or "grow").lower()
    size = {"tiny": 44, "grow": 90, "fast": 110, "stuck": 120, "free": 130}.get(b, 110)
    if b == "grow":
        size = int(60 + 120 * min(1.0, p))
    f = fe.load_font("Montserrat", size, 900)
    t = text.upper()
    w, h = int(_tw(f, t)) + 120, int(size * 1.5) + 40
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    x, y = 60, 20
    if b == "fast":
        for k in range(1, 5):
            d.text((x - k * 26, y), t, font=f, fill=(255, 255, 255, 70 - k * 12), stroke_width=4, stroke_fill=(0, 0, 0, 0))
    d.text((x, y), t, font=f, fill=(255, 255, 255, 255), stroke_width=max(5, size // 9), stroke_fill=(18, 18, 18, 255))
    if b == "stuck":
        d.rectangle((0, y + int(size * 0.62), w, y + int(size * 0.82)), fill=hi + (255,))
    return _shadow(img)


def countup(look, text, detail, p):
    """A real number that rolls up to its final value. Real numbers only: text is the true number, like $1,200 or 30%."""
    hb, ht, hi = _c(look)
    m = re.search(r"(\d[\d,]*\.?\d*)", text)
    if not m:
        return label(look, text, detail, p)
    final = float(m.group(1).replace(",", ""))
    pre, post = text[:m.start()], text[m.end():]
    k = min(1.0, p / 0.7)
    k = 1 - (1 - k) ** 3
    val = final * k
    dec_ = len(m.group(1).split(".")[1]) if "." in m.group(1) else 0
    shown = pre + (f"{val:,.{dec_}f}") + post
    f1, f2 = fe.load_font("Montserrat", 170, 900), fe.load_font("Inter", 46, 600)
    w = int(max(_tw(f1, pre + f"{final:,.{dec_}f}" + post), _tw(f2, detail or " "))) + 100
    h = 230 + (70 if detail else 0)
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.text(((w - _tw(f1, shown)) / 2, 10), shown, font=f1, fill=hi + (255,), stroke_width=14, stroke_fill=(18, 18, 18, 255))
    if detail:
        d.text(((w - _tw(f2, detail)) / 2, 215), detail, font=f2, fill=(255, 255, 255, 255), stroke_width=4, stroke_fill=(18, 18, 18, 255))
    return _shadow(img)


KINDS = {
    "lowerthird": {"name": "Name and title", "about": "Your name and what you do, in the lower left. Gone after a few seconds.", "fn": lower_third, "pos": (W // 2 - 20, 1330), "left": 60, "secs": 5.0},
    "chapter": {"name": "Section label", "about": "A small pill like Step 2 or The fix at the top.", "fn": chapter, "pos": (W // 2, 330), "secs": 6.0},
    "list": {"name": "List that builds", "about": "Up to five lines that land one at a time and stay. Separate lines with |.", "fn": list_card, "pos": (W // 2, 1000), "anim": "build", "secs": 7.0},
    "quote": {"name": "Big statement", "about": "A calm pause on one line. Hold a full breath.", "fn": quote, "pos": (W // 2, 960), "secs": 3.5},
    "question": {"name": "Question bubble", "about": "Someone's real question in a message bubble. Use their exact words.", "fn": question, "pos": (W // 2, 1280), "secs": 4.0},
    "label": {"name": "Small label", "about": "Describes what you are showing, like Tuesday, 9am. Never sells.", "fn": label, "pos": (W // 2, 1480), "left": 60, "secs": 3.0},
    "monolabel": {"name": "Date or place stamp", "about": "A small typed stamp for a time or place.", "fn": mono_label, "pos": (W // 2, 1480), "left": 60, "secs": 3.0},
    "pov": {"name": "POV opener", "about": "POV: and the situation, at the very start.", "fn": pov, "pos": (W // 2, 420), "secs": 2.5},
    "cta": {"name": "Last line (one ask)", "about": "One action only, like Comment ENGINE. Put the key word last.", "fn": cta, "pos": (W // 2, 1100), "secs": 3.0},
    "watermark": {"name": "Your handle", "about": "Quiet, in the same corner on every reel.", "fn": watermark, "pos": (W - 330, 300), "secs": None, "wm": True},
    "disclaimer": {"name": "Fine print", "about": "Disclosures and results-vary lines, readable, held at least 3 seconds.", "fn": disclaimer, "pos": (W // 2, 1540), "secs": 4.0},
    "strike": {"name": "Crossed-out rewrite", "about": "The old way gets crossed out, then the true line lands. Text = old way, detail = true line.", "fn": strike, "pos": (W // 2, 1000), "anim": "strike", "secs": 4.0},
    "signoff": {"name": "Sign-off", "about": "Your little signature word in the corner, at the end.", "fn": signoff, "pos": (W - 260, 1440), "secs": 3.0, "end": True},
    "redpen": {"name": "Margin note", "about": "A friendly note with a hand-drawn underline, like a teacher marked it.", "fn": redpen, "pos": (W // 2, 760), "anim": "strike", "secs": 2.5},
    "receipt": {"name": "Receipt", "about": "Lines print one by one with a total. Real numbers only. Separate lines with |.", "fn": receipt, "pos": (W // 2, 980), "anim": "build", "secs": 5.0},
    "typed": {"name": "Typed into a search bar", "about": "Your question types itself into a search bar.", "fn": typed, "pos": (W // 2, 520), "anim": "type", "secs": 3.5},
    "countup": {"name": "Number that counts up", "about": "A real number rolling up to its final value. Text = the number, like $1,200. Detail = what it is.", "fn": countup, "pos": (W // 2, 900), "anim": "build", "secs": 3.0},
    "costume": {"name": "Word costume", "about": "One word acts out its meaning. Detail: tiny, grow, fast, stuck or free.", "fn": costume, "pos": (W // 2, 960), "anim": "build", "secs": 1.8},
}


def render(kind, look, text, detail="", p=1.0):
    k = KINDS[kind]
    return k["fn"](look, text, detail or "", max(0.0, min(1.0, p)))


def position(kind, img=None):
    k = KINDS[kind]
    cx, cy = k["pos"]
    if k.get("left") and img is not None:
        cx = k["left"] + img.width // 2
    return int(cx), int(cy)
