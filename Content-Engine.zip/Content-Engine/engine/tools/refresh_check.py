#!/usr/bin/env python3
"""Sunday refresh check: did every step of the weekly refresh really happen? Reads files only, changes nothing except its own report.
  python refresh_check.py [--quiet]
Looks at what the refresh leaves behind (see step-planner.md section 5) and prints PASS or FAIL for each step. Writes
customer/insights/refresh-check.json and refresh-check.md. The hub shows a warning if any step failed, and the refresh runs this at its end
and fixes what failed (once). Exit code is always 0 so it never breaks a run."""
import datetime, glob, json, os, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
INS = os.path.join(ROOT, "customer", "insights")
PLANS = os.path.join(ROOT, "customer", "plans")


def mtime(p):
    return os.path.getmtime(p) if os.path.exists(p) else 0


def main():
    checks = []

    def add(name, ok, why=""):
        checks.append({"name": name, "ok": bool(ok), "why": "" if ok else why})

    lr = os.path.join(INS, "last-refresh.txt")
    now = datetime.datetime.now().timestamp()
    try:
        T = datetime.datetime.fromisoformat(open(lr, encoding="utf-8").read().strip()[:19]).timestamp()
    except Exception:
        T = 0
    recent = T and (now - T) < 8 * 86400
    add("The refresh ran", recent, "No refresh has been logged in the last 8 days (last-refresh.txt).")
    base = T - 6 * 3600 if T else now - 3 * 86400
    pulls = glob.glob(os.path.join(INS, "pull-*.json"))
    add("Last week's numbers were saved", any(mtime(p) >= base for p in pulls) or mtime(os.path.join(INS, "results-log.md")) >= base,
        "No new numbers were saved (pull-DATE.json or results-log.md).")
    add("What worked was written down", mtime(os.path.join(INS, "learned.md")) >= base, "learned.md was not updated.")
    add("Best performing content was updated", mtime(os.path.join(INS, "winners.jsonl")) >= base or mtime(os.path.join(INS, "content-that-hit.md")) >= base,
        "The best performing content list was not refreshed.")
    add("The three-line summary was written", mtime(os.path.join(INS, "refresh-summary.md")) >= base, "refresh-summary.md is missing or old.")
    add("The calendar was redrawn", mtime(os.path.join(PLANS, "calendar.html")) >= base, "calendar.html was not regenerated.")
    try:
        sys.path.insert(0, HERE)
        import plan as pl
        rows = pl.rows_of(pl.plan_path())
        today = datetime.date.today()
        soon = [r for r in rows if today <= r["d"] <= today + datetime.timedelta(days=8) and r["state"] == "outline"]
        add("Next week has scripts", not soon, "These days have no script yet: " + ", ".join(f"{r['date']} ({r.get('idea', '')[:30]})" for r in soon[:5]))
        miss = [r for r in rows if r["state"] == "missed"]
        add("Missed posts were rolled or dropped", not miss, f"{len(miss)} earlier post(s) are still marked missed: " + ", ".join(r["date"] for r in miss[:6]))
    except BaseException as e:
        add("Plan checks", False, "Could not read the plan: " + str(e)[:80])
    new_scripts = [p for p in glob.glob(os.path.join(ROOT, "customer", "scripts", "*.md")) if mtime(p) >= base and ".new-voice" not in p]
    flagged = []
    for p in new_scripts[:12]:
        r = subprocess.run([sys.executable, os.path.join(HERE, "compliance_scan.py"), p], capture_output=True, text=True, encoding="utf-8", errors="replace")
        if r.returncode == 0 and r.stdout.strip() and "no flags" not in r.stdout.lower() and "nothing" not in r.stdout.lower()[:60]:
            flagged.append(os.path.basename(p))
    add("New scripts passed the compliance scan", not flagged, "Worth a look before posting: " + ", ".join(flagged[:5]))
    failed = [c for c in checks if not c["ok"]]
    out = {"checked": datetime.datetime.now().isoformat(timespec="seconds"), "passed": len(checks) - len(failed), "total": len(checks), "failed": failed}
    os.makedirs(INS, exist_ok=True)
    json.dump(out, open(os.path.join(INS, "refresh-check.json"), "w", encoding="utf-8"), indent=1)
    with open(os.path.join(INS, "refresh-check.md"), "w", encoding="utf-8") as f:
        f.write(f"# Sunday refresh check ({out['checked']})\n\n")
        for c in checks:
            f.write(("- PASS: " if c["ok"] else "- FAIL: ") + c["name"] + ("" if c["ok"] else " - " + c["why"]) + "\n")
    if "--quiet" not in sys.argv:
        for c in checks:
            print(("PASS  " if c["ok"] else "FAIL  ") + c["name"] + ("" if c["ok"] else "  (" + c["why"] + ")"))
        print(f"{out['passed']} of {out['total']} steps passed.")


main()
