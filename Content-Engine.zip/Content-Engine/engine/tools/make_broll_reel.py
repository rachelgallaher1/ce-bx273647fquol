#!/usr/bin/env python3
"""B-roll reel: a reel made from short clips of her real world plus her voiceover. No face needed.
  python make_broll_reel.py VOICEOVER.m4a --plan PLAN.json [--name my-reel] [--no-sheet]
PLAN.json: {"look": "11", "hook": "THE HOOK *WORDS*", "captions": "pop|lines|karaoke",
            "shots": [{"phrase": "first words of the line", "clip": "path/to/clip.mov", "start": 0.0}, ...],
            "options": {"zoom": false, "sound": true, "grain": false}}
Each shot starts when its phrase is spoken and holds until the next shot. A clip that is too short loops; a longer one is trimmed
(optionally from "start" seconds into the clip). Clips are filled to 9:16, and iPhone HDR clips get the same color lift as the editor.
Then the normal editor does the rest on that picture and her voiceover: cuts retakes and pauses (picture and sound together), captions,
hook, sounds and progress bar. Her clips and voice recording are never changed.
"""
import json, os, re, shutil, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import first_edit as fe

ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
W, H = 1080, 1920


def sh(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        raise RuntimeError((r.stderr or r.stdout).strip().splitlines()[-1] if (r.stderr or r.stdout).strip() else "ffmpeg failed")
    return r


def duration(p):
    return float(sh(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p]).stdout.strip())


def main():
    a = sys.argv[1:]
    if not a or "--plan" not in a:
        sys.exit(__doc__)
    audio = os.path.abspath(a[0])
    plan = json.load(open(a[a.index("--plan") + 1], encoding="utf-8"))
    name = a[a.index("--name") + 1] if "--name" in a else re.sub(r"[^A-Za-z0-9_-]+", "-", os.path.splitext(os.path.basename(audio))[0]) + "-broll"
    outdir = os.path.join(ROOT, "customer", "videos", "edited")
    work = os.path.join(outdir, f".{name}_broll")
    os.makedirs(work, exist_ok=True)
    adur = duration(audio)
    print("1/4 Listening to your voiceover...", flush=True)
    data = fe.transcribe(audio, os.path.join(work, "words.json"), "")
    wl, fixes = fe.word_list()
    toks = [fe.norm(w["w"]) for w in data["words"]]
    shots = []
    for sh_ in plan["shots"]:
        want = [fe.norm(x) for x in sh_["phrase"].split()]
        at = next((k for k in range(len(toks) - len(want) + 1) if toks[k:k + len(want)] == want), None)
        if at is None:
            print("   I couldn't find the words \"%s\" in the voiceover, so I skipped that clip." % sh_["phrase"])
            continue
        shots.append((max(0.0, data["words"][at]["s"] - 0.08), sh_))
    shots.sort(key=lambda x: x[0])
    if not shots:
        sys.exit("None of the shots matched the voiceover.")
    shots[0] = (0.0, shots[0][1])
    print("2/4 Laying the clips under your voice (%d shots)..." % len(shots), flush=True)
    segs = []
    for i, (t0, s_) in enumerate(shots):
        t1 = shots[i + 1][0] if i + 1 < len(shots) else adur
        dur = max(0.4, t1 - t0)
        clip = os.path.abspath(os.path.expanduser(s_["clip"]))
        lift = "eq=contrast=1.08:saturation=1.25:gamma=0.95," if fe.is_hdr(clip) else ""
        vf = f"{lift}scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},setsar=1,fps=30,format=yuv420p"
        out = os.path.join(work, f"seg{i:02d}.mp4")
        cdur = duration(clip)
        ss = float(s_.get("start", 0))
        cmd = ["ffmpeg", "-y", "-loglevel", "error"]
        if cdur - ss < dur:  # too short: loop it
            cmd += ["-stream_loop", "-1"]
        cmd += ["-ss", str(ss), "-i", clip, "-t", f"{dur:.3f}", "-an", "-vf", vf, "-c:v", "libx264", "-crf", "17", out]
        sh(cmd)
        segs.append(out)
    lst = os.path.join(work, "list.txt")
    open(lst, "w", encoding="utf-8").write("".join(f"file '{s}'\n" for s in segs))
    silent = os.path.join(work, "silent.mp4")
    sh(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", silent])
    base = os.path.join(work, f"{name}.mp4")
    sh(["ffmpeg", "-y", "-loglevel", "error", "-i", silent, "-i", audio, "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-shortest", base])
    final_src = os.path.join(ROOT, "customer", "videos", "recorded", f"{name}.mp4")
    os.makedirs(os.path.dirname(final_src), exist_ok=True)
    shutil.copy2(base, final_src)
    print("3/4 Editing it (captions, hook, sounds)...", flush=True)
    dec = {"look": plan.get("look", "11"), "hook": plan.get("hook", ""), "graphics": plan.get("graphics", []),
           "options": {"zoom": False, "sound": True, "progress": True, **(plan.get("options") or {})}}
    dpath = os.path.join(outdir, f"{name}_decisions_v1.json")
    json.dump(dec, open(dpath, "w", encoding="utf-8"), indent=1)
    cmd = [sys.executable, "-X", "utf8", "-I", os.path.join(HERE, "first_edit.py"), final_src, "--decisions", dpath, "--version", "1",
           "--captions", plan.get("captions", "pop"), "--out", outdir]
    if plan.get("options", {}).get("grain"):
        cmd.append("--grain")
    if "--no-sheet" in a:
        cmd.append("--no-sheet")
    r = subprocess.run(cmd, text=True, capture_output=True, encoding="utf-8", errors="replace")
    print(r.stdout[-600:])
    if r.returncode != 0:
        sys.exit(r.stderr[-600:])
    shutil.rmtree(work, ignore_errors=True)
    print("4/4 Done:", os.path.join(outdir, f"{name}_edit1.mp4"))


main()
