"""Make a month calendar page from her plan.
Usage:  python3 engine/tools/make_calendar.py [PLAN.md]
With no argument it uses the newest customer/plans/*-month-plan.md.
Writes customer/plans/calendar.html (one file, opens in any browser) and prints its path.
The page is view-only apart from checkmarks and notes, which save in her browser. All real changes (swap an idea, mark posted, reschedule)
happen in chat and rewrite the plan file, which is the single source of truth; this page is regenerated from it.
"""
import datetime, glob, html, json, os, re, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
MONTHS = {m: i for i, m in enumerate("Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(), 1)}


def read_plan(path):
    text = open(path, encoding="utf-8").read()
    title = re.search(r"^# (.+)$", text, re.M)
    year = int(re.match(r"(\d{4})-", os.path.basename(path)).group(1))
    rows, prev = [], None
    for line in text.splitlines():
        m = re.match(r"\|\s*(\d+)\s*\|(.+)\|\s*$", line)
        if not m:
            continue
        cells = [c.strip() for c in m.group(2).split("|")]
        if len(cells) < 7:
            continue
        date_s, fmt, job, idea, why, script, status = cells[:7]
        pillar = cells[7] if len(cells) > 7 else ""
        mix = cells[8] if len(cells) > 8 else ""
        dm = re.search(r"([A-Z][a-z]{2}) (\d{1,2})$", date_s)
        if not dm:
            continue
        mon, day = MONTHS[dm.group(1)], int(dm.group(2))
        y = year
        if prev and mon < prev:
            y += 1
        prev = mon
        link = re.search(r"\(([^)]+\.md)\)", script)
        rows.append({"n": int(m.group(1)), "date": datetime.date(y, mon, day).isoformat(), "format": fmt, "job": job,
                     "idea": idea, "why": why, "status": status, "pillar": pillar, "mix": mix,
                     "script": os.path.normpath(os.path.join(os.path.dirname(path), link.group(1))) if link else None})
    return (title.group(1) if title else "Month plan"), rows


def state_of(r, today=None):
    """One of: posted, missed, outline, ready. 'planned' and 'outline' both mean the script is not written yet."""
    today = today or datetime.date.today()
    st = (r.get("status") or "").lower()
    if st == "posted":
        return "posted"
    if datetime.date.fromisoformat(r["date"]) < today:
        return "missed"
    if st in ("planned", "outline"):
        return "outline"
    return "ready"


def read_script(path):
    if not path or not os.path.exists(path):
        return []
    sections, name, buf = [], None, []
    for line in open(path, encoding="utf-8").read().splitlines():
        if line.startswith("## "):
            if name:
                sections.append((name, "\n".join(buf).strip()))
            name, buf = line[3:].strip(), []
        elif name:
            buf.append(line)
    if name:
        sections.append((name, "\n".join(buf).strip()))
    keep = ("Hook", "Beats", "Format", "Why", "CTA", "Script", "Caption", "Stories", "Carousel", "Needs from you")
    got = [[n, b] for n, b in sections if n.split(" ")[0] in keep and b]
    if not got:
        body = "\n".join(l for l in open(path, encoding="utf-8").read().splitlines() if not l.startswith("# ") and not l.startswith("## ")).strip()
        if body:
            got = [["Plan", body]]
    return got


def post_time(script_path):
    if not script_path or not os.path.exists(script_path):
        return ""
    m = re.search(r"\*\*Post:\*\*[^\n]*?(\d{1,2}:\d{2}\s*[ap]m)", open(script_path, encoding="utf-8").read(), re.I)
    return m.group(1).replace(" ", "") if m else ""


def hashtag_set():
    """Her niche and local hashtag set, from customer/profile/marketing-settings.md ("Hashtag set" line)."""
    p = os.path.join(ROOT, "customer", "profile", "marketing-settings.md")
    if os.path.exists(p):
        m = re.search(r"\*\*Hashtag set[^\n]*?:\*\*\s*([^\n]*)", open(p, encoding="utf-8").read())
        if m:
            return re.findall(r"#\w+", m.group(1))
    return []


def default_time():
    p = os.path.join(ROOT, "customer", "profile", "marketing-settings.md")
    if os.path.exists(p):
        m = re.search(r"\*\*Post time[^\n]*?:\*\*\s*(\d{1,2}:\d{2}\s*[ap]m)", open(p, encoding="utf-8").read(), re.I)
        if m:
            return m.group(1).replace(" ", "")
    return ""


def key_dates():
    """Fixed days (a launch, a holiday): customer/plans/key-dates.json, {"2026-11-01": "Cart opens 7pm CT"}."""
    p = os.path.join(ROOT, "customer", "plans", "key-dates.json")
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:
        return {}


def file_info(path):
    """What to show for a day's file: a video player, or small pictures of every slide. Paths are relative to customer/plans so the page works from the folder."""
    if not path:
        return None
    full = path if os.path.isabs(path) else os.path.join(ROOT, path)
    if not os.path.exists(full):
        return {"missing": True, "name": os.path.basename(path)}
    plans = os.path.join(ROOT, "customer", "plans")
    rel = lambda p_: os.path.relpath(p_, plans).replace(os.sep, "/")
    if os.path.isdir(full):
        pics = sorted(f for f in os.listdir(full) if f.lower().endswith((".png", ".jpg", ".jpeg")) and not f.startswith("."))
        pics = [f for f in pics if f.startswith(("slide", "story", "0", "1", "2"))] or pics
        out = {"kind": "slides", "name": os.path.basename(full.rstrip("/")), "folder": rel(full), "thumbs": [rel(os.path.join(full, f)) for f in pics[:20]]}
        for nm in ("caption.txt",):
            if os.path.exists(os.path.join(full, nm)):
                out["caption"] = rel(os.path.join(full, nm))
        return out
    ext = os.path.splitext(full)[1].lower()
    kind = "video" if ext in (".mp4", ".mov", ".m4v") else "image" if ext in (".png", ".jpg", ".jpeg") else "file"
    return {"kind": kind, "name": os.path.basename(full), "rel": rel(full)}


def write_shortcut():
    """Files at the top of her folder that open her Content Engine home. The page opens the live home if it is running, otherwise the plain calendar."""
    try:
        page = ('<!doctype html><meta charset="utf-8"><title>My Content Engine</title><p style="font-family:system-ui;padding:30px">Opening your Content Engine... <a href="customer/plans/calendar.html">Click here to see your calendar.</a><br><br>'
                'For everything (editing, batch day, results), double-click <b>Open My Content Engine</b> in this folder first.</p>'
                '<script>var ports=[8780,8781,8782,8783],i=0;function go(){if(i>=ports.length){location.replace("customer/plans/calendar.html");return}'
                'var p=ports[i++];var c=new AbortController();setTimeout(function(){c.abort()},600);'
                'fetch("http://127.0.0.1:"+p+"/api/status",{mode:"no-cors",signal:c.signal}).then(function(){location.replace("http://127.0.0.1:"+p+"/")}).catch(go)}go();</script>')
        open(os.path.join(ROOT, "Content Calendar.html"), "w", encoding="utf-8").write(page)
        cmd = os.path.join(ROOT, "Open My Content Engine.command")
        open(cmd, "w", encoding="utf-8").write('#!/bin/bash\ncd "$(dirname "$0")"\nPY="$HOME/.cache/content-engine/whisper-venv/bin/python"\n[ -x "$PY" ] || PY=python3\n"$PY" -I engine/tools/batch_day.py hub\n')
        os.chmod(cmd, 0o755)
        open(os.path.join(ROOT, "Open My Content Engine.bat"), "w", encoding="utf-8").write('@echo off\r\ncd /d "%~dp0"\r\nset PY=%USERPROFILE%\\.cache\\content-engine\\whisper-venv\\Scripts\\python.exe\r\nif not exist "%PY%" set PY=python\r\n"%PY%" -I engine\\tools\\batch_day.py hub\r\npause\r\n')
    except OSError:
        pass


def post_files():
    """Which file to post for each day, from customer/plans/post-files.json ({"2026-10-16": "path"})."""
    p = os.path.join(ROOT, "customer", "plans", "post-files.json")
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:
        return {}


def copy_text(sections, base):
    """The caption plus her hashtag set. Hashtags already in the caption are not repeated."""
    cap = ""
    tags = []
    for name, body in sections:
        w = name.split(" ")[0]
        if w == "Caption" and not cap:
            cap = body.replace("**", "").strip()
        if w == "Hashtags":
            tags += re.findall(r"#\w+", body)
    if not cap:
        return ""
    have = {t.lower() for t in re.findall(r"#\w+", cap)}
    add = [t for t in tags + base if t.lower() not in have]
    seen, out = set(), []
    for t in add:
        if t.lower() not in seen:
            seen.add(t.lower()); out.append(t)
    return cap + ("\n\n" + " ".join(out) if out else "")


def results_by_date():
    """Logged numbers per posting date, from customer/insights/results-log.jsonl."""
    p = os.path.join(ROOT, "customer", "insights", "results-log.jsonl")
    out = {}
    if os.path.exists(p):
        for ln in open(p, encoding="utf-8"):
            if ln.strip():
                r = json.loads(ln)
                if r.get("posted"):
                    out.setdefault(r["posted"], r)
    return out


STAGE = {"outline": 0, "planned": 0, "ready": 1, "scripted": 1, "filmed": 2, "edited": 3, "posted": 4}


def all_plans(path=None):
    plans = sorted(glob.glob(os.path.join(ROOT, "customer", "plans", "*-month-plan.md")))
    if path and path not in plans and os.path.exists(path):
        plans.append(path)
    return plans


def page_for(path, live):
    today = datetime.date.today().isoformat()
    res = results_by_date()
    base_tags = hashtag_set()
    files = post_files()
    rows, title = [], "Content calendar"
    for pl in all_plans(path):
        t, rs = read_plan(pl)
        title = t
        for r in rs:
            sp = r.pop("script")
            r["sections"] = read_script(sp)
            r["time"] = post_time(sp) or default_time()
            if not r["mix"]:
                r["mix"] = "SOFT PITCH" if "act" in r["job"].lower() else "VALUE"
            r["copy"] = copy_text(r["sections"], base_tags)
            r["file"] = files.get(r["date"], "")
            r["fileinfo"] = file_info(r["file"])
            r["plan"] = os.path.basename(pl)
            r["state"] = state_of(r)
            r["stage"] = STAGE.get((r["status"] or "").lower(), 1)
            if r["state"] == "posted":
                r["stage"] = 4
            g = res.get(r["date"])
            if g:
                r["stats"] = {k: g.get(k) for k in ("views", "likes", "comments") if g.get(k) is not None}
                r["stats"]["early"] = r["date"] >= today
                if not any(v is not None for k, v in r["stats"].items() if k != "early"):
                    r.pop("stats")
            rows.append(r)
    rows.sort(key=lambda r: r["date"])
    font = ""
    fp = os.path.join(ROOT, "engine", "fonts", "Anton-Regular.ttf")
    if os.path.exists(fp):
        import base64
        font = base64.b64encode(open(fp, "rb").read()).decode()
    tpl = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "calendar_template.html"), encoding="utf-8").read()
    try:   # how many of her own photos are on the My brand tab (carousel days that need photos show the yellow ! until she has some)
        bp = json.load(open(os.path.join(ROOT, "customer", "profile", "brand.json"), encoding="utf-8")).get("photos") or []
        nphotos = len([x for x in bp if os.path.exists(os.path.join(ROOT, "customer", "profile", "brand", "photos", x))])
    except Exception:
        nphotos = 0
    tpl = tpl.replace("var DATA=__DATA__;", "var BRANDPHOTOS=" + str(nphotos) + ";var DATA=__DATA__;")
    return (tpl.replace("__TITLE__", html.escape(title if rows else "Content calendar"))
            .replace("__KEYS__", json.dumps(key_dates()))
            .replace("__LIVE__", "false")
            .replace("__BUILTISO__", today)
            .replace("__BUILT__", datetime.datetime.now().strftime("%A %B %d, %Y at %I:%M %p").replace(" 0", " "))
            .replace("__FONT__", font)
            .replace("__DATA__", json.dumps(rows).replace("</", "<\\/")))


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    plans = sorted(glob.glob(os.path.join(ROOT, "customer", "plans", "*-month-plan.md")))
    path = args[0] if args else (plans[-1] if plans else None)
    if not path:
        path = os.path.join(ROOT, "customer", "plans", "none-month-plan.md")
    out = os.path.join(os.path.dirname(path), "calendar.html")
    open(out, "w", encoding="utf-8").write(page_for(path, False))
    write_shortcut()
    print(out)


if __name__ == "__main__":
    main()
