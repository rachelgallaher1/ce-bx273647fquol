"""Hook designs: different looks for the opening line, all drawn in her palette, so her reels do not all look the same.
  render(style_id, look, lines, max_h, max_w=940, scale=1.0)  ->  transparent picture
  suggest(lines, history=[])  ->  style ids, best first (the first three are the ones shown as "suggested")
Words between *stars* are highlighted. The build and the live editor both call render(), so they always match.
"""
import math
import re

from PIL import Image, ImageDraw

import first_edit as fe

PAD = 15


def parse(lines):
    parts = [x.strip() for x in lines if x.strip()]
    text = " ".join(parts)
    if len(text.split()) > 7 and len(parts) > 1:
        text = parts[-1]
    words, flags, on = [], [], False
    for tok in text.upper().split():
        s, e = tok.startswith("*"), tok.endswith("*") and len(tok) > 1
        if s:
            on = True
        flags.append(on)
        words.append(tok.strip("*"))
        if e or (s and tok.endswith("*")):
            on = False
    return words, flags


def split_lines(words, flags, n):
    """n lines of about equal length, keeping each word with its highlight flag."""
    n = max(1, min(n, len(words)))
    text = " ".join(words)
    target = len(text) / n
    out, cur, curtxt = [], [], ""
    for w, f in zip(words, flags):
        cand = (curtxt + " " + w).strip()
        if cur and len(cand) > target * 1.15 and len(out) < n - 1:
            out.append(cur)
            cur, curtxt = [], ""
        cur.append((w, f))
        curtxt = (curtxt + " " + w).strip()
    out.append(cur)
    return out


def colors(look):
    hb = fe.hex2rgb(look["hook"]["bg"])[:3]
    ht = fe.hex2rgb(look["hook"]["text"])[:3]
    hi = fe.hex2rgb(look["highlight"]["bg"])[:3]
    hit = fe.hex2rgb(look["highlight"]["text"])[:3]
    if fe.luminance(look["highlight"]["bg"]) < 0.25:
        hi = tuple(min(255, int(c * 1.8) + 40) for c in hi)
    return hb, ht, hi, hit


def line_width(d, line, font, space):
    return sum(d.textlength(w, font=font) for w, _ in line) + space * (len(line) - 1)


def fit(d, lines, fam, weight, max_w, max_h, line_gap=1.05, italic=False, start=None):
    """Biggest size where every line fits the width and all lines fit the height."""
    size = start or int(max_h / (len(lines) * line_gap))
    while size > 24:
        f = fe.load_font(fam, size, weight, italic)
        sp = d.textlength(" ", font=f)
        if max(line_width(d, l, f, sp) for l in lines) <= max_w and size * line_gap * len(lines) <= max_h:
            return f, size
        size -= 3
    return fe.load_font(fam, 24, weight, italic), 24


def draw_line(d, x, y, line, font, fill, hi_fill, stroke=0, stroke_fill=None, hi_font=None, hi_stroke_fill=None, underline_hi=None):
    sp = d.textlength(" ", font=font)
    for w, f in line:
        ft = hi_font if (f and hi_font) else font
        d.text((x, y), w, font=ft, fill=hi_fill if f else fill, stroke_width=stroke, stroke_fill=(hi_stroke_fill if (f and hi_stroke_fill) else stroke_fill))
        wd = d.textlength(w, font=ft)
        if f and underline_hi:
            yy = y + ft.size * 1.0
            pts = [(x, yy), (x + wd * 0.3, yy - 5), (x + wd * 0.6, yy + 3), (x + wd, yy - 3)]
            d.line(pts, fill=underline_hi, width=max(5, ft.size // 14), joint="curve")
        x += wd + sp


def finish(img, scale):
    if abs(scale - 1.0) > 0.01:
        img = img.resize((max(1, int(img.width * scale)), max(1, int(img.height * scale))), Image.LANCZOS)
    return img


def n_lines(words):
    return 1 if len(words) <= 3 else 2


# ---------- the styles ----------
def s_box(look, lines, max_h, max_w):
    return fe.render_hook(look, lines, max_h=max_h, max_w=max_w)


def s_stack(look, lines, max_h, max_w):
    words, flags = parse(lines)
    hb, ht, hi, hit = colors(look)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    ls = split_lines(words, flags, 1 if len(words) <= 3 else (3 if len(words) > 7 else 2))
    f, sz = fit(d0, ls, look["hookFont"], look.get("hookWeight", 700), max_w - 40, max_h - 30, 1.02)
    sw = max(6, sz // 10)
    w = int(max(line_width(d0, l, f, d0.textlength(" ", font=f)) for l in ls)) + 2 * sw + 40
    h = int(sz * 1.02 * len(ls)) + 2 * sw + 30
    img = Image.new("RGBA", (w + 2 * PAD, h + 2 * PAD), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    y = PAD + sw + 4
    for l in ls:
        lw = line_width(d, l, f, d.textlength(" ", font=f))
        x = PAD + (w - lw) / 2
        draw_line(d, x + 5, y + 7, l, f, (0, 0, 0, 120), (0, 0, 0, 120), stroke=sw, stroke_fill=(0, 0, 0, 120))
        draw_line(d, x, y, l, f, (255, 255, 255, 255), hi + (255,), stroke=sw, stroke_fill=(18, 18, 18, 255))
        y += int(sz * 1.02)
    return img


def s_marker(look, lines, max_h, max_w):
    words, flags = parse(lines)
    hb, ht, hi, hit = colors(look)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    ls = split_lines(words, flags, n_lines(words) if len(words) < 7 else 3)
    f, sz = fit(d0, ls, "Oswald", 700, max_w - 80, max_h - 20, 1.25)
    lh = int(sz * 1.25)
    sp = d0.textlength(" ", font=f)
    w = int(max(line_width(d0, l, f, sp) for l in ls)) + 100
    h = lh * len(ls) + 30
    img = Image.new("RGBA", (w + 2 * PAD, h + 2 * PAD), (0, 0, 0, 0))
    bar = hi + (240,) if fe.luminance(look["highlight"]["bg"]) > 0.35 else (255, 226, 70, 240)
    d = ImageDraw.Draw(img)
    y = PAD + 14
    for k, l in enumerate(ls):
        lw = line_width(d, l, f, sp)
        x = PAD + (w - lw) / 2
        tilt = -3 if k % 2 == 0 else 3
        d.polygon([(x - 26, y + 6), (x + lw + 24, y + 6 + tilt), (x + lw + 30, y + lh - 6 + tilt), (x - 20, y + lh - 4)], fill=bar)
        draw_line(d, x, y + (lh - sz) / 2 - 4, l, f, (24, 24, 22, 255), (24, 24, 22, 255))
        y += lh
    return img


def s_sticker(look, lines, max_h, max_w):
    words, flags = parse(lines)
    hb, ht, hi, hit = colors(look)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    ls = split_lines(words, flags, n_lines(words) if len(words) < 6 else 2)
    f, sz = fit(d0, ls, "Baloo 2", 800, max_w - 130, max_h - 90, 1.0)
    sp = d0.textlength(" ", font=f)
    tw = int(max(line_width(d0, l, f, sp) for l in ls))
    w, h = tw + 110, int(sz * 1.0 * len(ls)) + 70
    card = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(card)
    fill = hi + (255,)
    txt = hit + (255,)
    d.rounded_rectangle((0, 0, w - 1, h - 1), radius=34, fill=(255, 255, 255, 255))
    d.rounded_rectangle((10, 10, w - 11, h - 11), radius=26, fill=fill, outline=(22, 22, 22, 255), width=6)
    y = 32
    for l in ls:
        lw = line_width(d, l, f, sp)
        draw_line(d, (w - lw) / 2, y, l, f, txt, txt)
        y += int(sz)
    card = fe.rotated(card, -3) if hasattr(fe, "rotated") else card
    img = Image.new("RGBA", (card.width + 2 * PAD, card.height + 2 * PAD), (0, 0, 0, 0))
    img.alpha_composite(fe.shadowed(card, blur=10, dy=8, alpha=130) if hasattr(fe, "shadowed") else card, (PAD // 2, PAD // 2))
    return img


def s_serif(look, lines, max_h, max_w):
    words, flags = parse(lines)
    hb, ht, hi, hit = colors(look)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    ls = split_lines(words, flags, n_lines(words) if len(words) < 7 else 3)
    f, sz = fit(d0, ls, "Gloock", 400, max_w - 110, max_h - 60, 1.12)
    fi = fe.load_font("Instrument Serif", sz, 400, True)
    sp = d0.textlength(" ", font=f)
    tw = int(max(line_width(d0, l, f, sp) for l in ls))
    w, h = tw + 100, int(sz * 1.12 * len(ls)) + 56
    img = Image.new("RGBA", (w + 2 * PAD, h + 2 * PAD), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((PAD, PAD, PAD + w, PAD + h), radius=26, fill=(14, 18, 16, 190), outline=hi + (255,), width=3)
    y = PAD + 28
    for l in ls:
        lw = sum(d.textlength(wd, font=(fi if fl else f)) for wd, fl in l) + sp * (len(l) - 1)
        draw_line(d, PAD + (w - lw) / 2, y, l, f, (244, 238, 226, 255), hi + (255,), hi_font=fi)
        y += int(sz * 1.12)
    return img


def s_script(look, lines, max_h, max_w):
    words, flags = parse(lines)
    hb, ht, hi, hit = colors(look)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    ls = split_lines(words, flags, n_lines(words) if len(words) < 6 else 2)
    f, sz = fit(d0, ls, "Caveat", 700, max_w - 60, max_h - 40, 1.0)
    sw = max(5, sz // 12)
    sp = d0.textlength(" ", font=f)
    w = int(max(line_width(d0, l, f, sp) for l in ls)) + 80
    h = int(sz * 1.0 * len(ls)) + 50
    img = Image.new("RGBA", (w + 2 * PAD, h + 2 * PAD), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    y = PAD + 14
    for l in ls:
        lw = line_width(d, l, f, sp)
        x = PAD + (w - lw) / 2
        draw_line(d, x + 4, y + 5, l, f, (0, 0, 0, 110), (0, 0, 0, 110), stroke=sw, stroke_fill=(0, 0, 0, 110))
        draw_line(d, x, y, l, f, (255, 255, 255, 255), hi + (255,), stroke=sw, stroke_fill=(20, 20, 20, 255), hi_stroke_fill=(20, 20, 20, 255), underline_hi=hi + (255,))
        y += int(sz)
    return img


def s_ribbon(look, lines, max_h, max_w):
    words, flags = parse(lines)
    hb, ht, hi, hit = colors(look)
    ab = fe.hex2rgb(look["accent"]["bg"])[:3]
    at = fe.hex2rgb(look["accent"]["text"])[:3]
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    ls = split_lines(words, flags, 1 if len(words) <= 4 else 2)
    f, sz = fit(d0, ls, look["hookFont"], look.get("hookWeight", 700), max_w - 120, max_h - 50, 1.05)
    sp = d0.textlength(" ", font=f)
    tw = int(max(line_width(d0, l, f, sp) for l in ls))
    w, h = min(max_w + 40, tw + 150), int(sz * 1.05 * len(ls)) + 44
    img = Image.new("RGBA", (w + 2 * PAD + 60, h + 2 * PAD), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    x0, y0 = PAD + 30, PAD
    d.polygon([(x0 - 30, y0 + 14), (x0 + 20, y0 + 14), (x0 + 20, y0 + h + 14), (x0 - 30, y0 + h + 14), (x0 - 4, y0 + h / 2 + 14)], fill=tuple(int(c * 0.65) for c in ab) + (255,))
    d.polygon([(x0 + w + 30, y0 + 14), (x0 + w - 20, y0 + 14), (x0 + w - 20, y0 + h + 14), (x0 + w + 30, y0 + h + 14), (x0 + w + 4, y0 + h / 2 + 14)], fill=tuple(int(c * 0.65) for c in ab) + (255,))
    d.rectangle((x0, y0, x0 + w, y0 + h), fill=ab + (255,), outline=(22, 22, 22, 255), width=5)
    y = y0 + 20
    for l in ls:
        lw = line_width(d, l, f, sp)
        draw_line(d, x0 + (w - lw) / 2, y, l, f, at + (255,), hi + (255,) if fe.luminance(look["accent"]["bg"]) < 0.5 else (140, 20, 40, 255))
        y += int(sz * 1.05)
    return img


def s_outline(look, lines, max_h, max_w):
    words, flags = parse(lines)
    hb, ht, hi, hit = colors(look)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    ls = split_lines(words, flags, 1 if len(words) <= 3 else (3 if len(words) > 8 else 2))
    f, sz = fit(d0, ls, "Bebas Neue", 400, max_w - 40, max_h - 30, 1.0)
    sw = max(5, sz // 14)
    sp = d0.textlength(" ", font=f)
    w = int(max(line_width(d0, l, f, sp) for l in ls)) + 40
    h = int(sz * 1.0 * len(ls)) + 30
    img = Image.new("RGBA", (w + 2 * PAD, h + 2 * PAD), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    y = PAD + 8
    for l in ls:
        lw = line_width(d, l, f, sp)
        x = PAD + (w - lw) / 2
        draw_line(d, x + 6, y + 7, l, f, (0, 0, 0, 130), (0, 0, 0, 130), stroke=sw, stroke_fill=(0, 0, 0, 130))
        draw_line(d, x, y, l, f, (0, 0, 0, 0), hi + (255,), stroke=sw, stroke_fill=(255, 255, 255, 255), hi_stroke_fill=(20, 20, 20, 255))
        y += int(sz)
    return img


def s_poster(look, lines, max_h, max_w):
    """Poster drop: heavy letters with a solid offset copy behind them (a designed, not default, look)."""
    words, flags = parse(lines)
    hb, ht, hi, hit = colors(look)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    ls = split_lines(words, flags, 1 if len(words) <= 3 else (3 if len(words) > 7 else 2))
    f, sz = fit(d0, ls, "Archivo Black", 400, max_w - 60, max_h - 40, 1.02)
    off = max(6, sz // 11)
    w = int(max(line_width(d0, l, f, d0.textlength(" ", font=f)) for l in ls)) + off + 40
    h = int(sz * 1.02 * len(ls)) + off + 30
    img = Image.new("RGBA", (w + 2 * PAD, h + 2 * PAD), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    y = PAD + 8
    for l in ls:
        lw = line_width(d, l, f, d.textlength(" ", font=f))
        x = PAD + (w - off - lw) / 2
        draw_line(d, x + off, y + off, l, f, hb + (255,), hb + (255,))
        draw_line(d, x, y, l, f, (255, 255, 255, 255), hi + (255,), stroke=2, stroke_fill=(20, 20, 20, 255))
        y += int(sz * 1.02)
    return img


def s_softpill(look, lines, max_h, max_w):
    """Soft pill: friendly rounded letters on a cream pill with a gentle lift."""
    words, flags = parse(lines)
    hb, ht, hi, hit = colors(look)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    ls = split_lines(words, flags, 1 if len(words) <= 3 else 2)
    f, sz = fit(d0, ls, "Poppins", 800, max_w - 120, max_h - 70, 1.12)
    w = int(max(line_width(d0, l, f, d0.textlength(" ", font=f)) for l in ls)) + 90
    h = int(sz * 1.12 * len(ls)) + 56
    img = Image.new("RGBA", (w + 2 * PAD + 10, h + 2 * PAD + 14), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((PAD, PAD + 8, PAD + w, PAD + 8 + h), radius=h // 2 if len(ls) == 1 else 44, fill=(0, 0, 0, 70))
    d.rounded_rectangle((PAD, PAD, PAD + w, PAD + h), radius=h // 2 if len(ls) == 1 else 44, fill=(252, 246, 236, 255))
    y = PAD + 28
    for l in ls:
        lw = line_width(d, l, f, d.textlength(" ", font=f))
        draw_line(d, PAD + (w - lw) / 2, y, l, f, (38, 38, 34, 255), hi + (255,))
        y += int(sz * 1.12)
    return img


def s_behind(look, lines, max_h, max_w):
    """Huge words with no box. The build puts you in front of them, so the words sit behind your head and shoulders."""
    words, flags = parse(lines)
    hb, ht, hi, hit = colors(look)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    words, flags = words[:3], flags[:3]
    ls = split_lines(words, flags, 1 if len(words) <= 2 else 2)
    f, sz = fit(d0, ls, "Archivo Black", 400, max_w, max_h + 120, 0.98)
    w = int(max(line_width(d0, l, f, d0.textlength(" ", font=f)) for l in ls)) + 40
    h = int(sz * 0.98 * len(ls)) + 30
    img = Image.new("RGBA", (w + 2 * PAD, h + 2 * PAD), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    y = PAD + 6
    for l in ls:
        lw = line_width(d, l, f, d.textlength(" ", font=f))
        x = PAD + (w - lw) / 2
        draw_line(d, x + 6, y + 8, l, f, (0, 0, 0, 110), (0, 0, 0, 110))
        draw_line(d, x, y, l, f, (255, 255, 255, 255), hi + (255,))
        y += int(sz * 0.98)
    return img


STYLES = {
    "box": {"name": "Classic box", "about": "A solid box in your colors. Clear on any picture.", "fn": s_box, "best": "any"},
    "stack": {"name": "Big stack", "about": "Huge words with a heavy outline, no box.", "fn": s_stack, "best": "short"},
    "marker": {"name": "Highlighter", "about": "Dark words on a swiped highlighter.", "fn": s_marker, "best": "medium"},
    "sticker": {"name": "Sticker", "about": "A tilted rounded sticker with a border.", "fn": s_sticker, "best": "short"},
    "serif": {"name": "Editorial", "about": "Elegant serif on a soft dark band.", "fn": s_serif, "best": "medium"},
    "script": {"name": "Handwritten", "about": "Handwriting with a hand-drawn underline.", "fn": s_script, "best": "short"},
    "ribbon": {"name": "Ribbon", "about": "A banner across the top, like a headline.", "fn": s_ribbon, "best": "long"},
    "poster": {"name": "Poster drop", "about": "Heavy letters with a solid shadow copy, like a poster.", "fn": s_poster, "best": "short"},
    "softpill": {"name": "Soft pill", "about": "Friendly rounded letters on a cream pill.", "fn": s_softpill, "best": "medium"},
    "behind": {"name": "Behind you", "about": "Huge words that sit behind your head, so you stand in front of your own headline.", "fn": s_behind, "best": "short"},
    "outline": {"name": "Outline", "about": "Tall outlined letters with colored key words.", "fn": s_outline, "best": "short"},
}


def render(style_id, look, lines, max_h, max_w=940, scale=1.0):
    st = STYLES.get(style_id) or STYLES["box"]
    img = st["fn"](look, lines, max_h, max_w)
    return finish(img, scale)


def suggest(lines, history=()):
    """Style ids, best first. Fits the length of the hook, and avoids the styles used on her last reels."""
    words, _ = parse(lines)
    n = len(words)
    order = (["stack", "poster", "sticker", "outline", "script", "box", "softpill", "marker", "serif", "ribbon"] if n <= 4 else
             ["box", "marker", "softpill", "serif", "stack", "poster", "ribbon", "sticker", "script", "outline"] if n <= 8 else
             ["box", "ribbon", "serif", "marker", "softpill", "stack", "poster", "outline", "script", "sticker"])
    recent = list(history)[-3:]
    fresh = [s for s in order if s not in recent]
    stale = [s for s in order if s in recent]
    return fresh + stale
