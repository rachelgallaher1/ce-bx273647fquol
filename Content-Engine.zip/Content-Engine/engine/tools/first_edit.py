#!/usr/bin/env python3
"""
First edit (Stages 1 and 3 of the video edit step).

Takes a recorded talking video and makes a finished vertical video:
  1. listens to it (free speech tool, runs on her computer)
  2. cuts silences, filler words, and restarted takes (the LAST take of a line wins)
  3. adds a hook at the top and word by word captions in her chosen look
  4. adds automatic graphics: stat cards for numbers, full-screen words for punchy phrases,
     and a "comment" label on the call to action
  5. evens out the sound

It also writes a plan file (<name>_edit1.plan.json) that the edit sheet page will read later.

Run with the engine's speech environment, for example:
  ~/.cache/content-engine/whisper-venv/bin/python -I engine/tools/first_edit.py VIDEO --look 1 --script SCRIPT.md

Only needs a basic ffmpeg and Pillow. It draws all text itself, so it works even when ffmpeg has no
text or subtitle support.
"""
import shutil
import argparse, json, math, os, re, subprocess, sys, time

from PIL import Image, ImageDraw, ImageFont, ImageSequence, ImageFilter, ImageOps

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
W, H, FPS = 1080, 1920, 30
FXSCALE = 1.3  # effects are drawn big, like a designed poster
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
ENGINE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILLERS = {"um", "uh", "er", "erm", "ah", "hmm", "uhh", "umm"}
STOP = set("there's here's that's what's it's i'm i've don't doesn't can't you're we're they're let's the a an and or but so to of in on at for with you your i me my we our it is are was were be been this that just really very like not no do does did have has had can will would could should what when how why there here then than them they their he she his her us if as by from up out about into over".split())
NUMW = {"two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
        "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15, "twenty": 20, "thirty": 30,
        "forty": 40, "fifty": 50, "sixty": 60, "hundred": 100, "thousand": 1000}


def run(cmd, **kw):
    return subprocess.run(cmd, check=True, **kw)


# ---------- 1. listen ----------
def word_list():
    """Her saved word list: customer/rules/word-list.txt. A line is a word to listen for (a name), or `heard => Correct` to fix a mishearing."""
    p = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "customer", "rules", "word-list.txt")
    names, fixes = [], {}
    if os.path.exists(p):
        for ln in open(p, encoding="utf-8"):
            ln = ln.strip()
            if not ln or ln.startswith("#"):
                continue
            if "=>" in ln:
                a, b = [x.strip() for x in ln.split("=>", 1)]
                if a and b:
                    fixes[re.sub(r"[^a-z0-9']", "", a.lower())] = b
                    names.append(b)
            else:
                names.append(ln)
    return names, fixes


def transcribe(video, cache, prompt=""):
    if os.path.exists(cache):
        return json.load(open(cache, encoding="utf-8"))
    from faster_whisper import WhisperModel
    m = WhisperModel("small", device="cpu", compute_type="int8")
    segs, info = m.transcribe(video, word_timestamps=True, vad_filter=True, initial_prompt=prompt or None,
                              vad_parameters=dict(min_silence_duration_ms=300))
    words = []
    for s in segs:
        for w in (s.words or []):
            words.append({"w": w.word.strip(), "s": round(w.start, 3), "e": round(w.end, 3)})
    data = {"language": info.language, "duration": info.duration, "words": words}
    json.dump(data, open(cache, "w", encoding="utf-8"), indent=1)
    return data


# ---------- 2. decide what to cut ----------
def norm(w):
    return re.sub(r"[^a-z0-9']", "", w.lower())


def find_retakes(toks, minlen=3, window=45):
    """If a run of words is said again soon after, the first (earlier) attempt is dropped."""
    drop, i, n = set(), 0, len(toks)
    while i < n:
        hit = None
        for j in range(i + 1, min(n, i + window)):
            k = 0
            while i + k < j and j + k < n and toks[i + k] and toks[i + k] == toks[j + k]:
                k += 1
            if k >= minlen:
                hit = j
                break
        if hit:
            drop.update(range(i, hit))
            i = hit
        else:
            i += 1
    return drop


def plan_cuts(words, gap_keep=0.32, pad_in=0.08, pad_out=0.12, dur=None, cut=(), keep=(), trim=None, edges=None):
    toks = [norm(w["w"]) for w in words]
    reasons = {}
    for i in find_retakes(toks):
        reasons[i] = "restarted take"
    for i, t in enumerate(toks):
        if t in FILLERS:
            reasons[i] = "filler word"
    for i in keep:
        reasons.pop(int(i), None)
    for i in cut:
        reasons[int(i)] = "you cut it"
    kept = [i for i in range(len(words)) if i not in reasons]
    segs = []  # [a, b, first_idx, last_idx]
    for pos, i in enumerate(kept):
        w = words[i]
        if segs and kept[pos - 1] == i - 1 and w["s"] - words[i - 1]["e"] <= gap_keep:
            segs[-1][1] = w["e"] + pad_out
            segs[-1][3] = i
        else:
            a = w["s"] - pad_in
            if segs:
                a = max(a, segs[-1][1])
            segs.append([max(a, 0), w["e"] + pad_out, i, i])
    if dur:
        segs[-1][1] = min(segs[-1][1], dur)
    for k, sec in (trim or {}).items():
        # trim the end of the piece that ends on this word (for a stray breath or a trailing sound)
        for sg in segs:
            if sg[3] == int(k):
                sg[1] = max(sg[0] + 0.1, sg[1] - float(sec))
    # she dragged the ends of a piece on the timeline: "<first word>s" moves the start earlier (+) or later (-), "<last word>e" moves the end later (+) or earlier (-)
    for k, sg in enumerate(segs):
        v = (edges or {}).get(f"{sg[2]}s")
        if v:
            sg[0] = max(0.0, sg[0] - float(v))
        v = (edges or {}).get(f"{sg[3]}e")
        if v:
            sg[1] = sg[1] + float(v)
        if dur:
            sg[1] = min(sg[1], dur)
        if k > 0:
            sg[0] = max(sg[0], segs[k - 1][1])
        sg[1] = max(sg[1], sg[0] + 0.1)
    return segs, reasons, kept


def build_mapper(segs):
    offs, acc = [], 0.0
    for a, b, *_ in segs:
        offs.append(acc)
        acc += b - a

    def mp(t):
        for (a, b, *_), o in zip(segs, offs):
            if a - 1e-6 <= t <= b + 1e-6:
                return o + (t - a)
        return None
    return mp, acc


# ---------- 3. look and fonts ----------
def brand_look(base_id="1"):
    """Her own brand colors (customer/profile/brand.json, from her website or typed in) on a normal look's fonts and shapes."""
    import copy
    bj = os.path.join(os.path.dirname(ENGINE), "customer", "profile", "brand.json")
    if not os.path.exists(bj):
        raise SystemExit("I don't have your brand colors yet. Run brand_colors.py first (or tell me your website).")
    b = json.load(open(bj, encoding="utf-8"))
    cols = [c["hex"] for c in b["colors"]] or ["#2A6E6F"]
    dark = b.get("dark", "#1F1F1F")
    d = json.load(open(os.path.join(ENGINE, "looks", "looks.json"), encoding="utf-8"))
    base = next(l for l in d["looks"] if str(l["id"]) == str(base_id))
    look = copy.deepcopy(base)
    look["id"], look["name"] = "brand", "My brand"

    def on(h):
        return "#FFFFFF" if luminance(h) < 0.55 else dark if luminance(dark) < 0.4 else "#1F1F1F"
    prim = cols[0]
    sec = cols[1] if len(cols) > 1 else cols[0]
    acc = cols[2] if len(cols) > 2 else sec
    # the highlight has to show up on a photo and on white, so prefer the most lively mid-tone color
    lively = sorted(cols, key=lambda h: abs(luminance(h) - 0.5))[0]
    bf_ = brand_font_name()
    if bf_:   # her brand font on the big hook words (captions keep their easy-to-read font)
        look["hookFont"] = bf_
        if isinstance(look.get("display"), dict):
            look["display"] = dict(look["display"], font=bf_)
    look["palette"] = cols[:3]
    look["hook"].update(bg=prim, text=on(prim))
    look["hook"].pop("border", None)
    look["caption"].update(bg="#FFFFFF", text=dark)
    look["highlight"].update(bg=lively, text=on(lively))
    look["accent"].update(bg=acc, text=on(acc))
    return look


def load_look(look):
    if str(look).lower() in ("brand", "my brand"):
        return brand_look()
    d = json.load(open(os.path.join(ENGINE, "looks", "looks.json"), encoding="utf-8"))
    for l in d["looks"]:
        if str(l["id"]) == str(look) or l["name"].lower() == str(look).lower():
            bf_ = brand_font_name()
            if bf_:   # her uploaded brand font on the big hook words, in every look
                import copy
                l = copy.deepcopy(l)
                l["hookFont"] = bf_
                if isinstance(l.get("display"), dict):
                    l["display"]["font"] = bf_
            return l
    raise SystemExit(f"No look called {look}")


FALLBACK = ["/System/Library/Fonts/Supplemental/Arial Rounded Bold.ttf",
            "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
            "/System/Library/Fonts/Helvetica.ttc"]
used_fonts = {}
SKIPPED = []


BRAND_FONTS = os.path.join(ROOT_DIR, "customer", "profile", "brand", "fonts")   # fonts she uploaded on the My brand tab


def find_font(name, italic=False, weight=None):
    key = re.sub(r"[^a-z0-9]", "", name.lower())
    for folder in (BRAND_FONTS, os.path.join(ENGINE, "fonts")):   # her own font files win over the engine's
        if not os.path.isdir(folder):
            continue
        files = sorted(f for f in os.listdir(folder) if f.lower().endswith((".ttf", ".otf")))
        cands = [f for f in files if key in re.sub(r"[^a-z0-9]", "", f.lower())]
        exact = [f for f in cands if re.sub(r"[^a-z0-9]", "", re.split(r"[\[-]", f)[0].lower()) == key]   # "Caveat" means Caveat, not Caveat Brush
        cands = exact or cands
        if italic:
            cands = [f for f in cands if "italic" in f.lower()] or cands
        else:
            cands = [f for f in cands if "italic" not in f.lower()] or cands
        if cands:
            pick = cands[0]
            if weight and len(cands) > 1:
                kw = "black" if weight >= 900 else "extrabold" if weight >= 800 else "bold" if weight >= 700 else "semibold" if weight >= 600 else "medium" if weight >= 500 else "regular"
                if not any(kw in c.lower() for c in cands):
                    kw = "bold" if weight >= 700 else kw
                for c in cands:
                    if kw in c.lower() and not (kw == "bold" and ("semibold" in c.lower() or "extrabold" in c.lower())):
                        pick = c
                        break
            used_fonts[name] = pick
            return os.path.join(folder, pick)
    for f in FALLBACK:
        if os.path.exists(f):
            used_fonts[name] = "fallback: " + os.path.basename(f)
            return f
    raise SystemExit("No font found")


_font_cache = {}


def _has_font(name):
    key = re.sub(r"[^a-z0-9]", "", str(name).lower())
    if not key:
        return False
    for folder in (BRAND_FONTS, os.path.join(ENGINE, "fonts")):
        if os.path.isdir(folder) and any(f.lower().endswith((".ttf", ".otf")) and key in re.sub(r"[^a-z0-9]", "", f.lower()) for f in os.listdir(folder)):
            return True
    return False


def font_set():
    """A picked look's three fonts ({"headline","body","script"}) from brand.json "fontSet", each only if its file is available, else None."""
    try:
        bj = os.path.join(ROOT_DIR, "customer", "profile", "brand.json")
        fs = json.load(open(bj, encoding="utf-8")).get("fontSet") or {}
        out = {k: fs[k] for k in ("headline", "body", "script") if fs.get(k) and _has_font(fs[k])}
        return out or None
    except Exception:
        return None


def brand_font_name():
    """Her brand font (the headline font of a picked look, else the first font on the My brand tab) when its file is available, else None. Her uploaded files and the engine's fonts both count."""
    fs = font_set()
    if fs and fs.get("headline"):
        return fs["headline"]
    try:
        bj = os.path.join(ROOT_DIR, "customer", "profile", "brand.json")
        b = json.load(open(bj, encoding="utf-8"))
        f = (b.get("fonts") or [""])[0]
        return f if f and _has_font(f) else None
    except Exception:
        return None


def load_font(name, size, weight=600, italic=False):
    key = (name, size, weight, italic)
    if key in _font_cache:
        return _font_cache[key]
    path = find_font(name, italic, weight)
    f = ImageFont.truetype(path, size)
    try:
        axes = f.get_variation_axes()
        vals = []
        for ax in axes:
            nm = ax.get("name", b"")
            nm = nm.decode() if isinstance(nm, bytes) else str(nm)
            if "eight" in nm:
                vals.append(max(ax["minimum"], min(ax["maximum"], weight)))
            else:
                vals.append(ax["default"])
        f.set_variation_by_axes(vals)
    except Exception:
        pass
    _font_cache[key] = f
    return f


def hex2rgb(h, a=255):
    h = h.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)


def ease_out_back(x):
    c1, c3 = 1.70158, 2.70158
    x = max(0.0, min(1.0, x))
    return 1 + c3 * (x - 1) ** 3 + c1 * (x - 1) ** 2


def ease_out(x):
    x = max(0.0, min(1.0, x))
    return 1 - (1 - x) ** 3


def scaled(img, s):
    """Resize without dark edges (premultiplied alpha)."""
    if abs(s - 1.0) < 1e-3:
        return img
    w, h = max(1, int(img.width * s)), max(1, int(img.height * s))
    return img.convert("RGBa").resize((w, h), Image.BICUBIC).convert("RGBA")


def rotated(img, deg):
    if not deg:
        return img
    return img.convert("RGBa").rotate(deg, resample=Image.BICUBIC, expand=True).convert("RGBA")


def paste_center(frame, img, cx, cy, scale=1.0, alpha=1.0):
    img = scaled(img, scale)
    if alpha < 1.0:
        a = img.getchannel("A").point(lambda v: int(v * alpha))
        img = img.copy()
        img.putalpha(a)
    frame.alpha_composite(img, (int(cx - img.width / 2), int(cy - img.height / 2)))


def text_w(d, t, f):
    return d.textlength(t, font=f)


def fit_size(lines, name, weight, start, max_w, italic=False):
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    size = start
    while size > 24:
        f = load_font(name, size, weight, italic)
        if all(text_w(d0, ln, f) <= max_w for ln in lines):
            return f
        size -= 4
    return load_font(name, 24, weight, italic)


# ---------- design polish: display type, depth, gradients ----------
def display_font(look, size):
    d = look.get("display") or {}
    return load_font(d.get("font") or look["hookFont"], size, d.get("weight", 700))


def fit_display(look, lines, start, max_w, step=6):
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    size = start
    while size > 40:
        f = display_font(look, size)
        if all(d0.textlength(ln, font=f) <= max_w for ln in lines):
            return f
        size -= step
    return display_font(look, 40)


def shadowed(img, blur=16, dy=12, alpha=120):
    """A soft shadow under a picture, so cards feel lifted."""
    pad = blur * 3
    base = Image.new("RGBA", (img.width + pad * 2, img.height + pad * 2 + dy), (0, 0, 0, 0))
    sh = Image.new("RGBA", base.size, (0, 0, 0, 0))
    a = img.getchannel("A").point(lambda v: int(v * alpha / 255))
    sh.paste((0, 0, 0, 255), (pad, pad + dy), a)
    sh = sh.filter(ImageFilter.GaussianBlur(blur))
    base.alpha_composite(sh)
    base.alpha_composite(img, (pad, pad))
    return base


def gradient(w, h, color, max_alpha, from_top=True):
    g = Image.linear_gradient("L").resize((w, h))
    if from_top:
        g = ImageOps.invert(g)
    a = g.point(lambda v: int((v / 255) ** 1.5 * max_alpha))
    img = Image.new("RGBA", (w, h), tuple(color) + (0,))
    img.putalpha(a)
    return img


def scrim_color(look):
    c = look["caption"]["bg"]
    return hex2rgb(c)[:3] if luminance(c) < 0.35 else (16, 16, 22)


# ---------- 4. drawing the pieces ----------
def render_blocks(look, lines, start_size, max_w, tilt=0, outline=True, shadow=False, big=False):
    """Stacked color blocks (hook and full-screen words)."""
    f = fit_size(lines, look["hookFont"], look.get("hookWeight", 600), start_size, max_w - 80,
                 italic=look.get("hookStyle") == "italic")
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    pad_x, pad_y, gap = 34, 16, 10
    blocks = []
    for i, ln in enumerate(lines):
        bb = d0.textbbox((0, 0), ln, font=f)
        bg = look["hook"]["bg"] if i % 2 == 0 else look["highlight"]["bg"]
        fg = look["hook"]["text"] if i % 2 == 0 else look["highlight"]["text"]
        blocks.append((ln, bb, bg, fg))
    wmax = max(b[1][2] - b[1][0] for b in blocks) + pad_x * 2
    heights = [(b[1][3] - b[1][1]) + pad_y * 2 + int(f.size * 0.22) for b in blocks]
    img = Image.new("RGBA", (wmax + 40, sum(heights) + gap * (len(blocks) - 1) + 40), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    y = 14
    for (ln, bb, bg, fg), bh in zip(blocks, heights):
        tw = bb[2] - bb[0]
        bw = tw + pad_x * 2
        x = (img.width - bw) // 2
        if shadow:
            d.rounded_rectangle((x + 8, y + 8, x + bw + 8, y + bh + 8), radius=22, fill=hex2rgb("#1F1F1F"))
        d.rounded_rectangle((x, y, x + bw, y + bh), radius=22, fill=hex2rgb(bg),
                            outline=hex2rgb("#1F1F1F") if outline else None, width=5)
        d.text((x + pad_x - bb[0], y + pad_y - bb[1] + int(f.size * 0.04)), ln, font=f, fill=hex2rgb(fg))
        y += bh + gap
    return rotated(img, tilt)


def _balanced(text, n):
    """Split text into n lines of about equal length, keeping words whole."""
    words = text.split()
    if n <= 1 or len(words) <= 1:
        return [text]
    target = len(text) / n
    out, cur = [], []
    for w in words:
        if cur and len(" ".join(cur + [w])) > target * 1.15 and len(out) < n - 1:
            out.append(" ".join(cur))
            cur = []
        cur.append(w)
    out.append(" ".join(cur))
    return out


def render_hook(look, lines, max_h=360, max_w=940):
    """The hook: one or two huge lines at the top of the screen, inside a solid box in her look's colors so it stands out on any picture.
    The text fills the height, then is stretched sideways to use the width. No small label."""
    parts = [x.strip() for x in lines if x.strip()]
    text = " ".join(parts).upper()
    if len(text.split()) > 7 and len(parts) > 1:
        text = parts[-1].upper()
    # words between *stars* are highlighted, like: IF YOU *HATE PLANNING* OUT YOUR SOCIAL CONTENT
    flags, plain, on = [], [], False
    for tok in text.split():
        star_start, star_end = tok.startswith("*"), tok.endswith("*") and len(tok) > 1
        if star_start:
            on = True
        flags.append(on)
        plain.append(tok.strip("*"))
        if star_end or (star_start and tok.endswith("*")):
            on = False
    text = " ".join(plain)
    nwords = len(plain)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    pad_x, pad_y = 44, 18
    inner_h = max_h - 2 * pad_y

    def fit_layout(nlines):
        lines_ = _balanced(text, nlines)
        sz = int(inner_h / len(lines_) * 0.98)
        fnt = display_font(look, sz)
        wide = max(d0.textlength(l, font=fnt) for l in lines_)
        while max_w / wide < 0.8 and sz > 40:
            sz -= 4
            fnt = display_font(look, sz)
            wide = max(d0.textlength(l, font=fnt) for l in lines_)
        return lines_, sz, fnt, wide
    # one line for a very short hook, two lines for everything else (she prefers two lines), as big as the space allows
    cands = [fit_layout(1)] if nwords <= 3 else [fit_layout(2)]
    ls, size, f, widest = cands[0]
    sx = min(max(max_w / widest, 0.8), 1.3)
    lh = int(size * 1.0)
    box_bg = hex2rgb(look["hook"]["bg"])[:3] + (255,)
    txt_col = hex2rgb(look["hook"]["text"])[:3] + (255,)
    edge = hex2rgb(look["highlight"]["bg"])[:3] + (255,)
    if luminance(look["hook"]["bg"]) > 0.6 and luminance(look["highlight"]["bg"]) > 0.6:
        edge = (20, 20, 22, 255)
    hi_col = hex2rgb(look["highlight"]["bg"])[:3] + (255,)
    if luminance(look["highlight"]["bg"]) < 0.25:
        hi_col = tuple(min(255, int(c * 1.8) + 40) for c in hi_col[:3]) + (255,)
    rows, wi = [], 0
    for ln in ls:
        w = int(d0.textlength(ln, font=f)) + 24
        row = Image.new("RGBA", (w, lh + 24), (0, 0, 0, 0))
        rd = ImageDraw.Draw(row)
        x = 12
        space = d0.textlength(" ", font=f)
        for word in ln.split():
            rd.text((x, 4), word, font=f, fill=hi_col if wi < len(flags) and flags[wi] else txt_col)
            x += d0.textlength(word, font=f) + space
            wi += 1
        rows.append(row.resize((int(row.width * sx), row.height), Image.LANCZOS))
    tw = max(r.width for r in rows)
    th = int(lh * 0.98) * len(rows) + 16
    bw, bh = tw + 2 * pad_x, th + 2 * pad_y
    img = Image.new("RGBA", (bw + 30, bh + 30), (0, 0, 0, 0))
    box = Image.new("RGBA", (bw, bh), (0, 0, 0, 0))
    bd = ImageDraw.Draw(box)
    bd.rounded_rectangle((0, 0, bw - 1, bh - 1), radius=34, fill=box_bg, outline=edge, width=9)
    y = pad_y
    for r in rows:
        box.alpha_composite(r, ((bw - r.width) // 2, y))
        y += int(lh * 0.98)
    img.alpha_composite(shadowed(box, blur=14, dy=10, alpha=140) if False else box, (15, 10))
    return img


def render_plain_words(look, lines, start_size, max_w):
    """Big editorial words, no blocks."""
    f = fit_size(lines, look["hookFont"], look.get("hookWeight", 600), start_size, max_w,
                 italic=look.get("hookStyle") == "italic")
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    lh = int(f.size * 1.15)
    img = Image.new("RGBA", (max_w + 60, lh * len(lines) + 40), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for i, ln in enumerate(lines):
        w = text_w(d0, ln, f)
        d.text(((img.width - w) / 2, 14 + i * lh), ln, font=f, fill=hex2rgb(look["hook"]["bg"]))
    return img


def render_takeover(look, text, hi=None):
    """Words that take over the screen: huge bold condensed caps, tight lines, one word in the look color."""
    words = text.upper().split()
    per = 1 if len(words) <= 3 else 2
    lines = [" ".join(words[i:i + per]) for i in range(0, len(words), per)]
    f = fit_display(look, lines, 420, 880)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    lh = int(f.size * 1.02)
    img = Image.new("RGBA", (1100, lh * len(lines) + int(f.size * 0.8) + 120), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    longest = max(range(len(words)), key=lambda i: len(norm(words[i])))
    if hi:
        for i, w in enumerate(words):
            if norm(w) == norm(hi):
                longest = i
    sw = max(7, f.size // 20)
    wi = 0
    for li, ln in enumerate(lines):
        parts = ln.split()
        space = d0.textlength(" ", font=f)
        total = sum(d0.textlength(w, font=f) for w in parts) + space * (len(parts) - 1)
        x = (img.width - total) / 2
        for w in parts:
            col = hl_color(look) if wi == longest else (255, 255, 255, 255)
            d.text((x, 36 + li * lh + 10), w, font=f, fill=(0, 0, 0, 120), stroke_width=sw, stroke_fill=(0, 0, 0, 120))
            d.text((x, 36 + li * lh), w, font=f, fill=col, stroke_width=sw, stroke_fill=(20, 20, 20, 235))
            x += d0.textlength(w, font=f) + space
            wi += 1
    box = img.getbbox()
    if box:
        pad = 28
        img = img.crop((max(0, box[0] - pad), max(0, box[1] - pad), min(img.width, box[2] + pad), min(img.height, box[3] + pad)))
    return img


def render_stat(look, number, label):
    a = look["accent"]
    fn = display_font(look, 250)
    fl = display_font(look, 62)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    lab = label.upper()
    bn = d0.textbbox((0, 0), number, font=fn)
    bl = d0.textbbox((0, 0), lab, font=fl)
    wmax = max(bn[2] - bn[0], bl[2] - bl[0])
    pad = 44
    w, h = wmax + pad * 2, (bn[3] - bn[1]) + (bl[3] - bl[1]) + pad * 2 + 30
    img = Image.new("RGBA", (w + 24, h + 24), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((12, 12, 12 + w, 12 + h), radius=40, fill=hex2rgb(a["bg"]),
                        outline=hex2rgb("#1F1F1F") if look["hook"].get("border") else None, width=5)
    d.text((12 + (w - (bn[2] - bn[0])) / 2 - bn[0], 12 + pad - bn[1]), number, font=fn, fill=hex2rgb(a["text"]))
    d.text((12 + (w - (bl[2] - bl[0])) / 2 - bl[0], 12 + pad + (bn[3] - bn[1]) + 30 - bl[1]), lab, font=fl, fill=hex2rgb(a["text"]))
    return shadowed(rotated(img, -3 if look["mood"] == "bubbly" else 0))


def render_pill(look, text):
    a = look["accent"]
    f = load_font(look["captionFont"], 58, 700)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    bb = d0.textbbox((0, 0), text, font=f)
    w, h = bb[2] - bb[0] + 80, bb[3] - bb[1] + 44
    img = Image.new("RGBA", (w + 16, h + 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((8, 8, 8 + w, 8 + h), radius=h // 2, fill=hex2rgb(a["bg"]),
                        outline=hex2rgb("#1F1F1F") if look["hook"].get("border") else None, width=5)
    d.text((8 + 40 - bb[0], 8 + 22 - bb[1]), text, font=f, fill=hex2rgb(a["text"]))
    return shadowed(img)


def render_caption(look, words, hi_idx, font, max_w=900):
    cap = look["caption"]
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    space = d0.textlength(" ", font=font)
    lines, cur, curw = [], [], 0
    for i, w in enumerate(words):
        ww = d0.textlength(w, font=font)
        if cur and curw + space + ww > max_w:
            lines.append(cur)
            cur, curw = [], 0
        cur.append((i, w, ww))
        curw += (space if len(cur) > 1 else 0) + ww
    if cur:
        lines.append(cur)
    lh = int(font.size * 1.35)
    pad_x, pad_y = 36, 20
    wmax = max(sum(x[2] for x in ln) + space * (len(ln) - 1) for ln in lines)
    img = Image.new("RGBA", (int(wmax + pad_x * 2 + 8), int(lh * len(lines) + pad_y * 2 + 8)), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((4, 4, img.width - 4, img.height - 4), radius=34, fill=hex2rgb(cap["bg"]),
                        outline=hex2rgb("#1F1F1F") if cap.get("border") else None, width=5)
    y = 4 + pad_y
    for ln in lines:
        lw = sum(x[2] for x in ln) + space * (len(ln) - 1)
        x = (img.width - lw) / 2
        for i, w, ww in ln:
            if i == hi_idx:
                d.rounded_rectangle((x - 10, y + 6, x + ww + 10, y + lh - 6), radius=14, fill=hex2rgb(look["highlight"]["bg"]))
                col = hex2rgb(look["highlight"]["text"])
            else:
                col = hex2rgb(cap["text"])
            d.text((x, y), w, font=font, fill=col)
            x += ww + space
        y += lh
    return img


def luminance(h):
    r, g, b, _ = hex2rgb(h)
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255


def hl_color(look):
    for c in (look["highlight"]["bg"], look["hook"]["bg"], look["accent"]["bg"]):
        if luminance(c) > 0.45:
            return hex2rgb(c)
    return hex2rgb(look["highlight"]["bg"])


def render_caption_plain(look, words, hi_idx, font, max_w=940):
    """Plain white words with a thin dark outline (easy to read on any picture), no box."""
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    space = d0.textlength(" ", font=font)
    lines, cur, curw = [], [], 0
    for i, w in enumerate(words):
        ww = d0.textlength(w, font=font)
        if cur and curw + space + ww > max_w:
            lines.append(cur)
            cur, curw = [], 0
        cur.append((i, w, ww))
        curw += (space if len(cur) > 1 else 0) + ww
    if cur:
        lines.append(cur)
    lh = int(font.size * 1.3)
    sw = max(4, font.size // 14)
    wmax = max(sum(x[2] for x in ln) + space * (len(ln) - 1) for ln in lines)
    img = Image.new("RGBA", (int(wmax + 60), int(lh * len(lines) + 50)), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    y = 20
    for ln in lines:
        lw = sum(x[2] for x in ln) + space * (len(ln) - 1)
        x = (img.width - lw) / 2
        for i, w, ww in ln:
            col = hl_color(look) if i == hi_idx else (255, 255, 255, 255)
            d.text((x, y + 5), w, font=font, fill=(0, 0, 0, 90), stroke_width=sw, stroke_fill=(0, 0, 0, 90))
            d.text((x, y), w, font=font, fill=col, stroke_width=sw, stroke_fill=(20, 20, 20, 235))
            x += ww + space
        y += lh
    return img


def _words_layout(words, font, max_w):
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    space = d0.textlength(" ", font=font)
    lines, cur, curw = [], [], 0
    for i, w in enumerate(words):
        ww = d0.textlength(w, font=font)
        if cur and curw + space + ww > max_w:
            lines.append(cur)
            cur, curw = [], 0
        cur.append((i, w, ww))
        curw += (space if len(cur) > 1 else 0) + ww
    if cur:
        lines.append(cur)
    return lines, space


def render_caption_soft(look, words, hi_idx, font, max_w=940):
    """Karaoke Soft (her font spec C2): sentence case, soft lift shadow, the spoken word sits in an accent box."""
    words = [re.sub(r"[.,;:]+$", "", w) or w for w in words]
    lines, space = _words_layout(words, font, max_w)
    lh = int(font.size * 1.3)
    sw = max(5, int(font.size * 0.12))
    wmax = max(sum(x[2] for x in ln) + space * (len(ln) - 1) for ln in lines)
    img = Image.new("RGBA", (int(wmax + 80), int(lh * len(lines) + 60)), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    box = hl_color(look)
    boxtxt = (255, 255, 255, 255) if luminance("#%02x%02x%02x" % box[:3]) < 0.55 else (25, 25, 25, 255)
    y = 24
    for ln in lines:
        lw = sum(x[2] for x in ln) + space * (len(ln) - 1)
        x = (img.width - lw) / 2
        for i, w, ww in ln:
            if i == hi_idx:
                d.rounded_rectangle((x - 14, y + 4, x + ww + 14, y + lh - 8), radius=18, fill=box)
                d.text((x, y), w, font=font, fill=boxtxt)
            else:
                d.text((x, y + 7), w, font=font, fill=(0, 0, 0, 110), stroke_width=sw, stroke_fill=(0, 0, 0, 110))
                d.text((x, y), w, font=font, fill=(255, 255, 255, 255), stroke_width=sw, stroke_fill=(20, 20, 20, 240))
            x += ww + space
        y += lh
    return img


def render_caption_phrase(look, words, hi_idx, font, max_w=900):
    """Phrase Clean (C3): a calm sentence-case phrase, thick dark outline, one accent keyword."""
    lines, space = _words_layout(words, font, max_w)
    lh = int(font.size * 1.3)
    sw = max(4, int(font.size * 0.09))
    wmax = max(sum(x[2] for x in ln) + space * (len(ln) - 1) for ln in lines)
    img = Image.new("RGBA", (int(wmax + 70), int(lh * len(lines) + 50)), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    y = 20
    for ln in lines:
        lw = sum(x[2] for x in ln) + space * (len(ln) - 1)
        x = (img.width - lw) / 2
        for i, w, ww in ln:
            col = hl_color(look) if i == hi_idx else (255, 255, 255, 255)
            d.text((x, y + 6), w, font=font, fill=(0, 0, 0, 100), stroke_width=sw, stroke_fill=(0, 0, 0, 100))
            d.text((x, y), w, font=font, fill=col, stroke_width=sw, stroke_fill=(20, 20, 20, 240))
            x += ww + space
        y += lh
    return img


def render_caption_past(look, words, hi_idx, font, max_w=900):
    """Past-me captions: a muted typewriter voice, for the 'before' part of a story."""
    lines, space = _words_layout(words, font, max_w)
    lh = int(font.size * 1.3)
    wmax = max(sum(x[2] for x in ln) + space * (len(ln) - 1) for ln in lines)
    img = Image.new("RGBA", (int(wmax + 70), int(lh * len(lines) + 50)), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    y = 20
    for ln in lines:
        lw = sum(x[2] for x in ln) + space * (len(ln) - 1)
        x = (img.width - lw) / 2
        for i, w, ww in ln:
            d.text((x, y + 5), w, font=font, fill=(0, 0, 0, 100), stroke_width=4, stroke_fill=(0, 0, 0, 100))
            d.text((x, y), w, font=font, fill=(205, 200, 190, 255), stroke_width=4, stroke_fill=(20, 20, 20, 240))
            x += ww + space
        y += lh
    return img


def render_caption_boxed(look, words, hi_idx, font, max_w=880):
    """Boxed Broadcast (C4): white words on a dark rounded box. Best on busy or bright footage."""
    lines, space = _words_layout(words, font, max_w)
    lh = int(font.size * 1.35)
    pad_x, pad_y = 40, 24
    wmax = max(sum(x[2] for x in ln) + space * (len(ln) - 1) for ln in lines)
    img = Image.new("RGBA", (int(wmax + pad_x * 2), int(lh * len(lines) + pad_y * 2)), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0, 0, img.width - 1, img.height - 1), radius=30, fill=(0, 0, 0, 190))
    y = pad_y
    for ln in lines:
        lw = sum(x[2] for x in ln) + space * (len(ln) - 1)
        x = (img.width - lw) / 2
        for i, w, ww in ln:
            d.text((x, y), w, font=font, fill=hl_color(look) if i == hi_idx else (255, 255, 255, 255))
            x += ww + space
        y += lh
    return img


CAPTION_STYLES = [
    {"id": "soft", "name": "Lit-up word", "about": "Short bursts of words. The word you are saying lights up in a box.", "suggested": True},
    {"id": "phrase", "name": "Calm phrases", "about": "A short phrase at a time, one key word in color. Gentle and easy to read.", "suggested": True},
    {"id": "boxed", "name": "On a dark box", "about": "Words on a dark box. Easiest to read when the picture is busy.", "suggested": True},
    {"id": "pop", "name": "Big bouncy word", "about": "One huge word at a time that pops in.", "suggested": False},
    {"id": "karaoke", "name": "Line with lit word", "about": "A line of words with the spoken word in color.", "suggested": False},
    {"id": "lines", "name": "Plain lines", "about": "A calm line of words at the bottom.", "suggested": False},
]


def render_caption_style(style, look, words, hi_idx):
    """One caption picture for a style. The build and the live editor both use this, so they match."""
    if style == "soft":
        return render_caption_soft(look, words, hi_idx, load_font("Poppins", 68, 800))
    if style == "phrase":
        return render_caption_phrase(look, words, hi_idx, load_font("Inter", 60, 700))
    if style == "boxed":
        return render_caption_boxed(look, words, hi_idx, load_font("Roboto", 54, 700))
    return render_caption_plain(look, words, hi_idx, load_font(look["captionFont"], 70, max(600, look.get("captionWeight", 600))))


def chunk_words(items, out_gap=0.35, max_words=4):
    chunks, cur = [], []
    for it in items:
        if cur and (len(cur) >= max_words or it["os"] - cur[-1]["oe"] > out_gap or re.search(r"[.?!]$", cur[-1]["w"])):
            chunks.append(cur)
            cur = []
        cur.append(it)
    if cur:
        chunks.append(cur)
    return chunks


def pick_highlight(chunk):
    best, bl = -1, 0
    for i, it in enumerate(chunk):
        t = norm(it["w"])
        if t not in STOP and len(t) > bl and len(t) >= 5:
            best, bl = i, len(t)
    return best


# ---------- 5. automatic graphics ----------
def clean(w):
    return re.sub(r"[^\w$%'\-]", "", w)


def find_graphics(items, total, hook_secs, cta=None, picks=None):
    gfx = []
    taken = []

    def free(a, b):
        return all(b < x or a > y for x, y in taken)

    # stat cards: numbers and what they count
    last = -99
    for k, it in enumerate(items):
        raw = it["w"].strip(".,?!")
        low = raw.lower()
        num = None
        if re.match(r"^\$?\d[\d,\.]*[kK%]?$", raw):
            num = raw
        elif low in NUMW:
            num = str(NUMW[low])
        if not num or it["os"] < hook_secs + 0.5 or it["os"] - last < 6:
            continue
        label_words = []
        for nx in items[k + 1:k + 3]:
            c = clean(nx["w"]).lower()
            if not c or c in STOP:
                break
            label_words.append(c)
            if nx["w"].endswith((".", "?", "!", ",")):
                break
        label = " ".join(label_words[:2]).strip()
        if not label:
            continue
        a, b = it["os"] - 0.1, it["os"] + 2.8
        if free(a, b):
            gfx.append({"type": "stat", "start": a, "end": b, "number": num, "label": label})
            taken.append((a, b))
            last = it["os"]

    # full-screen words chosen by phrase (Claude reads the sentences list in the plan and picks the best ones)
    if picks is not None:
        toks = [norm(i["w"]) for i in items]
        for pk in picks:
            want = [norm(x) for x in pk["phrase"].split()]
            at = next((k for k in range(len(toks) - len(want) + 1) if toks[k:k + len(want)] == want), None)
            label = "Full-screen words \u201c" + pk.get("text", pk["phrase"]) + "\u201d"
            if at is None:
                SKIPPED.append(f"{label}: I couldn't find those exact words in your video. Pick the words from a line instead of typing them.")
                continue
            a = items[at]["os"] - 0.05
            b = max(a + 1.8, items[at + len(want) - 1]["oe"] + 0.6)
            if a < hook_secs + 0.3:
                SKIPPED.append(f"{label}: that's during your hook (the first {hook_secs:.0f} seconds). Pick a later line.")
            elif not free(a, b):
                SKIPPED.append(f"{label}: another graphic is already at that spot. Remove it or pick a different line.")
            else:
                gfx.append({"type": "punch", "start": a, "end": b, "text": pk.get("text", pk["phrase"]),
                            "hi": pk.get("hi"), "phrase": pk["phrase"], "pick": pk})
                taken.append((a, b))
        gfx.sort(key=lambda g: g["start"])
        return gfx

    # full-screen words: punchy end of a sentence
    cands, cur = [], []
    for ki, it in enumerate(items):
        cur.append(it)
        if sentence_end(it["w"], len(cur), (items[ki + 1]["os"] - it["oe"]) if ki + 1 < len(items) else 9):
            if len(cur) >= 5:
                tail = cur[-3:] if len(cur) >= 7 else cur[-2:]
                score = sum(1 for t in tail if norm(t["w"]) not in STOP and len(norm(t["w"])) >= 6)
                text = " ".join(clean(t["w"]) for t in tail).strip()
                cands.append((score, tail, text))
            cur = []
    cands = [c for c in cands if c[0] >= 1 and 2 <= len(c[1]) <= 3]
    cands.sort(key=lambda c: (-c[0], c[1][0]["os"]))
    chosen = []
    for score, tail, text in cands:
        a = tail[0]["os"] - 0.05
        b = max(a + 1.5, tail[-1]["oe"] + 0.5)
        if a < hook_secs + 1.0 or b > total - 1.5:
            continue
        if not free(a, b) or any(abs(a - c) < 9 for c in chosen):
            continue
        text = text[:1].upper() + text[1:]
        gfx.append({"type": "punch", "start": a, "end": b, "text": text})
        taken.append((a, b))
        chosen.append(a)
        if len(chosen) >= 3:
            break

    # call to action label (off by default: it tended to land on the face)
    if cta and False:
        for k, it in enumerate(items):
            if norm(it["w"]) == "comment" and it["os"] > total * 0.6:
                a = it["os"] - 0.1
                spoken = clean(items[k + 1]["w"]).upper() if k + 1 < len(items) else ""
                word = spoken if spoken and spoken.lower() not in STOP else cta.upper()
                gfx.append({"type": "pill", "start": a, "end": min(total, a + 4.5), "text": "COMMENT  " + word})
                break
    gfx.sort(key=lambda g: g["start"])
    return gfx


# ---------- GIFs and stickers (her own files, or a search with her free Giphy key) ----------
def giphy_key():
    k = os.environ.get("GIPHY_API_KEY")
    if k:
        return k.strip()
    p = os.path.expanduser("~/.cache/content-engine/giphy.key")
    return open(p, encoding="utf-8").read().strip() if os.path.exists(p) else None


def download_url(u, work):
    import urllib.request, hashlib
    try:
        os.makedirs(os.path.join(work, "gifs"), exist_ok=True)
        out = os.path.join(work, "gifs", hashlib.md5(u.encode()).hexdigest() + ".gif")
        if not os.path.exists(out):
            open(out, "wb").write(urllib.request.urlopen(u, timeout=30).read())
        return out
    except Exception as e:
        print("    (download failed:", e, ")")
        return None


def fetch_gif(query, work, sticker=False):
    """Search Giphy (G rated) and download the first result. Returns a file path, or None."""
    import urllib.request, urllib.parse, hashlib
    key = giphy_key()
    if not key:
        return None
    kind = "stickers" if sticker else "gifs"
    url = (f"https://api.giphy.com/v1/{kind}/search?api_key={key}&q={urllib.parse.quote(query)}"
           f"&limit=6&rating=g&lang=en")
    try:
        data = json.loads(urllib.request.urlopen(url, timeout=30).read())
        os.makedirs(os.path.join(work, "gifs"), exist_ok=True)
        for r in data.get("data", []):
            u = r["images"]["fixed_width"]["url"]
            out = os.path.join(work, "gifs", hashlib.md5(u.encode()).hexdigest() + ".gif")
            if not os.path.exists(out):
                open(out, "wb").write(urllib.request.urlopen(u, timeout=30).read())
            return out
    except Exception as e:
        print("    (GIF search failed:", e, ")")
    return None


def pexels_key():
    k = os.environ.get("PEXELS_API_KEY")
    if k:
        return k.strip()
    p = os.path.expanduser("~/.cache/content-engine/pexels.key")
    return open(p, encoding="utf-8").read().strip() if os.path.exists(p) else None


def fetch_photo(query, work):
    """Free stock photo from Pexels (commercial use allowed). Returns a file path, or None."""
    import urllib.request, urllib.parse, hashlib
    key = pexels_key()
    if not key:
        return None
    try:
        req = urllib.request.Request(f"https://api.pexels.com/v1/search?query={urllib.parse.quote(query)}&per_page=5",
                                     headers={"Authorization": key, "User-Agent": "content-engine"})
        data = json.loads(urllib.request.urlopen(req, timeout=30).read())
        os.makedirs(os.path.join(work, "gifs"), exist_ok=True)
        for r in data.get("photos", []):
            u = r["src"]["medium"]
            out = os.path.join(work, "gifs", hashlib.md5(u.encode()).hexdigest() + ".jpg")
            if not os.path.exists(out):
                open(out, "wb").write(urllib.request.urlopen(u, timeout=30).read())
            return out
    except Exception as e:
        print("    (photo search failed:", e, ")")
    return None


def load_gif(path, width, framed=True):
    im = Image.open(path)
    frames, durs = [], []
    for fr in ImageSequence.Iterator(im):
        f = fr.convert("RGBA")
        f = f.resize((width, max(1, int(f.height * width / f.width))), Image.LANCZOS)
        if framed:
            pad = 14
            box = Image.new("RGBA", (f.width + pad * 2, f.height + pad * 2), (0, 0, 0, 0))
            d = ImageDraw.Draw(box)
            d.rounded_rectangle((0, 0, box.width - 1, box.height - 1), radius=26, fill=(255, 255, 255, 255))
            mask = Image.new("L", f.size, 0)
            ImageDraw.Draw(mask).rounded_rectangle((0, 0, f.width - 1, f.height - 1), radius=16, fill=255)
            box.paste(f, (pad, pad), mask)
            f = shadowed(rotated(box, -3), blur=12, dy=10, alpha=110)
        frames.append(f)
        durs.append(max(0.03, fr.info.get("duration", 80) / 1000))
    return frames, durs


def own_gif(query, phrase=""):
    """A picture from HER OWN folder (customer/profile/gifs/) whose file name shares a word with the search, tried before Giphy."""
    d = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "customer", "profile", "gifs")
    if not os.path.isdir(d):
        return None
    want = set(re.findall(r"[a-z0-9']+", (query + " " + phrase).lower())) - {"a", "the", "of", "and", "to", "in", "is", "it"}
    best, score = None, 0
    for f in sorted(os.listdir(d)):
        if not f.lower().endswith((".gif", ".png", ".jpg", ".jpeg", ".webp")):
            continue
        have = set(re.findall(r"[a-z0-9']+", os.path.splitext(f)[0].lower()))
        sc = len(want & have)
        if sc > score:
            best, score = os.path.join(d, f), sc
    return best


def find_gifs(items, picks, work, existing, hook_secs):
    out = []
    toks = [norm(i["w"]) for i in items]
    busy = [(g["start"], g["end"]) for g in existing]
    for pk in picks or []:
        want = [norm(x) for x in pk["phrase"].split()]
        at = next((k for k in range(len(toks) - len(want) + 1) if toks[k:k + len(want)] == want), None)
        if at is None:
            SKIPPED.append(f"GIF on \u201c{pk['phrase']}\u201d: I couldn't find those exact words in your video.")
            continue
        a = items[at]["os"] - 0.1
        b = a + pk.get("seconds", 2.6)
        if a < hook_secs + 0.3 or any(not (b < x or a > y) for x, y in busy + [(g["start"], g["end"]) for g in out]):
            why = "that's during your hook" if a < hook_secs + 0.3 else "another graphic is already at that spot"
            SKIPPED.append(f"GIF on \u201c{pk['phrase']}\u201d: {why}. Pick a different line.")
            continue
        if pk.get("url") and not pk.get("file"):
            path = download_url(pk["url"], work)
        elif pk.get("photo") and not pk.get("file"):
            path = fetch_photo(pk.get("query", pk["phrase"]), work)
        else:
            path = pk.get("file") or own_gif(pk.get("query", pk["phrase"]), pk["phrase"]) or fetch_gif(pk.get("query", pk["phrase"]), work, pk.get("sticker", False))
        if not path or not os.path.exists(path):
            SKIPPED.append(f"GIF on \u201c{pk['phrase']}\u201d: I couldn't get a picture (no Giphy key, or nothing found).")
            continue
        sticker = bool(pk.get("sticker", False)) and not pk.get("file")
        frames, durs = load_gif(path, pk.get("size", 560), framed=not sticker)
        out.append({"type": "gif", "start": a, "end": b, "phrase": pk["phrase"], "frames": frames, "durs": durs,
                    "source": os.path.basename(path), "mode": pk.get("mode", "behind"), "pick": pk})
    return out


# ---------- putting a picture BEHIND her (cut her out, then lay her back on top) ----------
def is_hdr(video):
    """iPhone video is often HDR (HLG or PQ). Treated as ordinary video it looks flat and gray, so it gets a light color lift."""
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=color_transfer", "-of", "csv=p=0", video],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    return r.stdout.strip().split(",")[0] in ("arib-std-b67", "smpte2084")


def source_geometry(video):
    """Width and height of the picture as it is shown (phones store video sideways and mark it as turned)."""
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height:stream_side_data=rotation:stream_tags=rotate",
                        "-of", "json", video], capture_output=True, text=True, encoding="utf-8", errors="replace")
    st = json.loads(r.stdout)["streams"][0]
    w, h = st["width"], st["height"]
    rot = 0
    for sd in st.get("side_data_list", []):
        if "rotation" in sd:
            rot = int(sd["rotation"])
    rot = rot or int(st.get("tags", {}).get("rotate", 0) or 0)
    if abs(rot) in (90, 270):
        w, h = h, w
    return w, h


def face_track(video, dur, w, h, step=0.5):
    """Where her face is, left to right, every half second (0 to 1). Used to keep her in a tall crop of a wide video."""
    import cv2
    cap = cv2.VideoCapture(video)
    try:
        cap.set(cv2.CAP_PROP_ORIENTATION_AUTO, 1)
    except Exception:
        pass
    casc = cv2.CascadeClassifier(os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml"))
    pts, last, t = [], 0.5, 0.0
    while t <= dur:
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ok, fr = cap.read()
        if ok:
            sc = 480.0 / max(fr.shape[:2])
            g = cv2.cvtColor(cv2.resize(fr, (int(fr.shape[1] * sc), int(fr.shape[0] * sc))), cv2.COLOR_BGR2GRAY)
            faces = casc.detectMultiScale(g, 1.1, 5, minSize=(int(g.shape[0] * 0.08),) * 2)
            if len(faces):
                x, y, fw, fh = max(faces, key=lambda f: f[2] * f[3])
                last = (x + fw / 2) / g.shape[1]
        pts.append((t, last))
        t += step
    # smooth, so the crop glides and never jumps
    sm = []
    for i in range(len(pts)):
        win = [p[1] for p in pts[max(0, i - 3):i + 4]]
        sm.append((pts[i][0], sum(win) / len(win)))
    return sm


def reframe_x(track, src_w, crop_w, t0, t1=None):
    """A moving crop position for ffmpeg, as a function of time inside a cut piece that starts at source time t0.
    Only the part of the track this piece uses goes into the expression, so long videos do not make ffmpeg choke."""
    parts = []
    if t1 is not None:
        track = [p for p in track if t0 - 1.0 <= p[0] <= t1 + 1.0] or track[:2]
    if len(track) > 36:  # a long piece: the face moves slowly, so fewer points are plenty (and ffmpeg can read the expression)
        step = -(-len(track) // 36)
        track = track[::step] + ([track[-1]] if (len(track) - 1) % step else [])
    for (ta, ca), (tb, cb) in zip(track, track[1:]):
        xa = min(max(ca * src_w - crop_w / 2, 0), src_w - crop_w)
        xb = min(max(cb * src_w - crop_w / 2, 0), src_w - crop_w)
        parts.append(f"between(T,{ta:.2f},{tb:.2f})*({xa:.1f}+({xb:.1f}-{xa:.1f})*(T-{ta:.2f})/{max(0.01, tb - ta):.2f})")
    return "(" + "+".join(parts).replace("T", f"(t+{t0:.3f})") + ")" if parts else "0"


def apply_speed_ramps(path, ramps, total):
    """Slow or speed up short windows of the finished video (video and sound together)."""
    ramps = sorted([r for r in ramps if 0 < r["start"] < r["end"] <= total], key=lambda r: r["start"])
    if not ramps:
        return
    segs, pos = [], 0.0
    for r in ramps:
        if r["start"] > pos:
            segs.append((pos, r["start"], 1.0))
        segs.append((r["start"], r["end"], r["speed"]))
        pos = r["end"]
    if pos < total:
        segs.append((pos, total + 1, 1.0))
    fc, labels = [], []
    for i, (a, b, sp) in enumerate(segs):
        fc.append(f"[0:v]trim=start={a:.3f}:end={b:.3f},setpts=(PTS-STARTPTS)/{sp}[v{i}]")
        at = []
        x = sp
        while x < 0.5:
            at.append("atempo=0.5")
            x /= 0.5
        while x > 2.0:
            at.append("atempo=2.0")
            x /= 2.0
        at.append(f"atempo={x:.4f}")
        fc.append(f"[0:a]atrim=start={a:.3f}:end={b:.3f},asetpts=PTS-STARTPTS,{','.join(at)}[a{i}]")
        labels.append(f"[v{i}][a{i}]")
    fc.append("".join(labels) + f"concat=n={len(segs)}:v=1:a=1[vo][ao]")
    tmp = path + ".ramp.mp4"
    run(["ffmpeg", "-y", "-v", "error", "-i", path, "-filter_complex", ";".join(fc), "-map", "[vo]", "-map", "[ao]",
         "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
         "-movflags", "+faststart", tmp])
    os.replace(tmp, path)


def find_ramps(items, picks):
    out = []
    toks = [norm(i["w"]) for i in items]
    for pk in picks or []:
        want = [norm(x) for x in pk["phrase"].split()]
        at = next((k for k in range(len(toks) - len(want) + 1) if toks[k:k + len(want)] == want), None)
        if at is None:
            SKIPPED.append(f"Speed change on \u201c{pk['phrase']}\u201d: I couldn't find those exact words in your video.")
            continue
        a = items[at]["os"]
        b = items[min(len(items) - 1, at + len(want) - 1)]["oe"]
        out.append({"start": a, "end": max(b, a + 0.4), "speed": float(pk.get("speed", 0.6))})
    return out


def fetch_broll_video(query, work):
    """A free portrait stock video from Pexels (commercial use allowed). Returns a file path, or None."""
    import urllib.request, urllib.parse, hashlib
    key = pexels_key()
    if not key:
        return None
    try:
        req = urllib.request.Request(f"https://api.pexels.com/videos/search?query={urllib.parse.quote(query)}&orientation=portrait&per_page=6",
                                     headers={"Authorization": key, "User-Agent": "content-engine"})
        data = json.loads(urllib.request.urlopen(req, timeout=30).read())
        os.makedirs(os.path.join(work, "broll"), exist_ok=True)
        for v in data.get("videos", []):
            files = sorted([f for f in v.get("video_files", []) if f.get("width") and f["width"] >= 540 and f.get("file_type") == "video/mp4"],
                           key=lambda f: abs(f["width"] - 1080))
            if not files:
                continue
            u = files[0]["link"]
            out = os.path.join(work, "broll", hashlib.md5(u.encode()).hexdigest() + ".mp4")
            if not os.path.exists(out):
                open(out, "wb").write(urllib.request.urlopen(u, timeout=90).read())
            return out
    except Exception as e:
        print("    (stock video search failed:", e, ")")
    return None


def find_brolls(items, picks, work, gfx, hook_secs):
    """B-roll: cut away to a clip or picture on a phrase, then come back to her. Her voice keeps going."""
    out = []
    toks = [norm(i["w"]) for i in items]
    taken = [(g["start"], g["end"]) for g in gfx]
    for pk in picks or []:
        want = [norm(x) for x in pk["phrase"].split()]
        at = next((k for k in range(len(toks) - len(want) + 1) if toks[k:k + len(want)] == want), None)
        label = f"B-roll on \u201c{pk['phrase']}\u201d"
        if at is None:
            SKIPPED.append(f"{label}: I couldn't find those exact words in your video.")
            continue
        a = items[at]["os"] - 0.05
        b = a + float(pk.get("seconds", 2.8))
        if a < hook_secs + 0.3:
            SKIPPED.append(f"{label}: that's during your hook. Pick a later line.")
            continue
        if any(not (b < x or a > y) for x, y in taken):
            SKIPPED.append(f"{label}: another graphic is already at that spot. Pick a different line.")
            continue
        path = pk.get("file")
        if not path and pk.get("query"):
            path = fetch_broll_video(pk["query"], work)
            if not path:
                SKIPPED.append(f"{label}: I couldn't get a stock clip (no Pexels key, or nothing found). Upload your own clip instead.")
                continue
        if not path or not os.path.exists(path):
            SKIPPED.append(f"{label}: I couldn't find that clip or picture.")
            continue
        is_img = path.lower().endswith((".jpg", ".jpeg", ".png", ".webp", ".heic"))
        out.append({"type": "broll", "start": a, "end": b, "path": path, "is_image": is_img, "pos": (W // 2, H // 2),
                    "transition": pk.get("transition", "whip"), "pick": pk})
        taken.append((a, b))
    return out


def cover_fit(img, w=W, h=H, extra=1.0):
    sc = max(w / img.width, h / img.height) * extra
    im = img.resize((int(img.width * sc) + 1, int(img.height * sc) + 1))
    l, t = (im.width - w) // 2, (im.height - h) // 2
    return im.crop((l, t, l + w, t + h))


def broll_frame(g, t):
    """The picture to show for a B-roll insert at time t."""
    p = (t - g["start"]) / max(0.1, g["end"] - g["start"])
    if g["is_image"]:
        if "_img" not in g:
            g["_img"] = Image.open(g["path"]).convert("RGB")
        return cover_fit(g["_img"], extra=1.0 + 0.08 * p).convert("RGBA")
    import cv2
    if "_cap" not in g:
        g["_cap"] = cv2.VideoCapture(g["path"])
        try:
            g["_cap"].set(cv2.CAP_PROP_ORIENTATION_AUTO, 1)
        except Exception:
            pass
        g["_fps"] = g["_cap"].get(cv2.CAP_PROP_FPS) or 30
        g["_n"] = int(g["_cap"].get(cv2.CAP_PROP_FRAME_COUNT) or 1)
        g["_last"] = -5
    idx = int((t - g["start"]) * g["_fps"]) % max(1, g["_n"])
    if idx != g["_last"] + 1:
        g["_cap"].set(cv2.CAP_PROP_POS_FRAMES, idx)
    ok, fr = g["_cap"].read()
    g["_last"] = idx
    if not ok:
        return g.get("_prev") or Image.new("RGBA", (W, H), (0, 0, 0, 255))
    im = cover_fit(Image.fromarray(cv2.cvtColor(fr, cv2.COLOR_BGR2RGB))).convert("RGBA")
    g["_prev"] = im
    return im


def apply_transition(layer, kind, p_in, p_out):
    """How a full-screen insert comes in and goes out: whip, iris, wipe, flash or fade. p_in and p_out run 0 to 1."""
    kind = kind or "fade"
    if p_out > 0:
        # going out: a quick fade is clean for every style
        a = layer.getchannel("A").point(lambda v: int(v * (1 - p_out)))
        out = layer.copy()
        out.putalpha(a)
        return out
    e = ease_out(min(1.0, max(0.0, p_in)))
    if e >= 0.999:
        return layer
    if kind == "whip":
        import numpy as np
        shift = int((1 - e) * W)
        arr = np.array(layer).astype("float32")
        k = max(1, int((1 - e) * 36))
        acc = np.zeros_like(arr)
        for i in range(k):
            acc += np.roll(arr, i * 3, axis=1)
        arr = (acc / k).astype("uint8")
        im = Image.fromarray(arr, "RGBA")
        out = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        out.alpha_composite(im, (shift, 0), (0, 0, W - shift, H)) if shift < W else None
        return out
    if kind == "iris":
        m = Image.new("L", (W, H), 0)
        r = int(((W / 2) ** 2 + (H / 2) ** 2) ** 0.5 * e)
        ImageDraw.Draw(m).ellipse((W // 2 - r, H // 2 - r, W // 2 + r, H // 2 + r), fill=255)
    elif kind == "wipe":
        m = Image.new("L", (W, H), 0)
        ImageDraw.Draw(m).rectangle((0, 0, int(W * e), H), fill=255)
    elif kind == "flash":
        out = layer.copy()
        fl = Image.new("RGBA", (W, H), (255, 255, 255, int(90 * (1 - e))))  # photosensitivity floor: a soft brightening, never a full white flash
        out.alpha_composite(fl)
        return out
    else:
        out = layer.copy()
        out.putalpha(layer.getchannel("A").point(lambda v: int(v * e)))
        return out
    out = layer.copy()
    a = layer.getchannel("A")
    from PIL import ImageChops
    out.putalpha(ImageChops.multiply(a, m))
    return out


def find_freezes(items, picks, gfx, hook_secs):
    """Freeze frames: the picture holds for a beat on a word, with a small flash and slow push in."""
    out = []
    toks = [norm(i["w"]) for i in items]
    taken = [(g["start"], g["end"]) for g in gfx]
    for pk in picks or []:
        want = [norm(x) for x in pk["phrase"].split()]
        at = next((k for k in range(len(toks) - len(want) + 1) if toks[k:k + len(want)] == want), None)
        label = f"Freeze frame on \u201c{pk['phrase']}\u201d"
        if at is None:
            SKIPPED.append(f"{label}: I couldn't find those exact words in your video.")
            continue
        a = items[at]["os"]
        b = a + float(pk.get("seconds", 0.9))
        if a < hook_secs + 0.3:
            SKIPPED.append(f"{label}: that's during your hook. Pick a later line.")
        elif any(not (b < x or a > y) for x, y in taken):
            SKIPPED.append(f"{label}: another graphic is already at that spot. Pick a different line.")
        else:
            out.append({"type": "freeze", "start": a, "end": b, "pos": (W // 2, H // 2), "transition": pk.get("transition"), "pick": pk})
            taken.append((a, b))
    return out


def find_scenes(items, picks, gfx, hook_secs):
    """Scenes: she floats in front of a still background with big words behind her."""
    out = []
    toks = [norm(i["w"]) for i in items]
    taken = [(g["start"], g["end"]) for g in gfx]
    for pk in picks or []:
        want = [norm(x) for x in pk["phrase"].split()]
        at = next((k for k in range(len(toks) - len(want) + 1) if toks[k:k + len(want)] == want), None)
        label = f"Floating head scene on \u201c{pk['phrase']}\u201d"
        if at is None:
            SKIPPED.append(f"{label}: I couldn't find those exact words in your video.")
            continue
        a = items[at]["os"] - 0.05
        b = items[min(len(items) - 1, at + len(want) - 1)]["oe"] + float(pk.get("after", 1.2))
        b = min(b, a + float(pk.get("seconds", 3.2)))
        if a < hook_secs + 0.3:
            SKIPPED.append(f"{label}: that's during your hook (the first {hook_secs:.0f} seconds). Pick a later line.")
        elif any(not (b < x or a > y) for x, y in taken):
            SKIPPED.append(f"{label}: another graphic is already at that spot. Pick a different line.")
        else:
            out.append({"type": "scene", "start": a, "end": b, "text": pk.get("text", pk["phrase"]), "hi": pk.get("hi"),
                        "bg": pk.get("bg", "gradient"), "pos": (W // 2, H // 2), "transition": pk.get("transition"), "pick": pk})
            taken.append((a, b))
    return out


def scene_background(look, spec):
    """A still full-screen background: a color, a gradient from the look, or her own picture."""
    spec = spec or "gradient"
    if spec.startswith("image:") and os.path.exists(spec[6:]):
        im = Image.open(spec[6:]).convert("RGBA")
        sc = max(W / im.width, H / im.height)
        im = im.resize((int(im.width * sc) + 1, int(im.height * sc) + 1))
        l, t = (im.width - W) // 2, (im.height - H) // 2
        return im.crop((l, t, l + W, t + H))
    if spec.startswith("color:"):
        return Image.new("RGBA", (W, H), hex2rgb(spec[6:]))
    top = hex2rgb(look["hook"]["bg"])[:3]
    if luminance(look["hook"]["bg"]) > 0.6:
        top = hex2rgb(look["accent"]["bg"])[:3]
    bot = tuple(int(c * 0.45) for c in top)
    g = Image.linear_gradient("L").resize((W, H))
    a = Image.new("RGBA", (W, H), top + (255,))
    b = Image.new("RGBA", (W, H), bot + (255,))
    return Image.composite(b, a, g)


class Cutout:
    """Finds her outline in each frame so a picture can sit behind her head and shoulders."""
    def __init__(self, base):
        import cv2, numpy as np, mediapipe as mp
        self.cv2, self.np = cv2, np
        self.cap = cv2.VideoCapture(base)
        self.seg = mp.solutions.selfie_segmentation.SelfieSegmentation(model_selection=0)
        self.last = -5
        self.cur = None
        self.cache = None

    def grab(self, t):
        """One plain frame from her video at time t, as a picture."""
        cv2 = self.cv2
        self.cap.set(cv2.CAP_PROP_POS_FRAMES, int(round(t * FPS)))
        ok, bgr = self.cap.read()
        self.last = -5
        self.cache = None
        return Image.fromarray(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)).convert("RGBA") if ok else None

    def blurred(self):
        """The frame last read by person(), blurred, for a portrait-mode background."""
        if self.cur is None:
            return None
        cv2 = self.cv2
        small = cv2.GaussianBlur(cv2.resize(self.cur, (W // 4, H // 4)), (0, 0), 7)
        return Image.fromarray(cv2.cvtColor(cv2.resize(small, (W, H)), cv2.COLOR_BGR2RGB)).convert("RGBA")

    def person(self, t):
        cv2, np = self.cv2, self.np
        idx = int(round(t * FPS))
        if idx == self.last and self.cache is not None:
            return self.cache
        if idx != self.last + 1:
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ok, bgr = self.cap.read()
        self.last = idx
        if not ok:
            return None
        self.cur = bgr
        small = cv2.cvtColor(cv2.resize(bgr, (540, 960)), cv2.COLOR_BGR2RGB)
        m = self.seg.process(small).segmentation_mask
        m = cv2.GaussianBlur(m, (9, 9), 0)
        m = np.clip((m - 0.30) / 0.45, 0, 1)
        m = cv2.resize(m, (W, H), interpolation=cv2.INTER_LINEAR)
        img = Image.fromarray(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)).convert("RGBA")
        img.putalpha(Image.fromarray((m * 255).astype("uint8")))
        self.cache = img
        return img


# ---------- the effects library (see effects.py) ----------
class Lib:
    """What an effect needs from the editor: the look, fonts, and drawing helpers."""
    def __init__(self, look):
        self.look = look
        self.rotated = rotated
        self.scaled = scaled

    def font(self, name, size, weight=600, italic=False):
        return load_font(name, size, weight, italic)

    def emoji(self, ch, size):
        """One emoji as a picture, or None if this computer has no color emoji font."""
        for path, sz in (("/System/Library/Fonts/Apple Color Emoji.ttc", 160), ("C:/Windows/Fonts/seguiemj.ttf", 109)):
            if os.path.exists(path):
                try:
                    f = ImageFont.truetype(path, sz)
                    im = Image.new("RGBA", (sz + 40, sz + 40), (0, 0, 0, 0))
                    ImageDraw.Draw(im).text((10, 10), ch, font=f, embedded_color=True)
                    bb = im.getbbox()
                    if bb:
                        im = im.crop(bb)
                        r = size / max(im.size)
                        return im.resize((int(im.width * r), int(im.height * r)), Image.LANCZOS)
                except Exception:
                    return None
        return None

    def display(self, size):
        return display_font(self.look, size)

    def shadowed(self, img, **k):
        return shadowed(img, **k)

    def rgb(self, h, a=255):
        return hex2rgb(h, a)

    def lum(self, h):
        return luminance(h)


def auto_effects(items):
    """If no add-ins were chosen, add one that always fits: a comment popup on her call to action."""
    toks = [norm(i["w"]) for i in items]
    for k, t in enumerate(toks):
        if t == "comment" and k + 1 < len(items) and k > len(items) * 0.5:
            word = clean(items[k + 1]["w"]).upper()
            if word and word.lower() not in STOP:
                return [{"effect": "popup", "phrase": f"comment {norm(items[k + 1]['w'])}", "text": word}]
    return []


def find_effects(items, picks, existing, hook_secs):
    import effects as fxmod
    out = []
    toks = [norm(i["w"]) for i in items]
    busy = [(g["start"], g["end"]) for g in existing]
    for pk in picks or []:
        spec = fxmod.EFFECTS.get(pk.get("effect"))
        if not spec:
            SKIPPED.append(f"Effect \u201c{pk.get('effect')}\u201d isn't one I know yet.")
            continue
        want = [norm(x) for x in pk["phrase"].split()]
        at = next((k for k in range(len(toks) - len(want) + 1) if toks[k:k + len(want)] == want), None)
        label = f"{spec['label']} on \u201c{pk['phrase']}\u201d"
        if at is None:
            SKIPPED.append(f"{label}: I couldn't find those exact words in your video.")
            continue
        a = items[at]["os"] - 0.1
        b = a + pk.get("seconds", spec["seconds"])
        if a < hook_secs + 0.3:
            SKIPPED.append(f"{label}: that's during your hook (the first {hook_secs:.0f} seconds). Pick a later line.")
        elif any(not (b < x or a > y) for x, y in busy):
            SKIPPED.append(f"{label}: another graphic is already at that spot. Pick a different line.")
        else:
            out.append({"type": "effect", "effect": pk["effect"], "start": a, "end": b, "phrase": pk["phrase"],
                        "text": pk.get("text", spec["default"]), "pick": pk})
            busy.append((a, b))
    return out


# ---------- 6. keeping graphics off faces ----------
def detect_faces(video, step=0.4):
    """Find her face about 2 to 3 times a second. Returns [(time, (x0, y0, x1, y1) or None)] in 1080x1920 pixels,
    already grown to cover her hair and chin."""
    try:
        import cv2
    except Exception:
        return []
    cas = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    cap = cv2.VideoCapture(video)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    out, last, i = [], None, 0
    while True:
        cap.set(cv2.CAP_PROP_POS_FRAMES, i)
        ok, fr = cap.read()
        if not ok:
            break
        sm = cv2.resize(fr, (540, 960))
        faces = cas.detectMultiScale(cv2.cvtColor(sm, cv2.COLOR_BGR2GRAY), 1.1, 5, minSize=(60, 60))
        if len(faces):
            x, y, w, h = max(faces, key=lambda f: f[2] * f[3])
            x, y, w, h = x * 2, y * 2, w * 2, h * 2
            last = (max(0, x - 0.25 * w), max(0, y - 0.5 * h), min(W, x + 1.25 * w), min(H, y + 1.25 * h))
        out.append((i / fps, last))
        i += max(1, int(step * fps))
    first = next((r for _, r in out if r), None)
    default = first or (W * 0.2, H * 0.18, W * 0.8, H * 0.58)
    return [(t, r or default) for t, r in out]


def face_rect(faces, a, b):
    rs = [r for t, r in faces if a - 0.3 <= t <= b + 0.3] or ([faces[-1][1]] if faces else [])
    if not rs:
        return (W * 0.2, H * 0.18, W * 0.8, H * 0.58)
    return (min(r[0] for r in rs), min(r[1] for r in rs), max(r[2] for r in rs), max(r[3] for r in rs))


def overlap(a, b):
    return max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))


def choose_slot(slots, size, obstacles):
    """slots: [(cx, cy)], size: (w, h). Pick the slot that covers the least of the obstacles (first one wins ties)."""
    best, bo = slots[0], None
    for cx, cy in slots:
        r = (cx - size[0] / 2, cy - size[1] / 2, cx + size[0] / 2, cy + size[1] / 2)
        o = sum(overlap(r, ob) for ob in obstacles)
        if bo is None or o < bo - 1:
            best, bo = (cx, cy), o
    return best


# ---------- 7. the overlay (everything drawn on top of the video) ----------
def env(t, a, b, tin=0.35, tout=0.25):
    """Calm entrance: a small settle and a fade, no bounce. Returns (scale, alpha) while on screen."""
    if t < a or t > b:
        return None
    x_in = (t - a) / tin
    sc = 0.94 + 0.06 * ease_out(x_in)
    al = min(1.0, x_in * 1.6) * min(1.0, (b - t) / tout)
    return max(0.05, sc), max(0.0, min(1.0, al))


def write_srt(items, path):
    """Captions file (.srt) of the kept words, 4 words or a phrase at a time."""
    lines, cur = [], []
    for it in items:
        cur.append(it)
        if len(cur) >= 4 or re.search(r"[.?!,]$", it["w"]):
            lines.append(cur)
            cur = []
    if cur:
        lines.append(cur)

    def ts(x):
        return f"{int(x // 3600):02d}:{int(x % 3600 // 60):02d}:{int(x % 60):02d},{int(round((x % 1) * 1000)):03d}"
    out = []
    for n, ln in enumerate(lines, 1):
        end = ln[-1]["oe"] if n == len(lines) else max(ln[-1]["oe"], min(lines[n][0]["os"], ln[-1]["oe"] + 0.4))
        out.append(f"{n}\n{ts(ln[0]['os'])} --> {ts(end)}\n{' '.join(x['w'] for x in ln)}\n")
    open(path, "w", encoding="utf-8").write("\n".join(out))


def pop_word_image(look, txt, is_hi, pop_font=None):
    """One big caption word (the default 'pop' style), as a transparent picture. Used by the build and by the live editor."""
    pop_font = pop_font or load_font(look["captionFont"], 124, 800)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    tw = d0.textlength(txt, font=pop_font)
    im = Image.new("RGBA", (int(tw + 80), int(pop_font.size * 1.5)), (0, 0, 0, 0))
    dd = ImageDraw.Draw(im)
    sw = max(6, pop_font.size // 11)
    col = hl_color(look) if is_hi else (255, 255, 255, 255)
    dd.text((40, 16), txt, font=pop_font, fill=(0, 0, 0, 110), stroke_width=sw, stroke_fill=(0, 0, 0, 110))
    dd.text((40, 8), txt, font=pop_font, fill=col, stroke_width=sw, stroke_fill=(18, 18, 18, 240))
    return im


DEST = ['reels']
DEST_SLOTS = {'tiktok': (0.58, 0.50, 0.66), 'shorts': (0.60, 0.52, 0.66), 'stories': (0.62, 0.55, 0.70)}


def suggest_fun(items, hook_lines, total):
    """Fun moments that fit what she actually said. Suggestions only: she keeps or cuts each one."""
    out = []
    text = " ".join(i["w"] for i in items)
    m = re.search(r"([^.?!]{3,60}?)\s+instead of\s+([^.?!,]{3,50})", text, re.I)
    if m:
        new, old = m.group(1).split()[-6:], m.group(2).split()[:6]
        ph = " ".join(re.sub(r"[^\w']", "", w) for w in m.group(2).split()[:2])
        out.append({"kind": "strike", "text": " ".join(old), "detail": " ".join(new), "phrase": ph, "why": "You said \"instead of\": cross out the old way and show the true one. Check which is which after you add it."})
    costumes = {"tiny": "tiny", "small": "tiny", "grow": "grow", "growing": "grow", "fast": "fast", "stuck": "stuck", "free": "free"}
    for it in items:
        w = norm(it["w"])
        if w in costumes and it["os"] > 1.5:
            out.append({"kind": "costume", "text": w, "detail": costumes[w], "start": round(it["os"], 1), "why": f"You said \"{w}\": let the word act it out."})
            break
    hk = " ".join(hook_lines)
    if hk.strip().endswith("?") or re.match(r"^(how|why|what|when|where|can|do|does|should)\b", hk.strip(), re.I):
        out.append({"kind": "typed", "text": hk.replace("*", ""), "detail": "", "start": 0.3, "why": "Your hook is a question: it can type itself into a search bar."})
    return out[:3]


def fatigue_note(history, kinds, caption_mode, hook_style):
    last = history[-5:]
    notes = []
    for label, val, key in (("caption style", caption_mode, "caption_mode"), ("hook style", hook_style, "hook_style")):
        if val and sum(1 for h in last if h.get(key) == val) >= 3:
            notes.append(f"You have used the same {label} on 3 of your last 5 videos. Try a different one so it stays fresh.")
    for k in kinds:
        if sum(1 for h in last if k in h.get("kinds", [])) >= 3:
            notes.append(f"The {k} extra is on 3 of your last 5 videos. Try a different one this time.")
    return notes


def find_texts(items, dec, total, hook_secs):
    """Extra text on the reel (names, labels, lists, fun moments) from the decisions. See text_jobs.py."""
    import text_jobs as tj
    out = []
    for e in (dec.get("texts") or []):
        k = tj.KINDS.get(e.get("kind"))
        if not k or not (e.get("text") or "").strip():
            continue
        secs = float(e.get("seconds") or k.get("secs") or 3.0)
        st = e.get("start")
        if st is None and e.get("phrase"):
            ph = [norm(x) for x in e["phrase"].split()]
            for i in range(len(items) - len(ph) + 1):
                if [norm(items[i + j]["w"]) for j in range(len(ph))] == ph:
                    st = items[i]["os"]
                    break
        if st is None:
            continue
        st = max(0.0, float(st))
        if e["kind"] == "disclaimer":
            secs = max(3.0, secs)
        out.append({"kind": e["kind"], "text": e["text"], "detail": e.get("detail", ""), "start": st, "end": min(total, st + secs), "x": e.get("x"), "y": e.get("y")})
    for pk in (dec.get("freezes") or []):
        if (pk.get("note") or "").strip() and pk.get("phrase"):
            ph = [norm(x) for x in pk["phrase"].split()]
            for i in range(len(items) - len(ph) + 1):
                if [norm(items[i + j]["w"]) for j in range(len(ph))] == ph:
                    a0 = items[i]["os"]
                    out.append({"kind": "signoff", "text": pk["note"].strip(), "detail": "", "start": a0, "end": min(total, a0 + max(1.4, float(pk.get("seconds", 0.9)) + 0.6)), "x": W // 2, "y": 1260})
                    break
    if (dec.get("watermark") or "").strip():
        out.append({"kind": "watermark", "text": dec["watermark"].strip(), "detail": "", "start": 0.0, "end": total, "x": None, "y": None})
    if (dec.get("signoff") or "").strip():
        out.append({"kind": "signoff", "text": dec["signoff"].strip(), "detail": "", "start": max(0.0, total - 3.0), "end": total, "x": None, "y": None})
    return out


def build_overlay(path, total, items, look, hook_lines, hook_secs, gfx, faces, base=None, cap_mode="pop", progress=True, blur_bg=False, cap_ranges=None, grain=False, layout_dir=None, hook_style="box", hook_scale=1.0, hook_dy=0, hook_dx=0, textjobs=None, hook_drop=False):
    cap_font = load_font(look["captionFont"], 70, max(600, look.get("captionWeight", 600)))
    chunks = chunk_words(items)
    states = []
    cap_rects = []
    last_hi = -9
    for k, ch in enumerate(chunks):
        hi = pick_highlight(ch)
        if hi >= 0 and (k - last_hi < 3 or len(norm(ch[hi]["w"])) < 7):
            hi = -1
        if hi >= 0:
            last_hi = k
        img = render_caption_plain(look, [c["w"] for c in ch], hi, cap_font)
        a, b = ch[0]["os"], ch[-1]["oe"] + 0.3
        fr = face_rect(faces, a, b)
        cy = choose_slot([(W // 2, int(H * y)) for y in DEST_SLOTS.get(DEST[0], (0.65, 0.73, 0.58))], img.size, [fr])[1]
        states.append((ch, hi, img, cy))
        cap_rects.append((W / 2 - img.width / 2, cy - img.height / 2, W / 2 + img.width / 2, cy + img.height / 2, a, b))
    if grain:
        import numpy as np
        grain_rng = np.random.default_rng(7)
    ranges = [(float(r["from"]), float(r["to"]), r["style"]) for r in (cap_ranges or []) if r.get("style") in ("pop", "lines", "karaoke", "soft", "phrase", "boxed", "past", "none")]
    styles_used = {cap_mode} | {r[2] for r in ranges}

    def style_at(t):
        for a0, b0, sty in ranges:
            if a0 <= t < b0:
                return sty
        return cap_mode
    soft_font = load_font("Poppins", 68, 800)
    phr_font = load_font("Inter", 60, 700)
    box_font = load_font("Roboto", 54, 700)
    chunk_imgs = {}
    for mode, rf, fnt in (("phrase", render_caption_phrase, phr_font), ("boxed", render_caption_boxed, box_font), ("past", render_caption_past, load_font("Courier Prime", 58, 700))):
        if mode in styles_used:
            chunk_imgs[mode] = [rf(look, [c["w"] for c in ch], hi, fnt) for (ch, hi, _i, _c) in states]
    kars = []
    if "soft" in styles_used:
        for k, (ch, hi, img, cy) in enumerate(states):
            for j, it in enumerate(ch):
                nxt = ch[j + 1]["os"] if j + 1 < len(ch) else ch[-1]["oe"] + 0.30
                kars.append({"os": it["os"], "end": max(nxt, it["os"] + 0.15), "img": render_caption_soft(look, [c["w"] for c in ch], j, soft_font), "cy": cy})
    kp2 = 0
    kar = []
    if "karaoke" in styles_used:
        for k, (ch, hi, img, cy) in enumerate(states):
            for j, it in enumerate(ch):
                nxt = ch[j + 1]["os"] if j + 1 < len(ch) else ch[-1]["oe"] + 0.30
                kar.append({"os": it["os"], "end": max(nxt, it["os"] + 0.15), "img": render_caption_plain(look, [c["w"] for c in ch], j, cap_font), "cy": cy})
    kp = 0
    wlist = []
    if "pop" in styles_used:
        pop_font = load_font(look["captionFont"], 124, 800)
        cache_w = {}
        for k, (ch, hi, img, cy) in enumerate(states):
            for j, it in enumerate(ch):
                txt = it["w"].strip(".,?!;:").upper() or it["w"]
                key = (txt, j == hi)
                if key not in cache_w:
                    cache_w[key] = pop_word_image(look, txt, j == hi, pop_font)
                nxt = ch[j + 1]["os"] if j + 1 < len(ch) else ch[-1]["oe"] + 0.25
                wlist.append({"os": it["os"], "end": max(nxt, it["os"] + 0.18), "img": cache_w[key], "cy": cy, "i": it.get("i"), "key": key})
    # the hook fills the top of the screen (about the top quarter), above her eyes when it can
    hfr = face_rect(faces, 0, hook_secs)
    eyes_y = hfr[1] + 0.30 * (hfr[3] - hfr[1])
    HOOK_TOP = 255  # Instagram covers the top ~270px (name, audio line), so the hook starts below it
    zone_h = int(max(180, min(360, eyes_y - 14 - HOOK_TOP)))
    import hook_styles
    hook_img = hook_styles.render(hook_style, look, hook_lines, zone_h, scale=hook_scale) if hook_lines else None
    hook_early = None
    if hook_drop and hook_img is not None and len(" ".join(hook_lines).split()) > 2:
        _hw = " ".join(hook_lines).split()
        hook_early = hook_styles.render(hook_style, look, [" ".join(_hw[:-1])], zone_h, scale=hook_scale)
    hook_fit = 1.0
    hook_bottom = False
    hook_cy = int(HOOK_TOP + hook_dy + (hook_img.height // 2 if hook_img else 0))
    hook_cx = W // 2
    if hook_img is not None:
        hook_cy = max(hook_img.height // 2, min(H - hook_img.height // 2, hook_cy))
        hook_cx = max(hook_img.width // 2, min(W - hook_img.width // 2, W // 2 + hook_dx))
    if layout_dir:
        # a record of exactly what is drawn and where, so the live editor shows the same pictures in the same places
        try:
            import hashlib
            os.makedirs(layout_dir, exist_ok=True)
            lay = {"W": W, "H": H, "hook_secs": hook_secs, "cap_mode": cap_mode, "styles": sorted(styles_used), "hook": None, "pop": [],
                   "zone_h": zone_h, "top": HOOK_TOP, "hook_style": hook_style, "hook_scale": hook_scale, "hook_dy": hook_dy, "hook_dx": hook_dx}
            if hook_img is not None:
                hook_img.save(os.path.join(layout_dir, "hook.png"))
                lay["hook"] = {"file": "hook.png", "cx": W // 2, "cy": hook_cy, "w": hook_img.width, "h": hook_img.height}
            seen = {}
            for w0 in wlist:
                tag = hashlib.md5(repr(w0["key"]).encode()).hexdigest()[:12]
                fn = f"w_{tag}.png"
                if tag not in seen:
                    w0["img"].save(os.path.join(layout_dir, fn))
                    seen[tag] = True
                lay["pop"].append({"i": w0["i"], "os": round(w0["os"], 3), "end": round(w0["end"], 3), "cy": w0["cy"], "file": fn, "w": w0["img"].width, "h": w0["img"].height})
            json.dump(lay, open(os.path.join(layout_dir, "layout.json"), "w", encoding="utf-8"))
        except Exception:
            pass
    art = {}
    caption_zone = (0, H * 0.60, W, H * 0.72)
    for g in gfx:
        if g["type"] == "stat":
            im = render_stat(look, g["number"], g["label"])
            art[id(g)] = im
            fr = face_rect(faces, g["start"], g["end"])
            obs = [fr, caption_zone] + [r[:4] for r in cap_rects if r[4] < g["end"] and r[5] > g["start"]] + \
                  ([(0, 0, W, H * 0.30)] if g["start"] < hook_secs else [])
            hw = im.width / 2
            slots = [(int(W * 0.05 + hw), int(H * y)) for y in (0.32, 0.50, 0.58)] + \
                    [(int(W * 0.95 - hw), int(H * y)) for y in (0.32, 0.50, 0.58)]
            g["pos"] = choose_slot(slots, im.size, obs)
        elif g["type"] == "gif":
            im = g["frames"][0]
            art[id(g)] = im
            fr = face_rect(faces, g["start"], g["end"])
            if g.get("mode", "behind") == "behind":
                # sits behind her head, off to the side that has more room, high on the screen
                fc = (fr[0] + fr[2]) / 2
                cx = int(W * 0.72) if fc <= W / 2 else int(W * 0.28)
                g["pos"] = (cx, int(H * 0.15) + im.height // 2 + 10)  # tucked up high, just under the top zone
            else:
                obs = [fr] + [r[:4] for r in cap_rects if r[4] < g["end"] and r[5] > g["start"]]
                hw = im.width / 2
                slots = [(int(W * 0.95 - hw), int(H * y)) for y in (0.30, 0.46, 0.58)] + \
                        [(int(W * 0.05 + hw), int(H * y)) for y in (0.30, 0.46, 0.58)]
                g["pos"] = choose_slot(slots, im.size, obs)
        elif g["type"] == "effect":
            import effects as fxmod
            spec = fxmod.EFFECTS[g["effect"]]
            sc_ = spec.get("scale", FXSCALE)
            sz = tuple(int(v * sc_) for v in spec["size"])
            fr = face_rect(faces, g["start"], g["end"])
            obs = [fr] + [r[:4] for r in cap_rects if r[4] < g["end"] and r[5] > g["start"]]
            hw = sz[0] / 2
            place = spec.get("place", "corner")
            if place == "center":
                slots = [(W // 2, int(H * y)) for y in (0.36, 0.30, 0.50, 0.42)]
            elif place == "lower":
                slots = [(W // 2, int(H * 0.60)), (W // 2, int(H * 0.52)), (W // 2, int(H * 0.45))]
            elif place == "top":
                slots = [(W // 2, int(H * 0.15) + sz[1] // 2 + 10)]
            elif place == "left":
                slots = [(int(W * 0.04 + hw), int(H * y)) for y in (0.56, 0.48, 0.40)]
            else:
                slots = [(W // 2, int(H * 0.19) + sz[1] // 2 - 20)] + \
                        [(int(W * 0.95 - hw), int(H * y)) for y in (0.22, 0.40, 0.55)] + \
                        [(int(W * 0.05 + hw), int(H * y)) for y in (0.22, 0.40, 0.55)] + [(W // 2, int(H * 0.52))]
            g["pos"] = choose_slot(slots, sz, obs)
        elif g["type"] == "punch":
            art[id(g)] = render_takeover(look, g["text"], g.get("hi"))
            g["pos"] = (W // 2, int(H * 0.50))
        elif g["type"] == "pill":
            im = render_pill(look, g["text"])
            art[id(g)] = im
            fr = face_rect(faces, g["start"], g["end"])
            obs = [fr] + [r[:4] for r in cap_rects if r[4] < g["end"] and r[5] > g["start"]]
            g["pos"] = choose_slot([(W // 2, int(H * y)) for y in (0.60, 0.82, 0.54, 0.46)], im.size, obs)
    lib = Lib(look)
    sc_col = scrim_color(look)
    scrim_bottom = gradient(W, int(H * 0.42), sc_col, 125, from_top=False)
    scrim_top = gradient(W, int(H * 0.40), sc_col, 150, from_top=True)
    tj_cache = {}
    try:
        cutout = Cutout(base) if base and (any((g["type"] == "gif" and g.get("mode", "behind") == "behind") or g["type"] in ("scene", "freeze") for g in gfx) or blur_bg or hook_style == "behind") else None
    except Exception:
        cutout = None  # no outline tool here: the hook just sits in front instead
    for g in gfx:
        if g["type"] == "freeze" and cutout is not None:
            g["img"] = cutout.grab(g["start"])
    scene_art = {}
    for g in gfx:
        if g["type"] == "scene":
            scene_art[id(g)] = (scene_background(look, g.get("bg")), render_takeover(look, g["text"], g.get("hi")))
    nframes = int(total * FPS) + 1
    proc = subprocess.Popen(
        ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", f"{W}x{H}", "-r", str(FPS),
         "-i", "-", "-c:v", "qtrle", path], stdin=subprocess.PIPE)
    blank = bytes(W * H * 4)
    ci = 0
    pw = 0
    for fr_i in range(nframes):
        t = fr_i / FPS
        frame = None

        def get():
            nonlocal frame
            if frame is None:
                frame = Image.new("RGBA", (W, H), (0, 0, 0, 0))
            return frame

        if progress:
            # a rounded bar just above Instagram's bottom zone (the very top edge is hidden by the app)
            x0, x1, yb, hb = 100, W - 100, 1560, 16
            bar = int((x1 - x0) * min(1.0, t / max(0.1, total)))
            dr = ImageDraw.Draw(get())
            dr.rounded_rectangle((x0 - 3, yb - 3, x1 + 3, yb + hb + 3), radius=11, fill=(0, 0, 0, 90))
            dr.rounded_rectangle((x0, yb, x1, yb + hb), radius=8, fill=(255, 255, 255, 80))
            if bar > 12:
                dr.rounded_rectangle((x0, yb, x0 + bar, yb + hb), radius=8, fill=hl_color(look))
        if blur_bg and cutout is not None:
            _p = cutout.person(t)
            _b = cutout.blurred()
            if _b is not None and _p is not None:
                get().alpha_composite(_b)
                get().alpha_composite(_p)
        def _trans(g, default):
            p_in = (t - g["start"]) / 0.28
            p_out = max(0.0, (t - (g["end"] - 0.2)) / 0.2)
            return g.get("transition") or default, p_in, p_out

        in_broll = next((g for g in gfx if g["type"] == "broll" and g["start"] <= t <= g["end"]), None)
        if in_broll is not None:
            kind, p_in, p_out = _trans(in_broll, "whip")
            get().alpha_composite(apply_transition(broll_frame(in_broll, t), kind, p_in, p_out))
        in_freeze = next((g for g in gfx if g["type"] == "freeze" and g["start"] <= t <= g["end"] and g.get("img") is not None), None)
        if in_freeze is not None:
            fp = (t - in_freeze["start"]) / max(0.1, in_freeze["end"] - in_freeze["start"])
            layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
            paste_center(layer, in_freeze["img"], W // 2, H // 2, scale=1.0 + 0.05 * fp, alpha=1.0)
            kind, p_in, p_out = _trans(in_freeze, "flash")
            get().alpha_composite(apply_transition(layer, kind, p_in, p_out))
        in_scene = next((g for g in gfx if g["type"] == "scene" and g["start"] <= t <= g["end"]), None)
        if in_scene is not None and cutout is not None:
            sbg, swords = scene_art[id(in_scene)]
            layer = sbg.copy()
            if not in_scene.get("front"):
                paste_center(layer, swords, W // 2, int(H * 0.36), scale=1.0, alpha=1.0)
            pimg = cutout.person(t)
            if pimg is not None:
                paste_center(layer, pimg, W // 2, int(H - H * 0.88 / 2 + 30), scale=0.88, alpha=1.0)
            if in_scene.get("front"):
                paste_center(layer, swords, W // 2, int(H * 0.72), scale=0.85, alpha=1.0)
            kind, p_in, p_out = _trans(in_scene, "fade")
            get().alpha_composite(apply_transition(layer, kind, p_in, p_out))
        get().alpha_composite(scrim_bottom, (0, H - scrim_bottom.height))
        if hook_img is not None and t < hook_secs:
            et = env(t, 0, hook_secs, tin=0.4, tout=0.25)
            top = scrim_top if et[1] >= 0.999 else scrim_top.copy()
            if et[1] < 0.999:
                top.putalpha(top.getchannel("A").point(lambda v: int(v * et[1])))
            get().alpha_composite(top, (0, 0))
        behind = [g for g in gfx if g["type"] == "gif" and g.get("mode", "behind") == "behind"
                  and g["start"] <= t <= g["end"]]
        if behind and cutout is not None:
            for g in behind:
                e = env(t, g["start"], g["end"])
                tot = sum(g["durs"])
                tt, k = (t - g["start"]) % tot, 0
                for k, d_ in enumerate(g["durs"]):
                    if tt < d_:
                        break
                    tt -= d_
                paste_center(get(), g["frames"][k], g["pos"][0], g["pos"][1], scale=(e[0] * (1 + 0.08 * (t - g["start"]) / max(0.1, g["end"] - g["start"])) if len(g["frames"]) == 1 else e[0]), alpha=e[1])
            pimg = cutout.person(t)
            if pimg is not None:
                get().alpha_composite(pimg)
        for g in gfx:
            e = env(t, g["start"], g["end"])
            if not e:
                continue
            if g["type"] == "gif" and g.get("mode", "behind") == "behind":
                continue
            sc, al = e
            cx, cy = g["pos"]
            if g["type"] == "punch":
                paste_center(get(), art[id(g)], cx, cy, scale=sc, alpha=al)
            elif g["type"] == "stat":
                x_in = min(1.0, (t - g["start"]) / 0.45)
                off = (1 - ease_out(x_in)) * (-380 if cx < W / 2 else 380)
                paste_center(get(), art[id(g)], int(cx + off), cy, scale=1.0, alpha=al)
            elif g["type"] == "pill":
                paste_center(get(), art[id(g)], cx, cy, scale=sc, alpha=al)
            elif g["type"] == "gif":
                tot = sum(g["durs"])
                tt, k = (t - g["start"]) % tot, 0
                for k, d_ in enumerate(g["durs"]):
                    if tt < d_:
                        break
                    tt -= d_
                paste_center(get(), g["frames"][k], cx, cy, scale=(sc * (1 + 0.08 * (t - g["start"]) / max(0.1, g["end"] - g["start"])) if len(g["frames"]) == 1 else sc), alpha=al)
        for g in gfx:
            if g["type"] == "effect" and g["start"] <= t <= g["end"]:
                import effects as fxmod
                e = env(t, g["start"], g["end"], tin=0.25, tout=0.25)
                p = (t - g["start"]) / max(0.1, g["end"] - g["start"])
                im = shadowed(fxmod.EFFECTS[g["effect"]]["fn"](lib, g["text"], p), blur=14, dy=10, alpha=110)
                paste_center(get(), im, g["pos"][0], g["pos"][1], scale=fxmod.EFFECTS[g["effect"]].get("scale", FXSCALE), alpha=e[1])
        if hook_img is not None and t < hook_secs:
            # it bounces in: drops from small, overshoots a little, then settles
            e = env(t, 0, hook_secs, tin=0.4, tout=0.25)
            bp = min(1.0, t / 0.5)
            bs = 0.35 + 0.65 * ease_out_back(bp)
            _hi = hook_early if (hook_early is not None and t < 0.55) else hook_img
            paste_center(get(), _hi, hook_cx, hook_cy, scale=bs * (e[0] if t > hook_secs - 0.3 else 1.0), alpha=min(e[1], min(1.0, t / 0.12 + 0.2)))
            if hook_style == "behind" and cutout is not None:
                _pimg = cutout.person(t)
                if _pimg is not None:
                    get().alpha_composite(_pimg)
        for tj_ in (textjobs or []):
            if not (tj_["start"] <= t <= tj_["end"]):
                continue
            import text_jobs as _tj
            kd = _tj.KINDS[tj_["kind"]]
            pp = (t - tj_["start"]) / max(0.1, tj_["end"] - tj_["start"])
            an = kd.get("anim")
            q = round(pp * 24) / 24 if an in ("type", "strike", "build") else 1.0
            if tj_["kind"] == "costume" and (tj_["detail"] or "grow") == "grow":
                q = round(min(1.0, pp * 2.5) * 8) / 8
            key = (tj_["kind"], tj_["text"], tj_["detail"], q)
            if key not in tj_cache:
                tj_cache[key] = _tj.render(tj_["kind"], look, tj_["text"], tj_["detail"], q)
            im = tj_cache[key]
            cx, cy = _tj.position(tj_["kind"], im)
            if tj_.get("x") is not None:
                cx = int(tj_["x"])
            if tj_.get("y") is not None:
                cy = int(tj_["y"])
            if kd.get("wm"):
                al, off = 1.0, 0
            else:
                ein = min(1.0, (t - tj_["start"]) / 0.25)
                eout = min(1.0, (tj_["end"] - t) / 0.25)
                al, off = max(0.0, min(ein, eout)), int((1 - ease_out(ein)) * 22)
            paste_center(get(), im, cx, cy + off, scale=1.0, alpha=al)
        while ci < len(states) and t > states[ci][0][-1]["oe"] + 0.30:
            ci += 1
        punching = any(g["type"] == "punch" and g["start"] <= t <= g["end"] for g in gfx)
        punching = punching or (in_scene is not None and bool(in_scene.get("front")))
        sty = style_at(t)
        if sty == "karaoke" and kar and not punching:
            while kp + 1 < len(kar) and t >= kar[kp + 1]["os"]:
                kp += 1
            k0 = kar[kp]
            if k0["os"] - 0.03 <= t <= k0["end"] + 0.05:
                paste_center(get(), k0["img"], W // 2, k0["cy"], scale=1.0, alpha=min(1.0, (t - k0["os"] + 0.03) / 0.06))
        elif sty == "soft" and kars and not punching:
            while kp2 + 1 < len(kars) and t >= kars[kp2 + 1]["os"]:
                kp2 += 1
            k0 = kars[kp2]
            if k0["os"] - 0.03 <= t <= k0["end"] + 0.05:
                paste_center(get(), k0["img"], W // 2, k0["cy"], scale=1.0, alpha=min(1.0, (t - k0["os"] + 0.03) / 0.06))
        elif sty in ("phrase", "boxed", "past") and ci < len(states) and not punching:
            ch, hi, img, cy = states[ci]
            if ch[0]["os"] - 0.05 <= t <= ch[-1]["oe"] + 0.30:
                fade = min(1.0, max(0.0, (t - (ch[0]["os"] - 0.05)) / 0.15))
                paste_center(get(), chunk_imgs[sty][ci], W // 2, cy + int(12 * (1 - fade)), scale=1.0, alpha=fade)
        elif sty == "pop" and wlist and not punching:
            while pw + 1 < len(wlist) and t >= wlist[pw + 1]["os"]:
                pw += 1
            w0 = wlist[pw]
            if w0["os"] - 0.02 <= t <= w0["end"] + 0.05:
                x = min(1.0, max(0.0, (t - w0["os"]) / 0.17))
                c1 = 1.9
                sc = 0.7 + 0.3 * (1 + (c1 + 1) * (x - 1) ** 3 + c1 * (x - 1) ** 2)
                paste_center(get(), w0["img"], W // 2, (330 if hook_bottom and t < hook_secs + 0.2 else w0["cy"]), scale=sc, alpha=min(1.0, (t - w0["os"] + 0.02) / 0.05))
        elif sty == "lines" and ci < len(states) and not punching:
            ch, hi, img, cy = states[ci]
            if ch[0]["os"] - 0.05 <= t <= ch[-1]["oe"] + 0.30:
                fade = min(1.0, max(0.0, (t - (ch[0]["os"] - 0.05)) / 0.12))
                paste_center(get(), img, W // 2, cy, scale=1.0, alpha=fade)
        if grain:
            import numpy as np
            gl = get()
            noise = grain_rng.integers(0, 256, (H // 3, W // 3), dtype=np.uint8)
            rgba = np.stack([noise, noise, noise, np.full_like(noise, 26)], axis=-1)
            gim = Image.fromarray(rgba, "RGBA").resize((W, H), Image.NEAREST)
            gl.alpha_composite(gim)
        proc.stdin.write(frame.tobytes() if frame is not None else blank)
    proc.stdin.close()
    proc.wait()


# ---------- script helpers ----------
def read_script(path):
    txt = open(path, encoding="utf-8").read()
    hook = ""
    m = re.search(r"\*\*Read \(text at the top\):\*\*\s*(.+)", txt) or re.search(r"Read[^:\n]*:\s*(.+)", txt)
    if m:
        hook = m.group(1).strip().replace(" / ", "|")
    cta = None
    m = re.search(r"comment\s+[\"“']?([A-Za-z]+)[\"”']?", txt, re.I)
    if m:
        cta = m.group(1)
    vocab = sorted(set(re.findall(r"[A-Za-z][A-Za-z'\-]{4,}", txt)))
    prompt = ("Hi, everyone. Here is what I want to talk about today: Claude, Instagram, content, and scripts. "
              "It is simple. " + ", ".join(vocab[:60]) + ".")
    return hook, cta, prompt


# ---------- tidying up (keeps her computer from filling up) ----------
def tidy(outdir, name, work, keep):
    """Remove big temporary files, and keep only the newest finished versions. Never touches her original video."""
    freed = 0
    for tmp in ("base.mp4", "overlay.mov"):
        f = os.path.join(work, tmp)
        if os.path.exists(f):
            freed += os.path.getsize(f)
            os.remove(f)
    vs = [int(m.group(1)) for f in sorted((f for f in os.listdir(outdir)), key=lambda f: os.path.getmtime(os.path.join(outdir, f)))
          for m in [re.fullmatch(re.escape(name) + r"_edit(\d+)\.mp4", f)] if m]
    removed = []
    for v in vs[:-keep] if keep and len(vs) > keep else []:
        for f in (f"{name}_edit{v}.mp4", f"{name}_edit{v}.plan.json", f"{name}_decisions_v{v}.json"):
            fp = os.path.join(outdir, f)
            if os.path.exists(fp):
                freed += os.path.getsize(fp)
                os.remove(fp)
        removed.append(v)
    msg = f"Tidied: freed {freed / 1e6:.0f} MB"
    if removed:
        msg += f" (removed old versions {', '.join(map(str, removed))}; keeping the newest {keep})"
    print(msg)


def sentence_end(word, count, gap):
    """Where a spoken 'sentence' ends. Speech-to-text often leaves out punctuation, so also end at a natural pause (about half a second) or after about 14 words."""
    return bool(re.search(r"[.?!]$", word)) or (gap > 0.45 and count >= 4) or count >= 14


# ---------- main ----------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--out", help="output folder (default: edited/ next to recorded/)")
    ap.add_argument("--look", default="1")
    ap.add_argument("--script", help="her script file (gives the hook, the comment word, and spelling help)")
    ap.add_argument("--hook", default="", help="hook lines separated by |")
    ap.add_argument("--cta", default="", help="the comment word, like CONTENT")
    ap.add_argument("--hook-seconds", type=float, default=6.0)
    ap.add_argument("--graphics", help="JSON file of full-screen phrases to use: [{phrase, text, hi}]")
    ap.add_argument("--gifs", help="JSON file of GIF moments: [{phrase, query or file, sticker, size, seconds}]")
    ap.add_argument("--decisions", help="JSON file with her choices from the edit sheet")
    ap.add_argument("--zoom", type=float, default=0.1, help="punch-in zoom on every other sentence (0 = off)")
    ap.add_argument("--version", type=int, default=0, help="output name suffix: _edit<version> (0 = next free number, never overwrites)")
    ap.add_argument("--listen-only", action="store_true", help="only listen and write the pick sheet (no video)")
    ap.add_argument("--keep", type=int, default=2, help="how many finished versions to keep (newest)")
    ap.add_argument("--effects", help="JSON file of pop effects: [{effect, phrase, text, seconds}]")
    ap.add_argument("--no-graphics", action="store_true")
    ap.add_argument("--broll", help="json file: B-roll cutaways [{phrase, file or query, seconds, transition}]")
    ap.add_argument("--stabilize", action="store_true", help="smooth out shaky handheld video")
    ap.add_argument("--reframe", choices=["auto", "off"], default="auto", help="wide video: follow her face in the tall crop")
    ap.add_argument("--speed", help="json file: speed changes [{phrase, speed}] (0.6 is slow motion, 1.5 is fast)")
    ap.add_argument("--freezes", help="json file: freeze frames [{phrase, seconds}]")
    ap.add_argument("--blur-bg", action="store_true", help="blur the background behind her (portrait mode look)")
    ap.add_argument("--endcard", help="words for a closing card, like \"COMMENT ENGINE|ENGINE\"")
    ap.add_argument("--no-clean-audio", action="store_true", help="skip the voice cleanup (noise, echo, EQ)")
    ap.add_argument("--no-progress", action="store_true", help="skip the progress bar")
    ap.add_argument("--scenes", help="json file: floating head scenes [{phrase, text, hi, bg}]")
    ap.add_argument("--capcut", action="store_true", help="make a folder for CapCut: clean video, graphics layer, sounds, captions file")
    ap.add_argument("--captions", choices=["pop", "lines", "karaoke", "soft", "phrase", "boxed"], default="pop", help="pop = one big bouncy word at a time, lines = plain lines, karaoke = a line with the spoken word lit up, soft = karaoke with the spoken word in an accent box, phrase = calm phrases with one accent word, boxed = phrases on a dark box")
    ap.add_argument("--no-sheet", action="store_true", help="do not open the edit sheet after the build")
    ap.add_argument("--grain", action="store_true", help="film grain over the whole reel")
    ap.add_argument("--no-sound", action="store_true", help="skip the little sound effects")
    ap.add_argument("--clean", action="store_true", help="clean cut for CapCut: video with mistakes cut and sound leveled, plus a captions file, and nothing drawn on it")
    ap.add_argument("--fresh", action="store_true", help="listen again instead of using the saved words")
    a = ap.parse_args()
    if a.script:
        a.script = os.path.abspath(a.script)
    if a.out:
        a.out = os.path.abspath(a.out)
    if a.decisions:
        a.decisions = os.path.abspath(a.decisions)

    t_start = time.time()
    video = os.path.abspath(a.video)
    name = os.path.splitext(os.path.basename(video))[0]
    outdir = a.out or os.path.join(os.path.dirname(os.path.dirname(video)), "edited")
    os.makedirs(outdir, exist_ok=True)
    work = os.path.join(outdir, f".{name}_work")
    os.makedirs(work, exist_ok=True)
    if not a.version:
        taken_v = [int(m.group(1)) for f in os.listdir(outdir) for m in [re.match(re.escape(name) + r"_edit(\d+)\.mp4$", f)] if m]
        a.version = max(taken_v, default=0) + 1
    look = load_look(a.look)
    hook_txt, cta, vocab = ("", None, "")
    if a.script:
        hook_txt, cta, vocab = read_script(a.script)
    hook_txt = a.hook or hook_txt
    cta = a.cta or cta
    dec = json.load(open(a.decisions, encoding="utf-8")) if a.decisions else {}
    DEST[0] = dec.get("destination") or "reels"
    if dec.get("look"):
        look = load_look(dec["look"])
    if dec.get("season_accent"):
        import copy
        look = copy.deepcopy(look)
        hexc = dec["season_accent"] if str(dec["season_accent"]).startswith("#") else "#" + str(dec["season_accent"])
        tcol = "#FFFFFF" if luminance(hexc) < 0.55 else "#1F1F1F"
        for key in ("highlight", "accent"):
            look[key]["bg"], look[key]["text"] = hexc, tcol
    if "hook" in dec:
        hook_txt = dec["hook"]
    if hook_txt and "hook" not in dec:
        dec["hook"] = hook_txt  # kept in the edit plan so the live editor and rebuilds start from it

    print("1/5 Listening to your video...")
    cache = os.path.join(work, "words.json")
    if a.fresh and os.path.exists(cache):
        os.remove(cache)
    wl_names, wl_fixes = word_list()
    if wl_names:
        vocab = (vocab + " " + ", ".join(wl_names) + ".").strip()
    data = transcribe(video, cache, vocab)
    if wl_fixes:
        for w in data["words"]:
            core = re.sub(r"[^a-z0-9']", "", w["w"].lower())
            if core in wl_fixes:
                tail = re.search(r"[^A-Za-z0-9']+$", w["w"])
                w["w"] = wl_fixes[core] + (tail.group(0) if tail else "")
    for wi, wtxt in (dec.get("wordfix") or {}).items():
        try:
            data["words"][int(wi)]["w"] = wtxt
        except (ValueError, IndexError):
            pass
    words = data["words"]
    segs, reasons, kept = plan_cuts(words, dur=data["duration"], cut=dec.get("cut", []), keep=dec.get("keep", []), trim=dec.get("trim"), edges=dec.get("edges"))
    mp, total = build_mapper(segs)
    print(f"    {len(words)} words heard; cutting {len(reasons)} words "
          f"({sum(1 for r in reasons.values() if r == 'restarted take')} from restarted takes). "
          f"{data['duration']:.1f}s -> {total:.1f}s")

    if a.listen_only:
        sentences, cur = [], []
        for ki, i in enumerate(kept):
            w = words[i]
            o = mp(w["s"])
            if o is None:
                continue
            cur.append((o, w["w"]))
            if sentence_end(w["w"], len(cur), (words[kept[ki + 1]]["s"] - w["e"]) if ki + 1 < len(kept) else 9):
                sentences.append(f"{cur[0][0]:5.1f}  " + " ".join(x[1] for x in cur))
                cur = []
        if cur:
            sentences.append(f"{cur[0][0]:5.1f}  " + " ".join(x[1] for x in cur))
        with open(os.path.join(outdir, f"{name}_pick-sheet.txt"), "w", encoding="utf-8") as ps:
            ps.write("Sentences (time, text). Pick 3 or 4 punchy phrases for full-screen words, and 2 or 3 GIF moments.\n")
            ps.write("\n".join(sentences) + "\n")
        print(f"Listened. {len(words)} words, {data['duration']:.1f}s -> {total:.1f}s. Pick sheet: {name}_pick-sheet.txt")
        return

    try:
        import build_times
        print("   " + build_times.text(outdir, data["duration"]))
    except Exception:
        pass
    print("2/5 Cutting the video...")
    fc, v = [], []
    fade = 0.012
    opts0 = dec.get("options") or {}
    lift = "eq=contrast=1.08:saturation=1.25:gamma=0.95," if is_hdr(video) else ""
    if lift:
        print("    Your video was recorded in HDR, so I'm bringing the color back (it looks flat otherwise).")
    stab = "deshake=rx=32:ry=32:edge=mirror," if (a.stabilize or opts0.get("stabilize")) else ""
    track, crop_w, src_w = None, 0, 0
    sw, sh = source_geometry(video)
    if sw / sh > 0.62 and a.reframe != "off" and opts0.get("reframe", True):
        print("    Your video is wide, so I'm following your face to keep you centered in the tall picture.")
        crop_w = int(sh * 9 / 16) // 2 * 2
        src_w = sw
        track = face_track(video, data["duration"], sw, sh)
    for i, (s, e, *_) in enumerate(segs):
        if track:
            cropf = (f"crop=w={crop_w}:h={sh}:x='{reframe_x(track, src_w, crop_w, s, e)}':y=0,"
                     f"scale={W}:{H},{lift}")
        else:
            cropf = f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},{lift}"
        fc.append(f"[0:v]trim=start={s:.3f}:end={e:.3f},setpts=PTS-STARTPTS,{stab}{cropf}fps={FPS}[v{i}]")
        fc.append(f"[0:a]atrim=start={s:.3f}:end={e:.3f},asetpts=PTS-STARTPTS,"
                  f"afade=t=in:st=0:d={fade},afade=t=out:st={max(0, e - s - fade):.3f}:d={fade}[a{i}]")
        v.append(f"[v{i}][a{i}]")
    zoom_ranges = []
    zoom_on = (dec.get("options") or {}).get("zoom", True)
    if a.zoom > 0 and zoom_on:
        cur_s, n_sent = None, 0
        cur_n = 0
        for ki, i in enumerate(kept):
            w = words[i]
            o = mp(w["s"])
            if o is None:
                continue
            if cur_s is None:
                cur_s = o
            cur_n += 1
            if sentence_end(w["w"], cur_n, (words[kept[ki + 1]]["s"] - w["e"]) if ki + 1 < len(kept) else 9):
                cur_n = 0
                n_sent += 1
                oe = mp(w["e"])
                if n_sent % 2 == 0 and cur_s >= a.hook_seconds and oe is not None and oe - cur_s >= 1.2:
                    zoom_ranges.append((cur_s, oe))
                cur_s = None
    if zoom_ranges:
        zx = "+".join(f"between(t,{x:.2f},{y:.2f})" for x, y in zoom_ranges)
        zf = f"1+{a.zoom}*({zx})"
        fc.append("".join(v) + f"concat=n={len(segs)}:v=1:a=1[vcat][ac]")
        fc.append(f"[vcat]scale=w='trunc({W}*({zf})/2)*2':h='trunc({H}*({zf})/2)*2':eval=frame,"
                  f"crop={W}:{H}:(iw-{W})/2:(ih-{H})*0.3[vc]")
    else:
        fc.append("".join(v) + f"concat=n={len(segs)}:v=1:a=1[vc][ac]")
    opts = dec.get("options") or {}
    clean_audio = opts.get("clean_audio", not a.no_clean_audio)
    if clean_audio:
        fc.append("[ac]highpass=f=80,afftdn=nr=10:nf=-32,equalizer=f=3000:t=q:w=1.2:g=2,"
                  "acompressor=threshold=-21dB:ratio=3:attack=5:release=80,loudnorm=I=-14:TP=-1.5:LRA=11[aout]")
    else:
        fc.append("[ac]loudnorm=I=-14:TP=-1.5:LRA=11[aout]")
    base = os.path.join(work, "base.mp4")
    run(["ffmpeg", "-y", "-v", "error", "-i", video, "-filter_complex", ";".join(fc), "-map", "[vc]", "-map", "[aout]",
         "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", base])

    if a.clean:
        print("3/3 Saving the clean cut and captions for CapCut...")
        lines, cur = [], []
        for i in kept:
            w = words[i]
            os_, oe = mp(w["s"]), mp(w["e"])
            if os_ is None:
                continue
            cur.append({"w": dec.get("text", {}).get(str(i), w["w"]), "s": os_, "e": oe if oe is not None else os_ + 0.2})
            if len(cur) >= 4 or re.search(r"[.?!,]$", w["w"]):
                lines.append(cur)
                cur = []
        if cur:
            lines.append(cur)

        def ts(x):
            return f"{int(x // 3600):02d}:{int(x % 3600 // 60):02d}:{int(x % 60):02d},{int(round((x % 1) * 1000)):03d}"
        srt = []
        for n, ln in enumerate(lines, 1):
            end = ln[-1]["e"] if n == len(lines) else max(ln[-1]["e"], min(lines[n][0]["s"], ln[-1]["e"] + 0.4))
            srt.append(f"{n}\n{ts(ln[0]['s'])} --> {ts(end)}\n{' '.join(x['w'] for x in ln)}\n")
        n_clean = 1
        while os.path.exists(os.path.join(outdir, f"{name}_cleancut{n_clean}.mp4")):
            n_clean += 1
        cc = os.path.join(outdir, f"{name}_cleancut{n_clean}.mp4")
        shutil.copy2(base, cc)
        open(cc[:-4] + ".srt", "w", encoding="utf-8").write("\n".join(srt))
        tidy(outdir, name, work, a.keep)
        print(f"Done: {cc}")
        return
    # move or resize the whole picture (for example, to make room at the top); the empty space is filled with a soft blur of the same video
    vs = float(dec.get("video_scale", 1.0))
    vdx, vdy = int(dec.get("video_dx", 0)), int(dec.get("video_dy", 0))
    if abs(vs - 1.0) > 0.01 or vdx or vdy:
        sw, sh = int(W * vs) // 2 * 2, int(H * vs) // 2 * 2
        fc2 = (f"[0:v]split[a][b];[a]scale={W}:{H},boxblur=40:8,eq=brightness=-0.08[bg];[b]scale={sw}:{sh}[fg];"
               f"[bg][fg]overlay=x='(main_w-overlay_w)/2+({vdx})':y='(main_h-overlay_h)/2+({vdy})'[v]")
        base_t = os.path.join(work, "base_t.mp4")
        run(["ffmpeg", "-y", "-v", "error", "-i", base, "-filter_complex", fc2, "-map", "[v]", "-map", "0:a", "-c:v", "libx264", "-preset", "veryfast",
             "-crf", "18", "-pix_fmt", "yuv420p", "-c:a", "copy", base_t])
        os.replace(base_t, base)
    print("3/5 Finding your face, then drawing your hook, captions and graphics...")
    fc_checks = []
    _fcv = dec.get("face_cover") or {}
    if _fcv.get("faces") or _fcv.get("all"):
        try:
            import face_cover as fcm
            _cov = os.path.join(work, "base_cover.mp4")
            fc_checks, _n = fcm.apply(base, _cov, _fcv)
            os.replace(_cov, base)
            print(f"   Covered {_n} face(s).", flush=True)
        except Exception as e:
            SKIPPED.append("Cover a face: I could not cover the faces this time (" + str(e)[:80] + "). Check your video before posting.")
    faces = detect_faces(base)
    items = []
    for i in kept:
        w = words[i]
        os_, oe = mp(w["s"]), mp(w["e"])
        if os_ is None:
            continue
        txt = dec.get("text", {}).get(str(i), w["w"])
        if items and items[-1]["w"].lower() == "y" and txt.lower().startswith("'all") and os_ - items[-1]["oe"] < 0.3:
            # the speech tool splits "y'all" into two pieces: join them back into one word
            items[-1]["w"] = "y'all" + txt[4:]
            items[-1]["oe"] = oe if oe is not None else os_ + 0.2
            continue
        if items and items[-1]["w"].lower().strip(".,?!") == "wait" and txt.lower().strip(".,?!") == "list" and os_ - items[-1]["oe"] < 0.3:
            # "wait list" is one word on screen
            items[-1]["w"] = "waitlist" + (txt[4:] if len(txt) > 4 else "")
            items[-1]["oe"] = oe if oe is not None else os_ + 0.2
            continue
        items.append({"w": txt, "os": os_, "oe": oe if oe is not None else os_ + 0.2, "i": i})
    hook_lines = [x.strip() for x in hook_txt.split("|") if x.strip()]
    picks = dec["graphics"] if "graphics" in dec else (json.load(open(a.graphics, encoding="utf-8")) if a.graphics else None)
    gfx = [] if a.no_graphics else find_graphics(items, total, a.hook_seconds, cta, picks)
    if dec.get("no_stats"):
        gfx = [g for g in gfx if g["type"] != "stat"]
    # taste ceiling (reel-font-system.md, part I): never more of the loud things than the chosen level allows
    level = int(dec.get("intensity") or 2)
    caps = {"punch": {1: 1, 2: 3, 3: 3}.get(level, 3), "stat": {1: 1, 2: 2, 3: 3}.get(level, 2)}
    for kind, mx in caps.items():
        mine = [g for g in gfx if g["type"] == kind]
        if len(mine) > mx:
            drop = set(id(g) for g in mine[mx:])
            gfx = [g for g in gfx if id(g) not in drop]
            print(f"TASTE: kept {mx} of {len(mine)} {kind} moments (intensity level {level}) so the video does not feel over-edited.", flush=True)
    gif_picks = dec["gifs"] if "gifs" in dec else (json.load(open(a.gifs, encoding="utf-8")) if a.gifs else None)
    for _pk in list(gif_picks or []) + list(dec.get("broll") or []):
        if isinstance(_pk, dict) and _pk.get("file") and not os.path.isabs(_pk["file"]):
            _pk["file"] = os.path.join(ROOT_DIR, _pk["file"])
    if gif_picks and not a.no_graphics:
        gfx += find_gifs(items, gif_picks, work, gfx, a.hook_seconds)
        gfx.sort(key=lambda g: g["start"])
    scene_picks = dec["scenes"] if "scenes" in dec else (json.load(open(a.scenes, encoding="utf-8")) if a.scenes else None)
    if scene_picks and not a.no_graphics:
        gfx += find_scenes(items, scene_picks, gfx, a.hook_seconds)
        gfx.sort(key=lambda g: g["start"])
    br_picks = dec["broll"] if "broll" in dec else (json.load(open(a.broll, encoding="utf-8")) if a.broll else None)
    if br_picks and not a.no_graphics:
        gfx += find_brolls(items, br_picks, work, gfx, a.hook_seconds)
        gfx.sort(key=lambda g: g["start"])
    frz_picks = dec["freezes"] if "freezes" in dec else (json.load(open(a.freezes, encoding="utf-8")) if a.freezes else None)
    if frz_picks and not a.no_graphics:
        gfx += find_freezes(items, frz_picks, gfx, a.hook_seconds)
        gfx.sort(key=lambda g: g["start"])
    ec = dec.get("end_card") or ({"text": a.endcard.split("|")[0], "hi": (a.endcard.split("|") + [None])[1]} if a.endcard else None)
    if ec and ec.get("text") and not a.no_graphics:
        e0 = max(a.hook_seconds + 1.0, total - 2.4)
        gfx = [g for g in gfx if g["end"] < e0 - 0.1]
        gfx.append({"type": "punch", "start": e0, "end": total, "text": ec["text"], "hi": ec.get("hi"), "phrase": ec["text"]})
        gfx.sort(key=lambda g: g["start"])
    fx_picks = dec["effects"] if "effects" in dec else (json.load(open(a.effects, encoding="utf-8")) if a.effects else None)
    if fx_picks is None and not a.no_graphics:
        fx_picks = auto_effects(items)
    if fx_picks and not a.no_graphics:
        gfx += find_effects(items, fx_picks, gfx, a.hook_seconds)
        gfx.sort(key=lambda g: g["start"])
    for sk in SKIPPED:
        print("SKIPPED: " + sk)
    for g in gfx:
        print(f"    graphic: {g['type']:5s} {g['start']:5.1f}s  {g.get('effect','') + ' ' if g['type']=='effect' else ''}{g.get('text') or g.get('phrase') or g.get('number','') + ' ' + g.get('label','')}")
    overlay = os.path.join(work, "overlay.mov")
    import hook_styles
    hs_hist_path = os.path.join(ROOT_DIR, "customer", "profile", "hook-history.json")
    try:
        hs_hist = json.load(open(hs_hist_path, encoding="utf-8"))
    except Exception:
        hs_hist = []
    auto_style = not dec.get("hook_style")
    hook_style = dec.get("hook_style") or (hook_styles.suggest(hook_lines, hs_hist)[0] if hook_lines else "box")
    dec["hook_style"] = hook_style  # kept in the edit plan, so later rebuilds keep the same style unless she changes it
    build_overlay(overlay, total, items, look, hook_lines, a.hook_seconds, gfx, faces, base, "none" if a.capcut else (dec.get("caption_mode") or a.captions), progress=(not a.no_progress and (dec.get("options") or {}).get("progress", True)), blur_bg=bool(a.blur_bg or (dec.get("options") or {}).get("blur_bg")), cap_ranges=dec.get("caption_styles"), textjobs=find_texts(items, dec, total, a.hook_seconds), hook_drop=bool(dec.get("hook_drop")), grain=bool(a.grain or (dec.get("options") or {}).get("grain")),
                  layout_dir=None if a.capcut else os.path.join(outdir, ".live", f"{name}_layers_v{a.version}"),
                  hook_style=hook_style, hook_scale=float(dec.get("hook_scale", 1.0)), hook_dy=int(dec.get("hook_dy", 0)), hook_dx=int(dec.get("hook_dx", 0)))
    if hook_lines and auto_style:
        try:
            os.makedirs(os.path.dirname(hs_hist_path), exist_ok=True)
            json.dump((hs_hist + [hook_style])[-8:], open(hs_hist_path, "w", encoding="utf-8"))
        except Exception:
            pass

    print("4/5 Putting it together...")
    final = os.path.join(outdir, f"{name}_edit{a.version}.mp4")
    if a.capcut:
        import sounds as _snd
        ev = []
        for g in gfx:
            t0, kind = g["start"], g["type"]
            if kind == "punch":
                ev += [(t0 - 0.12, "whoosh", 0.5), (t0, "impact", 0.55)]
            elif kind == "scene":
                ev += [(t0 - 0.1, "whoosh", 0.6), (t0 + 0.1, "pop", 0.5), (g["end"] - 0.25, "whoosh", 0.4)]
            elif kind == "freeze":
                ev.append((t0, "pop", 0.6))
            elif kind == "broll":
                ev += [(t0 - 0.08, "whoosh", 0.55)]
            elif kind == "gif":
                ev.append((t0, "pop", 0.5))
            elif kind == "stat":
                ev.append((t0, "pop", 0.5))
            elif kind == "effect":
                ev.append((t0, {"typing": "typing", "popup": "notif", "notifpile": "notif", "reply": "notif", "chat": "notif", "screenshot": "shutter", "phone": "shutter", "collage": "shutter", "receipt": "coin"}.get(g.get("effect", ""), "pop"), 0.5))
        for zs, _ze in zoom_ranges:
            ev.append((zs - 0.08, "whoosh", 0.3))
        root = os.path.join(os.path.dirname(os.path.abspath(outdir)), "capcut")
        os.makedirs(root, exist_ok=True)
        nn = 1
        while os.path.exists(os.path.join(root, f"{name}_for-capcut_v{nn}")):
            nn += 1
        cdir = os.path.join(root, f"{name}_for-capcut_v{nn}")
        os.makedirs(cdir)
        shutil.copy2(base, os.path.join(cdir, "1-video.mp4"))
        run(["ffmpeg", "-y", "-v", "error", "-i", overlay, "-c:v", "prores_ks", "-profile:v", "4444", "-pix_fmt", "yuva444p10le",
             "-qscale:v", "22", os.path.join(cdir, "2-graphics.mov")])
        if ev:
            _snd.build_track(ev, max(0.5, total - 1.0), os.path.join(cdir, "3-sounds.wav"))
        write_srt(items, os.path.join(cdir, "4-captions.srt"))
        open(os.path.join(cdir, "READ-ME.txt"), "w", encoding="utf-8").write(
            "Edit this in CapCut\n\n"
            "1. Open CapCut, start a new project, and drag in 1-video.mp4. It is already cut, zoomed and leveled.\n"
            "2. Drag in 2-graphics.mov and put it on a track above the video. It holds your hook, big words, GIFs and add-ins (no captions). Start it at 0:00.\n"
            "3. Drag in 3-sounds.wav on an audio track. Start it at 0:00. It holds the little whooshes, pops and pings.\n"
            "4. For captions, use CapCut's Captions, then Local captions (or Import), and pick 4-captions.srt. Or let CapCut make its own.\n"
            "5. Add your own effects, a trending sound at low volume, and export.\n\n"
            "All three files are exactly the same length and start at 0:00, so they line up.\n")
        print("CAPCUT: " + cdir)
        tidy(outdir, name, work, a.keep)
        return
    sfx = None
    if not a.no_sound and (dec.get("options") or {}).get("sound", True):
        import sounds
        ev = []
        for g in gfx:
            t0, kind = g["start"], g["type"]
            if kind == "punch":
                ev += [(t0 - 0.12, "whoosh", 0.5), (t0, "impact", 0.55)]
            elif kind == "scene":
                ev += [(t0 - 0.1, "whoosh", 0.6), (t0 + 0.1, "pop", 0.5), (g["end"] - 0.25, "whoosh", 0.4)]
            elif kind == "freeze":
                ev.append((t0, "pop", 0.6))
            elif kind == "broll":
                ev += [(t0 - 0.08, "whoosh", 0.55)]
            elif kind == "gif":
                ev.append((t0, "pop", 0.5))
            elif kind == "stat":
                ev.append((t0, "coin" if "$" in str(g.get("number", "")) else "pop", 0.5))
            elif kind == "effect":
                fxk = g.get("effect", "")
                snd = {"typing": "typing", "popup": "notif", "notifpile": "notif", "reply": "notif", "chat": "notif",
                       "screenshot": "shutter", "phone": "shutter", "collage": "shutter", "receipt": "coin"}.get(fxk, "pop")
                ev.append((t0, snd, 0.5))
        for zs, _ze in zoom_ranges:
            ev.append((zs - 0.08, "whoosh", 0.3))
        if ev:
            sfx = sounds.build_track(ev, total, os.path.join(work, "sfx.wav"))
    opts_mix = dec.get("options") or {}
    music = opts_mix.get("music") or {}
    music_file = music.get("file")
    if music_file and not os.path.isabs(music_file):
        music_file = os.path.join(ROOT_DIR, music_file)
    if music_file and not os.path.exists(music_file):
        SKIPPED.append("Background music: I could not find that song file, so I left it out.")
        music_file = None
    sfx_vol = float(opts_mix.get("sfx_volume", 0.55))
    cmd = ["ffmpeg", "-y", "-v", "error", "-i", base, "-i", overlay]
    n_in = 2
    fc = "[0:v][1:v]overlay=format=auto[o]"
    mix_labels = []
    if sfx:
        cmd += ["-i", sfx]
        fc += f";[{n_in}:a]volume={sfx_vol:.2f}[s]"
        mix_labels.append("[s]")
        n_in += 1
    if music_file:
        mv = max(0.02, min(0.6, float(music.get("volume", 0.15))))
        cmd += ["-stream_loop", "-1", "-i", music_file]
        fc += (f";[0:a]asplit=2[va][vb];[{n_in}:a]atrim=0:{total:.2f},asetpts=PTS-STARTPTS,afade=t=in:d=0.8,afade=t=out:st={max(0.0, total - 1.2):.2f}:d=1.2,volume={mv:.2f}[mus];"
               f"[mus][vb]sidechaincompress=threshold=0.03:ratio=10:attack=30:release=400[md]")
        mix_labels.append("[md]")
        voice = "[va]"
    else:
        voice = "[0:a]"
    if mix_labels:
        fc += f";{voice}{''.join(mix_labels)}amix=inputs={1 + len(mix_labels)}:duration=first:normalize=0[ao]"
        maps = ["-map", "[o]", "-map", "[ao]", "-c:a", "aac", "-b:a", "192k"]
    else:
        maps = ["-map", "[o]", "-map", "0:a", "-c:a", "copy"]
    run(cmd + ["-filter_complex", fc] + maps + ["-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p", "-profile:v", "high", "-level", "4.2", "-movflags", "+faststart", final])

    try:
        def _ts(x):
            return f"{int(x // 3600):02d}:{int(x % 3600 // 60):02d}:{int(x % 60):02d},{int(round((x % 1) * 1000)) % 1000:03d}"
        _ch = chunk_words(items, max_words=6)
        _srt = []
        for _n, _c in enumerate(_ch, 1):
            _end = _c[-1]["oe"] if _n == len(_ch) else max(_c[-1]["oe"], min(_ch[_n][0]["os"], _c[-1]["oe"] + 0.4))
            _srt.append(f"{_n}\n{_ts(_c[0]['os'])} --> {_ts(_end)}\n{' '.join(x['w'] for x in _c)}\n")
        open(os.path.splitext(final)[0] + ".srt", "w", encoding="utf-8").write("\n".join(_srt))
    except Exception:
        pass
    sp_picks = dec["speed"] if "speed" in dec else (json.load(open(a.speed, encoding="utf-8")) if a.speed else None)
    if sp_picks:
        apply_speed_ramps(final, find_ramps(items, sp_picks), total)
    print("5/5 Saving the edit plan...")
    sentences, cur = [], []
    for ki, it in enumerate(items):
        cur.append(it)
        if sentence_end(it["w"], len(cur), (items[ki + 1]["os"] - it["oe"]) if ki + 1 < len(items) else 9):
            sentences.append({"start": round(cur[0]["os"], 1), "text": " ".join(c["w"] for c in cur)})
            cur = []
    if cur:
        sentences.append({"start": round(cur[0]["os"], 1), "text": " ".join(c["w"] for c in cur)})
    fun_sugg, fat = [], []
    try:
        fun_sugg = suggest_fun(items, hook_lines, total)
        hpath = os.path.join(ROOT_DIR, "customer", "profile", "style-history.json")
        hist = json.load(open(hpath, encoding="utf-8")) if os.path.exists(hpath) else []
        kinds = sorted({t["kind"] for t in (dec.get("texts") or [])})
        fat = fatigue_note(hist, kinds, dec.get("caption_mode") or a.captions, hook_style)
        os.makedirs(os.path.dirname(hpath), exist_ok=True)
        json.dump((hist + [{"video": name, "look": look["name"], "hook_style": hook_style, "caption_mode": dec.get("caption_mode") or a.captions, "kinds": kinds}])[-12:], open(hpath, "w", encoding="utf-8"), indent=1)
    except Exception:
        pass
    plan = {"face_cover_checks": fc_checks, "fun_suggestions": fun_sugg, "fatigue": fat, "source": video, "script": a.script, "skipped": list(SKIPPED), "sentences": sentences, "look": look["name"], "language": data["language"], "fonts": used_fonts,
            "original_seconds": data["duration"], "edited_seconds": total,
            "segments": [{"start": s, "end": e} for s, e, *_ in segs],
            "words": [{"i": i, **w, "cut": reasons.get(i)} for i, w in enumerate(words)],
            "decisions": dec, "hook": hook_lines, "decisions": dec, "graphics": [{k: v for k, v in g.items() if k not in ("frames", "durs", "img") and not k.startswith("_")} for g in gfx], "cta": cta,
            "faces": [{"t": round(t, 2), "box": [round(v) for v in r]} for t, r in faces][::3]}
    json.dump(plan, open(os.path.join(outdir, f"{name}_edit{a.version}.plan.json"), "w", encoding="utf-8"), indent=1)
    with open(os.path.join(outdir, f"{name}_pick-sheet.txt"), "w", encoding="utf-8") as ps:  # the only thing Claude needs to read
        ps.write("Sentences (time, text). Pick 3 or 4 punchy phrases for full-screen words, and 2 or 3 GIF moments.\n")
        for sn in sentences:
            ps.write(f"{sn['start']:5.1f}  {sn['text']}\n")
    tidy(outdir, name, work, a.keep)
    try:
        import build_times
        build_times.record(outdir, data["duration"], time.time() - t_start)
    except Exception:
        pass
    print(f"Done in {time.time()-t_start:.0f}s: {final}")
    print("Fonts used:", used_fonts)
    if not a.no_sheet and not os.environ.get("CE_NO_SHEET") and not a.capcut:
        try:  # open her edit sheet right away so she never has to hunt for it
            from sheet_launcher import launch
            url = launch(outdir, name)
            if url:
                print("Edit sheet:", url)
        except Exception:
            pass


if __name__ == "__main__":
    main()
