#!/usr/bin/env python3
"""Makes engine/tools/effects.html: every effect the engine can add, each playing, with its name and what to say to ask for it.
  python make_effects_page.py        then open the printed path (she says: "show me the effects")
Reads gallery/gallery.json (made by build_gallery.py) so the page always matches what the engine can do.
"""
import html, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
SAY = {"count": "Put a {n} on my number.", "shimmer": "Put a {n} on my hook.", "chart": "Add a {n} when I talk about growth.",
       "slam": "Use {n} on my big line.", "glitch": "Add a {n} on my punchline.", "orbit": "Put my reels in an {n}."}
WHOLE = [("Film grain", "Add film grain to the whole reel so it feels like film.", "Over the whole video, light and subtle."),
         ("Pop captions", "Do my captions in pop.", "One big bouncy word at a time. The default."),
         ("Karaoke captions", "Do my captions in karaoke.", "A line of words with the spoken word lit up."),
         ("Plain caption lines", "Do my captions as plain lines.", "A calm line at the bottom."),
         ("Mix caption styles", "Karaoke on my hook, pop on my punchline, plain for the rest.", "Different styles in one reel.")]
BA = [("Side-by-side", "Raw on the left, edited on the right, playing together.", "Make a side-by-side before and after of my video."),
      ("Curtain wipe", "A curtain slides between raw and edited, ending on the finished reel.", "Make a curtain wipe before and after of my video."),
      ("Freeze-frame reveal", "The raw clip freezes on its worst moment, then snaps to the edited version.", "Make a freeze-frame reveal of my video."),
      ("Screen recording to result", "A sped-up screen recording of the engine working, then the finished reel.", "Make a screen recording to result reel.")]
CAM = [("Punch-in zoom", "A slow push in on a line. On by default on every other sentence."),
       ("Freeze frame", "The picture holds for a beat on a word, with a small flash."),
       ("Cutaway (B-roll)", "A full-screen clip or photo for a moment, with a whip, iris, wipe, flash or fade."),
       ("Full-screen takeover words", "Big words fill the screen on your key line."),
       ("GIFs and memes", "A GIF behind or beside you. Your own GIF folder is used first.")]


def main():
    items = json.load(open(os.path.join(HERE, "gallery", "gallery.json"), encoding="utf-8"))
    cards = ""
    for it in items:
        name = it["label"]
        say = SAY.get(it["key"], "Add a {n} on “my words”.").format(n=name)
        cards += (f'<div class="card"><img src="gallery/{it["key"]}.gif" alt="{html.escape(name)}" loading="lazy">'
                  f'<div class="t"><b>{html.escape(name)}</b><span>{html.escape(it["about"])}</span><em>Say: “{html.escape(say)}”</em></div></div>')
    whole = "".join(f'<div class="row"><b>{html.escape(a)}</b><span>{html.escape(c)}</span><em>Say: “{html.escape(b)}”</em></div>' for a, b, c in WHOLE)
    ba = "".join(f'<div class="row"><b>{html.escape(a)}</b><span>{html.escape(b)}</span><em>Say: “{html.escape(c)}”</em></div>' for a, b, c in BA)
    cam = "".join(f'<div class="row"><b>{html.escape(a)}</b><span>{html.escape(b)}</span></div>' for a, b in CAM)
    page = f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Effects you can ask for</title>
<style>:root{{--bg:#F4EDE2;--card:#fff;--ink:#26332C;--muted:#55544B;--line:#DACDB9;--teal:#2A6E6F}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:16px/1.5 system-ui,-apple-system,Segoe UI,sans-serif}}
header,main{{max-width:1100px;margin:0 auto;padding:20px 16px}}h1{{margin:0 0 6px;font-size:30px}}h2{{margin:28px 0 10px;font-size:20px;color:var(--teal)}}
.sub{{color:var(--muted);margin:0}}.grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:16px}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:16px;overflow:hidden}}.card img{{width:100%;display:block;background:#8a93a0}}
.t{{padding:12px 14px}}.t b,.row b{{display:block;font-size:17px}}.t span,.row span{{display:block;font-size:14px;color:var(--muted);margin-top:2px}}
em{{display:block;font-size:13px;color:var(--teal);margin-top:8px;font-style:normal}}
.row{{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:12px 14px;margin:8px 0}}</style></head><body>
<header><h1>Effects you can ask for</h1><p class="sub">Ask for any of these by name when your plan comes up, or any time. Effects only show up when you ask. Everything else looks like your style.</p></header>
<main><h2>Extras that pop up on a line</h2><div class="grid">{cards}</div>
<h2>Looks and captions for the whole reel</h2>{whole}
<h2>Before and after reels</h2>{ba}<h2>Camera moves and cutaways</h2>{cam}</main></body></html>"""
    out = os.path.join(HERE, "effects.html")
    open(out, "w", encoding="utf-8").write(page)
    print(out)


main()
