#!/usr/bin/env python3
"""The inbox: one folder (inbox/ at the top of the engine folder) where all her new videos go.
  python inbox.py list                 what is in the inbox (name, length, size, date), newest first
  python inbox.py take FILE            copy that video into customer/videos/recorded/ and add it to the library
  python inbox.py images               pictures in the inbox (inspiration screenshots, GIFs)
  python inbox.py take-inspo FILE...   copy screenshots into customer/profile/inspo/ (her style references)
  python inbox.py take-gifs            copy every GIF/picture file from inbox/gifs/ (or the named files) into customer/profile/gifs/
Her original stays in the inbox, untouched. Nothing is ever deleted or renamed here.
"""
import datetime, os, shutil, subprocess, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
INBOX = os.path.join(ROOT, "inbox")
REC = os.path.join(ROOT, "customer", "videos", "recorded")
EXT = (".mov", ".mp4", ".m4v", ".mkv", ".avi", ".webm")
IMG = (".png", ".jpg", ".jpeg", ".webp", ".heic", ".gif")
INSPO = os.path.join(ROOT, "customer", "profile", "inspo")
GIFS = os.path.join(ROOT, "customer", "profile", "gifs")


def length(p):
    try:
        r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p], capture_output=True, text=True, encoding="utf-8", errors="replace")
        s = round(float(r.stdout.strip()))
        return "%d:%02d" % (s // 60, s % 60)
    except Exception:
        return "?"


def videos():
    if not os.path.isdir(INBOX):
        return []
    fs = [os.path.join(INBOX, f) for f in os.listdir(INBOX) if f.lower().endswith(EXT) and not f.startswith(".")]
    return sorted(fs, key=os.path.getmtime, reverse=True)


def main():
    a = sys.argv[1:]
    if not a or a[0] not in ("list", "take", "images", "take-inspo", "take-gifs"):
        sys.exit(__doc__)
    if a[0] == "images":
        fs = []
        for dp, _, names in os.walk(INBOX):
            fs += [os.path.join(dp, n) for n in names if n.lower().endswith(IMG) and not n.startswith(".")]
        for i, p in enumerate(sorted(fs, key=os.path.getmtime, reverse=True), 1):
            print(f"{i}. {os.path.relpath(p, INBOX)} · {os.path.getsize(p) / 1e3:.0f} KB")
        if not fs:
            print("No pictures in the inbox yet.")
        return
    if a[0] in ("take-inspo", "take-gifs"):
        dest = INSPO if a[0] == "take-inspo" else GIFS
        os.makedirs(dest, exist_ok=True)
        names = a[1:]
        if not names:
            src_dir = os.path.join(INBOX, "gifs") if a[0] == "take-gifs" else INBOX
            names = [os.path.join(src_dir, n) for n in os.listdir(src_dir) if n.lower().endswith(IMG)] if os.path.isdir(src_dir) else []
        n = 0
        for nm in names:
            src = nm if os.path.isabs(nm) else os.path.join(INBOX, nm)
            if os.path.exists(src) and not os.path.exists(os.path.join(dest, os.path.basename(src))):
                shutil.copy2(src, os.path.join(dest, os.path.basename(src)))
                n += 1
        print(f"Copied {n} file(s) to {dest}. Your originals are still in the inbox.")
        return
    if a[0] == "list":
        vs = videos()
        if not vs:
            print("Your inbox is empty. Drop your videos in:", INBOX)
            return
        for i, p in enumerate(vs, 1):
            when = datetime.datetime.fromtimestamp(os.path.getmtime(p)).strftime("%b %d")
            print(f"{i}. {os.path.basename(p)} · {length(p)} · {os.path.getsize(p) / 1e6:.0f} MB · {when}")
        return
    src = a[1]
    if not os.path.isabs(src):
        src = os.path.join(INBOX, src)
    if not os.path.exists(src):
        sys.exit("I can't find that file in the inbox.")
    os.makedirs(REC, exist_ok=True)
    dst = os.path.join(REC, os.path.basename(src))
    if os.path.exists(dst):
        print("Already copied:", dst)
    else:
        shutil.copy2(src, dst)
        print("Copied to", dst, "(your original is still in the inbox).")
    subprocess.run([sys.executable, os.path.join(ROOT, "engine", "tools", "library.py"), "scan"])


main()
