#!/usr/bin/env python3
"""Build the zip customers download. (For the engine's builder, not for customers.)
  python package_engine.py [OUT_FOLDER]
Makes Content-Engine.zip with ONE top folder named Content-Engine (no version number in the name, so Mac and PC are the same
and nobody picks the wrong folder). The version lives in engine/VERSION. The zip holds CLAUDE.md, engine/, inbox/ and an empty
customer/ skeleton. No customer data, no builder notes, no old engine copies, no cache files, and an EMPTY inbox (just its README).
"""
import os, sys, zipfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
TOP = "Content-Engine"
SKELETON = ["customer/profile", "customer/rules", "customer/scripts", "customer/videos/recorded", "customer/videos/edited",
            "customer/insights", "customer/plans", "customer/content"]
SKIP_DIRS = {"__pycache__", ".git", ".DS_Store"}


def main():
    out = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.join(os.path.dirname(ROOT), "My Engine DIST")
    os.makedirs(out, exist_ok=True)
    version = open(os.path.join(ROOT, "engine", "VERSION"), encoding="utf-8").read().strip() if os.path.exists(os.path.join(ROOT, "engine", "VERSION")) else "unknown"
    path = os.path.join(out, TOP + ".zip")
    n = 0
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(os.path.join(ROOT, "CLAUDE.md"), TOP + "/CLAUDE.md")
        for nm in ("Open My Content Engine.command", "Open My Content Engine.bat"):
            if os.path.exists(os.path.join(ROOT, nm)):
                z.write(os.path.join(ROOT, nm), TOP + "/" + nm)
        # the customer's inbox starts empty: only its README and the b-roll folder ship (never the builder's own screenshots and clips)
        for rel in ("inbox/README.txt", "inbox/broll/README.txt"):
            if os.path.exists(os.path.join(ROOT, rel)):
                z.write(os.path.join(ROOT, rel), TOP + "/" + rel)
                n += 1
        for base in ("engine",):
            for dp, dns, fns in os.walk(os.path.join(ROOT, base)):
                dns[:] = [d for d in dns if d not in SKIP_DIRS and not d.startswith("engine-old-")]
                for f in fns:
                    if f.endswith(".pyc") or f == ".DS_Store":
                        continue
                    full = os.path.join(dp, f)
                    z.write(full, TOP + "/" + os.path.relpath(full, ROOT).replace(os.sep, "/"))
                    n += 1
        for d in SKELETON:
            z.writestr(TOP + "/" + d + "/.keep", "")
    # the little file the updater reads: version, where the zip is, a fingerprint, and what is new
    import hashlib, json
    notes = ""
    rn = os.path.join(ROOT, "engine", "RELEASE-NOTES.md")
    if os.path.exists(rn):
        first = open(rn, encoding="utf-8").read().split("\n\n")
        notes = " ".join(x.strip() for x in first[1:2] if x.strip())[:400] if len(first) > 1 else ""
    json.dump({"version": version, "zip": TOP + ".zip", "sha256": hashlib.sha256(open(path, "rb").read()).hexdigest(), "notes": notes},
              open(os.path.join(out, "latest.json"), "w", encoding="utf-8"), indent=1)
    print("Built", path, "(%d engine files, %.1f MB, version %s)" % (n, os.path.getsize(path) / 1e6, version))


main()

# release reminder: placeholders that must be filled in before customers get this
for _f in ("SUPPORT", "UPDATE_URL"):
    _p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", _f)
    if os.path.exists(_p) and "REPLACE_BEFORE_RELEASE" in open(_p, encoding="utf-8").read():
        print(f"REMINDER: engine/{_f} still says REPLACE_BEFORE_RELEASE. Fill it in before you send this to customers.")
