#!/usr/bin/env python3
"""Her B-roll clips: collect them in one place, make a contact sheet of each, and keep a label for each so the engine can match clips to lines.
  python broll_index.py scan                 copy new clips from inbox/broll/ into customer/videos/broll/, make contact sheets, list what needs a label
  python broll_index.py label FILE "what it shows"      save a plain description (the engine looks at the sheet and writes this)
  python broll_index.py list                 every clip, its length and its label
Her originals stay in the inbox. Nothing is deleted or renamed.
"""
import json, os, shutil, subprocess, sys
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
INBOX = os.path.join(ROOT, "inbox", "broll")
LIB = os.path.join(ROOT, "customer", "videos", "broll")
DB = os.path.join(LIB, "library.json")
EXT = (".mov", ".mp4", ".m4v", ".webm")


def load():
    try:
        return json.load(open(DB, encoding="utf-8"))
    except Exception:
        return {}


def save(d):
    os.makedirs(LIB, exist_ok=True)
    json.dump(d, open(DB, "w", encoding="utf-8"), indent=1)


def dur(p):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p], capture_output=True, text=True, encoding="utf-8", errors="replace")
    try:
        return round(float(r.stdout.strip()), 1)
    except Exception:
        return None


def sheet(p, out):
    d = dur(p) or 3
    ims = []
    for k in range(3):
        o = out + f".{k}.jpg"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", f"{d * (k + 0.5) / 3:.2f}", "-i", p, "-frames:v", "1", "-vf", "scale=-2:420", o])
        if os.path.exists(o):
            ims.append(Image.open(o).convert("RGB"))
    if ims:
        w, h = ims[0].size
        s = Image.new("RGB", (w * len(ims), h))
        for i, im in enumerate(ims):
            s.paste(im, (i * w, 0))
        s.save(out + ".jpg", quality=85)
    for k in range(3):
        try: os.remove(out + f".{k}.jpg")
        except Exception: pass


def main():
    a = sys.argv[1:]
    if not a or a[0] not in ("scan", "label", "list"):
        sys.exit(__doc__)
    db = load()
    if a[0] == "scan":
        os.makedirs(os.path.join(LIB, "_sheets"), exist_ok=True)
        if os.path.isdir(INBOX):
            for f in sorted(os.listdir(INBOX)):
                if f.lower().endswith(EXT) and not f.startswith("."):
                    dst = os.path.join(LIB, f)
                    if not os.path.exists(dst):
                        shutil.copy2(os.path.join(INBOX, f), dst)
        for f in sorted(os.listdir(LIB)) if os.path.isdir(LIB) else []:
            if f.lower().endswith(EXT) and f not in db:
                p = os.path.join(LIB, f)
                sheet(p, os.path.join(LIB, "_sheets", os.path.splitext(f)[0]))
                db[f] = {"seconds": dur(p), "label": ""}
        save(db)
    if a[0] == "label":
        if a[1] in db:
            db[a[1]]["label"] = a[2]
            save(db)
    for f, v in sorted(db.items()):
        print(f"{f} · {v['seconds']}s · {v['label'] or '(needs a label: look at _sheets/' + os.path.splitext(f)[0] + '.jpg)'}")
    if not db:
        print("No B-roll clips yet. Drop clips in the inbox/broll folder.")


main()
