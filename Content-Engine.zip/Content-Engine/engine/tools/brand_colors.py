"""Find her brand colors from her website.
  python3 brand_colors.py https://her-site.com            show what I found
  python3 brand_colors.py https://her-site.com --kit       her whole brand card: name, logo, fonts, colors and photos (saved in customer/profile/brand/)
  python3 brand_colors.py https://her-site.com --save      also save customer/profile/brand.json (her "brand look")
  python3 brand_colors.py --image logo-or-screenshot.png [--save]   colors from a logo or a screenshot of her site
  python3 brand_colors.py --hex "#2A6E6F,#C9A227"          save colors she types in (no website)
Reads only the public page and its stylesheets. Never asks for a login.
"""
import colorsys, json, os, re, sys, urllib.request, urllib.parse
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
UA = {"User-Agent": "Mozilla/5.0 (Macintosh) ContentEngine/1.0"}


def get(url, limit=600000):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.read(limit).decode("utf-8", "ignore")


def to_rgb(tok):
    tok = tok.strip().lower()
    if tok.startswith("#"):
        h = tok[1:]
        if len(h) in (3, 4):
            h = "".join(c * 2 for c in h[:3])
        if len(h) >= 6:
            try:
                return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
            except ValueError:
                return None
    m = re.match(r"rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)", tok)
    if m:
        return tuple(min(255, int(x)) for x in m.groups())
    return None


def hexof(rgb):
    return "#%02X%02X%02X" % tuple(rgb)


def hsl(rgb):
    h, l, s = colorsys.rgb_to_hls(*(c / 255 for c in rgb))
    return h, s, l


def chromatic(rgb):
    h, s, l = hsl(rgb)
    return s >= 0.18 and 0.12 <= l <= 0.88


def dist(a, b):
    return sum((x - y) ** 2 for x, y in zip(a, b)) ** 0.5


def scan(html, css_texts):
    score = Counter()
    for m in re.finditer(r'<meta[^>]+name=["\'](?:theme-color|msapplication-TileColor)["\'][^>]*content=["\']([^"\']+)', html, re.I):
        c = to_rgb(m.group(1))
        if c:
            score[c] += 60
    blob = html + "\n" + "\n".join(css_texts)
    for m in re.finditer(r"--([a-z0-9_-]*(?:primary|brand|accent|main|theme|secondary|highlight)[a-z0-9_-]*)\s*:\s*([^;}\n]+)", blob, re.I):
        c = to_rgb(m.group(2).split()[0]) if m.group(2).strip() else None
        if c:
            score[c] += 25
    for m in re.finditer(r"#[0-9a-fA-F]{6}\b|#[0-9a-fA-F]{3}\b|rgba?\(\s*\d+[ ,]+\d+[ ,]+\d+", blob):
        c = to_rgb(m.group(0))
        if c:
            score[c] += 1
    return score


def pick(score):
    merged = []
    for c, n in score.most_common(200):
        for m in merged:
            if dist(m[0], c) < 38:
                m[1] += n
                break
        else:
            merged.append([c, n])
    chroma = sorted([m for m in merged if chromatic(m[0])], key=lambda m: -m[1])
    pal = []
    for c, n in chroma:
        if all(dist(c, p[0]) > 70 for p in pal):
            pal.append((c, n))
        if len(pal) == 4:
            break
    darks = [m for m in merged if hsl(m[0])[2] < 0.22]
    dark = max(darks, key=lambda m: m[1])[0] if darks else (31, 31, 31)
    return [p[0] for p in pal], dark


def logo_colors(html, base):
    try:
        m = re.search(r'<meta[^>]+property=["\']og:image["\'][^>]*content=["\']([^"\']+)', html, re.I)
        if not m:
            return Counter()
        url = urllib.parse.urljoin(base, m.group(1))
        req = urllib.request.Request(url, headers=UA)
        data = urllib.request.urlopen(req, timeout=15).read(3_000_000)
        from io import BytesIO
        from PIL import Image
        im = Image.open(BytesIO(data)).convert("RGB")
        im.thumbnail((120, 120))
        q = im.quantize(8)
        pal = q.getpalette()
        cnt = Counter()
        for n, idx in q.getcolors():
            cnt[tuple(pal[idx * 3:idx * 3 + 3])] += n // 8
        return cnt
    except Exception:
        return Counter()


def from_site(url):
    if not re.match(r"^https?://", url):
        url = "https://" + url
    html = get(url)
    css = []
    links = re.findall(r'<link[^>]+rel=["\']stylesheet["\'][^>]*href=["\']([^"\']+)', html, re.I) + re.findall(r'<link[^>]+href=["\']([^"\']+\.css[^"\']*)["\']', html, re.I)
    for l in list(dict.fromkeys(links))[:4]:
        try:
            css.append(get(urllib.parse.urljoin(url, l), 400000))
        except Exception:
            pass
    score = scan(html, css)
    pal, dark = pick(score)
    if len(pal) < 2:
        extra = logo_colors(html, url)
        pal2, _ = pick(score + extra)
        pal = pal2 or pal
    return url, pal, dark


def from_image(path, n=8):
    """Colors from a logo or a screenshot of her website or brand kit. Returns up to n distinct colors, most used first."""
    from PIL import Image
    im = Image.open(path).convert("RGB")
    im.thumbnail((200, 200))
    q = im.quantize(24)
    pal = q.getpalette()
    cnt = Counter()
    for c, idx in q.getcolors():
        cnt[tuple(pal[idx * 3:idx * 3 + 3])] += c
    merged = []
    for c, k in cnt.most_common():
        if not chromatic(c):
            continue
        for m in merged:
            if dist(m[0], c) < 50:
                m[1] += k
                break
        else:
            merged.append([c, k])
    merged.sort(key=lambda m: -m[1])
    out = []
    for c, k in merged:
        if all(dist(c, o) > 60 for o in out):
            out.append(c)
        if len(out) == n:
            break
    dark = min(cnt, key=lambda c: sum(c)) if cnt else (31, 31, 31)
    if sum(dark) > 200:
        dark = (31, 31, 31)
    return out, dark


def save(url, pal, dark):
    folder = os.path.join(ROOT, "customer", "profile")
    os.makedirs(folder, exist_ok=True)
    roles = ["primary", "secondary", "accent", "extra"]
    data = {"url": url, "colors": [{"role": roles[i], "hex": hexof(c)} for i, c in enumerate(pal)], "dark": hexof(dark)}
    json.dump(data, open(os.path.join(folder, "brand.json"), "w", encoding="utf-8"), indent=1)
    with open(os.path.join(folder, "brand.md"), "w", encoding="utf-8") as f:
        f.write("# Her brand colors\n\n" + (f"From: {url}\n\n" if url else "") + "\n".join(f"- {d['role']}: {d['hex']}" for d in data["colors"]) + f"\n- dark text: {data['dark']}\n")
    return data


def _abs(base, u):
    return urllib.parse.urljoin(base, u.strip())


def brand_kit(url):
    """Everything a brand card needs from a website: name, logo, fonts, photos and colors. Reads only public pages."""
    if not re.match(r"^https?://", url):
        url = "https://" + url
    html_ = get(url)
    css = []
    links = re.findall(r'<link[^>]+rel=["\']stylesheet["\'][^>]*href=["\']([^"\']+)', html_, re.I) + re.findall(r'<link[^>]+href=["\']([^"\']+\.css[^"\']*)["\']', html_, re.I)
    for l in list(dict.fromkeys(links))[:4]:
        try:
            css.append(get(urllib.parse.urljoin(url, l), 400000))
        except Exception:
            pass
    blob = html_ + "\n" + "\n".join(css)
    # name
    m = re.search(r'<meta[^>]+property=["\']og:site_name["\'][^>]*content=["\']([^"\']+)', html_, re.I) or re.search(r"<title[^>]*>([^<]+)</title>", html_, re.I)
    name = re.split(r"\s[|\-\u2013\u2014:]\s", (m.group(1) if m else urllib.parse.urlparse(url).netloc).strip())[0].strip()[:60]
    # fonts
    fonts = Counter()
    for fam in re.findall(r"family=([A-Za-z0-9+]+)", blob):
        fonts[fam.replace("+", " ")] += 6
    for decl in re.findall(r"font-family\s*:\s*([^;}{]+)", blob, re.I):
        for f in decl.split(","):
            f = f.strip().strip("\"'")
            if f and f.lower() not in ("inherit", "initial", "sans-serif", "serif", "monospace", "system-ui", "-apple-system", "blinkmacsystemfont", "segoe ui", "helvetica", "helvetica neue", "arial", "georgia", "times", "times new roman", "cursive", "fantasy", "emoji") and not f.startswith("var(") and len(f) < 32 and "icon" not in f.lower():
                fonts[f] += 1
    font_list = [f for f, _ in fonts.most_common(3)]
    # logo
    logo = None
    cands = []
    for tag in re.findall(r"<img\b[^>]*>", html_, re.I):
        src = re.search(r'(?:data-src|src)=["\']([^"\']+)', tag, re.I)
        if src and re.search(r"logo|brand", tag, re.I) and not src.group(1).startswith("data:"):
            cands.append(_abs(url, src.group(1)))
    for rel in ("apple-touch-icon", "icon"):
        for m_ in re.findall(r'<link[^>]+rel=["\'][^"\']*%s[^"\']*["\'][^>]*href=["\']([^"\']+)' % rel, html_, re.I):
            cands.append(_abs(url, m_))
    for u in cands:
        if not u.lower().split("?")[0].endswith(".ico"):
            logo = u
            break
    # photos
    photos = []
    og = re.search(r'<meta[^>]+property=["\']og:image["\'][^>]*content=["\']([^"\']+)', html_, re.I)
    if og:
        photos.append(_abs(url, og.group(1)))
    for tag in re.findall(r"<img\b[^>]*>", html_, re.I):
        src = re.search(r'(?:data-src|src)=["\']([^"\']+)', tag, re.I)
        if not src or src.group(1).startswith("data:"):
            continue
        u = _abs(url, src.group(1))
        low = u.lower().split("?")[0]
        if low.endswith((".svg", ".gif", ".ico")) or re.search(r"logo|icon|sprite|pixel|avatar|badge", tag, re.I):
            continue
        wm = re.search(r'width=["\']?(\d+)', tag, re.I)
        if wm and int(wm.group(1)) < 200:
            continue
        photos.append(u)
    photos = list(dict.fromkeys(photos))
    return {"url": url, "name": name, "logo_url": logo, "fonts": font_list, "photo_urls": photos, "html": html_, "css": css}


def save_kit(kit, pal, dark):
    """Download the logo and a few photos next to her profile and write brand.json."""
    from io import BytesIO
    from PIL import Image
    folder = os.path.join(ROOT, "customer", "profile", "brand")
    os.makedirs(os.path.join(folder, "photos"), exist_ok=True)

    def grab(u, maxw):
        req = urllib.request.Request(u, headers=UA)
        data = urllib.request.urlopen(req, timeout=15).read(6_000_000)
        im = Image.open(BytesIO(data))
        im.load()
        return im

    logo_file = ""
    if kit.get("logo_url"):
        try:
            im = grab(kit["logo_url"], 600)
            im = im.convert("RGBA")
            im.thumbnail((600, 400))
            im.save(os.path.join(folder, "logo.png"))
            logo_file = "logo.png"
        except Exception:
            logo_file = ""
    photos = []
    for u in kit.get("photo_urls", [])[:14]:
        if len(photos) >= 6:
            break
        try:
            im = grab(u, 900).convert("RGB")
            if im.width < 200 or im.height < 150:
                continue
            im.thumbnail((700, 700))
            fn = f"photo{len(photos) + 1}.jpg"
            im.save(os.path.join(folder, "photos", fn), quality=86)
            photos.append(fn)
        except Exception:
            continue
    roles = ["primary", "secondary", "accent", "extra"]
    data = {"url": kit["url"], "name": kit["name"], "fonts": kit["fonts"], "logo": logo_file, "photos": photos, "photo_total": len(kit.get("photo_urls", [])),
            "colors": [{"role": roles[i], "hex": hexof(c)} for i, c in enumerate(pal)], "dark": hexof(dark)}
    json.dump(data, open(os.path.join(ROOT, "customer", "profile", "brand.json"), "w", encoding="utf-8"), indent=1)
    with open(os.path.join(ROOT, "customer", "profile", "brand.md"), "w", encoding="utf-8") as f:
        f.write("# Her brand\n\n" + f"Name: {data['name']}\nFrom: {data['url']}\nFonts: {', '.join(data['fonts'])}\n\n" + "\n".join(f"- {c['role']}: {c['hex']}" for c in data["colors"]) + "\n")
    return data


def card_html(data, base="/customer/profile/brand"):
    """A brand card: name, logo, font, colors and photos (the look of a Canva brand kit). Images come from `base`."""
    import html as H
    cols = [c["hex"] for c in data.get("colors", [])][:4]
    if data.get("dark"):
        cols.append(data["dark"])
    stripes = "".join(f'<i style="background:{c}"></i>' for c in cols) or '<i style="background:#DDD"></i>'
    font = (data.get("fonts") or ["Your font"])[0]
    logo = f'<img src="{base}/{data["logo"]}" alt="logo">' if data.get("logo") else '<span class="nl">' + H.escape(data.get("name", "")[:14]) + "</span>"
    shown = data.get("photos", [])[:3]
    more = max(0, len(data.get("photos", [])) - len(shown))
    ph = "".join(f'<div class="ph"><img src="{base}/photos/{p}" alt=""></div>' for p in shown) + (f'<div class="ph more">+{more}</div>' if more else "")
    return (f'<div class="bcard"><div class="bhead"><b>{H.escape(data.get("name", "My brand"))}</b></div>'
            f'<div class="brow"><div class="logo">{logo}</div><div class="font"><div class="aa" style="font-family:\'{H.escape(font)}\',system-ui,sans-serif">Aa</div><div class="fn">{H.escape(font)}</div></div><div class="pal">{stripes}</div></div>'
            f'<div class="brow2">{ph}</div></div>')


CARD_CSS = """.bcard{background:#E9EBF0;border:2px solid #8E96A3;border-radius:22px;padding:18px;max-width:640px;font-family:system-ui,-apple-system,"Segoe UI",sans-serif}
.bcard .bhead b{font-size:26px;color:#1d2330}.bcard .brow{display:grid;grid-template-columns:1.15fr 1fr 1fr;gap:12px;margin-top:14px;align-items:stretch}
.bcard .logo{background:#DADDE3;border-radius:16px;display:flex;align-items:center;justify-content:center;padding:10px;min-height:120px}.bcard .logo img{max-width:100%;max-height:90px;object-fit:contain}.bcard .nl{font-weight:800;font-size:20px;color:#333}
.bcard .font{background:#fff;border:1px solid #D4D7DD;border-radius:16px;overflow:hidden;display:flex;flex-direction:column}.bcard .aa{flex:1;display:flex;align-items:center;justify-content:center;font-size:44px;background:#EEF0F3}.bcard .fn{text-align:center;padding:10px 6px;font-size:17px;background:#fff}
.bcard .pal{display:flex;border-radius:16px;overflow:hidden;border:1px solid #D4D7DD;min-height:120px}.bcard .pal i{flex:1}
.bcard .brow2{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:12px}.bcard .ph{aspect-ratio:1;border-radius:18px;overflow:hidden;background:#D8DBE1}.bcard .ph img{width:100%;height:100%;object-fit:cover;display:block}.bcard .more{display:flex;align-items:center;justify-content:center;font-size:22px;color:#333;font-weight:700}"""


def from_instagram(info):
    """info = {handle, name, profile_pic, posts:[image urls, newest first]}. Her profile picture becomes the logo, her latest posts become the photos."""
    old = os.path.join(ROOT, "customer", "profile", "brand.json")
    prev = json.load(open(old, encoding="utf-8")) if os.path.exists(old) else {}
    kit = {"url": "instagram.com/" + info.get("handle", "").lstrip("@"), "name": info.get("name") or prev.get("name", ""),
           "fonts": prev.get("fonts", []), "logo_url": info.get("profile_pic", ""), "photo_urls": info.get("posts", [])[:6]}
    data = save_kit(kit, [], (31, 31, 31))
    folder = os.path.join(ROOT, "customer", "profile", "brand")
    tally = Counter()
    for f in ([os.path.join(folder, "photos", x) for x in data["photos"]] + ([os.path.join(folder, data["logo"])] if data["logo"] else [])):
        try:
            for c in from_image(f, 4)[0]:
                tally[c] += 1
        except Exception:
            pass
    pal = []
    for c, _ in tally.most_common():
        if all(dist(c, o) > 70 for o in pal):
            pal.append(c)
        if len(pal) == 4:
            break
    roles = ["primary", "secondary", "accent", "extra"]
    data["colors"] = [{"role": roles[i], "hex": hexof(c)} for i, c in enumerate(pal)]
    json.dump(data, open(old, "w", encoding="utf-8"), indent=1)
    return data


def main():
    a = sys.argv[1:]
    if "--instagram" in a:
        d = from_instagram(json.load(open(a[a.index("--instagram") + 1], encoding="utf-8")))
        print(f"Saved from Instagram: logo {'yes' if d['logo'] else 'no'}, {len(d['photos'])} photos, {len(d['colors'])} colors.")
        return
    if "--image" in a:
        pal, dark = from_image(a[a.index("--image") + 1])
        if not pal:
            sys.exit("I couldn't find clear colors in that picture. Try a picture of your logo or your website.")
        print("Colors in that picture (most used first):")
        for c in pal:
            print("  ", hexof(c))
        if "--save" in a:
            save("", pal[:3], dark)
            print("Saved the top three.")
        return
    if "--hex" in a:
        cols = [to_rgb(x if x.strip().startswith("#") else "#" + x.strip()) for x in a[a.index("--hex") + 1].split(",")]
        pal = [c for c in cols if c]
        if not pal:
            sys.exit("I couldn't read those colors. Try codes like #2A6E6F.")
        save("", pal, (31, 31, 31))
        print("Saved:", ", ".join(hexof(c) for c in pal))
        return
    if not a:
        sys.exit(__doc__)
    if "--kit" in a:
        try:
            kit = brand_kit(a[0])
            score = scan(kit["html"], kit["css"])
            pal, dark = pick(score)
            if len(pal) < 2:
                pal2, _ = pick(score + logo_colors(kit["html"], kit["url"]))
                pal = pal2 or pal
        except Exception as e:
            sys.exit(f"I couldn't open that website ({str(e)[:80]}). Add your logo or a screenshot of the site instead, or type your colors.")
        if not pal:
            sys.exit("I opened the site but couldn't find clear brand colors. Add your logo or a screenshot of it instead.")
        data = save_kit(kit, pal, dark)
        print(f"Brand kit for {data['name']}: {len(data['colors'])} colors, fonts {data['fonts']}, logo {'yes' if data['logo'] else 'no'}, {len(data['photos'])} photos saved ({data['photo_total']} found).")
        return
    try:
        url, pal, dark = from_site(a[0])
    except Exception as e:
        sys.exit(f"I couldn't open that website ({str(e)[:80]}). You can type your brand colors instead, like #2A6E6F.")
    if not pal:
        sys.exit("I opened the site but couldn't find clear brand colors. You can type them in instead, like #2A6E6F.")
    print("Brand colors I found on", url)
    for i, c in enumerate(pal):
        print(f"  {['primary', 'secondary', 'accent', 'extra'][i]}: {hexof(c)}")
    if "--save" in a:
        save(url, pal, dark)
        print("Saved to customer/profile/brand.json")


if __name__ == "__main__":
    main()
