#!/usr/bin/env python3
"""Find topics her niche posts about that she has not covered yet. Ideas only, labeled as niche data, never put into a finished post by itself.
  python3 niche_gaps.py scraped.json            scraped.json = a list of {"caption": "...", "likes": 0, "comments": 0, "owner": "handle"} from public posts
Her own topics come from customer/plans/post-ideas.md, customer/scripts/ and customer/content/ (captions). Output: customer/insights/niche-gaps.md
The scraping itself is done in chat with her own Apify account (see engine/instructions/niche-gaps.md). Nothing here logs in anywhere.
"""
import glob, json, os, re, sys
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
STOP = set("the a an and or to of in on for with your you my is it that this what why how one just not no from at as be are was were i me we our their they them have has had do does did can will would should about into out up so if but get got make made more most very than then there here when who which her his its it's i'm don't can't you're".split())


def terms(text):
    ws = [w for w in re.findall(r"[a-z']{3,}", text.lower()) if w not in STOP]
    out = set(ws)
    out |= {" ".join(ws[i:i + 2]) for i in range(len(ws) - 1)}
    return out


def mine():
    chunks = []
    for pat in ("customer/plans/post-ideas.md", "customer/scripts/*.md", "customer/content/**/caption*.txt", "customer/content/**/*caption.txt"):
        for f in glob.glob(os.path.join(ROOT, pat), recursive=True):
            try:
                chunks.append(open(f, encoding="utf-8", errors="ignore").read())
            except OSError:
                pass
    return terms(" ".join(chunks))


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    posts = json.load(open(sys.argv[1], encoding="utf-8"))
    own = mine()
    count, eng, owners = Counter(), defaultdict(float), defaultdict(set)
    for p in posts:
        cap = re.sub(r"#\w+|@\w+|https?://\S+", " ", p.get("caption", ""))
        score = p.get("likes", 0) + 4 * p.get("comments", 0)
        for t in terms(cap):
            if " " in t:
                count[t] += 1
                eng[t] += score
                owners[t].add(p.get("owner", "?"))
    rows = []
    for t, c in count.items():
        if c >= 3 and len(owners[t]) >= 2 and t not in own and not any(w in own and len(w) > 5 for w in t.split()[:1]) :
            rows.append((eng[t] / c, c, t, len(owners[t])))
    rows.sort(reverse=True)
    top = rows[:8]
    lines = ["# Niche gaps (niche data, ideas only)\n", f"From {len(posts)} public posts. These phrases show up across several accounts in her niche and not in her own plan, scripts or captions yet. Nothing here is a claim about her results.\n"]
    for avg, c, t, o in top:
        lines.append(f"- \"{t}\": in {c} posts from {o} accounts, about {int(avg)} likes and comments each on average. Could be a checklist or carousel idea for her, in her own words.")
    if not top:
        lines.append("No clear gaps found in this sample. Try more posts or a closer hashtag.")
    os.makedirs(os.path.join(ROOT, "customer", "insights"), exist_ok=True)
    open(os.path.join(ROOT, "customer", "insights", "niche-gaps.md"), "w", encoding="utf-8").write("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
