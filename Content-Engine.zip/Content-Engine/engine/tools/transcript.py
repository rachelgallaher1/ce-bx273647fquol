#!/usr/bin/env python3
"""Write a readable transcript of a video from its edit plan.
Usage: python transcript.py EDITED_DIR NAME
Writes customer/videos/transcripts/NAME_transcript.txt with two parts: what is in the edited video, and everything the engine heard
(words it cut are in [brackets]). Times are in the original recording.
"""
import json, os, re, sys

edited = os.path.abspath(sys.argv[1])
name = sys.argv[2]
vs = [int(m.group(1)) for f in sorted(os.listdir(edited), key=lambda f: os.path.getmtime(os.path.join(edited, f)))
      for m in [re.fullmatch(re.escape(name) + r"_edit(\d+)\.plan\.json", f)] if m]
if not vs:
    sys.exit("I can't find that video's edit yet. Edit it first.")
plan = json.load(open(os.path.join(edited, f"{name}_edit{vs[-1]}.plan.json"), encoding="utf-8"))
words = plan["words"]
out_dir = os.path.abspath(os.path.join(edited, "..", "transcripts"))
os.makedirs(out_dir, exist_ok=True)


def tidy(ws):
    """Join the pieces the speech tool splits apart, like y and 'all."""
    out = []
    for w in ws:
        if out and out[-1]["w"].lower() == "y" and w["w"].lower().startswith("'all"):
            out[-1] = dict(out[-1], w="y'all" + w["w"][4:])
        else:
            out.append(w)
    return out


def para(ws):
    ws = tidy(ws)
    lines, cur = [], []
    for w in ws:
        cur.append(w["w"])
        if re.search(r"[.?!]$", w["w"]) or len(cur) >= 28:
            lines.append(" ".join(cur))
            cur = []
    if cur:
        lines.append(" ".join(cur))
    return lines


with open(os.path.join(out_dir, f"{name}_transcript.txt"), "w", encoding="utf-8") as f:
    f.write(f"Transcript: {name}\nOriginal length {plan['original_seconds']:.0f} seconds, edited length {plan['edited_seconds']:.0f} seconds.\n\n")
    f.write("== What is in the edited video ==\n\n")
    f.write("\n".join(para([w for w in words if not w.get("cut")])) + "\n\n")
    f.write("== Everything the engine heard (cut words are in [brackets]) ==\n\n")
    full = []
    for w in tidy(words):
        full.append(f"[{w['w']}]" if w.get("cut") else w["w"])
    cur, lines = [], []
    for t in full:
        cur.append(t)
        if len(cur) >= 24:
            lines.append(" ".join(cur))
            cur = []
    if cur:
        lines.append(" ".join(cur))
    f.write("\n".join(lines) + "\n")
print(os.path.join(out_dir, f"{name}_transcript.txt"))
