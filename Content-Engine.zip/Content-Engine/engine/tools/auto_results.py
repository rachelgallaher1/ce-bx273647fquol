#!/usr/bin/env python3
"""Matches her recent public Instagram posts to the carousels the engine made, and logs their public numbers (likes, comments),
so the engine can learn which carousel LOOK works for her without her logging anything.

  python3 auto_results.py posts.json          posts.json = the list Apify's Instagram scraper gave back (see performance-insights.md)
  python3 auto_results.py posts.json --dry    show the matches without logging

Matching: first by caption (the first line of the carousel's caption.txt), else by date (the post-files.json day, within 1 day) for a
carousel-type post. Posts newer than 2 days are skipped (numbers are still moving). Re-running updates the same rows (never double counts).
Saves and shares are private on Instagram: she adds them on Sundays from screenshots (results.py add --carousel FOLDER --saves N --shares N).
Prints one JSON line: {"matched": [...], "unmatched": N, "skipped_new": N}.
"""
import datetime, glob, json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
PY = sys.executable


def norm(s):
    return re.sub(r"[^a-z0-9 ]", "", (s or "").lower()).strip()[:60]


def carousels():
    """[{folder, rel, date, cap}] for every finished carousel in a look."""
    out = []
    pf = {}
    try:
        for d, f in json.load(open(os.path.join(ROOT, "customer", "plans", "post-files.json"), encoding="utf-8")).items():
            pf[os.path.abspath(f)] = d
    except Exception:
        pass
    for p in glob.glob(os.path.join(ROOT, "customer", "content", "**", "slides.json"), recursive=True):
        folder = os.path.dirname(p)
        try:
            sp = json.load(open(p, encoding="utf-8"))
        except Exception:
            continue
        if not any(s.get("type") == "tpl" for s in sp.get("slides", [])) or os.sep + "zz-" in p:
            continue
        cap = ""
        cp = os.path.join(folder, "caption.txt")
        if os.path.exists(cp):
            _txt = open(cp, encoding="utf-8").read().strip()
            cap = _txt.splitlines()[0] if _txt else ""
        out.append({"folder": folder, "rel": os.path.relpath(folder, ROOT).replace(os.sep, "/"), "date": pf.get(os.path.abspath(folder)), "cap": norm(cap)})
    return out


def post_date(p):
    ts = str(p.get("timestamp") or p.get("takenAtTimestamp") or p.get("date") or "")[:10]
    try:
        return datetime.date.fromisoformat(ts)
    except Exception:
        return None


def is_carousel(p):
    t = str(p.get("type") or p.get("productType") or "").lower()
    return "sidecar" in t or "carousel" in t or bool(p.get("childPosts"))


def main():
    if len(sys.argv) < 2 or not os.path.exists(sys.argv[1]):
        print(json.dumps({"error": "Give me the file of her recent posts."}))
        sys.exit(1)
    posts = json.load(open(sys.argv[1], encoding="utf-8"))
    posts = posts if isinstance(posts, list) else posts.get("items", [])
    dry = "--dry" in sys.argv
    cars = carousels()
    today = datetime.date.today()
    matched, unmatched, skipped = [], 0, 0
    used = set()
    for p in posts:
        d = post_date(p)
        if d and (today - d).days < 2:
            skipped += 1
            continue
        cap = norm((p.get("caption") or "").splitlines()[0] if p.get("caption") else "")
        hit = next((c for c in cars if c["cap"] and cap and (c["cap"] == cap or c["cap"] in cap or cap in c["cap"]) and c["rel"] not in used), None)
        if hit is None and is_carousel(p) and d:
            hit = next((c for c in cars if c["date"] and abs((datetime.date.fromisoformat(c["date"]) - d).days) <= 1 and c["rel"] not in used), None)
        if hit is None:
            unmatched += 1
            continue
        used.add(hit["rel"])
        likes = p.get("likesCount", p.get("likes"))
        comments = p.get("commentsCount", p.get("comments"))
        row = {"carousel": hit["rel"], "posted": d.isoformat() if d else None, "likes": likes, "comments": comments, "link": p.get("url")}
        matched.append(row)
        if dry:
            continue
        cmd = [PY, "-X", "utf8", "-I", os.path.join(HERE, "results.py"), "add", "--kind", "carousel", "--carousel", hit["rel"], "--title", os.path.basename(hit["rel"])]
        for k, v in (("posted", row["posted"]), ("likes", likes), ("comments", comments), ("link", row["link"])):
            if v is not None and v != "":
                cmd += ["--" + k, str(v)]
        subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT)
    print(json.dumps({"matched": matched, "unmatched": unmatched, "skipped_new": skipped}))


if __name__ == "__main__":
    main()
