#!/usr/bin/env python3
"""Make a pretend social profile video: scroll a grid of sample posts, tap one, swipe through it.
Usage:  python3 engine/tools/make_mock_profile.py SPEC.json
SPEC.json: {"out": "folder", "look": "7", "handle": "@sample.name", "name": "Display Name", "category": "Real estate agent",
            "bio": ["line", "line"], "highlights": ["Tours", "FAQ", "Buyers"], "tiles": [12 short headlines],
            "post": {"slides": [3 headlines + items made by make_carousel], "caption": "text"}}
It makes the sample post images with make_carousel.py in the chosen look, draws a plain generic profile (not any app's logo),
and writes profile.mp4 (1080x1920, no sound). Everything on it is an invented example.
"""
import json, os, subprocess, sys, shutil
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
PY = sys.executable
FONT = os.path.join(ROOT, "engine", "fonts", "Montserrat[wght].ttf")
W, H = 1080, 1920
BG, INK, SOFT, LINE = (255, 255, 255), (20, 20, 22), (120, 120, 126), (225, 225, 228)


def font(size, wght=500):
    f = ImageFont.truetype(FONT, size)
    try:
        f.set_variation_by_axes([wght])
    except Exception:
        pass
    return f


def make_images(spec, out):
    tiles = [{"type": "bigtext", "headline": t.upper(), "hi": spec.get("hi", {}).get(t, ""), "lines": [], "source": "invented example"} for t in spec["tiles"]]
    os.makedirs(os.path.join(out, "tiles"), exist_ok=True)
    json.dump({"title": "slides", "look": spec["look"], "handle": spec["handle"], "slides": tiles}, open(os.path.join(out, "tiles", "slides.json"), "w", encoding="utf-8"))
    subprocess.run([PY, os.path.join(HERE, "make_carousel.py"), os.path.join(out, "tiles", "slides.json")], capture_output=True)
    os.makedirs(os.path.join(out, "post"), exist_ok=True)
    json.dump({"title": "slides", "look": spec["look"], "handle": spec["handle"], "slides": spec["post"]["slides"]}, open(os.path.join(out, "post", "slides.json"), "w", encoding="utf-8"))
    subprocess.run([PY, os.path.join(HERE, "make_carousel.py"), os.path.join(out, "post", "slides.json")], capture_output=True)


def accent(look):
    lk = json.load(open(os.path.join(ROOT, "engine", "looks", "looks.json"), encoding="utf-8"))
    L = lk.get("looks", lk)
    for l in (L if isinstance(L, list) else L.values()):
        if str(l.get("id")) == str(look):
            h = l["highlight"]["bg"].lstrip("#")
            return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    return (60, 60, 60)


def profile_image(spec, out):
    tiles = [Image.open(os.path.join(out, "tiles", "slides", f"slide-{i + 1:02d}.png")).convert("RGB").resize((358, 448)) for i in range(len(spec["tiles"]))]
    rows = (len(tiles) + 2) // 3
    img = Image.new("RGB", (W, 1070 + rows * 450 + 40), BG)
    d = ImageDraw.Draw(img)
    ac = accent(spec["look"])
    d.text((60, 85), "<", font=font(60, 500), fill=INK, anchor="mm")
    d.text((W // 2, 85), spec["handle"].lstrip("@"), font=font(44, 700), fill=INK, anchor="mm")
    d.ellipse((50, 160, 290, 400), fill=ac)
    initials = "".join(w[0] for w in spec["name"].split()[:2]).upper()
    d.text((170, 280), initials, font=font(96, 800), fill=(255, 255, 255) if sum(ac) < 500 else INK, anchor="mm")
    n = len(tiles)
    for k, (num, lab) in enumerate([(str(n), "posts"), ("", ""), ("", "")]):
        pass
    d.text((410, 250), str(n), font=font(48, 800), fill=INK)
    d.text((410, 310), "posts", font=font(30, 500), fill=INK)
    d.text((680, 250), "example", font=font(34, 700), fill=SOFT)
    d.text((680, 300), "account", font=font(34, 700), fill=SOFT)
    y = 430
    d.text((50, y), spec["name"], font=font(36, 700), fill=INK); y += 50
    d.text((50, y), spec["category"], font=font(32, 500), fill=SOFT); y += 48
    for ln in spec["bio"]:
        d.text((50, y), ln, font=font(34, 500), fill=INK); y += 46
    y += 14
    d.rounded_rectangle((50, y, 530, y + 76), 14, fill=(239, 239, 241))
    d.text((290, y + 38), "Following", font=font(32, 700), fill=INK, anchor="mm")
    d.rounded_rectangle((550, y, 1030, y + 76), 14, fill=(239, 239, 241))
    d.text((790, y + 38), "Message", font=font(32, 700), fill=INK, anchor="mm")
    y += 120
    for i, h in enumerate(spec["highlights"][:4]):
        cx = 50 + 90 + i * 250
        d.ellipse((cx - 90, y, cx + 90, y + 180), outline=LINE, width=5)
        d.ellipse((cx - 78, y + 12, cx + 78, y + 168), fill=tuple(int(c * 0.35 + 255 * 0.65) for c in ac))
        d.text((cx, y + 210), h, font=font(28, 500), fill=INK, anchor="mm")
    y = 1070
    d.line((0, y - 4, W, y - 4), fill=LINE, width=3)
    for i, t in enumerate(tiles):
        r, c = divmod(i, 3)
        img.paste(t, (c * 361 + 0, y + r * 451))
    return img


def post_frames(spec, out):
    ac = accent(spec["look"])
    frames = []
    for i in range(3):
        sl = Image.open(os.path.join(out, "post", "slides", f"slide-{i + 1:02d}.png")).convert("RGB").resize((1080, 1350))
        f = Image.new("RGB", (W, H), BG)
        d = ImageDraw.Draw(f)
        d.text((60, 85), "<", font=font(60, 500), fill=INK, anchor="mm")
        d.text((W // 2, 85), "Posts", font=font(44, 700), fill=INK, anchor="mm")
        d.ellipse((40, 190, 130, 280), fill=ac)
        d.text((150, 215), spec["handle"].lstrip("@"), font=font(34, 700), fill=INK)
        f.paste(sl, (0, 320))
        y = 320 + 1350 + 40
        d.ellipse((50, y, 110, y + 56), outline=INK, width=5)
        d.ellipse((140, y, 200, y + 56), outline=INK, width=5)
        d.polygon([(250, y + 28), (320, y), (300, y + 56)], outline=INK, width=5)
        for k in range(3):
            cx = W // 2 + (k - 1) * 34
            d.ellipse((cx - 9, y + 24, cx + 9, y + 42), fill=ac if k == i else (200, 200, 204))
        cap = spec["handle"].lstrip("@") + "  " + spec["post"]["caption"]
        fc = font(32, 500)
        while d.textlength(cap, font=fc) > W - 100:
            cap = cap[:-4].rstrip() + "..."
        d.text((50, y + 90), cap, font=fc, fill=INK)
        p = os.path.join(out, f"post-{i + 1}.png")
        f.save(p)
        frames.append(p)
    return frames


def run(a):
    subprocess.run(a, check=True, capture_output=True)


def main():
    spec = json.load(open(sys.argv[1], encoding="utf-8"))
    out = os.path.join(ROOT, spec["out"]) if not os.path.isabs(spec["out"]) else spec["out"]
    os.makedirs(out, exist_ok=True)
    make_images(spec, out)
    prof = os.path.join(out, "profile.png")
    profile_image(spec, out).save(prof)
    frames = post_frames(spec, out)
    ih = Image.open(prof).height
    scroll = os.path.join(out, "_scroll.mp4")
    expr = f"crop={W}:{H}:0:'({ih}-{H})*(1-cos(PI*clip((t-0.9)/6.5,0,1)))/2'"
    run(["ffmpeg", "-y", "-loglevel", "error", "-loop", "1", "-t", "8.4", "-i", prof, "-vf", expr + ",fps=30,format=yuv420p", scroll])
    parts = [scroll]
    for i, fr in enumerate(frames):
        p = os.path.join(out, f"_p{i}.mp4")
        run(["ffmpeg", "-y", "-loglevel", "error", "-loop", "1", "-t", "2.2", "-i", fr, "-vf", "fps=30,format=yuv420p", p])
        parts.append(p)
    cur = parts[0]
    off = 8.4
    for i, p in enumerate(parts[1:]):
        nxt = os.path.join(out, f"_x{i}.mp4")
        tr = "fade" if i == 0 else "slideleft"
        run(["ffmpeg", "-y", "-loglevel", "error", "-i", cur, "-i", p, "-filter_complex", f"xfade=transition={tr}:duration=0.45:offset={off - 0.45:.2f},format=yuv420p", nxt])
        cur = nxt
        off = off - 0.45 + 2.2
    final = os.path.join(out, "profile.mp4")
    shutil.copy(cur, final)
    for fn in os.listdir(out):
        if fn.startswith("_"):
            os.remove(os.path.join(out, fn))
    print(final)


if __name__ == "__main__":
    main()
