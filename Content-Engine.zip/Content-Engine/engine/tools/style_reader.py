#!/usr/bin/env python3
"""Read a reel she is proud of, so the engine can learn her style from it.
  python style_reader.py VIDEO [--name my-best-reel]
Writes customer/profile/style/NAME/stats.json and sheet.jpg (12 frames in a grid, for the engine to LOOK at and describe the caption
look, the hook box, the graphics and the colors in plain words). Prints the numbers: length, number of cuts, average shot length,
cuts per 10 seconds. Never changes her video.
"""
import json, os, re, subprocess, sys
from PIL import Image, ImageDraw

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))


def sh(a):
    return subprocess.run(a, capture_output=True, text=True, encoding="utf-8", errors="replace")


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    video = sys.argv[1]
    name = sys.argv[sys.argv.index("--name") + 1] if "--name" in sys.argv else re.sub(r"[^A-Za-z0-9_-]+", "-", os.path.splitext(os.path.basename(video))[0])
    out = os.path.join(ROOT, "customer", "profile", "style", name)
    os.makedirs(out, exist_ok=True)
    dur = float(sh(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", video]).stdout.strip())
    r = sh(["ffmpeg", "-i", video, "-vf", "select='gt(scene,0.28)',showinfo", "-an", "-f", "null", "-"])
    cuts = [float(m) for m in re.findall(r"pts_time:([0-9.]+)", r.stderr)]
    n_shots = len(cuts) + 1
    stats = {"video": os.path.basename(video), "seconds": round(dur, 1), "cuts": len(cuts), "shots": n_shots,
             "avg_shot_seconds": round(dur / n_shots, 1), "cuts_per_10s": round(len(cuts) / dur * 10, 1),
             "cut_times": [round(c, 1) for c in cuts][:80]}
    json.dump(stats, open(os.path.join(out, "stats.json"), "w", encoding="utf-8"), indent=1)
    tmp = os.path.join(out, "_f")
    os.makedirs(tmp, exist_ok=True)
    ims = []
    for i in range(12):
        t = dur * (i + 0.5) / 12
        p = os.path.join(tmp, f"f{i}.jpg")
        sh(["ffmpeg", "-y", "-loglevel", "error", "-ss", f"{t:.2f}", "-i", video, "-frames:v", "1", "-vf", "scale=-2:480", p])
        if os.path.exists(p):
            ims.append((t, Image.open(p).convert("RGB")))
    if ims:
        w, h = ims[0][1].size
        sheet = Image.new("RGB", (w * 6, h * 2), (20, 20, 20))
        d = ImageDraw.Draw(sheet)
        for i, (t, im) in enumerate(ims):
            x, y = (i % 6) * w, (i // 6) * h
            sheet.paste(im, (x, y))
            d.text((x + 8, y + 8), f"{t:.0f}s", fill=(255, 255, 0))
        sheet.save(os.path.join(out, "sheet.jpg"), quality=85)
    for f in os.listdir(tmp):
        os.remove(os.path.join(tmp, f))
    os.rmdir(tmp)
    print(json.dumps({k: v for k, v in stats.items() if k != "cut_times"}, indent=1))
    print("Frames to look at:", os.path.join(out, "sheet.jpg"))


main()
