#!/usr/bin/env python3
"""Film mode: a phone-friendly teleprompter page made from her scripts, so filming is "read, tap, read, tap".
  python make_film_mode.py                 writes customer/plans/film-mode.html (one file, works offline) and prints its path
  python make_film_mode.py --phone         also serves it on her Wi-Fi for two hours and prints an address to type on her phone
It lists her videos that still need filming (scripted, not yet filmed, edited or posted), one script at a time in big text.
Blanks in a script ([like this]) are highlighted and flagged so she fills them before she films.
"""
import datetime, html, json, os, re, socket, sys, threading, time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import make_calendar as mc

ROOT = mc.ROOT


def section(text, names):
    out, on = [], False
    for ln in text.splitlines():
        if ln.startswith("## "):
            on = any(ln[3:].strip().lower().startswith(n) for n in names)
            continue
        if on:
            out.append(ln)
    return "\n".join(out).strip()


def parse(path):
    t = open(path, encoding="utf-8").read()
    hook = ""
    m = re.search(r"\*\*Said:\*\*\s*(.+)", section(t, ["hook"]))
    if m:
        hook = re.sub(r"\s*\(what she actually said[^)]*\)", "", m.group(1)).strip()
    body = section(t, ["script"])
    lines = [re.sub(r"^\s*[-*]\s*", "", l).replace("**", "").strip() for l in body.splitlines() if l.strip()]
    note = section(t, ["filming direction", "filming note"]).replace("**", "")
    return hook, lines, note


def videos():
    plans = sorted(__import__("glob").glob(os.path.join(ROOT, "customer", "plans", "*-month-plan.md")))
    out = []
    for pl in plans:
        _, rows = mc.read_plan(pl)
        for r in rows:
            if r["format"] != "video" or (r["status"] or "").lower() in ("filmed", "edited", "posted", "outline", "planned"):
                continue
            sp = r.get("script")
            if not sp or not os.path.exists(sp):
                continue
            if r["date"] < (datetime.date.today() - datetime.timedelta(days=3)).isoformat():
                continue
            hook, lines, note = parse(sp)
            if not lines:
                continue
            words = sum(len(l.split()) for l in ([hook] if hook else []) + lines)
            blanks = re.findall(r"\[[^\]]{3,}\]", " ".join(lines + [hook]))
            out.append({"n": r["n"], "date": r["date"], "idea": r["idea"], "hook": hook, "lines": lines, "note": note,
                        "secs": round(words / 2.6), "blanks": blanks})
    out.sort(key=lambda v: v["date"])
    return out


TIPS = ["Hold the phone vertical at eye level.", "Face a window or a lamp, in a quiet spot.", "Prop the phone up so it stays steady.",
        "If you mess up, stop, pause a second, and say the line again. The edit cuts the mistake.", "Keep going to the end, even if a line feels clunky."]


def shot_lists():
    out = []
    d = os.path.join(ROOT, "customer", "plans", "shot-lists")
    if os.path.isdir(d):
        for f in sorted(os.listdir(d)):
            if f.endswith(".json"):
                try:
                    j = json.load(open(os.path.join(d, f), encoding="utf-8"))
                    j["id"] = f[:-5]
                    out.append(j)
                except Exception:
                    pass
    return out


def build():
    vs = videos()
    tpl = open(os.path.join(HERE, "film_mode_template.html"), encoding="utf-8").read()
    page = (tpl.replace("__DATA__", json.dumps({"videos": vs, "tips": TIPS, "shots": shot_lists(), "built": datetime.date.today().isoformat()}).replace("</", "<\\/")))
    out = os.path.join(ROOT, "customer", "plans", "film-mode.html")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    open(out, "w", encoding="utf-8").write(page)
    return out, vs


def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        s.close()


def serve(path, minutes=120, port=8780):
    d = os.path.dirname(path)
    class H(SimpleHTTPRequestHandler):
        def __init__(self, *a, **k):
            super().__init__(*a, directory=d, **k)
        def log_message(self, *a):
            pass
        def do_GET(self):
            if self.path in ("/", "/index.html", "/film-mode.html"):
                self.path = "/film-mode.html"
                return super().do_GET()
            self.send_error(404)
    srv = ThreadingHTTPServer(("0.0.0.0", port), H)
    threading.Timer(minutes * 60, lambda: os._exit(0)).start()
    print("On your phone (same Wi-Fi), open: http://%s:%d   (it stops by itself in %d minutes)" % (lan_ip(), port, minutes), flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


def main():
    out, vs = build()
    print(out)
    print("%d videos to film. Blanks to fill first: %d. B-roll shot lists: %d" % (len(vs), sum(1 for v in vs if v["blanks"]), len(shot_lists())))
    if "--phone" in sys.argv:
        serve(out)


main()
