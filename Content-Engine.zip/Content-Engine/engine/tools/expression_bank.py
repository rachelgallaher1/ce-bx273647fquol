#!/usr/bin/env python3
"""Her reaction library: the most expressive frames from her own videos, saved as she edits.
  python3 expression_bank.py <video> [--n 8] [--out customer/content/expression-bank]
Picks frames where her face is clear and sharp and differs most from her resting face (a raised brow, a laugh, a gasp, a squint), spread apart in time.
Nothing is posted or labeled for her. They are raw material for her own memes, GIFs and story reactions.
Saves face-centered 1080 x 1350 pictures plus index.json, and a contact sheet (bank-preview.png).
"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
MAX_TOTAL = 120


def pick(video, n=8, step=0.25):
    import cv2, numpy as np
    cap = cv2.VideoCapture(video)
    try:
        cap.set(cv2.CAP_PROP_ORIENTATION_AUTO, 1)
    except Exception:
        pass
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    cas = cv2.CascadeClassifier(os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml"))
    cands = []
    i = 0
    while i < total:
        cap.set(cv2.CAP_PROP_POS_FRAMES, i)
        ok, fr = cap.read()
        if not ok:
            break
        h, w = fr.shape[:2]
        sm = cv2.resize(fr, (480, int(480 * h / w)))
        g = cv2.cvtColor(sm, cv2.COLOR_BGR2GRAY)
        f = cas.detectMultiScale(g, 1.1, 5, minSize=(70, 70))
        if len(f):
            x, y, fw, fh = max(f, key=lambda r: r[2] * r[3])
            if fw / g.shape[1] > 0.18 and 0.15 < (x + fw / 2) / g.shape[1] < 0.85:
                crop = cv2.resize(g[y:y + fh, x:x + fw], (96, 96)).astype("float32")
                sharp = float(cv2.Laplacian(g[y:y + fh, x:x + fw], cv2.CV_64F).var())
                cands.append({"t": i / fps, "crop": crop, "sharp": sharp})
        i += max(1, int(step * fps))
    cap.release()
    if len(cands) < 4:
        return []
    med = np.median(np.stack([c["crop"] for c in cands]), axis=0)
    max_sharp = max(c["sharp"] for c in cands) or 1
    for c in cands:
        dev = float(np.mean(np.abs(c["crop"] - med)))
        c["score"] = dev * (0.4 + 0.6 * min(1.0, c["sharp"] / (0.6 * max_sharp)))
    out = []
    for c in sorted(cands, key=lambda c: -c["score"]):
        if all(abs(c["t"] - o["t"]) > 1.5 for o in out):
            out.append(c)
        if len(out) == n:
            break
    return sorted(out, key=lambda c: c["t"])


def save(video, out_dir, n=8):
    import cv2
    from PIL import Image
    os.makedirs(out_dir, exist_ok=True)
    idx_path = os.path.join(out_dir, "index.json")
    idx = json.load(open(idx_path, encoding="utf-8")) if os.path.exists(idx_path) else []
    if len(idx) >= MAX_TOTAL:
        print(f"Your reaction bank already has {len(idx)} frames. I'll leave it as it is. Tell me if you want to clear some out.")
        return idx
    name = os.path.splitext(os.path.basename(video))[0]
    if any(r["source"] == name for r in idx):
        return idx
    picks = pick(video, n)
    cap = cv2.VideoCapture(video)
    try:
        cap.set(cv2.CAP_PROP_ORIENTATION_AUTO, 1)
    except Exception:
        pass
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    for c in picks:
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(c["t"] * fps))
        ok, fr = cap.read()
        if not ok:
            continue
        im = Image.fromarray(cv2.cvtColor(fr, cv2.COLOR_BGR2RGB))
        sc = max(1080 / im.width, 1350 / im.height)
        im = im.resize((int(im.width * sc), int(im.height * sc)))
        im = im.crop(((im.width - 1080) // 2, max(0, (im.height - 1350) // 4), (im.width - 1080) // 2 + 1080, max(0, (im.height - 1350) // 4) + 1350))
        fn = f"{name}_{int(c['t'] * 10):04d}.jpg"
        im.save(os.path.join(out_dir, fn), quality=92)
        idx.append({"file": fn, "source": name, "t": round(c["t"], 1)})
    json.dump(idx, open(idx_path, "w", encoding="utf-8"), indent=1)
    cap.release()
    files = [r["file"] for r in idx][-24:]
    if files:
        th = [Image.open(os.path.join(out_dir, f)).resize((216, 270)) for f in files]
        cols = 6
        rows = (len(th) + cols - 1) // cols
        sheet = Image.new("RGB", (cols * 226 + 10, rows * 280 + 10), (24, 24, 24))
        for k, im in enumerate(th):
            sheet.paste(im, (10 + (k % cols) * 226, 10 + (k // cols) * 280))
        sheet.save(os.path.join(out_dir, "bank-preview.png"))
    return idx


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    a = sys.argv[1:]
    n = int(a[a.index("--n") + 1]) if "--n" in a else 8
    out = a[a.index("--out") + 1] if "--out" in a else os.path.join(ROOT, "customer", "content", "expression-bank")
    idx = save(a[0], out, n)
    print(f"Saved reaction frames. Your bank now has {len(idx)}. Look: {os.path.join(out, 'bank-preview.png')}")


if __name__ == "__main__":
    main()
