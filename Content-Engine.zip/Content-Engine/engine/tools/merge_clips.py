#!/usr/bin/env python3
"""Put several of her clips into one video, in the order given, so they can be edited as one reel.
  python merge_clips.py NAME CLIP1 CLIP2 [CLIP3 ...]
Copies the clips into customer/videos/recorded/ (her originals stay where they are), joins them without re-encoding, saves customer/videos/recorded/NAME.mov,
and notes in customer/videos/merged-from.json which clips went in, so the Edit page stops listing them as "not edited yet".
The clips should be from the same phone and the same orientation."""
import json, os, shutil, subprocess, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))


def main():
    a = sys.argv[1:]
    if len(a) < 3:
        sys.exit(__doc__)
    name, clips = a[0], a[1:]
    rec = os.path.join(ROOT, "customer", "videos", "recorded")
    os.makedirs(rec, exist_ok=True)
    local = []
    for c in clips:
        c = os.path.abspath(os.path.expanduser(c))
        if not os.path.exists(c):
            sys.exit(f"I can't find {c}")
        dst = os.path.join(rec, os.path.basename(c))
        if not os.path.exists(dst):
            shutil.copy2(c, dst)
        local.append(dst)
    lst = os.path.join(rec, f".{name}_list.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for p in local:
            f.write("file '" + p.replace("'", "'\\''") + "'\n")
    out = os.path.join(rec, name + ".mov")
    r = subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", out], capture_output=True, text=True, encoding="utf-8", errors="replace")
    os.remove(lst)
    if r.returncode != 0:
        sys.exit("I couldn't join those clips: " + (r.stderr.strip().splitlines() or ["unknown error"])[-1])
    mf = os.path.join(ROOT, "customer", "videos", "merged-from.json")
    d = json.load(open(mf, encoding="utf-8")) if os.path.exists(mf) else {}
    d[name] = [os.path.splitext(os.path.basename(p))[0] for p in local]
    json.dump(d, open(mf, "w", encoding="utf-8"), indent=1)
    print(f"Made {out} from {len(local)} clips.")


main()
