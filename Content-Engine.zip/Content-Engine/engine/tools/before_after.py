#!/usr/bin/env python3
"""Before and after reels: put a raw clip next to (or under) the engine's edited version of the same footage.
  python3 before_after.py side-by-side RAW.mp4 EDITED.mp4 --niche "Real estate agents" --changed "Added captions, cut dead air, tightened pacing" --out reel.mp4
  python3 before_after.py curtain      RAW.mp4 EDITED.mp4 --niche "Salon owners" [--hook "Same footage. Better edit."] --out reel.mp4

  python3 before_after.py freeze       RAW.mp4 EDITED.mp4 --niche "Real estate agents" --hook "3 things buyers hate about open houses" --out reel.mp4 [--freeze-at 3.0] [--edited-start SECONDS]
  python3 before_after.py screen       SCREEN_RECORDING.mov FINISHED_REEL.mp4 --niche "Salon owners" [--title "Raw video in, finished reel out."] [--crop x:y:w:h] [--blur x:y:w:h] --out reel.mp4

All of them make a 1080 x 1920, 30 fps, 7 to 10 second vertical reel for Instagram Reels, plus a suggested caption (reel.caption.txt).
The comparison shows from the first frame. Audio is the edited clip's audio only.

Options for both:
  --fill fit|crop       how each clip fills its space. fit (default) shows the whole picture so burned-in captions are never cut off,
                        with a soft blurred fill behind it. crop fills the space and cuts the edges (a horizontal clip is always cropped).
  --raw-x 0..1          where to center the crop when a clip is cropped (0 = left edge, 0.5 = middle, 1 = right edge)
  --edited-x 0..1       same, for the edited clip
  --length freeze|speed when the clips are different lengths: freeze (default) holds the shorter clip on its last frame until the longer one ends;
                        speed stretches the raw clip to the edited clip's length
  --best-section        if the footage is longer than 10 seconds, use the loudest 10 seconds (default: the first 10 seconds)
Freeze reveal:      --freeze-at SECONDS (pick the most awkward moment; default 3.0, or 60% of the clip if it is shorter than 3 s), --edited-start SECONDS (which moment of the edited clip matches; default is the same point in proportion)
Screen to result:   --title "text", --crop x:y:w:h (cut the screen recording to this box, in source pixels), --blur x:y:w:h (blur a private spot; use up to three times), --speed 2..4
Side by side only:  --niche-text "custom top line"
Curtain only:       --timing "1.0,2.0,3.0,4.0"   seconds: curtain starts, edited mostly, raw mostly, edited fills the frame
Nothing here changes the original clips.
"""
import json, math, os, re, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
W, H, FPS = 1080, 1920, 30
SAFE_TOP, SAFE_BOTTOM = 270, 1620


def sh(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        raise SystemExit("ffmpeg stopped: " + r.stderr[:900])
    return r


def probe(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,width,height,duration:stream_side_data=rotation:format=duration", "-of", "json", path], capture_output=True, text=True, encoding="utf-8", errors="replace")
    d = json.loads(r.stdout or "{}")
    v = next((s for s in d.get("streams", []) if s.get("codec_type") == "video"), None)
    if not v:
        raise SystemExit(f"I can't find a picture in {path}.")
    w, h = int(v["width"]), int(v["height"])
    for sd in v.get("side_data_list", []) or []:
        if abs(int(sd.get("rotation", 0))) in (90, 270):
            w, h = h, w
    dur = float(d.get("format", {}).get("duration") or v.get("duration") or 0)
    return {"w": w, "h": h, "dur": dur, "audio": any(s.get("codec_type") == "audio" for s in d.get("streams", []))}


def loudest_start(path, dur, win):
    """Start second of the loudest `win` seconds (to pick the most striking section of long footage)."""
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-vn", "-ac", "1", "-ar", "8000", "-f", "s16le", "-"], capture_output=True)
    import array
    a = array.array("h")
    a.frombytes(r.stdout[: len(r.stdout) // 2 * 2])
    if not len(a):
        return 0.0
    sec = [sum(abs(x) for x in a[i:i + 8000]) / 8000.0 for i in range(0, len(a), 8000)]
    best, bs = 0, -1
    for s in range(0, max(1, len(sec) - int(win) + 1)):
        v = sum(sec[s:s + int(win)])
        if v > bs:
            best, bs = s, v
    return float(min(best, max(0, dur - win)))


# ---------- text pieces drawn as pictures ----------
def font(size):
    import first_edit as fe
    return fe.load_font("Montserrat", size, 900)


def text_png(path, text, size=64, pad=(40, 22), fill=(255, 255, 255), box=(20, 20, 24, 215), max_w=980, stroke=0):
    from PIL import Image, ImageDraw
    f = font(size)
    d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    words, lines, cur = text.split(), [], ""
    for w in words:
        c = (cur + " " + w).strip()
        if cur and d0.textlength(c, font=f) > max_w - 2 * pad[0]:
            lines.append(cur)
            cur = w
        else:
            cur = c
    lines.append(cur)
    lh = int(size * 1.2)
    tw = int(max(d0.textlength(l, font=f) for l in lines))
    im = Image.new("RGBA", (tw + 2 * pad[0], lh * len(lines) + 2 * pad[1]), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    if box:
        d.rounded_rectangle((0, 0, im.width - 1, im.height - 1), radius=min(34, im.height // 2), fill=box)
    y = pad[1]
    for l in lines:
        x = (im.width - d0.textlength(l, font=f)) / 2
        d.text((x, y), l, font=f, fill=fill, stroke_width=stroke, stroke_fill=(0, 0, 0, 255))
        y += lh
    im.save(path)
    return im.size


def line_png(path, w=6, h=H, shadow=True):
    from PIL import Image, ImageDraw, ImageFilter
    pad = 14 if shadow else 0
    im = Image.new("RGBA", (w + 2 * pad, h), (0, 0, 0, 0))
    if shadow:
        sh_ = Image.new("RGBA", im.size, (0, 0, 0, 0))
        ImageDraw.Draw(sh_).rectangle((pad - 4, 0, pad + w + 4, h), fill=(0, 0, 0, 120))
        im.alpha_composite(sh_.filter(ImageFilter.GaussianBlur(7)))
    ImageDraw.Draw(im).rectangle((pad, 0, pad + w - 1, h), fill=(255, 255, 255, 255))
    im.save(path)
    return im.size


# ---------- filters ----------
def prep(label_in, out_label, info, w, h, fill, focus, notes, name):
    """A filter chain that turns one clip into a w x h picture. Returns the chain text."""
    tall = info["w"] / info["h"] <= 0.7
    mode = fill
    if fill == "fit" and not tall:
        mode = "crop"
        notes.append(f"{name} is horizontal, so I center-cropped it to fit the tall frame (I can shift the crop with --{'raw' if name == 'The raw clip' else 'edited'}-x).")
    if mode == "crop":
        return (f"[{label_in}]scale=-2:{h}:force_original_aspect_ratio=increase,scale='max(iw,{w})':'max(ih,{h})',"
                f"crop={w}:{h}:'(iw-{w})*{focus:.3f}':'(ih-{h})/2',setsar=1[{out_label}]")
    return (f"[{label_in}]split[{out_label}a][{out_label}b];"
            f"[{out_label}a]scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},boxblur=28:3,eq=brightness=-0.10[{out_label}bg];"
            f"[{out_label}b]scale={w}:-2,setsar=1[{out_label}fg];"
            f"[{out_label}bg][{out_label}fg]overlay=(W-w)/2:(H-h)/2[{out_label}]")


def time_fix(label_in, label_out, start, total, info, speed_to=None):
    """Start at `start`, hold the last frame if short (or stretch to speed_to), and cut at `total` seconds."""
    chain = f"[{label_in}]trim=start={start:.3f},setpts=PTS-STARTPTS"
    if speed_to:
        chain += f",setpts=PTS*{speed_to / max(0.1, info['dur'] - start):.5f}"
    chain += f",fps={FPS},tpad=stop_mode=clone:stop_duration={total + 2:.2f},trim=duration={total:.3f},setpts=PTS-STARTPTS"
    return chain + f"[{label_out}]"


def ease_expr(u):
    return f"(({u})*({u})*(3-2*({u})))"


def curtain_expr(tvar, segs):
    """Curtain position (0 to 1 across the frame) as a smooth function of time."""
    expr = f"{segs[-1][3]}"
    for t0, t1, a, b in reversed(segs[:-1]):
        u = f"(({tvar}-{t0})/{t1 - t0})"
        expr = f"if(lt({tvar},{t1}),{a}+({b}-{a})*{ease_expr(u)},{expr})"
    return f"if(lt({tvar},{segs[0][0]}),{segs[0][2]},{expr})"


def suggest_caption(niche, changed, kind):
    base = f"{niche}: raw footage on one side, the finished reel on the other. Same clip. What changed: {changed.rstrip('.')}."
    return base + (" Watch the curtain." if kind == "curtain" else "") + "\n\nWant yours edited like this? Comment WAITLIST."


def audio_or_silence(idx, info, start, dur, label, norm=True):
    if info["audio"]:
        return f"[{idx}:a]atrim=start={start:.3f}:end={start + dur:.3f},asetpts=PTS-STARTPTS,apad=whole_dur={dur:.3f},atrim=duration={dur:.3f}" + (",loudnorm=I=-16:TP=-1.5:LRA=11" if norm else "") + f",aresample=44100,aformat=channel_layouts=mono[{label}]"
    return f"anullsrc=r=44100:cl=mono,atrim=duration={dur:.3f}[{label}]"


def run_freeze(a, opt, notes):
    raw, edited = a[1], a[2]
    niche = opt("--niche", "Your niche")
    hook = opt("--hook", f"{niche}: before and after")
    changed = opt("--changed", "Added captions, cut dead air, tightened pacing")
    fill, rx, ex = opt("--fill", "fit"), float(opt("--raw-x", 0.5)), float(opt("--edited-x", 0.5))
    out = os.path.abspath(opt("--out", os.path.join(os.path.dirname(os.path.abspath(raw)), "freeze-reveal-reel.mp4")))
    ri, ei = probe(raw), probe(edited)
    fz = float(opt("--freeze-at", 3.0 if ri["dur"] >= 3.0 else 0.6 * ri["dur"]))
    if ri["dur"] < 3.0 and opt("--freeze-at") is None:
        notes.append(f"The raw clip is under 3 seconds, so it freezes at 60% of its length ({fz:.1f}s).")
    fz = min(max(0.3, fz), max(0.3, ri["dur"] - 0.1))
    hold = 0.4
    es = float(opt("--edited-start", min(max(0.0, fz * ei["dur"] / max(0.1, ri["dur"])), max(0.0, ei["dur"] - 3.0))))
    notes.append(f"The edited clip picks up at {es:.1f}s (about the same moment as the freeze, adjusted for the cuts). Use --edited-start to line it up exactly.")
    total = min(10.0, max(7.0, fz + hold + (ei["dur"] - es)))
    seg3 = total - fz - hold
    work = tempfile.mkdtemp(prefix="beforeafter-")
    text_png(os.path.join(work, "bl.png"), "BEFORE", 54, box=(60, 60, 66, 225))
    text_png(os.path.join(work, "al.png"), "AFTER", 54, box=(42, 110, 111, 235))
    text_png(os.path.join(work, "hook.png"), hook, 62, max_w=980)
    f = [prep("0:v", "rp", ri, W, H, fill, rx, notes, "The raw clip"), prep("1:v", "ep", ei, W, H, fill, ex, notes, "The edited clip")]
    f.append(f"[rp]fps={FPS},trim=start=0:end={fz:.3f},setpts=PTS-STARTPTS[s1]")
    f.append(f"[rp]fps={FPS},trim=start={fz:.3f}:end={fz + 0.06:.3f},setpts=PTS-STARTPTS,tpad=stop_mode=clone:stop_duration={hold:.2f},trim=duration={hold:.3f},setpts=PTS-STARTPTS[s2]")
    f.append(f"[ep]fps={FPS},trim=start={es:.3f},setpts=PTS-STARTPTS,tpad=stop_mode=clone:stop_duration=3,trim=duration={seg3:.3f},setpts=PTS-STARTPTS[s3]")
    f.append("[s1][s2][s3]concat=n=3:v=1:a=0[base]")
    sw = fz + hold
    f.append(f"[base][2:v]overlay=x=40:y=300:enable='between(t,0,{sw:.2f})'[b1]")
    f.append(f"[b1][3:v]overlay=x=40:y=300:enable='gte(t,{sw:.2f})'[b2]")
    f.append(f"[b2][4:v]overlay=x=(W-w)/2:y=300:enable='between(t,{sw:.2f},{sw + 2.0:.2f})'[b3]")
    f.append(f"[b3]drawbox=x=0:y=0:w=iw:h=ih:color=white@0.85:t=fill:enable='between(t,{sw:.2f},{sw + 0.12:.2f})'[vout]")
    import sounds
    wp = os.path.join(work, "sfx.wav")
    sounds.build_track([(fz, "shutter", 0.9), (sw - 0.05, "whoosh", 0.8)], total, wp)
    af = [audio_or_silence(0, ri, 0.0, fz, "a1"), f"anullsrc=r=44100:cl=mono,atrim=duration={hold:.3f}[a2]", audio_or_silence(1, ei, es, seg3, "a3"),
          "[a1][a2][a3]concat=n=3:v=0:a=1[voice]", "[5:a]volume=0.6,aresample=44100,aformat=channel_layouts=mono[fx]", "[voice][fx]amix=inputs=2:duration=first:normalize=0[aout]"]
    cmd = ["ffmpeg", "-y", "-v", "error", "-i", raw, "-i", edited]
    for p_ in ("bl.png", "al.png", "hook.png"):
        cmd += ["-loop", "1", "-t", f"{total:.2f}", "-i", os.path.join(work, p_)]
    cmd += ["-i", wp, "-filter_complex", ";".join(f) + ";" + ";".join(af), "-map", "[vout]", "-map", "[aout]", "-t", f"{total:.2f}", "-r", str(FPS),
            "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out]
    sh(cmd)
    return out, total, suggest_caption(niche, changed, "freeze")


def parse_box(v):
    x, y, w, h = [int(float(t)) for t in v.split(":")]
    return x, y, w, h


def activity_window(path, dur, win):
    """The most active stretch of a screen recording: where the picture changes the most."""
    import cv2, numpy as np
    cap = cv2.VideoCapture(path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    act, prev, t = [], None, 0.0
    while t < dur:
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ok, fr = cap.read()
        if not ok:
            break
        g = cv2.cvtColor(cv2.resize(fr, (160, 90)), cv2.COLOR_BGR2GRAY).astype("float32")
        act.append(float(np.abs(g - prev).mean()) if prev is not None else 0.0)
        prev = g
        t += 0.5
    cap.release()
    n = max(1, int(win / 0.5))
    best, bs = 0, -1.0
    for i in range(0, max(1, len(act) - n + 1)):
        v = sum(act[i:i + n])
        if v > bs:
            best, bs = i, v
    return best * 0.5, sum(1 for x in act if x > 0.4) * 0.5


def run_screen(a, opt, notes):
    scr, reel = a[1], a[2]
    niche = opt("--niche", "Your niche")
    title = opt("--title", "Raw video in, finished reel out.")
    changed = opt("--changed", "Added captions, cut dead air, tightened pacing")
    out = os.path.abspath(opt("--out", os.path.join(os.path.dirname(os.path.abspath(scr)), "screen-to-result-reel.mp4")))
    si, fi = probe(scr), probe(reel)
    speed = float(opt("--speed", 0))
    active_s = si["dur"]
    if not speed:
        ws0, active_s = activity_window(scr, si["dur"], 9.0)
        speed = min(4.0, max(2.0, active_s / 3.0)) if active_s >= 6 else 3.0
    win = 3.0 * speed
    ws, _ = activity_window(scr, si["dur"], win)
    ws = min(ws, max(0.0, si["dur"] - win))
    if si["dur"] < win:
        win, speed = si["dur"], max(1.0, si["dur"] / 3.0)
        notes.append(f"The screen recording is short ({si['dur']:.1f}s), so it plays at {speed:.1f}x.")
    else:
        notes.append(f"Screen recording: used the most active {win:.0f} seconds (from {ws:.0f}s) at {speed:.1f}x so it fits 3 seconds.")
    xf = 0.25
    R = min(5.0, max(2.0, fi["dur"]))
    total = min(10.0, max(7.0, 5.0 + R - xf))
    work = tempfile.mkdtemp(prefix="beforeafter-")
    text_png(os.path.join(work, "title.png"), title, 64, max_w=980)
    # picture of the recording: optional crop, optional blurred spots, then fit into the tall frame
    chain = f"[0:v]trim=start={ws:.3f}:end={ws + win:.3f},setpts=(PTS-STARTPTS)/{speed:.4f}"
    if opt("--crop"):
        x, y, w, h = parse_box(opt("--crop"))
        chain += f",crop={w}:{h}:{x}:{y}"
        notes.append(f"Cropped the screen recording to {w}x{h} to hide anything outside that box.")
    blurs = [a[i + 1] for i, v in enumerate(a) if v == "--blur"][:3]
    for k, bx in enumerate(blurs):
        x, y, w, h = parse_box(bx)
        chain += f",split[bm{k}a][bm{k}b];[bm{k}b]crop={w}:{h}:{x}:{y},boxblur=22:3[bm{k}c];[bm{k}a][bm{k}c]overlay={x}:{y}"
    if not opt("--crop") and not blurs:
        notes.append("PRIVACY: I can't find account names, file paths or notifications on a screen recording by myself. Tell me where they are (--crop or --blur x:y:w:h) or look at the result before you post.")
    chain += f",fps={FPS},tpad=stop_mode=clone:stop_duration=6,trim=duration=3.0,setpts=PTS-STARTPTS[scrv]"
    f = [chain]
    # the first two seconds: the first frame of the recording, held, with the title on top
    f.append("[scrv]split[sc1][sc2]")
    f.append(f"[sc1]trim=start=0:end=0.05,setpts=PTS-STARTPTS,tpad=stop_mode=clone:stop_duration=2.1,trim=duration=2.0,setpts=PTS-STARTPTS[head]")
    f.append("[head][sc2]concat=n=2:v=1:a=0[scseq]")
    f.append("[scseq]split[fa][fb];[fa]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=30:3,eq=brightness=-0.12[fbg];[fb]scale=1080:-2,setsar=1[ffg];[fbg][ffg]overlay=(W-w)/2:(H-h)/2,format=yuv420p[scr5]")
    f.append("[scr5][2:v]overlay=x=(W-w)/2:y=300:enable='between(t,0,2)'[scr5t]")
    f.append(prep("1:v", "rp", fi, W, H, "fit", 0.5, notes, "The finished reel"))
    f.append(f"[rp]fps={FPS},tpad=stop_mode=clone:stop_duration=6,trim=duration={R:.3f},setpts=PTS-STARTPTS,format=yuv420p,fps={FPS}[rl]")
    f.append(f"[scr5t]format=yuv420p,fps={FPS},settb=1/{FPS}[sa];[rl]settb=1/{FPS}[rl2];[sa][rl2]xfade=transition=slideleft:duration={xf}:offset={5.0 - xf:.2f}[vout]")
    import sounds
    wp = os.path.join(work, "sfx.wav")
    sounds.build_track([(5.0 - xf - 0.1, "whoosh", 0.9)], total, wp)
    delay = int((5.0 - xf) * 1000)
    if fi["audio"]:
        af = f"[1:a]atrim=duration={R:.3f},asetpts=PTS-STARTPTS,aresample=44100,aformat=channel_layouts=mono,adelay={delay}:all=1[ra];"
    else:
        af = f"anullsrc=r=44100:cl=mono,atrim=duration={total:.2f}[ra];"
        notes.append("The finished reel has no sound, so only the transition whoosh plays.")
    af += "[3:a]volume=0.6,aresample=44100,aformat=channel_layouts=mono[fx];[ra][fx]amix=inputs=2:duration=longest:normalize=0[aout]"
    cmd = ["ffmpeg", "-y", "-v", "error", "-i", scr, "-i", reel, "-loop", "1", "-t", f"{total:.2f}", "-i", os.path.join(work, "title.png"), "-i", wp,
           "-filter_complex", ";".join(f) + ";" + af, "-map", "[vout]", "-map", "[aout]", "-t", f"{total:.2f}", "-r", str(FPS),
           "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out]
    sh(cmd)
    return out, total, f"{niche}: here's what happens when you drop a raw video into the engine. Raw video in, finished reel out. What changed: {changed.rstrip('.')}.\n\nWant yours edited like this? Comment WAITLIST."


def main():
    a = sys.argv[1:]
    if len(a) >= 3 and a[0] in ("freeze", "screen"):
        def opt(k, d=None):
            return a[a.index(k) + 1] if k in a else d
        notes = []
        out, total, cap = (run_freeze if a[0] == "freeze" else run_screen)(a, opt, notes)
        open(os.path.splitext(out)[0] + ".caption.txt", "w", encoding="utf-8").write(cap + "\n")
        print(f"Made {out} ({total:.1f} seconds, {W}x{H}, {FPS} fps).")
        print("Suggested caption saved next to it.")
        for n in notes:
            print("NOTE:", n)
        return
    main_two()


def main_two():
    a = sys.argv[1:]
    if len(a) < 3 or a[0] not in ("side-by-side", "curtain"):
        sys.exit(__doc__)
    kind, raw, edited = a[0], a[1], a[2]

    def opt(k, d=None):
        return a[a.index(k) + 1] if k in a else d
    niche = opt("--niche", "Your niche")
    changed = opt("--changed", "Added captions, cut dead air, tightened pacing")
    hook = opt("--hook", "")
    fill = opt("--fill", "fit")
    rx, ex = float(opt("--raw-x", 0.5)), float(opt("--edited-x", 0.5))
    length = opt("--length", "freeze")
    out = os.path.abspath(opt("--out", os.path.join(os.path.dirname(os.path.abspath(raw)), f"{kind}-reel.mp4")))
    notes = []
    ri, ei = probe(raw), probe(edited)
    base_len = ei["dur"] if length == "speed" else max(ri["dur"], ei["dur"])
    start = 0.0
    if base_len > 10.0:
        if "--best-section" in a:
            start = loudest_start(edited, ei["dur"], 10.0)
            notes.append(f"The footage is {base_len:.0f} seconds, so I used the loudest 10 seconds (starting at {start:.0f}s). The raw clip uses the same start time, so check that both sides still match.")
        else:
            notes.append(f"The footage is {base_len:.0f} seconds, so I used the first 10 seconds. Add --best-section to use the loudest 10 instead.")
    total = min(10.0, max(7.0, base_len - start))
    if base_len - start < 7.0:
        notes.append("The footage is under 7 seconds, so the last frame holds to reach 7 seconds.")
    if length == "freeze":
        notes.append("Length setting: freeze. The shorter clip holds on its last frame until the longer one ends.")
    else:
        notes.append("Length setting: speed. The raw clip is stretched or squeezed to the edited clip's length.")
    notes.append(f"Fill setting: {fill}" + (" (the whole picture shows, so burned-in captions stay inside their half)." if fill == "fit" else " (edges are cropped; captions near the edge may be cut)."))
    work = tempfile.mkdtemp(prefix="beforeafter-")
    speed_to = (ei["dur"] - start) if length == "speed" else None
    if kind == "side-by-side":
        top = opt("--niche-text", f"{niche}: raw vs. edited")
        sizes = {}
        sizes["top"] = text_png(os.path.join(work, "top.png"), top, 58, max_w=980)
        sizes["bl"] = text_png(os.path.join(work, "bl.png"), "BEFORE", 54, box=(60, 60, 66, 225))
        sizes["al"] = text_png(os.path.join(work, "al.png"), "AFTER", 54, box=(42, 110, 111, 235))
        sizes["ch"] = text_png(os.path.join(work, "ch.png"), changed, 54, max_w=1000)
        line_png(os.path.join(work, "div.png"), 6, H, shadow=False)
        hw = W // 2
        f = [prep("0:v", "rp", ri, hw, H, fill, rx, notes, "The raw clip"), prep("1:v", "ep", ei, hw, H, fill, ex, notes, "The edited clip")]
        f.append(time_fix("rp", "rt", start, total, ri, speed_to))
        f.append(time_fix("ep", "et", start, total, ei))
        f.append("[rt][et]hstack=inputs=2[base]")
        f.append(f"[base][2:v]overlay=(W-w)/2:0[b1]")
        f.append(f"[b1][3:v]overlay=x={hw // 2}-w/2:y=470[b2]")
        f.append(f"[b2][4:v]overlay=x={hw + hw // 2}-w/2:y=470[b3]")
        f.append(f"[b3][5:v]overlay=x=(W-w)/2:y=300:enable='between(t,0,2)'[b4]")
        f.append(f"[b4][6:v]overlay=x=(W-w)/2:y=1380:enable='between(t,{total - 2.8:.2f},{total:.2f})'[vout]")
        extra = ["div.png", "bl.png", "al.png", "top.png", "ch.png"]
        # input order: 0 raw, 1 edited, 2 div, 3 bl, 4 al, 5 top, 6 ch
        pics = ["div.png", "bl.png", "al.png", "top.png", "ch.png"]
        sw_audio = None
    else:
        t0, t1, t2, t3 = [float(x) for x in opt("--timing", "1.0,2.0,3.0,4.0").split(",")]
        total = max(total, t3 + 3.0) if total < t3 + 3.0 else total
        total = min(total, 10.0)
        sizes = {}
        text_png(os.path.join(work, "bl.png"), "BEFORE", 54, box=(60, 60, 66, 225))
        text_png(os.path.join(work, "al.png"), "AFTER", 54, box=(42, 110, 111, 235))
        line_png(os.path.join(work, "edge.png"), 6, H, shadow=True)
        hook_txt = hook or f"{niche}: same footage, finished edit"
        text_png(os.path.join(work, "hook.png"), hook_txt, 60, max_w=980)
        f = [prep("0:v", "rp", ri, W, H, fill, rx, notes, "The raw clip"), prep("1:v", "ep", ei, W, H, fill, ex, notes, "The edited clip")]
        f.append(time_fix("rp", "rt", start, total, ri, speed_to))
        f.append(time_fix("ep", "et", start, total, ei))
        segs = [(t0, t1, 0.5, 0.1), (t1, t2, 0.1, 0.9), (t2, t3, 0.9, 0.0), (t3, 9999, 0.0, 0.0)]
        segs[0] = (t0, t1, 0.5, 0.1)
        cT = curtain_expr("T", [(t0, t1, 0.5, 0.1), (t1, t2, 0.1, 0.9), (t2, t3, 0.9, 0.0), (0, 0, 0.0, 0.0)])
        cT = curtain_expr("T", [(t0, t1, 0.5, 0.1), (t1, t2, 0.1, 0.9), (t2, t3, 0.9, 0.0), (t3, 9999, 0.0, 0.0)])
        ct = cT.replace("T", "t")
        f.append(f"color=c=black:s={W}x{H}:r={FPS}:d={total:.2f},format=gray,geq=lum='if(gte(X,W*({cT})),255,0)'[mask]")
        f.append("[et]format=yuva420p[etv];[etv][mask]alphamerge[ea]")
        f.append("[rt][ea]overlay=0:0[cur]")
        f.append(f"[cur][2:v]overlay=x='W*({ct})-w/2':y=0:enable='between(t,{t0 - 0.05:.2f},{t3:.2f})'[c1]")
        f.append(f"[c1][3:v]overlay=x='max(20,W*({ct})/2-w/2)':y=470:enable='between(t,0,{t3:.2f})*gt({ct},0.16)'[c2]")
        f.append(f"[c2][4:v]overlay=x='min(W-w-20,(W*({ct})+W)/2-w/2)':y=470:enable='between(t,0,{t3:.2f})*lt({ct},0.84)'[c3]")
        f.append(f"[c3][5:v]overlay=x=(W-w)/2:y=300:enable='gte(t,{t3:.2f})'[vout]")
        pics = ["edge.png", "bl.png", "al.png", "hook.png"]
        # whoosh on each curtain move
        import sounds
        wp = os.path.join(work, "whoosh.wav")
        sounds.build_track([(max(0.0, t0 - 0.1), "whoosh", 0.8), (t1 - 0.1, "whoosh", 0.8), (t2 - 0.1, "whoosh", 0.9)], total, wp)
        sw_audio = wp
    # audio: edited clip only
    cmd = ["ffmpeg", "-y", "-v", "error", "-i", raw, "-i", edited]
    for p_ in pics:
        cmd += ["-loop", "1", "-t", f"{total:.2f}", "-i", os.path.join(work, p_)]
    n_in = 2 + len(pics)
    if sw_audio:
        cmd += ["-i", sw_audio]
    if ei["audio"]:
        af = f"[1:a]atrim=start={start:.3f},asetpts=PTS-STARTPTS,apad=whole_dur={total:.2f},atrim=duration={total:.3f}[ea]"
    else:
        af = f"anullsrc=r=44100:cl=mono,atrim=duration={total:.3f}[ea]"
        notes.append("The edited clip has no sound, so the reel is silent" + (" except for the curtain whoosh." if sw_audio else "."))
    if sw_audio:
        af += f";[{n_in}:a]volume=0.55[wh];[ea][wh]amix=inputs=2:duration=first:normalize=0[aout]"
    else:
        af = af.replace("[ea]", "[aout]")
    graph = ";".join(f) + ";" + af
    cmd += ["-filter_complex", graph, "-map", "[vout]", "-map", "[aout]", "-t", f"{total:.2f}", "-r", str(FPS), "-c:v", "libx264", "-preset", "medium", "-crf", "18",
            "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out]
    sh(cmd)
    cap = suggest_caption(niche, changed, kind)
    open(os.path.splitext(out)[0] + ".caption.txt", "w", encoding="utf-8").write(cap + "\n")
    print(f"Made {out} ({total:.1f} seconds, {W}x{H}, {FPS} fps).")
    print("Suggested caption saved next to it.")
    for n in notes:
        print("NOTE:", n)


if __name__ == "__main__":
    main()
