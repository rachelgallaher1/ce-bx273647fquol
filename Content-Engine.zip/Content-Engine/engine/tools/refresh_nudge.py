#!/usr/bin/env python3
"""Sunday nudge: if this week's results refresh has not run yet, show a Mac notification asking her to open Claude.
Run by a small scheduled job on Sunday mornings (see engine/instructions/update-engine.md). Does nothing if the refresh already ran."""
import datetime, os, subprocess, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
f = os.path.join(ROOT, "customer", "insights", "last-refresh.txt")
try:
    last = datetime.datetime.fromisoformat(open(f, encoding="utf-8").read().strip()[:19])
    if (datetime.datetime.now() - last).total_seconds() < 5 * 3600 * 24 and last.date() == datetime.date.today():
        sys.exit(0)
except Exception:
    pass
MSG = "Open Claude so I can update your results and plan next week."
if sys.platform == "darwin":
    subprocess.run(["osascript", "-e", f'display notification "{MSG}" with title "Your Content Engine" subtitle "Sunday refresh is waiting"'])
elif sys.platform.startswith("win"):
    ps = ("Add-Type -AssemblyName System.Windows.Forms;$n=New-Object System.Windows.Forms.NotifyIcon;$n.Icon=[System.Drawing.SystemIcons]::Information;"
          f"$n.Visible=$true;$n.ShowBalloonTip(15000,'Your Content Engine','{MSG}',[System.Windows.Forms.ToolTipIcon]::Info);Start-Sleep 16;$n.Dispose()")
    subprocess.run(["powershell", "-NoProfile", "-Command", ps])
