#!/usr/bin/env python3
"""
Carousel maker: turns a small slide list (words only) into finished Instagram carousel pictures.

  ~/.cache/content-engine/whisper-venv/bin/python -I engine/tools/make_carousel.py slides.json

slides.json:
{
  "title": "month-of-content",            # folder name for the finished slides
  "look": "1",                            # her look (id or name)
  "video": "path/to/her/video.mp4",       # optional: slide photos are taken from it
  "handle": "@rachgallaher",              # optional, shown small on slides
  "slides": [
    {"type": "cover", "label": "SUNDAY NIGHT,", "headline": "NO IDEA WHAT TO POST?", "hi": "POST", "frame": 12.0},
    {"type": "point", "n": "01", "headline": "...", "body": "..."},
    {"type": "stat", "number": "12", "label": "YEARS", "body": "..."},
    {"type": "photo", "headline": "...", "body": "...", "frame": 30.0},
    {"type": "list", "headline": "...", "items": ["one", "two", "three"]},
    {"type": "cta", "keyword": "ENGINE", "line": "and I'll send you the details"}
  ]
}
Slides are 1080 x 1350 (the size Instagram carousels like best). Same look, fonts and style rules as her videos.
"""
import json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import first_edit as fe
from PIL import Image, ImageDraw

CW, CH = 1080, 1350
MARGIN = 100   # the same side margin on every new slide type (kept inside Instagram's overlays)


def frame_at(video, t, work):
    out = os.path.join(work, f"frame_{int(t * 10)}.jpg")
    if not os.path.exists(out):
        # iPhone video is HDR (wide color), which looks flat and gray as a still. A light lift brings the color back.
        vf = "eq=contrast=1.14:saturation=1.38:gamma=0.93:brightness=0.02" if fe.is_hdr(video) else "null"
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", f"{t:.2f}", "-i", video, "-frames:v", "1", "-vf", vf, "-q:v", "2", out], check=True)
    return Image.open(out).convert("RGB")


def pick_stills(video, dur, work, n=6):
    """Her best stills: face centered and big enough, eyes open, smiling or at rest (not mid-word), sharp. Returns times in the source video."""
    import cv2
    cache = os.path.join(work, f"stills{n}.json")
    if os.path.exists(cache):
        return json.load(open(cache, encoding="utf-8"))
    cap = cv2.VideoCapture(video)
    try:
        cap.set(cv2.CAP_PROP_ORIENTATION_AUTO, 1)
    except Exception:
        pass
    fc = cv2.CascadeClassifier(os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml"))
    ec = cv2.CascadeClassifier(os.path.join(cv2.data.haarcascades, "haarcascade_eye.xml"))
    sc_ = cv2.CascadeClassifier(os.path.join(cv2.data.haarcascades, "haarcascade_smile.xml"))
    scored, t = [], 1.0
    while t < dur - 0.5:
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ok, fr = cap.read()
        t += 0.5
        if not ok:
            continue
        k = 540.0 / max(fr.shape[:2])
        g = cv2.cvtColor(cv2.resize(fr, (int(fr.shape[1] * k), int(fr.shape[0] * k))), cv2.COLOR_BGR2GRAY)
        faces = fc.detectMultiScale(g, 1.1, 5, minSize=(90, 90))
        if len(faces) == 0:
            continue
        x, y, w, h = max(faces, key=lambda f: f[2] * f[3])
        cx = (x + w / 2) / g.shape[1]
        eyes = ec.detectMultiScale(g[y:y + h // 2, x:x + w], 1.1, 6, minSize=(18, 18))
        mouth_zone = g[y + int(h * 0.55):y + h, x:x + w]
        smile = len(sc_.detectMultiScale(mouth_zone, 1.7, 22, minSize=(25, 15))) > 0
        sharp = min(cv2.Laplacian(g[y:y + h, x:x + w], cv2.CV_64F).var(), 300) / 300
        score = -abs(cx - 0.5) * 2 + (0.8 if len(eyes) >= 2 else 0.0) + (0.7 if smile else 0.0) + sharp - abs(w / g.shape[1] - 0.4)
        scored.append((score, t - 0.5))
    scored.sort(reverse=True)
    picks = []
    for sc, tt in scored:
        if all(abs(tt - p) > 6 for p in picks):
            picks.append(round(tt, 1))
        if len(picks) == n:
            break
    json.dump(picks, open(cache, "w", encoding="utf-8"))
    return picks


def up_for_face(img, w, h, target=0.30, default=0.45):
    """Where to crop so her face sits about 30 percent down the slide (not cut off, not under the text)."""
    try:
        import cv2, numpy as np
        g = cv2.cvtColor(np.array(img.convert("RGB")), cv2.COLOR_RGB2GRAY)
        k = 600.0 / max(g.shape)
        g = cv2.resize(g, (int(g.shape[1] * k), int(g.shape[0] * k)))
        f = cv2.CascadeClassifier(os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml")).detectMultiScale(g, 1.1, 5, minSize=(60, 60))
        if len(f) == 0:
            return default
        x, y, fw, fh = max(f, key=lambda a: a[2] * a[3])
        r = max(w / img.width, h / img.height)
        face_y = (y + fh * 0.45) / k * r
        total = img.height * r - h
        if total <= 0:
            return default
        return min(1.0, max(0.0, (face_y - target * h) / total))
    except Exception:
        return default


_FACE_CACHE = {}


def find_faces(img):
    """Where faces are in a picture, as boxes (x0, y0, x1, y1) in the picture's own pixels. Empty when none are found (or the face tool is missing)."""
    key = (img.size, hash(img.tobytes()[:20000]))
    if key in _FACE_CACHE:
        return _FACE_CACHE[key]
    boxes = []
    try:
        import cv2
        import numpy as np
        sc = min(1.0, 900 / max(img.size))
        small = img.convert("L").resize((max(1, int(img.width * sc)), max(1, int(img.height * sc))))
        det = cv2.CascadeClassifier(os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml"))
        found = det.detectMultiScale(np.array(small), scaleFactor=1.1, minNeighbors=6, minSize=(max(30, int(small.width * 0.05)),) * 2)
        for (x, y, fw, fh) in found:
            boxes.append((x / sc, y / sc, (x + fw) / sc, (y + fh) / sc))
    except Exception:
        boxes = []
    _FACE_CACHE[key] = boxes
    return boxes


def cover_crop(img, w, h, up=0.45):
    r = max(w / img.width, h / img.height)
    faces = find_faces(img)
    img = img.resize((int(img.width * r) + 1, int(img.height * r) + 1), Image.LANCZOS)
    x, y = (img.width - w) // 2, int((img.height - h) * up)
    if faces:   # keep faces in the picture: slide the crop only as far as needed (a face already inside changes nothing)
        fx0 = min(f[0] for f in faces) * r; fy0 = min(f[1] for f in faces) * r
        fx1 = max(f[2] for f in faces) * r; fy1 = max(f[3] for f in faces) * r
        mx, my = (fx1 - fx0) * 0.35, (fy1 - fy0) * 0.45   # a little room around the face (hair, chin)
        if fx1 - fx0 + 2 * mx <= w:
            if fx0 - mx < x:
                x = int(fx0 - mx)
            elif fx1 + mx > x + w:
                x = int(fx1 + mx - w)
        if fy1 - fy0 + 2 * my <= h:
            if fy0 - my < y:
                y = int(fy0 - my)
            elif fy1 + my > y + h:
                y = int(fy1 + my - h)
        x = max(0, min(img.width - w, x))
        y = max(0, min(img.height - h, y))
    return img.crop((x, y, x + w, y + h))


def wcag_lum(c):
    def ch(v):
        v = v / 255
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    return 0.2126 * ch(c[0]) + 0.7152 * ch(c[1]) + 0.0722 * ch(c[2])


def contrast(a, b):
    la, lb = wcag_lum(a), wcag_lum(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def palette(look, i):
    """Solid slides cycle through the look's own colors; text color is picked for contrast."""
    cols = [look["hook"]["bg"], look["accent"]["bg"], look["caption"]["bg"], look["highlight"]["bg"]]
    bg = cols[i % len(cols)]
    ink = (20, 20, 22, 255) if fe.luminance(bg) > 0.5 else (255, 255, 255, 255)
    soft = (20, 20, 22, 150) if fe.luminance(bg) > 0.5 else (255, 255, 255, 170)
    accent = fe.hex2rgb(look["highlight"]["bg"] if bg != look["highlight"]["bg"] else look["accent"]["bg"])
    if fe.luminance(bg) > 0.5 and fe.luminance(look["highlight"]["bg"]) > 0.5:
        accent = (20, 20, 22, 255)
    # the highlight color must be readable on this slide's background (a ratio of 3 is the bar for big text)
    cands = [accent, fe.hex2rgb(look["highlight"]["bg"]), fe.hex2rgb(look["accent"]["bg"]), fe.hex2rgb(look["hook"]["bg"]),
             fe.hex2rgb(look["caption"]["bg"]), (255, 255, 255, 255), (20, 20, 22, 255)]
    bgrgb = fe.hex2rgb(bg)[:3]
    good = [c for c in cands if contrast(c[:3], bgrgb) >= 3.0]
    accent = good[0] if good else max(cands, key=lambda c: contrast(c[:3], bgrgb))
    return fe.hex2rgb(bg), ink, soft, accent


def _break_long(d, w, font, maxw):
    """A single word wider than the slide is split into pieces that fit (normal words are untouched)."""
    if d.textlength(w, font=font) <= maxw:
        return [w]
    out, cur = [], ""
    for ch in w:
        if cur and d.textlength(cur + ch, font=font) > maxw:
            out.append(cur)
            cur = ch
        else:
            cur += ch
    return out + ([cur] if cur else [])


def wrap(d, text, font, maxw):
    lines, cur = [], ""
    words = []
    for w in text.split():
        words.extend(_break_long(d, w, font, maxw))
    for w in words:
        t = (cur + " " + w).strip()
        if d.textlength(t, font=font) > maxw and cur:
            lines.append(cur)
            cur = w
        else:
            cur = t
    if cur:
        lines.append(cur)
    return lines


def fit_lines(d, look, text, start, maxw, maxlines):
    size = start
    while size > 60:
        f = fe.display_font(look, size)
        lines = wrap(d, text, f, maxw)
        if len(lines) <= maxlines and all(d.textlength(l, font=f) <= maxw for l in lines):
            return f, lines
        size -= 8
    f = fe.display_font(look, 60)
    return f, wrap(d, text, f, maxw)


def draw_text(d, xy, text, font, fill, stroke=0, stroke_fill=(20, 20, 22, 235)):
    d.text(xy, text, font=font, fill=fill, stroke_width=stroke, stroke_fill=stroke_fill)


def dots(d, i, n, ink):
    gap, r = 26, 7
    x0 = (CW - (n - 1) * gap) / 2
    for k in range(n):
        d.ellipse((x0 + k * gap - r, CH - 70 - r, x0 + k * gap + r, CH - 70 + r), fill=ink if k == i else ink[:3] + (70,))


def footer(d, look, handle, i, n, ink):
    """Her handle (left), slide number (right), and a small swipe cue on slides 1 to 3."""
    f = fe.load_font(look["captionFont"], 32, 700)
    if handle:
        d.text((MARGIN, CH - 92), handle, font=f, fill=ink[:3] + (200,))
    num = f"{i + 1}/{n}"
    d.text((CW - MARGIN - d.textlength(num, font=f), CH - 92), num, font=f, fill=ink[:3] + (200,))
    if i < min(3, n - 1):
        sw = "swipe"
        x1 = CW - MARGIN
        ax = x1 - d.textlength(num, font=f) - 22
        tw = d.textlength(sw, font=f)
        d.text((ax - tw - 40, CH - 92), sw, font=f, fill=ink[:3] + (200,))
        d.line((ax - 34, CH - 76, ax - 4, CH - 76), fill=ink[:3] + (200,), width=4)
        d.line((ax - 16, CH - 88, ax - 3, CH - 76, ax - 16, CH - 64), fill=ink[:3] + (200,), width=4, joint="curve")


def photo_bg(look, img, strong=True, up=None):
    bg = cover_crop(img, CW, CH, up_for_face(img, CW, CH, 0.30) if up is None else up).convert("RGBA")
    col = (8, 8, 8)   # a neutral dark so her photo keeps its own color (a tinted overlay made it look off)
    bg.alpha_composite(fe.gradient(CW, int(CH * 0.72), col, 170 if strong else 140, from_top=False), (0, CH - int(CH * 0.72)))
    bg.alpha_composite(fe.gradient(CW, int(CH * 0.25), col, 70, from_top=True), (0, 0))
    return bg


def stacked_headline(d, look, text, hi, start, y, maxw=940, maxlines=4, align="left", x0=70):
    f, lines = fit_lines(d, look, text.upper(), start, maxw, maxlines)
    hl = fe.hl_color(look)
    lh = int(f.size * 0.98)
    words = text.upper().split()
    hi_u = (hi or "").upper()
    if not hi_u:
        hi_u = max(words, key=len)
    for ln in lines:
        w_ = d.textlength(ln, font=f)
        x = x0 if align == "left" else (CW - w_) / 2
        for part in re.split(r"(\s+)", ln):
            pw = d.textlength(part, font=f)
            col = hl if part.strip(" ,.?!'\"") == hi_u.strip(" ,.?!'\"") and part.strip() else (255, 255, 255, 255)
            d.text((x, y + 8), part, font=f, fill=(0, 0, 0, 110), stroke_width=max(6, f.size // 22), stroke_fill=(0, 0, 0, 110))
            d.text((x, y), part, font=f, fill=col, stroke_width=max(6, f.size // 22), stroke_fill=(20, 20, 22, 235))
            x += pw
        y += lh
    return y


def slide_cover(look, s, img, i, n, handle):
    bg = photo_bg(look, img)
    d = ImageDraw.Draw(bg)
    fl = fe.display_font(look, 64)
    label = s.get("label", "").upper()
    f, lines = fit_lines(d, look, s["headline"].upper(), 200, 940, 3)
    total_h = (90 if label else 0) + int(f.size * 0.98) * len(lines) + 150
    y = CH - total_h - 40
    if label:
        d.text((70, y + 4), label, font=fl, fill=(0, 0, 0, 110), stroke_width=6, stroke_fill=(0, 0, 0, 110))
        d.text((70, y), label, font=fl, fill=(255, 255, 255, 255), stroke_width=5, stroke_fill=(20, 20, 22, 235))
        y += 90
    y = stacked_headline(d, look, s["headline"], s.get("hi"), 200, y, maxlines=3)
    if s.get("sub"):
        fs = fe.load_font(look["captionFont"], 46, 500)
        d.text((70, y + 10), s["sub"], font=fs, fill=(255, 255, 255, 235), stroke_width=3, stroke_fill=(20, 20, 22, 170))
    footer(d, look, handle, i, n, (255, 255, 255, 255))
    return bg


def slide_point(look, s, img, i, n, handle):
    im, d, bgc, ink, soft, accent = solid_s(look, i, s)
    fnum = fe.display_font(look, 420)
    num = s.get("n", f"{i:02d}")
    bb = d.textbbox((0, 0), num, font=fnum)
    d.text((50 - bb[0], 50 - bb[1]), num, font=fnum, fill=accent[:3] + (255,))
    top = 50 + (bb[3] - bb[1]) + 50
    fb = fe.load_font(look["captionFont"], 56, 500)
    body = wrap(d, s.get("body", ""), fb, 900)[:3]
    body_h = (56 + 76 * len(body)) if body else 0
    avail = CH - 200 - top - body_h
    size = 190
    while size > 60:
        f = fe.display_font(look, size)
        lines = wrap(d, s["headline"].upper(), f, 940)
        if int(size * 0.98) * len(lines) <= avail and len(lines) <= 4:
            break
        size -= 8
    y = top
    for ln in lines:
        d.text((70, y), ln, font=f, fill=ink)
        y += int(f.size * 0.98)
    y += 56
    for ln in body:
        d.text((70, y), ln, font=fb, fill=soft)
        y += 76
    footer(d, look, handle, i, n, ink)
    return im


def slide_stat(look, s, img, i, n, handle):
    im, d, bgc, ink, soft, accent = solid_s(look, i, s)
    num = str(s["number"])
    size = 620
    fn = fe.display_font(look, size)
    while d.textlength(num, font=fn) > 940 and size > 150:
        size -= 20
        fn = fe.display_font(look, size)
    bb = d.textbbox((0, 0), num, font=fn)
    y = 150
    d.text(((CW - (bb[2] - bb[0])) / 2 - bb[0], y - bb[1]), num, font=fn, fill=accent[:3] + (255,))
    y += (bb[3] - bb[1]) + 60
    lab = s.get("label", "").upper()
    fl = fe.display_font(look, 110)
    size = 110
    while d.textlength(lab, font=fl) > 940 and size > 50:
        size -= 6
        fl = fe.display_font(look, size)
    lb = d.textbbox((0, 0), lab, font=fl)
    d.text(((CW - (lb[2] - lb[0])) / 2 - lb[0], y - lb[1]), lab, font=fl, fill=ink)
    y += (lb[3] - lb[1]) + 60
    if s.get("body"):
        fb = fe.load_font(look["captionFont"], 54, 500)
        for ln in wrap(d, s["body"], fb, 880)[:3]:
            d.text(((CW - d.textlength(ln, font=fb)) / 2, y), ln, font=fb, fill=soft)
            y += 72
    footer(d, look, handle, i, n, ink)
    return im


def slide_photo(look, s, img, i, n, handle):
    bg = photo_bg(look, img, strong=False)
    d = ImageDraw.Draw(bg)
    f, lines = fit_lines(d, look, s["headline"].upper(), 200, 940, 3)
    fb = fe.load_font(look["captionFont"], 52, 500)
    body = wrap(d, s.get("body", ""), fb, 900)
    total = int(f.size * 0.98) * len(lines) + (30 + 70 * len(body) if body else 0)
    y = CH - total - 200
    y = stacked_headline(d, look, s["headline"], s.get("hi"), 200, y, maxlines=3)
    y += 44
    for ln in body:
        d.text((70, y), ln, font=fb, fill=(255, 255, 255, 240), stroke_width=3, stroke_fill=(20, 20, 22, 170))
        y += 70
    footer(d, look, handle, i, n, (255, 255, 255, 255))
    return bg


def mc_contrast(a, b):
    return contrast(a, b)


def slide_list(look, s, img, i, n, handle):
    im, d, bgc, ink, soft, accent = solid_s(look, i, s)
    f, lines = fit_lines(d, look, s["headline"].upper(), 170, CW - 2 * MARGIN, 3)
    y = 130
    for ln in lines:
        d.text((MARGIN, y), ln, font=f, fill=ink)
        y += int(f.size * 0.98)
    y += 70
    fi = fe.load_font(look["captionFont"], 56, 600)
    for it in s.get("items", [])[:6]:
        wl = wrap(d, it, fi, 700)[:2]
        d.rounded_rectangle((MARGIN, y, MARGIN + 88, y + 88), radius=24, fill=accent)
        chk = (255, 255, 255, 255) if mc_contrast(accent[:3], (255, 255, 255)) >= mc_contrast(accent[:3], (20, 20, 22)) else (20, 20, 22, 255)
        d.line((MARGIN + 22, y + 46, MARGIN + 42, y + 66, MARGIN + 70, y + 24), fill=chk, width=11, joint="curve")
        for k, ln in enumerate(wl):
            d.text((MARGIN + 130, y + 10 + k * 62), ln, font=fi, fill=ink)
        y += max(130, 40 + 62 * len(wl) + 24)
    footer(d, look, handle, i, n, ink)
    return im


def slide_cta(look, s, img, i, n, handle):
    bg = photo_bg(look, img, up=None)
    d = ImageDraw.Draw(bg)
    fl = fe.display_font(look, 90)
    y = 470
    d.text((70, y + 6), "COMMENT", font=fl, fill=(0, 0, 0, 110), stroke_width=7, stroke_fill=(0, 0, 0, 110))
    d.text((70, y), "COMMENT", font=fl, fill=(255, 255, 255, 255), stroke_width=7, stroke_fill=(20, 20, 22, 235))
    kw = s["keyword"].upper()
    size = 300
    fk = fe.display_font(look, size)
    while d.textlength(kw, font=fk) > 860 and size > 100:
        size -= 12
        fk = fe.display_font(look, size)
    bb = d.textbbox((0, 0), kw, font=fk)
    bw, bh = bb[2] - bb[0] + 110, bb[3] - bb[1] + 90
    y += 130
    box = Image.new("RGBA", (bw + 40, bh + 40), (0, 0, 0, 0))
    bd = ImageDraw.Draw(box)
    bd.rounded_rectangle((20, 20, 20 + bw, 20 + bh), radius=40, fill=fe.hex2rgb(look["accent"]["bg"]), outline=(20, 20, 22, 255), width=8)
    bd.text((20 + 55 - bb[0], 20 + 45 - bb[1]), kw, font=fk, fill=fe.hex2rgb(look["accent"]["text"]))
    bg.alpha_composite(fe.shadowed(box), (50 - 48, y - 48))
    if s.get("line"):
        fb = fe.load_font(look["captionFont"], 50, 700)
        yy = y + bh + 60
        for ln in wrap(d, s["line"], fb, CW - 2 * MARGIN)[:2]:
            d.text((MARGIN, yy), ln, font=fb, fill=(255, 255, 255, 245), stroke_width=3, stroke_fill=(20, 20, 22, 170))
            yy += 66
    footer(d, look, handle, i, n, (255, 255, 255, 255))
    return bg



# ---------------------------------------------------------------------------
# Version 1 slide types (all words come from her real content; see CAROUSEL-SPEC.md)
# ---------------------------------------------------------------------------
def mix(c1, c2, t):
    """A solid color t of the way from c2 to c1 (a see-through look without real transparency)."""
    return tuple(int(c2[k] + (c1[k] - c2[k]) * t) for k in range(3)) + (255,)


def scribble(d, x0, x1, y, color, width=10, seed=3):
    """A hand-drawn style underline: slightly wobbly, not a ruler line."""
    import random, math
    r = random.Random(seed)
    pts, n = [], max(6, int((x1 - x0) / 40))
    for k in range(n + 1):
        x = x0 + (x1 - x0) * k / n
        pts.append((x, y + math.sin(k * 1.3) * 5 + r.uniform(-4, 4)))
    d.line(pts, fill=color, width=width, joint="curve")


def hand_arrow(d, x0, y0, x1, y1, color, width=9):
    """A hand-drawn style arrow from (x0, y0) to (x1, y1)."""
    import math
    mx, my = (x0 + x1) / 2 + (y1 - y0) * 0.15, (y0 + y1) / 2 - (x1 - x0) * 0.15
    pts = [(x0 + (mx - x0) * t + (x1 - mx) * t * t - (x0 - mx) * 0 , 0) for t in (0,)]
    curve = []
    for k in range(21):
        t = k / 20
        curve.append(((1 - t) ** 2 * x0 + 2 * (1 - t) * t * mx + t * t * x1, (1 - t) ** 2 * y0 + 2 * (1 - t) * t * my + t * t * y1))
    d.line(curve, fill=color, width=width, joint="curve")
    ang = math.atan2(y1 - curve[-2][1], x1 - curve[-2][0])
    for da in (2.6, -2.6):
        d.line((x1, y1, x1 + 40 * math.cos(ang + da), y1 + 40 * math.sin(ang + da)), fill=color, width=width)


def person_cutout(img):
    """Her cut out of a photo (for sticker covers). Returns RGBA, or None if no person is found."""
    import numpy as np, mediapipe as mp
    seg = mp.solutions.selfie_segmentation.SelfieSegmentation(model_selection=0)
    small = img.convert("RGB").resize((540, 540 * img.height // img.width))
    m = seg.process(np.array(small)).segmentation_mask
    m = np.clip((m - 0.30) / 0.45, 0, 1)
    mi = Image.fromarray((m * 255).astype("uint8")).resize(img.size)
    out = img.convert("RGBA")
    out.putalpha(mi)
    return out


def text_block(d, x, y, text, font, fill, maxw, lh=None, align="left", stroke=0):
    lh = lh or int(font.size * 1.25)
    for ln in wrap(d, text, font, maxw):
        xx = x if align == "left" else x + (maxw - d.textlength(ln, font=font)) / 2
        d.text((xx, y), ln, font=font, fill=fill, stroke_width=stroke, stroke_fill=(20, 20, 22, 235))
        y += lh
    return y


def solid(look, i):
    bgc, ink, soft, accent = palette(look, i)
    im = Image.new("RGBA", (CW, CH), bgc)
    return im, ImageDraw.Draw(im), bgc, ink, soft, accent


def solid_s(look, i, s):
    """Like solid(), but a slide can sit on a photo with a dark overlay ("bgphoto": path, "overlay": 0 to 1). Text turns white."""
    im, d, bgc, ink, soft, accent = solid(look, i)
    ph = s.get("bgphoto")
    if ph and os.path.exists(ph):
        pic = cover_crop(Image.open(ph).convert("RGB"), CW, CH, s.get("photo_up", 0.25)).convert("RGBA")
        pic.alpha_composite(Image.new("RGBA", (CW, CH), (0, 0, 0, int(255 * float(s.get("overlay", 0.6))))))
        im = pic
        d = ImageDraw.Draw(im)
        ink, soft = (255, 255, 255, 255), (255, 255, 255, 200)
        accent = tuple(fe.hl_color(look)[:3]) + (255,)
    return im, d, bgc, ink, soft, accent


def slide_bigtext(look, s, img, i, n, handle):
    im, d, bgc, ink, soft, accent = solid_s(look, i, s)
    n_lines = len(s.get("lines", [])[:4])
    max_h = 980 - n_lines * 110 - (90 if n_lines else 0)
    size = 230
    while size > 70:
        f = fe.display_font(look, size)
        lines = wrap(d, s["headline"].upper(), f, CW - 2 * MARGIN)
        if len(lines) <= 4 and all(d.textlength(l, font=f) <= CW - 2 * MARGIN for l in lines) and len(lines) * int(size * 0.98) <= max_h:
            break
        size -= 8
    y = 130
    if s.get("bgphoto"):
        y = max(130, CH - 200 - (len(lines) * int(f.size * 0.98) + 90 + n_lines * 100))
    hi = (s.get("hi") or "").upper().strip(" ,.?!")
    for ln in lines:
        x = MARGIN
        for part in re.split(r"(\s+)", ln):
            pw = d.textlength(part, font=f)
            if hi and part.strip(" ,.?!") == hi:
                d.text((x, y), part, font=f, fill=accent[:3] + (255,))
                if s.get("underline"):
                    scribble(d, x, x + pw, y + int(f.size * 0.98) + 4, accent[:3] + (255,), 10)
            else:
                d.text((x, y), part, font=f, fill=ink)
            x += pw
        y += int(f.size * 0.98)
    y += 90
    fb = fe.load_font(look["captionFont"], 50, 700)
    for k, ln in enumerate(s.get("lines", [])[:4]):
        for part in wrap(d, ln, fb, CW - 2 * MARGIN):
            d.text((MARGIN, y), part, font=fb, fill=ink if k < n_lines - 1 else accent[:3] + (255,))
            y += 68
        y += 16
    footer(d, look, handle, i, n, ink)
    return im


def slide_quote(look, s, img, i, n, handle):
    im, d, bgc, ink, soft, accent = solid_s(look, i, s)
    fq = fe.display_font(look, 380)
    d.text((MARGIN - 6, 70), "\u201c", font=fq, fill=accent[:3] + (255,))
    size = 78
    while size > 44:
        fb = fe.load_font(look["captionFont"], size, 800)
        lines = wrap(d, s["quote"], fb, CW - 2 * MARGIN)
        if len(lines) * int(size * 1.3) <= 700:
            break
        size -= 4
    y = 400
    for ln in lines:
        d.text((MARGIN, y), ln, font=fb, fill=ink)
        y += int(size * 1.3)
    if s.get("who"):
        fw = fe.display_font(look, 52)
        d.text((MARGIN, y + 40), s["who"].upper(), font=fw, fill=accent[:3] + (255,))
    footer(d, look, handle, i, n, ink)
    return im


def slide_receipt(look, s, img, i, n, handle):
    """Proof: her photo, a white card holding real evidence (her screenshot, with anything rebuildable blurred), big text below."""
    bg = photo_bg(look, img if img is not None else Image.new("RGB", (CW, CH), (60, 60, 60)), strong=True)
    d = ImageDraw.Draw(bg)
    card_w, card_h = 800, 470
    card = Image.new("RGBA", (card_w, card_h), (255, 255, 255, 255))
    cd = ImageDraw.Draw(card)
    if s.get("image") and os.path.exists(s["image"]):
        shot = Image.open(s["image"]).convert("RGB")
        from PIL import ImageFilter
        for (x0, y0, x1, y1) in s.get("blur", []):
            box = (int(x0 * shot.width), int(y0 * shot.height), int(x1 * shot.width), int(y1 * shot.height))
            shot.paste(shot.crop(box).filter(ImageFilter.GaussianBlur(26)), box)
        r = min((card_w - 40) / shot.width, (card_h - 40) / shot.height)
        shot = shot.resize((int(shot.width * r), int(shot.height * r)))
        card.paste(shot, ((card_w - shot.width) // 2, (card_h - shot.height) // 2))
    else:
        fk = fe.load_font(look["captionFont"], 34, 500)
        fv = fe.load_font(look["captionFont"], 50, 800)
        cd.text((40, 30), s.get("card_title", "The proof"), font=fe.load_font(look["captionFont"], 36, 700), fill=(30, 30, 30, 255))
        for k, (a, b) in enumerate(s.get("rows", [])[:3]):
            yy = 110 + k * 110
            cd.line((40, yy - 16, card_w - 40, yy - 16), fill=(225, 225, 225, 255), width=2)
            cd.text((40, yy + 6), a, font=fk, fill=(90, 90, 90, 255))
            cd.text((card_w - 40, yy), b, font=fv, fill=(30, 30, 30, 255), anchor="ra")
    mask = Image.new("L", card.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, card_w - 1, card_h - 1), radius=30, fill=255)
    card.putalpha(mask)
    bg.alpha_composite(fe.shadowed(card, blur=22, dy=14, alpha=130), ((CW - card_w) // 2 - 66, 120 - 66))
    y = 760
    y = stacked_headline(d, look, s["headline"], s.get("hi"), 130, y, maxw=CW - 2 * MARGIN, maxlines=3, x0=MARGIN)
    if s.get("body"):
        fb = fe.load_font(look["captionFont"], 46, 700)
        text_block(d, MARGIN, y + 20, s["body"], fb, (255, 255, 255, 240), CW - 2 * MARGIN, stroke=3)
    footer(d, look, handle, i, n, (255, 255, 255, 255))
    return bg


def slide_transform(look, s, img, i, n, handle):
    im, d, bgc, ink, soft, accent = solid_s(look, i, s)
    fl = fe.display_font(look, 90)
    colw = (CW - 2 * MARGIN - 40) // 2
    fb = fe.load_font(look["captionFont"], 46, 700)
    nl = max(len(wrap(d, s["before"], fb, colw - 72)), len(wrap(d, s["after"], fb, colw - 72)))
    box_h = max(420, 190 + nl * 58 + 60) + (300 if s.get("calendar") else 0)
    for k, (lab, txt) in enumerate((("BEFORE", s["before"]), ("AFTER", s["after"]))):
        x = MARGIN + k * (colw + 40)
        d.rounded_rectangle((x, 160, x + colw, 160 + box_h), radius=30, fill=mix(ink, bgc, 0.1), outline=accent[:3] + (255,) if k else mix(ink, bgc, 0.35), width=6)
        d.text((x + 36, 200), lab, font=fl, fill=accent[:3] + (255,) if k else soft)
        text_block(d, x + 36, 330, txt, fb, ink, colw - 72)
        if s.get("calendar"):
            # a small calendar: empty for before, filled for after
            cell = (colw - 72) // 7
            gy = 160 + box_h - 36 - 5 * (cell + 8)
            for r in range(5):
                for c in range(7):
                    cx0, cy0 = x + 36 + c * cell, gy + r * (cell + 8)
                    filled = k == 1 and (r * 7 + c) < 30
                    d.rounded_rectangle((cx0, cy0, cx0 + cell - 8, cy0 + cell - 2), radius=8,
                                        fill=accent[:3] + (255,) if filled else None,
                                        outline=accent[:3] + (255,) if filled else mix(ink, bgc, 0.4), width=3)
    if s.get("feel"):
        ff = fe.load_font(look["captionFont"], 56, 800)
        y = 160 + box_h + 70
        d.text((MARGIN, y), "HOW IT FELT", font=fe.display_font(look, 52), fill=accent[:3] + (255,))
        text_block(d, MARGIN, y + 80, s["feel"], ff, ink, CW - 2 * MARGIN)
    footer(d, look, handle, i, n, ink)
    return im


def slide_recap(look, s, img, i, n, handle):
    s = dict(s)
    s.setdefault("headline", "HERE'S WHAT YOU JUST GOT")
    return slide_list(look, s, img, i, n, handle)


def slide_myth(look, s, img, i, n, handle):
    im, d, bgc, ink, soft, accent = solid_s(look, i, s)
    half = CH // 2 - 60
    d.rectangle((0, 0, CW, half), fill=mix(ink, bgc, 0.09))
    fl = fe.display_font(look, 96)
    fb = fe.load_font(look["captionFont"], 62, 800)
    d.text((MARGIN, 90), "MYTH", font=fl, fill=soft)
    text_block(d, MARGIN, 220, s["myth"], fb, ink, CW - 2 * MARGIN)
    d.text((MARGIN, half + 70), "FACT", font=fl, fill=accent[:3] + (255,))
    text_block(d, MARGIN, half + 200, s["fact"], fb, ink, CW - 2 * MARGIN)
    footer(d, look, handle, i, n, ink)
    return im


def slide_faq(look, s, img, i, n, handle):
    im, d, bgc, ink, soft, accent = solid_s(look, i, s)
    f, lines = fit_lines(d, look, s["question"].upper(), 150, CW - 2 * MARGIN, 3)
    y = 140
    for ln in lines:
        d.text((MARGIN, y), ln, font=f, fill=accent[:3] + (255,))
        y += int(f.size * 0.98)
    y += 50
    d.line((MARGIN, y, CW - MARGIN, y), fill=mix(ink, bgc, 0.35), width=4)
    fb = fe.load_font(look["captionFont"], 58, 700)
    text_block(d, MARGIN, y + 60, s["answer"], fb, ink, CW - 2 * MARGIN)
    footer(d, look, handle, i, n, ink)
    return im


def slide_pov(look, s, img, i, n, handle):
    im, d, bgc, ink, soft, accent = solid_s(look, i, s)
    tag = fe.display_font(look, 90)
    d.rounded_rectangle((MARGIN, 150, MARGIN + d.textlength("POV", font=tag) + 80, 150 + 130), radius=24, fill=accent[:3] + (255,))
    d.text((MARGIN + 40, 172), "POV", font=tag, fill=bgc + (255,) if len(bgc) == 3 else bgc)
    f, lines = fit_lines(d, look, s["headline"].upper(), 200, CW - 2 * MARGIN, 5)
    y = 360
    for ln in lines:
        d.text((MARGIN, y), ln, font=f, fill=ink)
        y += int(f.size * 0.98)
    footer(d, look, handle, i, n, ink)
    return im


def slide_quiz(look, s, img, i, n, handle):
    im, d, bgc, ink, soft, accent = solid_s(look, i, s)
    f, lines = fit_lines(d, look, s["question"].upper(), 150, CW - 2 * MARGIN, 3)
    y = 130
    for ln in lines:
        d.text((MARGIN, y), ln, font=f, fill=ink)
        y += int(f.size * 0.98)
    y += 60
    fo = fe.load_font(look["captionFont"], 52, 700)
    fl = fe.display_font(look, 84)
    nopt = len(s["options"][:3])
    box_h = int(min(220, (CH - 150 - y) / max(1, nopt) - 30))
    for k, opt in enumerate(s["options"][:3]):
        d.rounded_rectangle((MARGIN, y, CW - MARGIN, y + box_h), radius=30, fill=mix(ink, bgc, 0.1), outline=accent[:3] + (255,), width=5)
        letter = "ABC"[k]
        lb = d.textbbox((0, 0), letter, font=fl)
        d.text((MARGIN + 40 - lb[0], y + (box_h - (lb[3] - lb[1])) / 2 - lb[1]), letter, font=fl, fill=accent[:3] + (255,))
        wl = wrap(d, opt, fo, CW - 2 * MARGIN - 220)[:3]
        th = len(wl) * 62
        yy = y + (box_h - th) / 2 - 8
        for ln in wl:
            d.text((MARGIN + 170, yy), ln, font=fo, fill=ink)
            yy += 62
        y += box_h + 30
    footer(d, look, handle, i, n, ink)
    return im


def slide_negcover(look, s, img, i, n, handle):
    """Negative-space cover: one giant word, lots of empty space."""
    im, d, bgc, ink, soft, accent = solid_s(look, 0, s)
    word = s["word"].upper()
    size = 520
    f = fe.display_font(look, size)
    while d.textlength(word, font=f) > CW - 2 * MARGIN and size > 120:
        size -= 20
        f = fe.display_font(look, size)
    bb = d.textbbox((0, 0), word, font=f)
    d.text(((CW - (bb[2] - bb[0])) / 2 - bb[0], 520 - bb[1]), word, font=f, fill=accent[:3] + (255,))
    if s.get("underline"):
        scribble(d, (CW - (bb[2] - bb[0])) / 2, (CW + (bb[2] - bb[0])) / 2, 520 + (bb[3] - bb[1]) + 20, ink[:3] + (255,), 10)
    if s.get("label"):
        fl = fe.display_font(look, 60)
        d.text((MARGIN, 150), s["label"].upper(), font=fl, fill=soft)
    if s.get("sub"):
        text_block(d, MARGIN, 520 + (bb[3] - bb[1]) + 90, s["sub"], fe.load_font(look["captionFont"], 50, 600), ink, CW - 2 * MARGIN)
    footer(d, look, handle, i, n, ink)
    return im


def slide_sticker(look, s, img, i, n, handle):
    """Sticker cover: her cut out with a thick white border, slightly tilted, on a brand color."""
    im, d, bgc, ink, soft, accent = solid(look, 0)
    pic = None
    try:
        pic = person_cutout(cover_crop(img, 900, 900)) if img is not None else None
    except Exception:
        pic = None
    if pic is not None:
        from PIL import ImageFilter
        a = pic.getchannel("A")
        edge = a.filter(ImageFilter.MaxFilter(41)).filter(ImageFilter.GaussianBlur(3))
        sticker = Image.new("RGBA", pic.size, (0, 0, 0, 0))
        white = Image.new("RGBA", pic.size, (255, 255, 255, 255))
        sticker.paste(white, (0, 0), edge)
        sticker.alpha_composite(pic)
        sticker = sticker.rotate(5, expand=True, resample=Image.BICUBIC)
        im.alpha_composite(fe.shadowed(sticker, blur=24, dy=16, alpha=110), (CW // 2 - sticker.width // 2 - 72, 110 - 72))
    f, lines = fit_lines(d, look, s["headline"].upper(), 180, CW - 2 * MARGIN, 3)
    y = CH - 130 - int(f.size * 0.98) * len(lines) - 100
    for ln in lines:
        d.text((MARGIN, y), ln, font=f, fill=ink)
        y += int(f.size * 0.98)
    footer(d, look, handle, i, n, ink)
    return im


def slide_convo(look, s, img, i, n, handle):
    """A text exchange that ILLUSTRATES the point. Always labeled as an illustration, never a real message."""
    im, d, bgc, ink, soft, accent = solid_s(look, i, s)
    fb = fe.load_font(look["captionFont"], 50, 600)
    y = 150
    for k, (who, txt) in enumerate(s["messages"][:5]):
        right = who.lower() in ("me", "her", "you", "engine")
        lines = wrap(d, txt, fb, 640)
        h = 40 + 66 * len(lines)
        w = max(d.textlength(l, font=fb) for l in lines) + 80
        x0 = CW - MARGIN - w if right else MARGIN
        d.rounded_rectangle((x0, y, x0 + w, y + h), radius=44, fill=accent[:3] + (255,) if right else mix(ink, bgc, 0.13))
        for j, ln in enumerate(lines):
            d.text((x0 + 40, y + 24 + j * 66), ln, font=fb, fill=(255, 255, 255, 255) if right and fe.luminance(look["highlight"]["bg"]) < 0.6 else ink)
        y += h + 36
    d.text((MARGIN, CH - 170), "illustration, not a real conversation", font=fe.load_font(look["captionFont"], 28, 600), fill=soft)
    footer(d, look, handle, i, n, ink)
    return im


# ---------- more formats (carousel-spec.md) ----------
def slide_compare(look, s, img, i, n, handle):
    """This vs that: two columns, up to four rows, a one-line verdict."""
    im, d, bgc, ink, soft, accent = solid_s(look, i, s)
    f, lines = fit_lines(d, look, s["headline"].upper(), 130, CW - 2 * MARGIN, 2)
    y = 120
    for ln in lines:
        d.text((MARGIN, y), ln, font=f, fill=ink[:3] + (255,))
        y += int(f.size * 0.98)
    y += 40
    colw = (CW - 2 * MARGIN - 30) // 2
    ft = fe.display_font(look, 60)
    fb = fe.load_font(look["captionFont"], 40, 700)
    d.rounded_rectangle((MARGIN, y, MARGIN + colw, y + 90), radius=18, fill=mix(ink, bgc, 0.15))
    d.rounded_rectangle((MARGIN + colw + 30, y, MARGIN + 2 * colw + 30, y + 90), radius=18, fill=accent[:3] + (255,))
    d.text((MARGIN + 28, y + 14), s.get("left_title", "OLD WAY").upper(), font=ft, fill=ink[:3] + (255,))
    d.text((MARGIN + colw + 58, y + 14), s.get("right_title", "MY WAY").upper(), font=ft, fill=bgc[:3] + (255,) if contrast(accent[:3], bgc[:3]) > 2 else ink[:3] + (255,))
    y += 120
    for a, b in s.get("rows", [])[:4]:
        la, lb = wrap(d, a, fb, colw - 40), wrap(d, b, fb, colw - 40)
        h = max(len(la), len(lb)) * 52 + 28
        d.rounded_rectangle((MARGIN, y, MARGIN + colw, y + h), radius=16, outline=mix(ink, bgc, 0.35), width=3)
        d.rounded_rectangle((MARGIN + colw + 30, y, MARGIN + 2 * colw + 30, y + h), radius=16, outline=accent[:3] + (255,), width=4)
        for k, t in enumerate(la):
            d.text((MARGIN + 22, y + 14 + k * 52), t, font=fb, fill=ink[:3] + (230,))
        for k, t in enumerate(lb):
            d.text((MARGIN + colw + 52, y + 14 + k * 52), t, font=fb, fill=ink[:3] + (255,))
        y += h + 18
    if s.get("verdict"):
        fv = fe.display_font(look, 64)
        for k, t in enumerate(wrap(d, s["verdict"].upper(), fv, CW - 2 * MARGIN)[:2]):
            d.text((MARGIN, y + 20 + k * 66), t, font=fv, fill=accent[:3] + (255,))
    footer(d, look, handle, i, n, ink)
    return im


def slide_glossary(look, s, img, i, n, handle):
    im, d, bgc, ink, soft, accent = solid_s(look, i, s)
    fl = fe.load_font(look["captionFont"], 36, 800)
    d.text((MARGIN, 150), s.get("label", "WORDS IN MY WORLD, IN NORMAL HUMAN").upper(), font=fl, fill=accent[:3] + (255,))
    f, lines = fit_lines(d, look, s["term"].upper(), 230, CW - 2 * MARGIN, 3)
    y = 250
    for ln in lines:
        d.text((MARGIN, y), ln, font=f, fill=ink[:3] + (255,))
        y += int(f.size * 0.98)
    d.line((MARGIN, y + 55, MARGIN + 220, y + 55), fill=accent[:3] + (255,), width=10)
    fb = fe.load_font(look["captionFont"], 52, 700)
    text_block(d, MARGIN, y + 110, s["definition"], fb, ink[:3] + (255,), CW - 2 * MARGIN)
    footer(d, look, handle, i, n, ink)
    return im


def slide_stopstart(look, s, img, i, n, handle):
    im, d, bgc, ink, soft, accent = solid_s(look, i, s)
    f, lines = fit_lines(d, look, s.get("headline", "STOP THIS. START THIS.").upper(), 120, CW - 2 * MARGIN, 2)
    y = 120
    for ln in lines:
        d.text((MARGIN, y), ln, font=f, fill=ink[:3] + (255,))
        y += int(f.size * 0.98)
    y += 50
    fb = fe.load_font(look["captionFont"], 46, 700)
    red = (214, 64, 52)
    for t in s.get("stop", [])[:3]:
        ls = wrap(d, t, fb, CW - 2 * MARGIN - 80)
        for k, l in enumerate(ls):
            d.text((MARGIN + 70, y + k * 58), l, font=fb, fill=mix(ink, bgc, 0.55))
            w = d.textlength(l, font=fb)
            d.line((MARGIN + 62, y + k * 58 + 30, MARGIN + 78 + w, y + k * 58 + 24), fill=red, width=7)
        d.text((MARGIN, y - 2), "X", font=fe.display_font(look, 56), fill=red)
        y += len(ls) * 58 + 26
    y += 24
    d.line((MARGIN, y, CW - MARGIN, y), fill=mix(ink, bgc, 0.3), width=4)
    y += 40
    for t in s.get("start", [])[:3]:
        ls = wrap(d, t, fb, CW - 2 * MARGIN - 80)
        d.rounded_rectangle((MARGIN, y + 2, MARGIN + 50, y + 52), radius=12, fill=accent[:3] + (255,))
        d.line((MARGIN + 11, y + 28, MARGIN + 22, y + 40, MARGIN + 40, y + 15), fill=bgc[:3], width=7, joint="curve")
        for k, l in enumerate(ls):
            d.text((MARGIN + 70, y + k * 58), l, font=fb, fill=ink[:3] + (255,))
        y += len(ls) * 58 + 26
    footer(d, look, handle, i, n, ink)
    return im


def slide_timeline(look, s, img, i, n, handle):
    im, d, bgc, ink, soft, accent = solid_s(look, i, s)
    f, lines = fit_lines(d, look, s.get("headline", "HOW IT WENT").upper(), 120, CW - 2 * MARGIN, 2)
    y = 120
    for ln in lines:
        d.text((MARGIN, y), ln, font=f, fill=ink[:3] + (255,))
        y += int(f.size * 0.98)
    y += 50
    ft = fe.display_font(look, 62)
    fb = fe.load_font(look["captionFont"], 44, 700)
    steps = s.get("steps", [])[:5]
    x0 = MARGIN + 20
    if steps:
        d.line((x0, y + 20, x0, y + 20 + (len(steps) - 1) * 150), fill=mix(ink, bgc, 0.3), width=6)
    for t, txt in steps:
        d.ellipse((x0 - 16, y + 4, x0 + 16, y + 36), fill=accent[:3] + (255,))
        d.text((x0 + 50, y - 6), str(t).upper(), font=ft, fill=accent[:3] + (255,))
        ls = wrap(d, txt, fb, CW - 2 * MARGIN - 70)
        for k, l in enumerate(ls[:2]):
            d.text((x0 + 50, y + 62 + k * 48), l, font=fb, fill=ink[:3] + (255,))
        y += 150 if len(ls) < 2 else 190
    footer(d, look, handle, i, n, ink)
    return im


def slide_framework(look, s, img, i, n, handle):
    """Her named method: the name on top, its parts listed, the current part lit."""
    im, d, bgc, ink, soft, accent = solid_s(look, i, s)
    fl = fe.load_font(look["captionFont"], 36, 800)
    d.text((MARGIN, 130), s["name"].upper(), font=fl, fill=accent[:3] + (255,))
    parts = s.get("parts", [])
    act = int(s.get("active", 0))
    y = 210
    ft = fe.display_font(look, 72)
    for k, ptxt in enumerate(parts[:6]):
        on = (k == act)
        d.text((MARGIN, y), f"{k + 1}", font=ft, fill=accent[:3] + (255,) if on else mix(ink, bgc, 0.35))
        d.text((MARGIN + 90, y), ptxt.upper(), font=ft, fill=ink[:3] + (255,) if on else mix(ink, bgc, 0.35))
        y += 90
    y += 30
    fb = fe.load_font(look["captionFont"], 48, 700)
    if s.get("body"):
        d.line((MARGIN, y, MARGIN + 160, y), fill=accent[:3] + (255,), width=8)
        text_block(d, MARGIN, y + 36, s["body"], fb, ink[:3] + (255,), CW - 2 * MARGIN)
    footer(d, look, handle, i, n, ink)
    return im


def pano_canvas(look, s, i):
    """One wide picture (two slides side by side) so a headline can run across the swipe."""
    bgc, ink, soft, accent = palette(look, i)
    im = Image.new("RGBA", (CW * 2, CH), bgc)
    d = ImageDraw.Draw(im)
    f, lines = fit_lines(d, look, s["text"].upper(), 420, CW * 2 - 2 * MARGIN, 2)
    y = (CH - len(lines) * int(f.size * 0.98)) // 2 - 130
    hi = (s.get("hi") or "").upper()
    for ln in lines:
        x = MARGIN
        for part in re.split(r"(\s+)", ln):
            w = d.textlength(part, font=f)
            d.text((x, y), part, font=f, fill=accent[:3] + (255,) if hi and part.strip(" ,.?!") == hi else ink[:3] + (255,))
            x += w
        y += int(f.size * 0.98)
    if s.get("sub"):
        fb = fe.load_font(look["captionFont"], 52, 700)
        d.text((CW + MARGIN, CH - 230), s["sub"], font=fb, fill=ink[:3] + (230,))
    return im


def slide_panoL(look, s, img, i, n, handle):
    im = pano_canvas(look, s, i).crop((0, 0, CW, CH))
    d = ImageDraw.Draw(im)
    footer(d, look, handle, i, n, palette(look, i)[1])
    return im


def slide_panoR(look, s, img, i, n, handle):
    im = pano_canvas(look, s, i - 1).crop((CW, 0, CW * 2, CH))
    d = ImageDraw.Draw(im)
    footer(d, look, handle, i, n, palette(look, i - 1)[1])
    return im


def slide_videoclip(look, s, img, i, n, handle):
    """A short moving slide. The picture here is the still; the loop is saved next to it as slide-NN.mp4."""
    base = img if img is not None else Image.new("RGB", (CW, CH), (30, 30, 30))
    sc = max(CW / base.width, CH / base.height)
    im = base.resize((int(base.width * sc), int(base.height * sc)), Image.LANCZOS)
    im = im.crop(((im.width - CW) // 2, (im.height - CH) // 2, (im.width - CW) // 2 + CW, (im.height - CH) // 2 + CH)).convert("RGBA")
    d = ImageDraw.Draw(im)
    if s.get("headline"):
        f, lines = fit_lines(d, look, s["headline"].upper(), 120, CW - 2 * MARGIN, 2)
        y = CH - 260 - len(lines) * int(f.size * 0.98)
        for ln in lines:
            d.text((MARGIN, y), ln, font=f, fill=(255, 255, 255, 255), stroke_width=6, stroke_fill=(20, 20, 22, 235))
            y += int(f.size * 0.98)
    footer(d, look, handle, i, n, (255, 255, 255))
    return im


# ---------- hand-drawn doodles and the signature motif ----------
def _wob(pts, amt, seed):
    import random
    r = random.Random(seed)
    return [(x + r.uniform(-amt, amt), y + r.uniform(-amt, amt)) for x, y in pts]


def doodle(d, kind, x, y, w, h, color, seed=3):
    import math
    lw = 9
    if kind == "circle":
        pts = [(x + w / 2 + (w / 2) * math.cos(t / 30 * 2 * math.pi * 1.08), y + h / 2 + (h / 2) * math.sin(t / 30 * 2 * math.pi * 1.08)) for t in range(0, 32)]
        d.line(_wob(pts, 3, seed), fill=color, width=lw, joint="curve")
    elif kind == "underline":
        pts = [(x + w * k / 14, y + (7 if k % 2 else -7)) for k in range(15)]
        d.line(_wob(pts, 2, seed), fill=color, width=lw, joint="curve")
    elif kind == "arrow":
        pts = _wob([(x, y), (x + w * 0.5, y + h * 0.3), (x + w, y + h)], 4, seed)
        d.line(pts, fill=color, width=lw, joint="curve")
        ex, ey = x + w, y + h
        d.line([(ex - 38, ey - 8), (ex, ey), (ex - 12, ey - 40)], fill=color, width=lw, joint="curve")
    elif kind == "star":
        pts = []
        for k in range(10):
            r = (w / 2) if k % 2 == 0 else (w / 5)
            a = -math.pi / 2 + k * math.pi / 5
            pts.append((x + w / 2 + r * math.cos(a), y + w / 2 + r * math.sin(a)))
        d.polygon(pts, fill=color)
    elif kind == "check":
        d.line(_wob([(x, y + h * 0.55), (x + w * 0.35, y + h), (x + w, y)], 2, seed), fill=color, width=lw + 2, joint="curve")


def apply_doodles(pic, s, look):
    ds = s.get("doodles") or []
    if not ds:
        return pic
    im = pic.convert("RGBA")
    d = ImageDraw.Draw(im)
    col = (222, 64, 52, 255)
    for dd in ds[:2]:
        c = col if dd.get("color", "red") == "red" else fe.hl_color(look)[:3] + (255,)
        doodle(d, dd["kind"], dd["x"], dd["y"], dd.get("w", 120), dd.get("h", 60), c, seed=dd.get("seed", 3))
    return im.convert("RGB")


def apply_motif(pic, spec, look, idx, total):
    m = spec.get("motif")
    last = idx == total - 1
    if not m or not (idx == 0 or last):
        return pic
    im = pic.convert("RGBA")
    acc = fe.hl_color(look)[:3]
    if m == "tape":
        t = Image.new("RGBA", (260, 70), (240, 228, 190, 200))
        t = t.rotate(-12, expand=True, resample=Image.BICUBIC)
        im.alpha_composite(t, (CW - 250, 20) if not last else (-10, 20))
    elif m == "star":
        ov = Image.new("RGBA", im.size, (0, 0, 0, 0))
        doodle(ImageDraw.Draw(ov), "star", CW - 190, 60, 110, 110, acc + (255,))
        im.alpha_composite(ov)
    elif m == "stamp":
        txt = spec.get("motif_text", "REAL")
        f = fe.display_font(look, 52)
        tw = int(ImageDraw.Draw(Image.new("RGBA", (5, 5))).textlength(txt, font=f)) + 60
        st = Image.new("RGBA", (tw, 100), (0, 0, 0, 0))
        sd = ImageDraw.Draw(st)
        sd.rounded_rectangle((0, 0, tw - 1, 99), radius=16, outline=acc + (255,), width=7)
        sd.text((30, 18), txt, font=f, fill=acc + (255,))
        im.alpha_composite(st.rotate(8, expand=True, resample=Image.BICUBIC), (CW - tw - 70, 50))
    if last and spec.get("signoff"):
        f = fe.load_font("Caveat", 78, 700)
        d = ImageDraw.Draw(im)
        d.text((MARGIN, CH - 210), spec["signoff"], font=f, fill=acc + (255,))
    return im.convert("RGB")


def apply_series(pic, spec, look, idx, total):
    """Series: a label slot on the cover (name and number) and a back/next pointer on the last slide, so a profile visitor can binge in order."""
    sr = spec.get("series")
    if not sr:
        return pic
    im = pic.convert("RGBA")
    d = ImageDraw.Draw(im)
    acc = fe.hl_color(look)[:3]
    f = fe.load_font(look["captionFont"], 34, 800)
    if idx == 0:
        t = f"{sr['name'].upper()}  ·  {int(sr.get('number', 1)):02d}"
        w = int(d.textlength(t, font=f)) + 50
        d.rounded_rectangle((MARGIN, 60, MARGIN + w, 120), radius=30, fill=acc)
        d.text((MARGIN + 25, 70), t, font=f, fill=(255, 255, 255) if fe.luminance("#%02x%02x%02x" % acc) < 0.55 else (25, 25, 25))
    if idx == total - 1:
        lines = []
        if sr.get("next"):
            lines.append(f"NEXT: PART {int(sr.get('number', 1)) + 1:02d}, {sr['next'].upper()}")
        if sr.get("number", 1) > 1:
            lines.append(f"MISSED IT? START AT PART {1:02d}")
        y = CH - 340
        for ln in lines[:2]:
            d.text((MARGIN, y), ln, font=f, fill=acc + (255,))
            y += 46
    return im.convert("RGB")


def template_path(out):
    root = os.path.abspath(out)
    while root != os.path.dirname(root) and os.path.basename(root) != "customer":
        root = os.path.dirname(root)
    return os.path.join(root, "profile", "templates.json") if os.path.basename(root) == "customer" else None


MAKERS = {"cover": slide_cover, "point": slide_point, "stat": slide_stat, "photo": slide_photo, "list": slide_list, "cta": slide_cta,
          "bigtext": slide_bigtext, "quote": slide_quote, "receipt": slide_receipt, "transform": slide_transform, "recap": slide_recap,
          "myth": slide_myth, "faq": slide_faq, "pov": slide_pov, "quiz": slide_quiz, "negcover": slide_negcover, "sticker": slide_sticker,
          "convo": slide_convo, "compare": slide_compare, "glossary": slide_glossary, "stopstart": slide_stopstart, "timeline": slide_timeline,
          "framework": slide_framework, "panoL": slide_panoL, "panoR": slide_panoR, "videoclip": slide_videoclip}
NEEDS_PHOTO = ("cover", "photo", "cta", "receipt", "sticker", "videoclip")


BLOCKS = {}   # slide index -> the movable pieces of that slide (for the move editor)


def slide_tpl(look, s, img, i, n, handle):
    """One of the six original templates (see carousel_templates.py)."""
    import carousel_templates as ct
    pic = ct.render(sys.modules[__name__], look, s, img, i, n, handle)
    BLOCKS[i] = list(ct.LAST_BLOCKS)
    return pic


MAKERS["tpl"] = slide_tpl


def needs_photo(s):
    """Slide types that show a still from her video. Photo-led template slides (4, 6, and any cover) do too."""
    if s["type"] == "tpl":
        return s.get("template") in (4, 6) or s.get("kind") == "cover" or s.get("from_video") is True
    return s["type"] in NEEDS_PHOTO



TEXT_KEYS = ("text", "term", "definition", "name", "verdict", "left_title", "right_title", "label", "headline", "sub", "body", "line", "quote", "who", "question", "answer", "myth", "fact", "before", "after", "feel",
             "word", "number", "keyword", "card_title", "lead", "top", "bottom", "note")


def slide_text(sl):
    parts = [str(sl[k]) for k in TEXT_KEYS if sl.get(k)]
    for k in ("items", "lines", "options", "parts", "stop", "start"):
        v = sl.get(k, [])
        if isinstance(v, list):
            parts += [str(x) for x in v]
    for m in sl.get("messages", []):
        parts.append(str(m[1]))
    for r in sl.get("steps", []):
        parts += [str(r[0]), str(r[1])]
    for r in sl.get("rows", []):
        parts += [str(r[0]), str(r[1])]
    return " ".join(parts)


def grain(img, amount=7):
    import numpy as np
    arr = np.array(img.convert("RGB")).astype("int16")
    rng = np.random.default_rng(11)
    noise = rng.normal(0, amount, arr.shape[:2] + (1,))
    return Image.fromarray(np.clip(arr + noise, 0, 255).astype("uint8"))


def run_checks(spec, slides, look):
    """Quality checks before she sees the slides. Returns a list of plain-language notes (empty means all clear)."""
    notes = []
    n = len(slides)
    if n < 5:
        notes.append(f"Only {n} slides. Five is the least that feels like a carousel. Add real material (never pad).")
    if n > 20:
        notes.append(f"{n} slides. Instagram carousels stop at 20.")
    elif n > 12:
        notes.append(f"{n} slides is long. Over 12 only works for a story or tutorial where every slide earns its place.")
    if n >= 2 and slides[1]["type"] == "point" and slides[1].get("n") in ("01", "1"):
        notes.append("Slide 2 is step one. Instagram often shows a carousel again starting on slide 2, so slide 2 must work as a second hook that stands on its own, not a first step.")
    loud = [k + 1 for k, sl in enumerate(slides) if sl["type"] in ("stat", "negcover") and k > 0]
    if len(loud) > 1:
        notes.append(f"Slides {', '.join(map(str, loud))} are all loud (big number or giant word). Keep one loud slide, so it stands out against the calm ones.")
    for k, sl in enumerate(slides, 1):
        if len(sl.get("doodles") or []) > 2:
            notes.append(f"Slide {k} has more than two doodles. Keep two at most, each pointing at something real.")
    if sum(1 for sl in slides if sl["type"] == "videoclip") > 1:
        notes.append("More than one video slide. One per carousel keeps it a surprise.")
    # payoff check: does the deck deliver what the cover promised?
    import re as _re
    cover_txt = slide_text(slides[0])
    stop = set("the a an and or to of in on for with your you my is it that this what why how one just not no from at as be are was were i me we our their they them".split())
    ck = [w for w in _re.findall(r"[a-z']{4,}", cover_txt.lower()) if w not in stop]
    rest_txt = " ".join(slide_text(sl).lower() for sl in slides[1:])
    if ck and not spec.get("series"):
        missing = [w for w in dict.fromkeys(ck) if w not in rest_txt]
        if len(missing) >= max(1, (len(set(ck)) + 1) // 2):
            notes.append("Payoff: the cover promises " + ", ".join(f"\"{w}\"" for w in list(dict.fromkeys(ck))[:4]) + ", but the rest of the deck never says " + ", ".join(f"\"{w}\"" for w in missing[:3]) + ". Make sure the deck pays off what the cover promised.")
    mnum = _re.search(r"\b(\d+)\s+([a-z]+)", cover_txt.lower())
    if mnum and int(mnum.group(1)) <= 20 and mnum.group(2) not in ("years", "year", "minutes", "minute", "hours", "hour", "days", "day", "weeks", "week", "months", "month"):
        want = int(mnum.group(1))
        body = [sl for sl in slides[1:-1] if sl["type"] in ("point", "myth", "quote", "bigtext", "transform", "faq", "quiz", "glossary", "timeline", "pov")]
        listed = sum(len(sl.get("items", [])) for sl in slides if sl["type"] in ("list", "recap"))
        if want not in (len(body), listed, len(body) - 1, len(body) + 1):
            notes.append(f"Payoff: the cover says {want} {mnum.group(2)}, but I count {len(body)} body slides and {listed} checklist lines. A number on the cover must match what is inside.")
    if not any(sl["type"] in ("recap", "list", "compare", "framework", "stopstart") or (sl["type"] == "tpl" and sl.get("kind") in ("list", "split2", "split")) for sl in slides[-5:]):
        notes.append("Payoff: there is no save slide near the end, so nothing finishes what the cover started. Put the checklist or summary in the last few slides.")
    cw_ = len(slides[0].get("headline", slides[0].get("word", "")).split())
    if cw_ > 10:
        notes.append(f"The cover headline is {cw_} words. Six to ten reads at a glance.")
    et = lambda sl: ((sl.get("kind") or "point") if sl["type"] == "tpl" else sl["type"])   # a look's slide is judged by its kind (cover, list, stat, cta...)
    for k, sl in enumerate(slides, 1):
        words = len(slide_text(sl).split())
        if words > 40:
            notes.append(f"Slide {k} has {words} words. Keep body slides to 40 or fewer, one idea per slide. If it needs more, split it or move the words to the caption.")
        if k > 1 and et(sl) == et(slides[k - 2]):
            notes.append(f"Slides {k - 1} and {k} use the same layout ({et(sl)}). Change one so the swipe feels fresh.")
        if et(sl) not in ("cta", "recap", "receipt") and not sl.get("source"):
            notes.append(f"Slide {k} has no source line. Say where in her video or profile these words come from.")
        if et(sl) != "cta" and sl.get("keyword"):
            notes.append(f"Slide {k} has a comment word, but only the last slide may carry the hard ask.")
        if sl["type"] == "receipt" and not (sl.get("image") or sl.get("rows")):
            notes.append(f"Slide {k} is a proof slide with no real screenshot or numbers. Add her real evidence.")
    if et(slides[0]) not in ("cover", "sticker", "negcover", "panoL"):
        notes.append("The first slide should be a cover.")
    try:
        import pick_look as _pk
        notes.extend(_pk.variety_notes(slides, exclude=spec.get("_out")))
    except Exception:
        pass
    if slides[0]["type"] not in ("negcover", "panoL") and not (slides[0]["type"] == "tpl" and slides[0].get("template") in (1, 2, 3, 5)) and not (spec.get("video") or any(sl.get("photo") for sl in slides[:1])):
        notes.append("The cover has no photo of her. Add her video or a photo so her face is on slide one.")
    if et(slides[-1]) != "cta":
        notes.append("The last slide should be the comment-word ask.")
    elif spec.get("reel_cta") and slides[-1].get("keyword", "").upper() != spec["reel_cta"].upper():
        notes.append(f"The last slide says {slides[-1].get('keyword')} but the reel's ask is {spec['reel_cta']}. They must match.")
    if not any((sl["type"] in ("receipt", "transform", "stat")) or (sl["type"] == "tpl" and et(sl) in ("stat", "proof", "split2", "comment", "grid")) for sl in slides):
        notes.append("No proof slide yet (proof, before and after, or a big number).")
    if not any((sl["type"] in ("list", "recap")) or (sl["type"] == "tpl" and et(sl) == "list") for sl in slides):
        notes.append("No save-bait slide yet (a checklist or recap worth screenshotting).")
    # contrast on solid slides
    for k, sl in enumerate(slides):
        if sl["type"] in ("bigtext", "quote", "transform", "recap", "list", "myth", "faq", "pov", "quiz", "negcover", "convo", "point", "stat"):
            bgc, ink, soft, accent = palette(look, k)
            if contrast(ink[:3], bgc[:3]) < 4.5:
                notes.append(f"Slide {k + 1}: the text color does not read well on its background. Pick another look color.")
            if contrast(accent[:3], bgc[:3]) < 3.0:
                notes.append(f"Slide {k + 1}: the highlight color is too close to the background.")
    return notes


def template_sheet(look_id, handle, motif, out_dir):
    """One page showing her five locked templates with sample words, so she approves them once."""
    samples = [
        {"type": "negcover", "word": "COVER", "source": "sample"},
        {"type": "bigtext", "headline": "A body slide", "hi": "body", "lines": ["One idea per slide."], "source": "sample"},
        {"type": "recap", "items": ["A saveable checklist", "Short lines", "Easy to keep"], "source": "sample"},
        {"type": "quote", "quote": "A statement worth pausing on.", "who": "", "source": "sample"},
        {"type": "cta", "keyword": "WORD", "line": "and I will send it to you", "source": "sample"}]
    spec = {"title": "template-sample", "look": look_id, "handle": handle, "motif": motif, "slides": samples}
    os.makedirs(out_dir, exist_ok=True)
    sp = os.path.join(out_dir, "template-sample.json")
    json.dump(spec, open(sp, "w", encoding="utf-8"))
    subprocess.run([sys.executable, "-X", "utf8", "-I", os.path.abspath(__file__), sp, os.path.join(out_dir, "template-sample")], check=True, capture_output=True)
    return os.path.join(out_dir, "template-sample", "phone-preview.png")


def main():
    if len(sys.argv) > 1 and sys.argv[1] in ("--template-sheet", "--approve-templates"):
        a = sys.argv[2:]
        def opt(k, d=None):
            return a[a.index(k) + 1] if k in a else d
        look_id, handle, motif = opt("--look", "1"), opt("--handle", ""), opt("--motif")
        root = os.path.abspath(opt("--root", os.path.join(HERE, "..", "..")))
        if sys.argv[1] == "--template-sheet":
            pv = template_sheet(look_id, handle, motif, os.path.join(root, "customer", "profile", "template-preview"))
            print("Template sheet:", pv)
        else:
            import datetime
            data = {"approved": True, "look": look_id, "handle": handle, "motif": motif, "motif_text": opt("--motif-text"), "signoff": opt("--signoff"), "approved_on": str(datetime.date.today())}
            data = {k: v for k, v in data.items() if v is not None}
            os.makedirs(os.path.join(root, "customer", "profile"), exist_ok=True)
            json.dump(data, open(os.path.join(root, "customer", "profile", "templates.json"), "w", encoding="utf-8"), indent=1)
            print("Templates approved and locked:", data)
        return
    spec_path = sys.argv[1]
    spec = json.load(open(spec_path, encoding="utf-8"))
    out = sys.argv[2] if len(sys.argv) > 2 and not sys.argv[2].startswith("--") else os.path.join(os.path.dirname(os.path.abspath(spec_path)), spec.get("title", "carousel"))
    os.makedirs(out, exist_ok=True)
    work = os.path.join(out, ".work")
    os.makedirs(work, exist_ok=True)
    tp = template_path(out)
    tmpl = json.load(open(tp, encoding="utf-8")) if tp and os.path.exists(tp) else None
    if tmpl and tmpl.get("approved"):
        for k in ("look", "handle", "motif", "motif_text", "signoff", "grain"):
            if k in tmpl and k not in spec:
                spec[k] = tmpl[k]
    look = fe.load_look(spec.get("look", "1"))
    slides = []
    for sl in spec["slides"]:
        if sl["type"] == "pano":
            slides += [dict(sl, type="panoL"), dict(sl, type="panoR", source=sl.get("source", ""))]
        else:
            slides.append(sl)
    spec["slides"] = slides
    spec["_out"] = out
    # --- the engine, not the checklist, makes sure of these two things (for a carousel in one of the looks) ---
    tpl_ = [s for s in slides if s.get("type") == "tpl"]
    if tpl_ and any(not s.get("template") for s in tpl_):
        # 1. a look is always chosen: if nobody picked one, the engine picks the best fit (her pinned look first)
        import pick_look as _pk0
        _p = _pk0.choose(" ".join(slide_text(s) for s in slides), "", "", "", photos=bool(spec.get("video") or any(s.get("photo") for s in slides)))
        for s in tpl_:
            if not s.get("template"):
                s["template"] = _p["template"]
        spec.setdefault("look_auto", True)
        spec.setdefault("look_reason", _p["reason"])
        try:   # remember the choice in slides.json, so a redraw never picks a different look
            _raw = json.load(open(spec_path, encoding="utf-8"))
            for _s in _raw.get("slides", []):
                if _s.get("type") == "tpl" and not _s.get("template"):
                    _s["template"] = _p["template"]
            _raw.setdefault("look_auto", True)
            _raw.setdefault("look_reason", _p["reason"])
            json.dump(_raw, open(spec_path, "w", encoding="utf-8"), indent=1)
        except Exception:
            pass
        print(f"LOOK: no look was chosen, so the engine picked {_p['name']} ({_p['reason']}).")
    # 1b. her own brand photos (My brand tab) are used when a carousel has no video and no photos of its own. Never anything invented.
    if tpl_ and not spec.get("video") and not spec.get("photos_from_brand") and not spec.get("no_auto_photos"):
        try:
            _bj = os.path.join(os.path.dirname(os.path.dirname(HERE)), "customer", "profile", "brand.json")
            _bd = os.path.join(os.path.dirname(os.path.dirname(HERE)), "customer", "profile", "brand", "photos")
            _names = (json.load(open(_bj, encoding="utf-8")).get("photos") or []) if os.path.exists(_bj) else []
            _ph = [os.path.join(_bd, x) for x in _names if os.path.exists(os.path.join(_bd, x))]
        except Exception:
            _ph = []
        if _ph and not any(s.get("photo") or s.get("photos") for s in tpl_):
            _k = [0]

            def _nxt(c=1):
                r = [_ph[(_k[0] + j) % len(_ph)] for j in range(c)]
                _k[0] += c
                return r
            _pt = 0
            for s in tpl_:
                tv, kd = s.get("template"), s.get("kind", "point")
                custom_ = str(tv).startswith("custom:")
                if kd == "cover":
                    c = {1: 1, 2: 2, 4: 2, 5: 3}.get(tv, 1)
                    ps = _nxt(c)
                    s["photo"] = ps[0]
                    if c > 1:
                        s["photos"] = ps
                elif kd == "photo":
                    s["photo"] = _nxt()[0]
                elif tv in (4, 6, 8) and kd in ("point", "list", "quote", "stat", "cta", "split", "split2", "bigword", "proof"):
                    s["photo"] = _nxt()[0]
                elif kd == "point" and (tv in (1, 2, 3, 5, 7) or custom_):
                    _pt += 1
                    if _pt % 2 == 1:   # every other point slide gets a picture, so a carousel is never all pictures or all words
                        s["photo"] = _nxt()[0]
            spec["photos_from_brand"] = True
            try:   # keep the choice in slides.json so a redraw never changes the pictures
                _raw = json.load(open(spec_path, encoding="utf-8"))
                for _s, _s2 in zip([x for x in _raw.get("slides", []) if x.get("type") == "tpl"], tpl_):
                    for _key in ("photo", "photos"):
                        if _key in _s2 and _key not in _s:
                            _s[_key] = _s2[_key]
                _raw["photos_from_brand"] = True
                json.dump(_raw, open(spec_path, "w", encoding="utf-8"), indent=1)
            except Exception:
                pass
            print(f"PHOTOS: used {len(set(x for s in tpl_ for x in ([s.get('photo')] if s.get('photo') else []) + list(s.get('photos') or [])))} of your My brand photos.")
    if tpl_ and not os.path.exists(os.path.join(out, "slide-01.png")) and not spec.get("allow_similar"):
        # 2. a NEW carousel may not be almost the same as one of her recent ones (redrawing an existing one is always fine)
        import pick_look as _pk1
        _bad = [x for x in _pk1.variety_notes(slides, exclude=out) if "almost the same" in x]
        if _bad:
            print("REFUSED: " + _bad[0] + " Change the order or the kinds of the middle slides and run it again (or set allow_similar to true if she wants it that way).")
            sys.exit(3)
    n = len(slides)
    video = spec.get("video")
    dur = 60.0
    if video and os.path.exists(video):
        try:
            dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", video], capture_output=True, text=True, encoding="utf-8", errors="replace").stdout.strip())
        except Exception:
            pass
    auto_t = [dur * x for x in (0.12, 0.30, 0.5, 0.68, 0.84)]
    if video and os.path.exists(video):
        # candidate photos for the review page: her six best stills, as small pictures she can click
        sd = os.path.join(out, "stills")
        os.makedirs(sd, exist_ok=True)
        cands = pick_stills(video, dur, work)
        for ct in cands:
            tp = os.path.join(sd, f"still-{ct}.jpg")
            if not os.path.exists(tp):
                im = frame_at(video, ct, work)
                im.resize((180, int(im.height * 180 / im.width))).save(tp, quality=85)
        json.dump(cands, open(os.path.join(out, "stills.json"), "w", encoding="utf-8"))
    made, alts, sources = [], [], {}
    use_grain = spec.get("grain", True)
    for i, s in enumerate(slides):
        img = None
        if video and os.path.exists(video) and needs_photo(s) and not (s.get("photo") and os.path.exists(s["photo"])):
            t = s.get("frame", auto_t[i % len(auto_t)])
            if isinstance(t, str) and t.startswith("auto"):
                best = pick_stills(video, dur, work)
                t = best[min(len(best) - 1, int(t[4:] or 1) - 1)] if best else auto_t[i % len(auto_t)]
            img = frame_at(video, t, work)
        elif s.get("photo") and os.path.exists(s["photo"]):
            img = Image.open(s["photo"]).convert("RGB")
        elif needs_photo(s) and not (s["type"] == "tpl" and (s.get("template") in (1, 2, 3, 5, 7) or str(s.get("template")).startswith("custom:"))):   # those looks simply have no picture when she has none, never a blank one
            c = fe.hex2rgb(look["caption"]["bg"])[:3]
            img = Image.new("RGB", (CW, CH), c)
        if video and os.path.exists(video) and s.get("bg_frame") not in (None, "", "none") and not needs_photo(s):
            tb = s["bg_frame"]
            if isinstance(tb, str) and tb.startswith("auto"):
                best = pick_stills(video, dur, work)
                tb = best[min(len(best) - 1, int(tb[4:] or 1) - 1)] if best else auto_t[i % len(auto_t)]
            bgp = os.path.join(out, f"bg-{i + 1:02d}.jpg")
            frame_at(video, float(tb), work).convert("RGB").save(bgp, quality=90)
            s["bgphoto"] = bgp
            s.setdefault("overlay", 0.55)
        pic = MAKERS[s["type"]](look, s, img, i, n, spec.get("handle")).convert("RGB")
        if s["type"] in ("recap", "list") and spec.get("save_label", True) and i == max(k for k, x in enumerate(slides) if x["type"] in ("recap", "list")):
            _d = ImageDraw.Draw(pic)
            _f = fe.load_font(look["captionFont"], 34, 700)
            _t = "SAVE THIS ONE"
            _w = int(_d.textlength(_t, font=_f)) + 50
            _acc = fe.hl_color(look)[:3]
            _d.rounded_rectangle((CW - MARGIN - _w, CH - 190, CW - MARGIN, CH - 130), radius=30, fill=(25, 25, 25))
            _d.text((CW - MARGIN - _w + 25, CH - 181), _t, font=_f, fill=(255, 255, 255))
        pic = apply_series(pic, spec, look, i, n)
        pic = apply_doodles(pic, s, look)
        pic = apply_motif(pic, spec, look, i, n)
        if use_grain:
            pic = grain(pic, 3 if s["type"] in NEEDS_PHOTO else 7)
        path = os.path.join(out, f"slide-{i + 1:02d}.png")
        pic.save(path)
        made.append(path)
        if i in BLOCKS:   # where each movable piece sits, so the move editor can show them
            if s["type"] == "tpl":
                import carousel_templates as _ct
                try:
                    pbs = _ct.render_pieces(sys.modules[__name__], look, s, img, i, n, spec.get("handle"), path[:-4])
                    for bl in BLOCKS[i]:
                        if bl["id"] in pbs:
                            bl["pb"] = pbs[bl["id"]]
                except Exception as e:
                    print("pieces skipped:", e)
            json.dump(BLOCKS[i], open(path[:-4] + ".blocks.json", "w"))
        if s["type"] == "videoclip" and video and os.path.exists(video):
            t0 = float(s.get("start", 2.0))
            vf = f"scale={CW}:{CH}:force_original_aspect_ratio=increase,crop={CW}:{CH}"
            subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", f"{t0:.2f}", "-i", video, "-t", str(min(5.0, float(s.get("seconds", 4)))), "-vf", vf, "-r", "30", "-an",
                            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "20", path[:-4] + ".mp4"], check=False)
        txt = slide_text(s)
        alts.append(f"Slide {i + 1} of {n}: {txt}" if txt else f"Slide {i + 1} of {n}.")
        sources[i + 1] = {"type": s["type"], "text": txt, "source": s.get("source", "")}
        print("made", os.path.basename(path), s["type"])
    if spec.get("peek"):
        # the next slide's edge bleeds in from the right, so the eye wants to swipe (slide 1 into slide 2 by default)
        for k in spec.get("peek_pairs", [1]):
            if 1 <= k < len(made):
                cur, nxt = Image.open(made[k - 1]).convert("RGB"), Image.open(made[k]).convert("RGB")
                strip = nxt.crop((0, 0, 56, CH))
                cur.paste(strip, (CW - 56, 0))
                ImageDraw.Draw(cur).line((CW - 56, 0, CW - 56, CH), fill=(0, 0, 0), width=2)
                cur.save(made[k - 1])
    open(os.path.join(out, "alt-text.txt"), "w", encoding="utf-8").write("\n".join(alts) + "\n")
    json.dump(sources, open(os.path.join(out, "source-map.json"), "w", encoding="utf-8"), indent=1)
    if spec.get("caption"):
        open(os.path.join(out, "caption.txt"), "w", encoding="utf-8").write(spec["caption"].strip() + "\n")
    # phone-size preview: every slide at 390 px wide, side by side, so she sees what a phone sees
    pv = os.path.join(out, "phone-preview")
    os.makedirs(pv, exist_ok=True)
    thumbs = []
    for k, p in enumerate(made, 1):
        im = Image.open(p).resize((390, int(CH * 390 / CW)), Image.LANCZOS)
        im.save(os.path.join(pv, f"phone-{k:02d}.png"))
        thumbs.append(im)
    cols = 5
    rows = (len(thumbs) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * 410 + 20, rows * (thumbs[0].height + 20) + 20), (28, 28, 28))
    for k, im in enumerate(thumbs):
        sheet.paste(im, (20 + (k % cols) * 410, 20 + (k // cols) * (im.height + 20)))
    sheet.save(os.path.join(out, "phone-preview.png"))
    # second lives: a square repost card, a Pinterest pin and a LinkedIn document, all from the same approved slides
    try:
        save_k = max([k for k, x in enumerate(slides) if x["type"] in ("recap", "list")] or [len(made) - 1])
        rk = int(spec.get("repost_slide", save_k + 1)) - 1
        Image.open(made[rk]).crop((0, 135, CW, 135 + CW)).save(os.path.join(out, "repost-card-square.png"))
        pin = Image.new("RGB", (1000, 1500), (255, 255, 255))
        sv = Image.open(made[save_k]).resize((1000, 1250), Image.LANCZOS)
        pin.paste(sv, (0, 125))
        pin.save(os.path.join(out, "pinterest-pin.png"))
        ims = [Image.open(p).convert("RGB") for p in made]
        ims[0].save(os.path.join(out, "linkedin-document.pdf"), save_all=True, append_images=ims[1:], resolution=100.0)
    except Exception as e:
        print("NOTE: could not make the extra versions:", e)
    pace = {"cover": "FACE", "sticker": "FACE", "photo": "FACE", "negcover": "TYPE", "stat": "LOUD", "recap": "CHECKLIST", "list": "CHECKLIST", "cta": "CTA", "receipt": "PROOF", "transform": "PROOF"}
    pacing = " . ".join(pace.get(x["type"], "TYPE") for x in slides)
    # the grid check: how the new cover sits next to her other covers
    grid_note = ""
    try:
        import glob
        root = os.path.abspath(out)
        while root != os.path.dirname(root) and os.path.basename(root) != "customer":
            root = os.path.dirname(root)
        others = sorted([f for f in glob.glob(os.path.join(root, "content", "**", "slide-01.png"), recursive=True) if os.path.abspath(os.path.dirname(f)) != os.path.abspath(out)], key=os.path.getmtime, reverse=True)[:8]
        covers = [made[0]] + others
        def ctr(pth):
            im = Image.open(pth).convert("RGB")
            w, h = im.size
            return im.crop((0, (h - w) // 2, w, (h - w) // 2 + w)).resize((300, 300))
        if len(covers) > 1:
            g = Image.new("RGB", (3 * 306 + 6, ((len(covers) + 2) // 3) * 306 + 6), (28, 28, 28))
            for k, pth in enumerate(covers):
                g.paste(ctr(pth), (6 + (k % 3) * 306, 6 + (k // 3) * 306))
            g.save(os.path.join(out, "grid-preview.png"))
            def mean(pth):
                import numpy as np
                return tuple(np.array(ctr(pth).resize((20, 20))).reshape(-1, 3).mean(0))
            m0 = mean(covers[0])
            near = [pth for pth in covers[1:3] if sum((a - b) ** 2 for a, b in zip(m0, mean(pth))) ** 0.5 < 45]
            if len(near) == 2:
                grid_note = "The new cover looks like your last two covers on the grid (same dominant color). Change the cover color or layout so the profile stays varied."
    except Exception:
        pass
    notes = run_checks(spec, slides, look)
    if tmpl and tmpl.get("approved"):
        if str(spec.get("look")) != str(tmpl.get("look")):
            notes.append(f"Template drift: this carousel uses look {spec.get('look')} but your approved templates use {tmpl.get('look')}. Keep it the same so your profile is recognizable, or re-approve the templates.")
        if tmpl.get("motif") and spec.get("motif") != tmpl.get("motif"):
            notes.append("Template drift: your approved signature mark is missing or different on this carousel.")
    if spec.get("series") and grid_note:
        grid_note = ""
        notes = [x for x in notes if "last two covers" not in x]
    if grid_note:
        notes.append(grid_note)
    open(os.path.join(out, "pacing.txt"), "w", encoding="utf-8").write(pacing + "\n")
    print("PACING:", pacing)
    open(os.path.join(out, "checks.txt"), "w", encoding="utf-8").write("\n".join(notes) + ("\n" if notes else "All checks passed.\n"))
    for ln in notes:
        print("CHECK:", ln)
    if spec.get("post"):
        try:
            subprocess.run([sys.executable, os.path.join(HERE, "plan.py"), "file", str(spec["post"]), out], capture_output=True, timeout=60)
            print(f"Filed in your calendar for post {spec['post']}.")
        except Exception:
            pass
    print("Done:", out)


if __name__ == "__main__":
    main()
