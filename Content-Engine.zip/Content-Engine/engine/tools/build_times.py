"""How long a build usually takes, learned from her own past builds (kept in <edited folder>/.build-times.json)."""
import json, os, statistics

DEFAULT_RATIO = 1.4   # build seconds per second of source video until we have real numbers


def _path(folder):
    return os.path.join(folder, ".build-times.json")


def record(folder, src_seconds, build_seconds):
    try:
        data = json.load(open(_path(folder), encoding="utf-8"))
    except Exception:
        data = []
    if src_seconds and build_seconds and build_seconds < 3600:
        data.append({"src": round(src_seconds, 1), "build": round(build_seconds, 1)})
        json.dump(data[-40:], open(_path(folder), "w", encoding="utf-8"))


def estimate_seconds(folder, src_seconds):
    try:
        data = json.load(open(_path(folder), encoding="utf-8"))
        ratios = [d["build"] / d["src"] for d in data if d.get("src", 0) > 3]
        ratio = statistics.median(ratios) if len(ratios) >= 2 else DEFAULT_RATIO
    except Exception:
        ratio = DEFAULT_RATIO
    return max(20.0, ratio * src_seconds + 15)


def text(folder, src_seconds):
    s = estimate_seconds(folder, src_seconds)
    if s < 90:
        return "A build usually takes about a minute."
    m = round(s / 60 * 2) / 2
    return "A build usually takes about %s minutes." % (("%g" % m))
