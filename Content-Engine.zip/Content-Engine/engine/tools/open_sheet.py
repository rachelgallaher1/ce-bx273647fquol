#!/usr/bin/env python3
"""Open her edit sheet. With no name, opens the sheet for her newest edited video.
  python open_sheet.py [NAME]
"""
import glob, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from sheet_launcher import launch

ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
folder = os.path.join(ROOT, "customer", "videos", "edited")
name = sys.argv[1] if len(sys.argv) > 1 else None
if not name:
    plans = sorted(glob.glob(os.path.join(folder, "*_edit*.plan.json")), key=os.path.getmtime)
    if not plans:
        sys.exit("No edited videos yet.")
    name = re.sub(r"_edit\d+\.plan\.json$", "", os.path.basename(plans[-1]))
url = launch(folder, name)
print("Your edit sheet for", name, "is open at", url)
