"""Open the edit sheet for a video so she never has to hunt for it.
  from sheet_launcher import launch;  launch("customer/videos/edited", "my-video")
  python sheet_launcher.py FOLDER NAME     (or: python open_sheet.py [NAME])
If a sheet for that video is already running, it just opens it. Otherwise it starts one on a free port in the background and opens it
in her browser. Each video gets its own sheet. A sheet quits by itself after 6 hours with nobody using it.
"""
import json, os, socket, subprocess, sys, time, urllib.request, webbrowser

HERE = os.path.dirname(os.path.abspath(__file__))


def alive(port):
    try:
        urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=1).read(10)
        return True
    except Exception:
        return False


def free_port():
    for p in range(8765, 8800):
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", p)) != 0:
                return p
    return None


def launch(folder, name, open_browser=True):
    folder = os.path.abspath(folder)
    reg = os.path.join(folder, ".edit-sheets.json")
    try:
        data = json.load(open(reg, encoding="utf-8"))
    except Exception:
        data = {}
    port = data.get(name)
    if not (port and alive(port)):
        port = free_port()
        if port is None:
            return None
        subprocess.Popen([sys.executable, "-X", "utf8", "-I", os.path.join(HERE, "edit_sheet.py"), folder, name, "--port", str(port), "--no-open"],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, start_new_session=True)
        for _ in range(40):
            if alive(port):
                break
            time.sleep(0.25)
        data[name] = port
        try:
            json.dump(data, open(reg, "w", encoding="utf-8"))
        except Exception:
            pass
    url = f"http://127.0.0.1:{port}/"
    if open_browser:
        webbrowser.open(url)
    return url


if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    print(launch(sys.argv[1], sys.argv[2]))
