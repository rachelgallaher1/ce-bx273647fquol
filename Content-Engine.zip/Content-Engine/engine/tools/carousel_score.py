#!/usr/bin/env python3
"""Compare a new carousel with her own history, in plain words, and keep that history.
  python3 carousel_score.py log slides.json --saves 12 --shares 4 --comments 7     after she says "I posted it"
  python3 carousel_score.py score slides.json                                       before she posts: how does it compare to her winners?
History lives in customer/insights/carousel-log.json. With fewer than three logged carousels there is nothing fair to compare, and it says so.
Instagram gives no per-slide drop-off, so the score uses saves, shares and comments only.
"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
LOG = os.path.join(ROOT, "customer", "insights", "carousel-log.json")
SAVE_TYPES = ("recap", "list", "compare", "stopstart", "framework")


def features(spec):
    sl = spec["slides"]
    n = sum(2 if s["type"] == "pano" else 1 for s in sl)
    save = next((s["type"] for s in sl if s["type"] in SAVE_TYPES), "none")
    cover = sl[0].get("headline") or sl[0].get("word") or sl[0].get("text") or ""
    words = max((len(" ".join(str(v) for v in s.values() if isinstance(v, str)).split()) for s in sl), default=0)
    return {"slides": n, "save_slide": save, "cover_words": len(cover.split()), "max_words": words, "format": spec.get("format", ""), "angle": spec.get("angle", ""),
            "cta": (sl[-1].get("keyword") or sl[-1]["type"])}


def arg(a, k, default=0):
    return int(a[a.index(k) + 1]) if k in a else default


def main():
    a = sys.argv[1:]
    if len(a) < 2 or a[0] not in ("log", "score"):
        sys.exit(__doc__)
    spec = json.load(open(a[1], encoding="utf-8"))
    f = features(spec)
    hist = json.load(open(LOG, encoding="utf-8")) if os.path.exists(LOG) else []
    if a[0] == "log":
        f.update(title=spec.get("title", ""), saves=arg(a, "--saves"), shares=arg(a, "--shares"), comments=arg(a, "--comments"))
        hist.append(f)
        os.makedirs(os.path.dirname(LOG), exist_ok=True)
        json.dump(hist, open(LOG, "w", encoding="utf-8"), indent=1)
        print("Logged. That is", len(hist), "carousel(s) in your history.")
        return
    if len(hist) < 3:
        print("I only have", len(hist), "of your carousels logged, so I can't fairly compare yet. After a few more, I'll tell you how a new one stacks up against your best.")
        return
    top = sorted(hist, key=lambda h: -(h.get("saves", 0) * 2 + h.get("shares", 0) * 3 + h.get("comments", 0)))[:3]
    notes = []
    avg_sl = sum(h["slides"] for h in top) / len(top)
    notes.append(f"Your best carousels average {avg_sl:.0f} slides. This one has {f['slides']}." + (" Close." if abs(f["slides"] - avg_sl) <= 2 else " That is a real difference."))
    saves = [h["save_slide"] for h in top]
    if f["save_slide"] == "none":
        notes.append("This one has no save slide, and your top ones used: " + ", ".join(sorted(set(saves))) + ". Add one.")
    elif f["save_slide"] in saves:
        notes.append(f"It has a {f['save_slide']} save slide, like your top ones.")
    cw = sum(h["cover_words"] for h in top) / len(top)
    notes.append(f"Your best covers run about {cw:.0f} words. This cover has {f['cover_words']}.")
    ctas = [h["cta"] for h in top]
    if f["cta"] not in ctas:
        notes.append(f"Your best ones ended with {', '.join(sorted(set(ctas)))}. This one ends with {f['cta']}. Not wrong, just new.")
    print("\n".join(notes))


if __name__ == "__main__":
    main()
