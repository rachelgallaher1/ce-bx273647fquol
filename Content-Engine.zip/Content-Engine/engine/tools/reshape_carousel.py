#!/usr/bin/env python3
"""Make a carousel shorter or longer using ONLY the words it already has (nothing is invented, nothing is thrown away).

  python3 reshape_carousel.py <slides.json> shorter|longer      prints one JSON line: {"ok": true, "message": "..."} or {"ok": false, "error": "..."}

shorter: joins the two shortest neighbouring text slides into one (her words are kept), or drops a picture-only slide.
longer : splits the slide with the most words at a sentence (a long quote becomes two, a long list becomes two).
It never touches the cover or the last (ask) slide. Slides must be in a look ("type": "tpl").
"""
import json, re, sys


def out(o):
    print(json.dumps(o))
    sys.exit(0 if o.get("ok") else 1)


def words(s):
    return len(" ".join(str(s.get(k) or "") for k in ("headline", "body")).split()) + sum(len(str(x).split()) for x in (s.get("items") or []))


def sentences(t):
    return [x.strip() for x in re.split(r"(?<=[.!?])\s+(?=[A-Z\"“'])", t.strip()) if x.strip()]


def shorter(sl):
    mids = list(range(1, len(sl) - 1 if sl[-1].get("kind") == "cta" else len(sl)))
    if len(mids) <= 3:
        return None, "It is already short. I would have to cut your words to go shorter."
    best, bi = None, None
    for i in mids[:-1]:
        a, b = sl[i], sl[i + 1]
        if a.get("kind") in ("point", "quote") and b.get("kind") in ("point", "quote") and not a.get("moves") and not b.get("moves"):
            w = words(a) + words(b)
            if w <= 44 and (best is None or w < best):
                best, bi = w, i
    if bi is not None:
        a, b = sl[bi], sl[bi + 1]
        m = dict(a)
        if a.get("kind") == "quote" and b.get("kind") == "quote":
            m["headline"] = (a.get("headline") or "") + " " + (b.get("headline") or "")
        else:
            m["kind"] = "point"
            m["headline"] = a.get("headline") or b.get("headline") or ""
            rest = " ".join(x for x in ((b.get("headline") if a.get("headline") else ""), a.get("body"), b.get("body")) if x)
            if rest:
                m["body"] = rest
            m.pop("who", None)
        if not m.get("photo") and b.get("photo"):
            m["photo"] = b["photo"]
        sl[bi:bi + 2] = [m]
        return sl, f"Joined two short slides. Now {len(sl)} slides, all your words kept."
    for i in mids:   # a slide that is only a picture says nothing, so it can go
        if sl[i].get("kind") == "photo":
            sl.pop(i)
            return sl, f"Took out a picture-only slide. Now {len(sl)} slides."
    return None, "Every slide has its own words, and I do not want to cut them. You can remove a slide yourself in the editor."


def longer(sl):
    mids = list(range(1, len(sl) - 1 if sl[-1].get("kind") == "cta" else len(sl)))
    if len(sl) >= 10:
        return None, "Ten slides is the most that works well. People stop swiping after that."
    best, bi = 0, None
    for i in mids:
        s = sl[i]
        if s.get("kind") == "quote" and len(sentences(s.get("headline") or "")) >= 2:
            w = len((s.get("headline") or "").split())
        elif s.get("kind") == "point" and len(sentences(s.get("body") or "")) >= 2:
            w = len((s.get("body") or "").split())
        elif s.get("kind") == "list" and len(s.get("items") or []) >= 4:
            w = 30
        else:
            continue
        if w > best:
            best, bi = w, i
    if bi is None:
        return None, "That is all the material there is. Add more of your own words in the editor, then I can spread it out."
    s = sl[bi]
    if s["kind"] == "quote":
        ss = sentences(s["headline"])
        h = max(1, len(ss) // 2)
        a, b = dict(s, headline=" ".join(ss[:h])), dict(s, headline=" ".join(ss[h:]))
        a.pop("who", None)
    elif s["kind"] == "point":
        ss = sentences(s["body"])
        h = max(1, len(ss) // 2)
        a = dict(s, body=" ".join(ss[:h]))
        b = {k: v for k, v in s.items() if k not in ("photo", "photos", "note", "n", "moves", "hi")}
        b.update(kind="quote", headline=" ".join(ss[h:]))
        b.pop("body", None)
    else:
        it = s["items"]
        h = (len(it) + 1) // 2
        a, b = dict(s, items=it[:h]), dict(s, items=it[h:], headline=(s.get("headline") or "More") + " (cont.)")
    for x in (a, b):
        x.pop("moves", None)
    sl[bi:bi + 1] = [a, b]
    return sl, f"Split one long slide in two. Now {len(sl)} slides, same words."


def main():
    if len(sys.argv) < 3 or sys.argv[2] not in ("shorter", "longer"):
        out({"ok": False, "error": "Say shorter or longer."})
    p = sys.argv[1]
    sp = json.load(open(p, encoding="utf-8"))
    sl = sp.get("slides", [])
    if not sl or any(s.get("type") != "tpl" for s in sl):
        out({"ok": False, "error": "This one is in an older style. Use Make this one in a look first."})
    new, msg = (shorter if sys.argv[2] == "shorter" else longer)([dict(s) for s in sl])
    if new is None:
        out({"ok": False, "error": msg})
    sp["slides"] = new
    json.dump(sp, open(p, "w", encoding="utf-8"), indent=1)
    out({"ok": True, "message": msg})


if __name__ == "__main__":
    main()
