#!/usr/bin/env python3
"""Animated step-by-step guide video (for courses and how-tos), in her look.
Usage: python make_guide_video.py GUIDE.json [--tall]
GUIDE.json: {"title": "...", "subtitle": "...", "look": "11", "handle": "@name", "outro": "Next: ...",
             "steps": [{"title": "Short step name", "body": "One or two plain sentences.", "say": "What she says out loud for this step."}]}
Writes GUIDE.mp4 (sound effects only, no voice) and GUIDE-voiceover.txt (each step's start time and the line to say, so she can record over it).
Each step stays on screen long enough to read its "say" line out loud. Wide 16:9 by default, --tall for 9:16.
"""
import json, math, os, subprocess, sys
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import first_edit as fe
import sounds

FPS = 30


def lum(c):
    return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]


def ease(x):
    x = min(1.0, max(0.0, x))
    return 1 - (1 - x) ** 3


def wrap(d, text, font, maxw):
    lines, cur = [], ""
    for w in text.split():
        t = (cur + " " + w).strip()
        if d.textlength(t, font=font) > maxw and cur:
            lines.append(cur)
            cur = w
        else:
            cur = t
    if cur:
        lines.append(cur)
    return lines


def main():
    spec_path = os.path.abspath(sys.argv[1])
    spec = json.load(open(spec_path, encoding="utf-8"))
    tall = "--tall" in sys.argv
    W, H = (1080, 1920) if tall else (1920, 1080)
    look = fe.load_look(spec.get("look", "11"))
    hook = fe.hex2rgb(look["hook"]["bg"])[:3]
    bg = tuple(int(c * 0.55) for c in hook) if lum(hook) < 120 else (24, 26, 25)
    hl = fe.hex2rgb(look["highlight"]["bg"])[:3]
    if lum(hl) < 90:
        hl = tuple(min(255, int(c * 1.8) + 40) for c in hl)
    sand = (234, 223, 207)
    disp = lambda s: fe.display_font(look, s)
    body_f = lambda s: fe.load_font(look["captionFont"], s, 600)
    d0 = ImageDraw.Draw(Image.new("RGB", (10, 10)))

    # timeline
    steps = spec["steps"]
    items = [("title", 3.2, None)]
    for k, st in enumerate(steps):
        words = len((st.get("say") or st.get("body", "")).split())
        items.append(("step", max(4.2, 1.4 + words / 2.4), k))
    items.append(("end", 3.4, None))
    starts, t = [], 0.0
    for kind, dur, k in items:
        starts.append(t)
        t += dur
    total = t

    def frame(tt):
        im = Image.new("RGB", (W, H), bg)
        d = ImageDraw.Draw(im)
        idx = max(i for i, s in enumerate(starts) if s <= tt)
        kind, dur, k = items[idx]
        p = (tt - starts[idx])
        a_in, a_out = ease(p / 0.5), 1.0 - ease((p - (dur - 0.3)) / 0.3) if p > dur - 0.3 else 1.0
        al = min(a_in, a_out)
        shift = int((1 - a_in) * 180)
        layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        ld = ImageDraw.Draw(layer)
        pad = 110 if not tall else 80
        if kind == "title":
            f = fe.fit_display(look, [spec["title"].upper()], 230 if not tall else 170, W - 2 * pad)
            lines = wrap(ld, spec["title"].upper(), f, W - 2 * pad)
            f = fe.fit_display(look, lines, 230 if not tall else 170, W - 2 * pad)
            block = len(lines) * f.size * 1.12 + (110 if spec.get("subtitle") else 0)
            y = H / 2 - block / 2
            for ln in lines:
                ld.text((pad + shift, y), ln, font=f, fill=hl + (255,))
                y += f.size * 1.12
            if spec.get("subtitle"):
                ld.text((pad + shift, y + 40), spec["subtitle"], font=body_f(58 if not tall else 46), fill=sand + (255,))
        elif kind == "end":
            f = fe.fit_display(look, [spec.get("outro", "Thanks for watching").upper()], 160, W - 2 * pad)
            ld.text((pad + shift, H / 2 - f.size * 0.6), spec.get("outro", "Thanks for watching").upper(), font=f, fill=sand + (255,))
            if spec.get("handle"):
                ld.text((pad + shift, H / 2 + f.size * 0.6), spec["handle"], font=body_f(56), fill=hl + (255,))
        else:
            st = steps[k]
            n = f"{k + 1:02d}"
            if not tall:
                nf = disp(640)
                ld.text((pad - 20 - shift, H / 2 - 360), n, font=nf, fill=hl + (60,))
                x0 = 760
                tf = fe.fit_display(look, [st["title"].upper()], 130, W - x0 - pad)
                tl = wrap(ld, st["title"].upper(), tf, W - x0 - pad)
                bf = body_f(54)
                bl = wrap(ld, st.get("body", ""), bf, W - x0 - pad)
                block = len(tl) * tf.size * 1.12 + 50 + len(bl) * 78
                y = H / 2 - block / 2
                ld.rounded_rectangle((x0 - 44 + shift, y + 6, x0 - 32 + shift, y + block - 6), radius=6, fill=hl + (255,))
                for ln in tl:
                    ld.text((x0 + shift, y), ln, font=tf, fill=sand + (255,))
                    y += tf.size * 1.12
                y += 50
                for ln in bl:
                    ld.text((x0 + shift, y), ln, font=bf, fill=(255, 255, 255, 235))
                    y += 78
            else:
                ld.text((pad, 220 - shift), n, font=disp(520), fill=hl + (255,))
                tf = fe.fit_display(look, [st["title"].upper()], 150, W - 2 * pad)
                y = 820
                for ln in wrap(ld, st["title"].upper(), tf, W - 2 * pad):
                    ld.text((pad + shift, y), ln, font=tf, fill=sand + (255,))
                    y += tf.size * 1.02
                bf = body_f(50)
                y += 30
                for ln in wrap(ld, st.get("body", ""), bf, W - 2 * pad):
                    ld.text((pad + shift, y), ln, font=bf, fill=(255, 255, 255, 235))
                    y += 70
        if al < 0.999:
            layer.putalpha(layer.getchannel("A").point(lambda v: int(v * al)))
        im.paste(layer, (0, 0), layer)
        d = ImageDraw.Draw(im)
        # small header and progress bar
        d.text((pad, 44), spec["title"].upper(), font=disp(40), fill=sand)
        if spec.get("handle"):
            hw = d.textlength(spec["handle"], font=body_f(34))
            d.text((W - pad - hw, 48), spec["handle"], font=body_f(34), fill=sand)
        d.rectangle((0, H - 12, W, H), fill=tuple(int(c * 0.7) for c in bg))
        d.rectangle((0, H - 12, int(W * tt / total), H), fill=hl)
        return im

    out = os.path.splitext(spec_path)[0] + ("-tall" if tall else "") + ".mp4"
    ev = []
    for (kind, dur, k), s0 in zip(items, starts):
        if kind == "step":
            ev += [(s0 - 0.05, "whoosh", 0.35), (s0 + 0.2, "pop", 0.5)]
    wav = out[:-4] + ".sfx.wav"
    sounds.build_track(ev, total, wav)
    proc = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                             "-i", wav, "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "19",
                             "-c:a", "aac", "-b:a", "160k", "-t", f"{total:.2f}", "-movflags", "+faststart", out], stdin=subprocess.PIPE)
    for i in range(int(total * FPS)):
        proc.stdin.write(frame(i / FPS).tobytes())
    proc.stdin.close()
    proc.wait()
    os.remove(wav)
    with open(out[:-4] + "-voiceover.txt", "w", encoding="utf-8") as f:
        f.write(f"Voice-over script: {spec['title']}\n(total about {total:.0f} seconds; each step stays on screen long enough to say its line)\n\n")
        f.write(f"[0:00] (title card, pause)\n")
        for (kind, dur, k), s0 in zip(items, starts):
            if kind == "step":
                f.write(f"[{int(s0 // 60)}:{int(s0 % 60):02d}] Step {k + 1}: {steps[k].get('say') or steps[k].get('body', '')}\n")
        f.write(f"[{int(starts[-1] // 60)}:{int(starts[-1] % 60):02d}] {spec.get('outro', '')}\n")
    print("Done:", out)


main()
