#!/usr/bin/env python3
"""Makes the carousel for a calendar day straight from the script already written for that day. No chat step.

  python3 auto_carousel.py <post number>        prints one JSON line: {"ok": true, "folder": "customer/content/..."} or {"ok": false, "error": "..."}

It only uses words she already approved: the "## Carousel" slide list in that day's script file. It picks the look
(pick_look.py, her pinned look first), writes slides.json, draws the slides (the carousel tool files them on that day
of the plan by itself) and leaves her free to change the style or edit afterward. It never invents words: a day that is
still an outline (no script yet) says so plainly.
"""
import json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import plan as pl
import pick_look as pk

ROOT = pl.ROOT


def out(o):
    print(json.dumps(o))
    sys.exit(0 if o.get("ok") else 1)


def slide_items(text):
    """The numbered slide list under '## Carousel' (or '## Slides')."""
    m = re.search(r"^##\s+(?:Carousel|Slides?)\b.*?\n(.*?)(?=^##\s|\Z)", text, re.S | re.M)
    if not m:
        return []
    items = []
    for ln in m.group(1).splitlines():
        mm = re.match(r"\s*\d+[.)]\s+(.*\S)\s*$", ln)
        if mm:
            t = re.sub(r"\*\*([^*]+)\*\*:?\s*", lambda x: x.group(1).rstrip(":") + ": " if x.group(1).rstrip(":").lower() in ("cover", "hook", "slide", "cta", "ask") else x.group(1), mm.group(1)).strip()
            t = re.sub(r"^(cover|hook|slide \d+|cta|ask)\s*:\s*", "", t, flags=re.I).strip()
            if t:
                items.append(t)
    return items


def sentences(par):
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+(?=[A-Z\"“'])", par.strip()) if s.strip()]


def caption_of(text):
    """Her caption from the script (the '## Caption' section), so the carousel arrives with one ready to copy."""
    m = re.search(r"^##\s+Caption\s*\n(.*?)(?=^##\s|\Z)", text, re.S | re.M)
    if not m:
        m = re.search(r"^##\s+Caption first line\s*\n(.*?)(?=^##\s|\Z)", text, re.S | re.M)
    return (m.group(1).strip() if m else "")


def video_items(text):
    """A carousel from a VIDEO script: her own spoken words, cut into slides. Nothing is rewritten or added.
    Returns entries: a string (a slide's words), or {"kind": "list", "title": ..., "items": [...]} or {"kind": "cta", ...}."""
    m = re.search(r"^##\s+Script[^\n]*\n(.*?)(?=^##\s|\Z)", text, re.S | re.M)
    if not m:
        return []
    pars = []
    for blk in re.split(r"\n\s*\n", m.group(1)):
        blk = " ".join(l.strip() for l in blk.splitlines() if l.strip() and not l.strip().startswith(("*Version", "*")))
        blk = re.sub(r"\s+", " ", blk).strip()
        if blk:
            pars.append(blk)
    if not pars:
        return []
    items = []
    cta = None
    for k, par in enumerate(pars):
        cm = re.search(r"\bcomment\b[^\"“']*[\"“']([A-Za-z0-9 ]+)[\"”']", par, re.I)
        if cm and k == len(pars) - 1:
            cta = {"kind": "cta", "keyword": cm.group(1), "line": "and I'll send you the details"}
            continue
        nums = list(re.finditer(r"(?:^|\s)(\d)\.\s+", par))
        if len(nums) >= 3:   # her numbered signs or steps: the first stands alone, the rest become a list
            pre = par[:nums[0].start()].strip()
            if pre:
                items.append(pre)
            parts = [par[nums[j].end():(nums[j + 1].start() if j + 1 < len(nums) else len(par))].strip(" ,;") for j in range(len(nums))]
            parts = [re.sub(r"\s*,?\s+(and|or)$", "", x_).strip(" ,;") for x_ in parts if x_]
            parts = [re.sub(r"^[a-z]", lambda x: x.group(0).upper(), x_) for x_ in parts if x_]
            tail = []
            ls = sentences(parts[-1])
            if len(ls) > 1:   # the last item keeps its first sentence; what follows becomes its own slide
                parts[-1] = ls[0]
                tail = [" ".join(ls[1:])]
            words_ = {2: "two", 3: "three", 4: "four", 5: "five"}
            if len(parts) > 3:
                items.append(parts[0])
                items.append({"kind": "list", "title": f"The other {words_.get(len(parts) - 1, len(parts) - 1)}", "items": parts[1:5]})
            else:
                items.append({"kind": "list", "title": "Here they are", "items": parts})
            items.extend(tail)
            continue
        ss = sentences(par)
        if len(par.split()) <= 24 or len(ss) < 2:
            items.append(par)
        else:   # a long paragraph becomes two slides, split at a sentence
            half = 0
            for j in range(1, len(ss)):
                if len(" ".join(ss[:j]).split()) >= len(par.split()) / 2:
                    half = j
                    break
            half = half or len(ss) // 2
            items.append(" ".join(ss[:half]))
            items.append(" ".join(ss[half:]))
    while len(items) > 9:   # too many: join the two shortest neighbours (only plain text slides)
        best, bi = None, None
        for j in range(1, len(items) - 1):
            if isinstance(items[j], str) and isinstance(items[j + 1], str):
                w = len(items[j].split()) + len(items[j + 1].split())
                if best is None or w < best:
                    best, bi = w, j
        if bi is None:
            break
        items[bi:bi + 2] = [items[bi] + " " + items[bi + 1]]
    return items + ([cta] if cta else [])


def meta(text, key):
    m = re.search(r"\*\*" + key + r":\*\*\s*([^·\n]+)", text)
    return m.group(1).strip() if m else ""


def main():
    if len(sys.argv) < 2 or not sys.argv[1].isdigit():
        out({"ok": False, "error": "Tell me which post number."})
    n = int(sys.argv[1])
    path = pl.plan_path()
    if not path or not os.path.exists(path):
        out({"ok": False, "error": "I can't find your month plan yet."})
    rows = {r["n"]: r for r in pl.rows_of(path)}
    r = rows.get(n)
    if not r:
        out({"ok": False, "error": f"I can't find post {n} in your plan."})
    if "carousel" not in r["format"].lower():
        out({"ok": False, "error": "This day is not a carousel day."})
    script = r.get("script")
    if (not script or not os.path.exists(script)):   # "carousel from post 3": build from that post's script
        fm = re.search(r"from post (\d+)", r.get("idea") or "", re.I)
        src = rows.get(int(fm.group(1))) if fm else None
        script = src.get("script") if src else None
    if not script or not os.path.exists(script):
        out({"ok": False, "error": "This day's words are not written yet. Its script unlocks at your Sunday refresh (or say \"unlock week\" in chat)."})
    text = open(script, encoding="utf-8").read()
    r = dict(r, script=script)
    items = slide_items(text)
    if len(items) < 3:
        items = video_items(text)   # a video script: her spoken words become the slides
    if len(items) < 3:
        out({"ok": False, "error": "This script is too short to build a carousel from. Tell Claude: make the carousel for this day."})
    kind = (meta(text, "Kind") or "teaching").split()[0].lower()
    job = (meta(text, "Job") or r.get("job") or "").lower()
    fmt = r["format"].lower()
    pick = pk.choose(" ".join((x if isinstance(x, str) else " ".join(x.get("items", [x.get("title", "")]))) for x in items), kind if kind in ("teaching", "story", "reference") else "", job, fmt, photos=False)
    t = pick["template"]
    allowed = set(pk.KINDS.get(t, ()))
    slides = []
    last = len(items) - 1
    prev = ""
    src = "her script: " + os.path.relpath(r["script"], ROOT)
    for i, it in enumerate(items):
        if isinstance(it, dict):
            d = dict(type="tpl", template=t, source=src)
            if it["kind"] == "list" and "list" in allowed:
                d.update(kind="list", headline=it["title"], items=it["items"])
            elif it["kind"] == "cta":
                d.update(kind="cta", keyword=it["keyword"], line=it["line"])
            else:
                d.update(kind="point", headline=it.get("title") or " ".join(it.get("items", [])))
            prev = d["kind"]
            slides.append(d)
            continue
        words = it.split()
        if i == 0:
            sl = dict(kind="cover", headline=it)
        elif i == last and re.search(r"\bcomment\b", it, re.I):
            kw = re.search(r"[\"“']([A-Za-z0-9 ]+)[\"”']", it)
            sl = dict(kind="cta", keyword=(kw.group(1) if kw else "WORD"), line="and I'll send it to you")
        elif len(words) > 14 and "quote" in allowed and prev != "quote":
            sl = dict(kind="quote", headline=it)
        elif ":" in it and len(it.split(":")[0].split()) <= 8:
            h, b = it.split(":", 1)
            sl = dict(kind="point", headline=h.strip(), body=b.strip())
        elif len(words) <= 9:
            # short lines alternate between a headline slide and a big statement, so the swipe does not look the same
            sl = dict(kind="quote", headline=it) if (prev == "point" and "quote" in allowed) else dict(kind="point", headline=it)
        elif "quote" in allowed and prev != "quote":
            sl = dict(kind="quote", headline=it)   # a full sentence reads best as a big statement
        else:
            m = re.match(r"(.{20,70}?[.!?])\s+(.*)", it)
            sl = dict(kind="point", headline=(m.group(1) if m else it), body=(m.group(2) if m else ""))
        if sl["kind"] not in allowed:
            sl["kind"] = "point"
        if sl["kind"] == prev and sl["kind"] != "point":
            sl["kind"] = "point"
        if i not in (0, last) and sl["kind"] == "point" and prev == "point" and "quote" in allowed and len(words) >= 8:
            sl = dict(kind="quote", headline=it)
        prev = sl["kind"]
        d = dict(type="tpl", template=t, source=src)
        d.update(sl)
        if i > 0 and sl["kind"] == "point":
            d["n"] = False
        if i == 0 and t == 5:
            d["pov"] = False   # "POV:" only fits a headline that starts with "you"
        slides.append(d)
    slug = re.sub(r"[^a-z0-9]+", "-", (r["idea"] or "carousel").lower()).strip("-")[:40] or "carousel"
    folder = os.path.join(ROOT, "customer", "content", f"{r['date']}-{slug}-carousel")
    os.makedirs(folder, exist_ok=True)
    spec = {"title": slug, "handle": "", "look": "brand" if len(__import__("make_looks").brand_colors()) >= 2 else "1",
            "post": n, "look_auto": True, "look_reason": pick["reason"], "slides": slides}
    cap = caption_of(text)
    if cap:
        spec["caption"] = cap
    hp = os.path.join(ROOT, "customer", "profile", "handle.txt")
    if os.path.exists(hp):
        spec["handle"] = open(hp, encoding="utf-8").read().strip()
    else:
        mk = os.path.join(ROOT, "customer", "profile", "marketing-settings.md")
        if os.path.exists(mk):
            hm = re.search(r"@[A-Za-z0-9_.]+", open(mk, encoding="utf-8").read())
            if hm:
                spec["handle"] = hm.group(0)
    json.dump(spec, open(os.path.join(folder, "slides.json"), "w", encoding="utf-8"), indent=1)
    py = sys.executable
    pr = subprocess.run([py, "-X", "utf8", "-I", os.path.join(HERE, "make_carousel.py"), os.path.join(folder, "slides.json"), folder], capture_output=True, text=True, encoding="utf-8", errors="replace", cwd=ROOT, timeout=300)
    if pr.returncode == 3 and not os.path.exists(os.path.join(folder, "slide-01.png")):
        # too close to a recent carousel: mix up the middle slides (a short line becomes a big statement and back), then try again
        for k, s in enumerate(spec["slides"]):
            if 0 < k < len(spec["slides"]) - 1 and s["kind"] in ("point", "quote") and len((s.get("headline") or "").split()) <= 14 and not s.get("body"):
                s["kind"] = "quote" if (s["kind"] == "point" and "quote" in allowed) else "point"
        json.dump(spec, open(os.path.join(folder, "slides.json"), "w", encoding="utf-8"), indent=1)
        pr = subprocess.run([py, "-X", "utf8", "-I", os.path.join(HERE, "make_carousel.py"), os.path.join(folder, "slides.json"), folder], capture_output=True, text=True, encoding="utf-8", errors="replace", cwd=ROOT, timeout=300)
        if pr.returncode == 3:   # her script really is that similar: draw it anyway rather than block her
            spec["allow_similar"] = True
            json.dump(spec, open(os.path.join(folder, "slides.json"), "w", encoding="utf-8"), indent=1)
            pr = subprocess.run([py, "-X", "utf8", "-I", os.path.join(HERE, "make_carousel.py"), os.path.join(folder, "slides.json"), folder], capture_output=True, text=True, encoding="utf-8", errors="replace", cwd=ROOT, timeout=300)
    if not os.path.exists(os.path.join(folder, "slide-01.png")):
        out({"ok": False, "error": "The carousel did not draw: " + (pr.stderr or pr.stdout)[-200:]})
    subprocess.run([py, "-X", "utf8", "-I", os.path.join(HERE, "make_calendar.py")], capture_output=True, cwd=ROOT, timeout=120)
    out({"ok": True, "folder": os.path.relpath(folder, ROOT).replace(os.sep, "/"), "look": pick["name"], "reason": pick["reason"]})


if __name__ == "__main__":
    main()
