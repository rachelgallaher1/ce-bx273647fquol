#!/usr/bin/env python3
"""Carousel review page: fix the words, reorder or remove slides, and redraw. Free, runs on her computer.
Usage: python carousel_sheet.py PATH/TO/slides.json [--no-open]
Opens http://127.0.0.1:8766/ . Press "Redraw" to remake the slides from her edits. Her original words are kept in slides.backup.json.
"""
import json, os, shutil, subprocess, sys, threading, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
SPEC = os.path.abspath(sys.argv[1])
OUT = os.path.join(os.path.dirname(SPEC), json.load(open(SPEC, encoding="utf-8")).get("title", "carousel"))
STATE = {"state": "idle", "message": ""}

PAGE = r"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Carousel review</title>
<style>
:root{--bg:#f4efe6;--card:#fff;--ink:#26332c;--muted:#6b6a60;--line:#d8cdb9;--acc:#2a6e6f}
@media(prefers-color-scheme:dark){:root{--bg:#18211d;--card:#222e28;--ink:#eadfcf;--muted:#a9a290;--line:#35443c;--acc:#6fa7a8}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:system-ui,sans-serif}
header{position:sticky;top:0;background:var(--bg);border-bottom:1px solid var(--line);padding:12px 16px;display:flex;gap:12px;align-items:center;flex-wrap:wrap;z-index:2}
h1{font-size:18px;margin:0;flex:1}button{font:inherit;padding:8px 14px;border-radius:8px;border:1px solid var(--line);background:var(--card);color:var(--ink);cursor:pointer}
button.primary{background:var(--acc);color:#fff;border-color:var(--acc)}button:disabled{opacity:.5}
main{max-width:1100px;margin:0 auto;padding:16px;display:grid;gap:14px}
.s{display:grid;grid-template-columns:200px 1fr;gap:14px;background:var(--card);border:1px solid var(--line);border-radius:12px;padding:12px}
.s img{width:200px;border-radius:8px;display:block}.t{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin-bottom:6px;display:flex;gap:8px;align-items:center}
label{display:block;font-size:12px;color:var(--muted);margin:8px 0 3px}textarea,input{width:100%;font:inherit;padding:7px 9px;border:1px solid var(--line);border-radius:8px;background:var(--bg);color:var(--ink)}
.row{display:flex;gap:6px;margin-left:auto}.small{padding:4px 9px;font-size:13px}
#msg{font-size:14px;color:var(--muted)}#checks{max-width:1100px;margin:12px auto 0;padding:0 16px}#checks div{background:var(--card);border:1px solid var(--acc);border-radius:10px;padding:10px 14px;font-size:14px}
@media(max-width:640px){.s{grid-template-columns:1fr}.s img{width:140px}}
</style></head><body>
<header><h1>Carousel review</h1><span style="display:flex;gap:6px"><select id="addtype"></select><button id="addbtn">Add a slide</button></span><button id="quickbg" title="Puts a still from your video behind the first and last slides">Still behind first and last</button><span id="msg"></span><button id="redraw" class="primary">Redraw my slides</button><button id="done">I'm done</button></header>
<div id="checks"></div><div style="max-width:1100px;margin:12px auto 0;padding:0 16px"><label style="font-size:13px;color:var(--muted)">Notes for Claude about the whole carousel (saved automatically)</label><textarea id="gen" rows="3" placeholder="Anything you want changed or remembered..." style="width:100%;font:inherit;padding:9px 11px;border:1px solid var(--line);border-radius:8px;background:var(--card);color:var(--ink)"></textarea><div id="saved" style="font-size:12px;color:var(--muted);margin-top:4px"></div></div><main id="main"></main>
<script>
var TEMPLATES={cover:{type:"cover",label:"A SMALL LABEL,",headline:"YOUR BIG PROMISE HERE",hi:"PROMISE"},point:{type:"point",n:"01",headline:"One clear point",body:"One or two short lines that back it up."},bigtext:{type:"bigtext",headline:"A big statement",hi:"statement",lines:["One idea per slide."]},stat:{type:"stat",number:"12",label:"YEARS",body:"What the number means."},list:{type:"list",headline:"A short list",items:["one","two","three"]},recap:{type:"recap",items:["A saveable checklist","Short lines","Easy to keep"]},quote:{type:"quote",quote:"A line worth pausing on.",who:""},myth:{type:"myth",myth:"The myth",fact:"The fact"},faq:{type:"faq",question:"A question people ask?",answer:"Your short answer."},compare:{type:"compare",headline:"Old way vs new way",left_title:"Before",right_title:"After",rows:[["old","new"]],verdict:"The difference."},stopstart:{type:"stopstart",headline:"Stop this, start that",stop:["one"],start:["one"]},timeline:{type:"timeline",headline:"Step by step",steps:["First","Then","Last"]},quiz:{type:"quiz",question:"Which one are you?",options:["A","B","C"]},pov:{type:"pov",headline:"POV: your line here"},photo:{type:"photo",headline:"A headline",body:"A line of body text.",hi:""},cta:{type:"cta",keyword:"WORD",line:"and I will send it to you"}};
var TYPENAMES={cover:"Cover",point:"Point",bigtext:"Big statement",stat:"Big number",list:"List",recap:"Recap / checklist",quote:"Quote",myth:"Myth vs fact",faq:"Question and answer",compare:"Before and after",stopstart:"Stop and start",timeline:"Steps",quiz:"Quiz",pov:"POV",photo:"Photo and words",cta:"Call to action"};
var SPEC=null,STILLS=[],V=Date.now(),NOTES={general:"",slides:{}},T=null;
function saveNotes(){clearTimeout(T);T=setTimeout(function(){api("/api/notes",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(NOTES)}).then(function(){var e=document.getElementById("saved");e.textContent="Notes saved.";setTimeout(function(){e.textContent=""},1800)})},500)}
function api(u,o){return fetch(u,o).then(function(r){return r.json()})}
var SKIP={type:1,frame:1,source:1,image:1,photo:1,blur:1};
function load(){return api("/api/notes").then(function(n){NOTES=n&&n.slides?n:{general:"",slides:{}};document.getElementById("gen").value=NOTES.general||"";document.getElementById("gen").oninput=function(){NOTES.general=this.value;saveNotes()};return api("/api/spec")}).then(function(s){SPEC=s;return api("/api/stills")}).then(function(st){STILLS=st.times||[];render();showChecks()})}
function showChecks(){api("/api/checks").then(function(c){var b=document.getElementById("checks");if(c.notes&&c.notes.length){b.innerHTML="<div><b>Worth a look:</b><ul style='margin:6px 0 0 18px;padding:0'>"+c.notes.map(function(x){return "<li>"+x.replace(/</g,"&lt;")+"</li>"}).join("")+"</ul></div>"}else{b.innerHTML="<div>All checks passed.</div>"}})}
function dirty(){document.getElementById("msg").textContent="You have changes that are not drawn yet. Press Redraw to see them."}
function val(v){return Array.isArray(v)?v.map(function(x){return Array.isArray(x)?x.join(" | "):x}).join("\n"):(v==null?"":String(v))}
function render(){
  var m=document.getElementById("main");m.innerHTML="";
  SPEC.slides.forEach(function(sl,i){
    var d=document.createElement("div");d.className="s";
    var n=String(i+1).padStart(2,"0");
    var h='<img src="/out/slide-'+n+'.png?v='+V+'" alt="Slide '+(i+1)+'"><div><div class="t">Slide '+(i+1)+' · '+sl.type+'<span class="row"><select class="small" data-a="type" title="Change this slide\'s kind">'+typeOpts(sl.type)+'</select><button class="small" data-a="up">Up</button><button class="small" data-a="down">Down</button><button class="small" data-a="dup">Duplicate</button><button class="small" data-a="del">Remove</button></span></div>';
    Object.keys(sl).forEach(function(k){if(SKIP[k])return;var v=sl[k];var big=Array.isArray(v)||String(v).length>60;
      h+='<label>'+k+(Array.isArray(v)?' (one per line)':'')+'</label>'+(big?'<textarea rows="'+Math.min(6,Math.max(2,val(v).split("\n").length+1))+'" data-k="'+k+'">'+val(v).replace(/</g,"&lt;")+'</textarea>':'<input data-k="'+k+'" value="'+val(v).replace(/"/g,"&quot;")+'">')});
    if(STILLS.length&&["cover","sticker","receipt","photo","cta"].indexOf(sl.type)>=0){h+='<label>Pick the photo (click one, then Redraw)</label><div class="stills">'+STILLS.map(function(t){var on=String(sl.frame)===String(t)||(sl.frame==="auto1"&&t===STILLS[0])||(sl.frame==="auto2"&&t===STILLS[1]);return '<img data-still="'+t+'" src="/out/stills/still-'+t+'.jpg" style="width:84px;margin:2px;border-radius:6px;cursor:pointer;border:3px solid '+(on?"var(--acc)":"transparent")+'">'}).join("")+'</div>'}
    if(STILLS.length&&["cover","sticker","receipt","photo","cta"].indexOf(sl.type)<0){var bgOn=sl.bg_frame!==undefined&&sl.bg_frame!==""&&sl.bg_frame!=="none";
      h+='<label>Your best 3 shots from the video, if you want one behind the words (click to use it, click again to take it off, then Redraw)</label><div class="stills">'+STILLS.slice(0,3).map(function(t){var on=bgOn&&String(sl.bg_frame)===String(t);return '<img data-bg="'+t+'" src="/out/stills/still-'+t+'.jpg" style="width:84px;margin:2px;border-radius:6px;cursor:pointer;border:3px solid '+(on?"var(--acc)":"transparent")+'">'}).join("")+'</div>';
      if(bgOn)h+='<label>How dark behind the words (higher is easier to read)</label><input type="range" min="20" max="85" value="'+Math.round((sl.overlay===undefined?0.55:sl.overlay)*100)+'" data-ov="1" style="width:220px">'}
    h+='<label>where these words come from (source)</label><input data-k="source" value="'+val(sl.source).replace(/"/g,"&quot;")+'"><label>Note for Claude about this slide (not drawn on the slide)</label><textarea rows="2" data-note="'+i+'" placeholder="What should change on this slide?">'+(NOTES.slides[i+1]||"").replace(/</g,"&lt;")+'</textarea></div>';
    d.innerHTML=h;
    d.querySelectorAll("[data-k]").forEach(function(el){el.oninput=function(){dirty();var k=el.dataset.k,o=sl[k];
      if(Array.isArray(o)){sl[k]=el.value.split("\n").filter(function(x){return x.trim()}).map(function(x){return (Array.isArray(o[0]))?x.split("|").map(function(y){return y.trim()}):x})}else{sl[k]=el.value}}});
    d.querySelectorAll("[data-still]").forEach(function(im){im.onclick=function(){sl.frame=parseFloat(im.dataset.still);dirty();d.querySelectorAll("[data-still]").forEach(function(o){o.style.border="3px solid transparent"});im.style.border="3px solid var(--acc)"}});
    d.querySelectorAll("[data-bg]").forEach(function(im){im.onclick=function(){var t=parseFloat(im.dataset.bg);if(sl.bg_frame===t){delete sl.bg_frame}else{sl.bg_frame=t;if(sl.overlay===undefined)sl.overlay=0.55}dirty();render()}});
    d.querySelectorAll("[data-ov]").forEach(function(el){el.oninput=function(){sl.overlay=el.value/100;dirty()}});
    d.querySelectorAll("[data-note]").forEach(function(el){el.oninput=function(){NOTES.slides[+el.dataset.note+1]=el.value;saveNotes()}});
    d.querySelectorAll("[data-a]").forEach(function(b){b.onclick=function(){var a=b.dataset.a;
      if(a==="type")return;
      if(a==="dup"){SPEC.slides.splice(i+1,0,JSON.parse(JSON.stringify(sl)));dirty();render();return}
      if(a==="del")SPEC.slides.splice(i,1);else{var j=a==="up"?i-1:i+1;if(j<0||j>=SPEC.slides.length)return;var t=SPEC.slides[i];SPEC.slides[i]=SPEC.slides[j];SPEC.slides[j]=t}render()}});
    var ts=d.querySelector("select[data-a=type]");if(ts)ts.onchange=function(){var nt=ts.value,keep={source:sl.source,note:sl.note,frame:sl.frame,photo:sl.photo};var fresh=JSON.parse(JSON.stringify(TEMPLATES[nt]||{type:nt}));
      var old=[sl.headline,sl.body,sl.label,sl.quote].filter(Boolean);Object.keys(keep).forEach(function(k){if(keep[k]!==undefined)fresh[k]=keep[k]});
      if(fresh.headline!==undefined&&sl.headline)fresh.headline=sl.headline;if(fresh.body!==undefined&&sl.body)fresh.body=sl.body;
      SPEC.slides[i]=fresh;dirty();render()};
    m.appendChild(d)})}
function typeOpts(cur){return Object.keys(TEMPLATES).map(function(t){return '<option value="'+t+'"'+(t===cur?' selected':'')+'>'+(TYPENAMES[t]||t)+'</option>'}).join("")}
function addSlide(){var t=document.getElementById("addtype").value;var sl=JSON.parse(JSON.stringify(TEMPLATES[t]));sl.source="added by hand";var at=SPEC.slides.length>1&&SPEC.slides[SPEC.slides.length-1].type==="cta"?SPEC.slides.length-1:SPEC.slides.length;SPEC.slides.splice(at,0,sl);dirty();render();window.scrollTo(0,document.body.scrollHeight)}
document.getElementById("redraw").onclick=function(){var b=this;b.disabled=true;document.getElementById("msg").textContent="Redrawing...";
  api("/api/save",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(SPEC)}).then(function(){
    (function p(){api("/api/status").then(function(s){document.getElementById("msg").textContent=s.message||"";if(s.state==="working"){setTimeout(p,1200);return}b.disabled=false;V=Date.now();load()})})()})};
document.getElementById("done").onclick=function(){var b=this;b.disabled=true;document.getElementById("msg").textContent="Saving and redrawing before I close...";
  api("/api/save",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(SPEC)}).then(function(){
    (function p(){api("/api/status").then(function(s){if(s.state==="working"){setTimeout(p,1000);return}
      fetch("/api/quit",{method:"POST",body:"{}"}).then(function(){document.body.innerHTML="<p style='padding:40px'>All set. Your edits are drawn and your notes are saved. You can close this tab.</p>"})})})()})};
document.getElementById('addtype').innerHTML=typeOpts('point');document.getElementById('addbtn').onclick=addSlide;
document.getElementById('quickbg').onclick=function(){if(!STILLS.length){document.getElementById('msg').textContent='This carousel has no video to take stills from.';return}var PH=['cover','sticker','receipt','photo','cta'];var n=SPEC.slides.length;[[0,STILLS[0]],[n-1,STILLS[Math.min(1,STILLS.length-1)]]].forEach(function(p){var sl=SPEC.slides[p[0]];if(sl&&PH.indexOf(sl.type)<0){sl.bg_frame=p[1];if(sl.overlay===undefined)sl.overlay=0.55}else if(sl&&PH.indexOf(sl.type)>=0){sl.frame=p[1]}});dirty();render()};
load();
</script></body></html>"""


def run_make():
    STATE.update(state="working", message="Redrawing your slides...")
    try:
        r = subprocess.run([sys.executable, "-X", "utf8", "-I", os.path.join(HERE, "make_carousel.py"), SPEC], capture_output=True, text=True, encoding="utf-8", errors="replace")
        STATE.update(state="done" if r.returncode == 0 else "error",
                     message="Your slides are redrawn." if r.returncode == 0 else "That didn't finish: " + (r.stderr.strip().splitlines() or ["no details"])[-1][:200])
    except Exception as e:
        STATE.update(state="error", message=f"That didn't start: {e}")


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, body, ctype="application/json", code=200):
        if not isinstance(body, bytes):
            body = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        p = self.path.split("?")[0]
        if p == "/":
            return self.send(PAGE.encode(), "text/html; charset=utf-8")
        if p == "/api/spec":
            return self.send(json.load(open(SPEC, encoding="utf-8")))
        if p == "/api/notes":
            f = SPEC.replace(".json", ".notes.json")
            return self.send(json.load(open(f, encoding="utf-8")) if os.path.exists(f) else {"general": "", "slides": {}})
        if p == "/api/status":
            return self.send(STATE)
        if p == "/api/checks":
            f = os.path.join(OUT, "checks.txt")
            notes = [l for l in open(f, encoding="utf-8").read().splitlines() if l.strip() and l != "All checks passed."] if os.path.exists(f) else []
            return self.send({"notes": notes})
        if p == "/api/stills":
            f = os.path.join(OUT, "stills.json")
            return self.send({"times": json.load(open(f, encoding="utf-8")) if os.path.exists(f) else []})
        if p.startswith("/out/"):
            rel = p[5:]
            fp = os.path.join(OUT, "stills", os.path.basename(rel)) if rel.startswith("stills/") else os.path.join(OUT, os.path.basename(rel))
            if os.path.exists(fp):
                return self.send(open(fp, "rb").read(), "image/jpeg" if fp.endswith(".jpg") else "image/png")
        self.send({"error": "not found"}, code=404)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(n) or b"{}"
        if self.path == "/api/save":
            bk = SPEC.replace(".json", ".backup.json")
            if not os.path.exists(bk):
                shutil.copy2(SPEC, bk)
            json.dump(json.loads(body), open(SPEC, "w", encoding="utf-8"), indent=1)
            threading.Thread(target=run_make, daemon=True).start()
            return self.send({"ok": True})
        if self.path == "/api/notes":
            data = json.loads(body)
            base = SPEC.replace(".json", ".notes")
            json.dump(data, open(base + ".json", "w", encoding="utf-8"), indent=1)
            with open(base + ".txt", "w", encoding="utf-8") as f:
                f.write("Notes for Claude about this carousel\n\n")
                if data.get("general", "").strip():
                    f.write("General: " + data["general"].strip() + "\n\n")
                for k in sorted(data.get("slides", {}), key=int):
                    if data["slides"][k].strip():
                        f.write(f"Slide {k}: {data['slides'][k].strip()}\n")
            return self.send({"ok": True})
        if self.path == "/api/quit":
            self.send({"ok": True})
            threading.Thread(target=lambda: (__import__("time").sleep(0.3), os._exit(0)), daemon=True).start()
            return
        self.send({"error": "not found"}, code=404)


def main():
    port = int(sys.argv[sys.argv.index("--port") + 1]) if "--port" in sys.argv else 8766
    while True:
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", port), H)
            break
        except OSError:
            port += 1   # another copy of the engine is using this address: take the next free one
    print(f"Carousel review running at http://127.0.0.1:{port}/", flush=True)
    if "--no-open" not in sys.argv:
        threading.Timer(0.6, lambda: webbrowser.open(f"http://127.0.0.1:{port}/")).start()
    srv.serve_forever()


main()
