"""Original sound effects, made from scratch (no samples, no copyright).
Used by first_edit.py to put small sounds on graphics and scene changes.
Each maker returns a float32 numpy array at SR. build_track() lays them on a timeline and writes a wav.
"""
import wave
import numpy as np

SR = 44100
RNG = np.random.default_rng(7)


def _t(d):
    return np.arange(int(SR * d)) / SR


def _env(n, attack=0.004, decay=6.0):
    t = np.arange(n) / SR
    return np.minimum(1, t / attack) * np.exp(-decay * t)


def whoosh(d=0.38):
    n = int(SR * d)
    noise = RNG.standard_normal(n)
    out = np.zeros(n)
    y = 0.0
    for i in range(n):
        f = 0.03 + 0.35 * np.sin(np.pi * i / n) ** 2
        y += f * (noise[i] - y)
        out[i] = y
    out = out - np.convolve(out, np.ones(200) / 200, mode="same") * 0.6
    sh = np.sin(np.pi * np.arange(n) / n) ** 1.5
    return (out * sh / (np.abs(out * sh).max() + 1e-9) * 0.8).astype(np.float32)


def impact(d=0.3):
    t = _t(d)
    f = 110 * np.exp(-6 * t) + 45
    ph = 2 * np.pi * np.cumsum(f) / SR
    return (np.sin(ph) * _env(len(t), 0.002, 9) * 0.9).astype(np.float32)


def pop(d=0.16):
    t = _t(d)
    f = 900 * np.exp(-18 * t) + 280
    ph = 2 * np.pi * np.cumsum(f) / SR
    return (np.sin(ph) * _env(len(t), 0.002, 24) * 0.8).astype(np.float32)


def notif(d=0.5):
    t = _t(d)
    a = np.sin(2 * np.pi * 988 * t) * _env(len(t), 0.003, 9)
    b = np.sin(2 * np.pi * 1480 * t) * _env(len(t), 0.003, 9)
    sh = int(SR * 0.11)
    out = a.copy()
    out[sh:] += b[:-sh] * 0.9
    out += 0.25 * np.sin(2 * np.pi * 2960 * t) * _env(len(t), 0.003, 14)
    return (out / np.abs(out).max() * 0.7).astype(np.float32)


def _click(d=0.02, bright=1.0):
    n = int(SR * d)
    x = RNG.standard_normal(n) * _env(n, 0.0005, 260)
    x = x - np.concatenate([[0], x[:-1]]) * 0.95
    return (x * bright).astype(np.float32)


def typing(count=7, gap=0.075):
    out = np.zeros(int(SR * (count * gap + 0.05)), dtype=np.float32)
    pos = 0.0
    for _ in range(count):
        c = _click(0.022, 0.9 + 0.3 * RNG.random())
        i = int(pos * SR)
        out[i:i + len(c)] += c[:len(out) - i]
        pos += gap * (0.7 + 0.6 * RNG.random())
    return (out / (np.abs(out).max() + 1e-9) * 0.7).astype(np.float32)


def mouse_click():
    c = np.concatenate([_click(0.02), np.zeros(int(SR * 0.06)), _click(0.015, 0.7)])
    return (c / (np.abs(c).max() + 1e-9) * 0.7).astype(np.float32)


def shutter():
    out = np.zeros(int(SR * 0.22), dtype=np.float32)
    for at, g in ((0.0, 1.0), (0.07, 0.8)):
        c = _click(0.05, 1.0) * g
        i = int(at * SR)
        out[i:i + len(c)] += c
    t = _t(0.22)
    out += (np.sin(2 * np.pi * 2200 * t) * _env(len(t), 0.001, 40) * 0.15).astype(np.float32)
    return (out / (np.abs(out).max() + 1e-9) * 0.75).astype(np.float32)


def coin(d=0.55):
    t = _t(d)
    a = np.sin(2 * np.pi * 1318 * t) + 0.4 * np.sin(2 * np.pi * 2636 * t)
    a = a * _env(len(t), 0.002, 8)
    b = np.sin(2 * np.pi * 1760 * t) + 0.4 * np.sin(2 * np.pi * 3520 * t)
    b = b * _env(len(t), 0.002, 6)
    sh = int(SR * 0.075)
    out = a.copy()
    out[sh:] += b[:-sh]
    return (out / np.abs(out).max() * 0.65).astype(np.float32)


MAKERS = {"whoosh": whoosh, "impact": impact, "pop": pop, "notif": notif, "typing": typing,
          "click": mouse_click, "shutter": shutter, "coin": coin}


def build_track(events, total, path):
    """events: list of (seconds, name, gain 0..1). Writes a mono 16-bit wav."""
    buf = np.zeros(int(SR * (total + 1.0)), dtype=np.float32)
    cache = {}
    for at, name, gain in events:
        if name not in MAKERS:
            continue
        if name not in cache:
            cache[name] = MAKERS[name]()
        s = cache[name] * gain
        i = max(0, int(at * SR))
        if i >= len(buf):
            continue
        buf[i:i + len(s)] += s[:len(buf) - i]
    buf = np.clip(buf, -1, 1)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((buf * 32767).astype(np.int16).tobytes())
    return path


if __name__ == "__main__":
    import sys
    out = sys.argv[1] if len(sys.argv) > 1 else "sound-sampler.wav"
    ev, t = [], 0.3
    for n in ("whoosh", "impact", "pop", "notif", "typing", "click", "shutter", "coin"):
        ev.append((t, n, 0.9))
        t += 1.2
    build_track(ev, t, out)
    print(out)
