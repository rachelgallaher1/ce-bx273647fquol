#!/usr/bin/env python3
"""First-pass compliance scan for a script or caption file.
  python compliance_scan.py FILE [--niche real-estate|network-marketing|other]
Reads engine/rules/compliance/general.md plus the niche file. Niche comes from --niche or the "Niche:" line in
customer/profile/marketing-settings.md. Prints each flagged line, why, and a safer way to say it.
This is a first-pass flag, not legal advice.
"""
import os, re, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
RULES = os.path.join(ROOT, "engine", "rules", "compliance")


def niche_from_settings():
    p = os.path.join(ROOT, "customer", "profile", "marketing-settings.md")
    if os.path.exists(p):
        m = re.search(r"\*\*Niche:\*\*\s*(.+)", open(p, encoding="utf-8").read())
        if m:
            t = m.group(1).lower()
            if "real" in t:
                return "real-estate"
            if "network" in t or "direct" in t:
                return "network-marketing"
            return re.sub(r"[^a-z]+", "-", t).strip("-")
    return None


def load(name):
    p = os.path.join(RULES, name + ".md")
    out = []
    if os.path.exists(p):
        for ln in open(p, encoding="utf-8"):
            if ln.startswith("- ") and ln.count(" | ") >= 2:
                rx, why, fix = [x.strip() for x in ln[2:].split(" | ", 2)]
                out.append((rx, why, fix))
    return out


def main():
    a = sys.argv[1:]
    if not a:
        sys.exit(__doc__)
    path = a[0]
    niche = a[a.index("--niche") + 1] if "--niche" in a else niche_from_settings()
    rules = load("general") + (load(niche) if niche else [])
    text = open(path, encoding="utf-8").read().split("\n")
    hits = 0
    for i, line in enumerate(text, 1):
        for rx, why, fix in rules:
            m = re.search(rx, line, re.I)
            if m:
                hits += 1
                print(f"Line {i}: \"{m.group(0).strip()}\"\n  Why it is a risk: {why}\n  Safer: {fix}")
    if not hits:
        print("No flags found.")
    print(f"({'general + ' + niche if niche else 'general rules only'}. First-pass flag, not legal advice. Check your brokerage or company rules.)")


main()
