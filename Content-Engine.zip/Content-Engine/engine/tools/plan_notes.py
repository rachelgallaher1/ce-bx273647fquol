#!/usr/bin/env python3
"""Notes to the plan: requests she types on the Calendar ("one more video a week", "hard sell on Nov 5", "make a video about starter feeding").
  python plan_notes.py list              the notes still waiting (id, text)
  python plan_notes.py add "text"        add a note
  python plan_notes.py done ID "what was done"   mark a note done and keep what was done
Notes live in customer/plans/plan-notes.json. The hub writes them; the "update my plan" step reads them (see engine/instructions/plan-notes.md)."""
import datetime, json, os, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
PATH = os.path.join(ROOT, "customer", "plans", "plan-notes.json")


def load():
    try:
        return json.load(open(PATH, encoding="utf-8"))
    except Exception:
        return []


def save(notes):
    os.makedirs(os.path.dirname(PATH), exist_ok=True)
    json.dump(notes, open(PATH, "w", encoding="utf-8"), indent=1, ensure_ascii=False)


def main():
    a = sys.argv[1:]
    if not a:
        sys.exit(__doc__)
    notes = load()
    if a[0] == "list":
        waiting = [n for n in notes if n.get("status") == "waiting"]
        print("\n".join(f"{n['id']}. {n['text']}" for n in waiting) or "No notes waiting.")
    elif a[0] == "add":
        nid = max([n["id"] for n in notes] or [0]) + 1
        notes.append({"id": nid, "text": " ".join(a[1:]).strip(), "status": "waiting", "added": datetime.datetime.now().isoformat(timespec="seconds")})
        save(notes)
        print("Added note", nid)
    elif a[0] == "done":
        for n in notes:
            if n["id"] == int(a[1]):
                n["status"], n["result"], n["finished"] = "done", " ".join(a[2:]).strip(), datetime.datetime.now().isoformat(timespec="seconds")
        save(notes)
        print("Marked done.")
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main()
