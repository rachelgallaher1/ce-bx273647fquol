#!/usr/bin/env python3
"""Cover a face: keep kids (or anyone) in a video without showing their faces.
  python3 face_cover.py analyze VIDEO OUT_FOLDER      find the different faces, save a small picture of each + faces.json
  python3 face_cover.py apply VIDEO OUT.mp4 SPEC.json cover the chosen faces (blur, pixelate or a sticker) all the way through
SPEC.json: {"faces": [{"emb": [...], "style": "smiley", "size": 1.4}], "default_style": "smiley", "all": false}
Styles: blur, pixelate, smiley, heart, star, flower, sun, bear.
A face is found by looking, so a face turned away or very small can be missed. `apply` prints the moments to double check, and she should always watch the video before posting.
"""
import json, math, os, subprocess, sys

import numpy as np

STYLES = ["blur", "pixelate", "smiley", "heart", "star", "flower", "sun", "bear"]


# ---------- stickers (drawn, no emoji font needed, so they look the same on Mac and Windows) ----------
def sticker(name, size=256):
    from PIL import Image, ImageDraw
    S = size
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = S / 2
    if name == "smiley":
        d.ellipse((6, 6, S - 6, S - 6), fill=(255, 205, 60), outline=(60, 40, 20), width=8)
        d.ellipse((c - 60, c - 55, c - 30, c - 15), fill=(60, 40, 20))
        d.ellipse((c + 30, c - 55, c + 60, c - 15), fill=(60, 40, 20))
        d.arc((c - 70, c - 40, c + 70, c + 70), 15, 165, fill=(60, 40, 20), width=9)
    elif name == "heart":
        d.ellipse((12, 20, S / 2 + 8, S / 2 + 30), fill=(232, 70, 100))
        d.ellipse((S / 2 - 8, 20, S - 12, S / 2 + 30), fill=(232, 70, 100))
        d.polygon([(14, S / 2 + 6), (S - 14, S / 2 + 6), (c, S - 10)], fill=(232, 70, 100))
    elif name == "star":
        pts = []
        for k in range(10):
            r = (S / 2 - 8) if k % 2 == 0 else (S / 5)
            a = -math.pi / 2 + k * math.pi / 5
            pts.append((c + r * math.cos(a), c + r * math.sin(a)))
        d.polygon(pts, fill=(255, 205, 60), outline=(200, 150, 20))
    elif name == "flower":
        for k in range(8):
            a = k * math.pi / 4
            x, y = c + 70 * math.cos(a), c + 70 * math.sin(a)
            d.ellipse((x - 38, y - 38, x + 38, y + 38), fill=(250, 150, 190))
        d.ellipse((c - 44, c - 44, c + 44, c + 44), fill=(255, 205, 60))
    elif name == "sun":
        for k in range(12):
            a = k * math.pi / 6
            d.line((c + 80 * math.cos(a), c + 80 * math.sin(a), c + 118 * math.cos(a), c + 118 * math.sin(a)), fill=(255, 185, 40), width=14)
        d.ellipse((c - 74, c - 74, c + 74, c + 74), fill=(255, 205, 60))
        d.ellipse((c - 28, c - 22, c - 14, c - 4), fill=(120, 80, 20))
        d.ellipse((c + 14, c - 22, c + 28, c - 4), fill=(120, 80, 20))
        d.arc((c - 34, c - 14, c + 34, c + 38), 20, 160, fill=(120, 80, 20), width=6)
    elif name == "bear":
        d.ellipse((12, 12, 92, 92), fill=(150, 100, 60))
        d.ellipse((S - 92, 12, S - 12, 92), fill=(150, 100, 60))
        d.ellipse((24, 24, 80, 80), fill=(225, 185, 150))
        d.ellipse((S - 80, 24, S - 24, 80), fill=(225, 185, 150))
        d.ellipse((14, 38, S - 14, S - 8), fill=(160, 110, 70))
        d.ellipse((c - 52, c + 10, c + 52, c + 84), fill=(230, 195, 160))
        d.ellipse((c - 62, c - 30, c - 38, c - 4), fill=(50, 30, 20))
        d.ellipse((c + 38, c - 30, c + 62, c - 4), fill=(50, 30, 20))
        d.ellipse((c - 16, c + 20, c + 16, c + 44), fill=(50, 30, 20))
    return im


# ---------- finding faces ----------
def _cascade():
    import cv2
    return cv2.CascadeClassifier(os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml")), \
        cv2.CascadeClassifier(os.path.join(cv2.data.haarcascades, "haarcascade_profileface.xml"))


def embed(bgr_crop):
    """A tiny fingerprint of a face picture: its shape and its colors. Good enough to tell the people in ONE video apart."""
    import cv2
    g = cv2.cvtColor(cv2.resize(bgr_crop, (32, 32)), cv2.COLOR_BGR2GRAY)
    g = cv2.equalizeHist(g).astype("float32").flatten()
    g -= g.mean()
    n = np.linalg.norm(g) or 1.0
    hsv = cv2.cvtColor(cv2.resize(bgr_crop, (8, 8)), cv2.COLOR_BGR2HSV).reshape(-1, 3).mean(0) / 255.0
    return np.concatenate([g / n, hsv * 0.6]).astype("float32")


def cos(a, b):
    return float(np.dot(a, b) / ((np.linalg.norm(a) or 1) * (np.linalg.norm(b) or 1)))


def read_dets(video, step=0.25, want_frames=False):
    import cv2
    front, prof = _cascade()
    cap = cv2.VideoCapture(video)
    try:
        cap.set(cv2.CAP_PROP_ORIENTATION_AUTO, 1)
    except Exception:
        pass
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    dets, i, size = [], 0, None
    while i < n:
        cap.set(cv2.CAP_PROP_POS_FRAMES, i)
        ok, fr = cap.read()
        if not ok:
            break
        h, w = fr.shape[:2]
        size = (w, h)
        sc = 540.0 / w
        sm = cv2.resize(fr, (540, int(h * sc)))
        g = cv2.equalizeHist(cv2.cvtColor(sm, cv2.COLOR_BGR2GRAY))
        ms = max(24, int(0.045 * 540))
        found = [tuple(b) for b in front.detectMultiScale(g, 1.08, 4, minSize=(ms, ms))]
        for b in prof.detectMultiScale(g, 1.1, 4, minSize=(ms, ms)):
            found.append(tuple(b))
        fl = cv2.flip(g, 1)
        for (x, y, bw, bh) in prof.detectMultiScale(fl, 1.1, 4, minSize=(ms, ms)):
            found.append((540 - x - bw, y, bw, bh))
        # merge near-duplicates
        merged = []
        for b in sorted(found, key=lambda b: -b[2] * b[3]):
            cx, cy = b[0] + b[2] / 2, b[1] + b[3] / 2
            if all(math.hypot(cx - (m[0] + m[2] / 2), cy - (m[1] + m[3] / 2)) > 0.6 * max(b[2], m[2]) for m in merged):
                merged.append(b)
        for (x, y, bw, bh) in merged:
            crop = sm[max(0, y):y + bh, max(0, x):x + bw]
            if crop.size == 0:
                continue
            dets.append({"t": i / fps, "box": [x / sc, y / sc, bw / sc, bh / sc], "emb": embed(crop)})
        i += max(1, int(step * fps))
    cap.release()
    return dets, size, fps


def build_tracks(dets, gap=1.0):
    """Link detections over time into tracks (one person moving through the video)."""
    tracks = []
    for d in sorted(dets, key=lambda d: d["t"]):
        cx, cy = d["box"][0] + d["box"][2] / 2, d["box"][1] + d["box"][3] / 2
        best, bd = None, 1e9
        for tr in tracks:
            last = tr["dets"][-1]
            if d["t"] - last["t"] > gap or last["t"] == d["t"]:
                continue
            lx, ly = last["box"][0] + last["box"][2] / 2, last["box"][1] + last["box"][3] / 2
            dist = math.hypot(cx - lx, cy - ly) / max(last["box"][2], d["box"][2], 1)
            if dist < 1.6 and cos(d["emb"], last["emb"]) > 0.25 and dist < bd:
                best, bd = tr, dist
        if best is None:
            tracks.append({"dets": [d]})
        else:
            best["dets"].append(d)
    for tr in tracks:
        tr["emb"] = np.mean([x["emb"] for x in tr["dets"]], axis=0)
    return tracks


def identities(tracks, merge=0.62):
    """Group tracks of the same person (they leave and come back) into identities."""
    ids = []
    for tr in sorted(tracks, key=lambda t: -len(t["dets"])):
        placed = False
        for idn in ids:
            if cos(tr["emb"], idn["emb"]) >= merge:
                idn["tracks"].append(tr)
                idn["emb"] = np.mean([t["emb"] for t in idn["tracks"]], axis=0)
                placed = True
                break
        if not placed:
            ids.append({"tracks": [tr], "emb": tr["emb"]})
    for idn in ids:
        idn["n"] = sum(len(t["dets"]) for t in idn["tracks"])
    ids = [i for i in ids if i["n"] >= 3]
    return sorted(ids, key=lambda i: -i["n"])


def analyze(video, out, step=0.25):
    import cv2
    os.makedirs(out, exist_ok=True)
    dets, size, fps = read_dets(video, step)
    ids = identities(build_tracks(dets))
    cap = cv2.VideoCapture(video)
    try:
        cap.set(cv2.CAP_PROP_ORIENTATION_AUTO, 1)
    except Exception:
        pass
    res = []
    for k, idn in enumerate(ids, 1):
        best = max((d for t in idn["tracks"] for d in t["dets"]), key=lambda d: d["box"][2] * d["box"][3])
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(best["t"] * fps))
        ok, fr = cap.read()
        thumb = ""
        if ok:
            x, y, w, h = [int(v) for v in best["box"]]
            m = int(0.25 * w)
            crop = fr[max(0, y - m):y + h + m, max(0, x - m):x + w + m]
            crop = cv2.resize(crop, (160, int(160 * crop.shape[0] / max(1, crop.shape[1]))))
            thumb = f"face_{k}.jpg"
            cv2.imwrite(os.path.join(out, thumb), crop)
        t0 = min(d["t"] for t in idn["tracks"] for d in t["dets"])
        t1 = max(d["t"] for t in idn["tracks"] for d in t["dets"])
        res.append({"id": k, "thumb": thumb, "seen": idn["n"], "from": round(t0, 1), "to": round(t1, 1),
                    "size": round(float(np.mean([d["box"][2] for t in idn["tracks"] for d in t["dets"]])) / (size[0] if size else 1080), 3),
                    "emb": [round(float(v), 4) for v in idn["emb"]]})
    cap.release()
    json.dump({"faces": res, "video": os.path.basename(video)}, open(os.path.join(out, "faces.json"), "w", encoding="utf-8"))
    return res


# ---------- covering ----------
def box_at(track, t, hold=1.2):
    ds = track["dets"]
    if t < ds[0]["t"] - 0.3 or t > ds[-1]["t"] + hold:
        return None
    if t <= ds[0]["t"]:
        return ds[0]["box"]
    for a, b in zip(ds, ds[1:]):
        if a["t"] <= t <= b["t"]:
            if b["t"] - a["t"] > hold + 0.5:
                return a["box"] if t - a["t"] <= hold else None
            u = (t - a["t"]) / max(1e-6, b["t"] - a["t"])
            return [a["box"][k] + (b["box"][k] - a["box"][k]) * u for k in range(4)]
    return ds[-1]["box"]


def apply(video, out, spec):
    import cv2
    chosen = [(np.array(f["emb"], dtype="float32"), f.get("style") or spec.get("default_style", "smiley"), float(f.get("size", 1.4))) for f in spec.get("faces", [])]
    cover_all = bool(spec.get("all"))
    dets, size, fps = read_dets(video, 0.2)
    tracks = build_tracks(dets)
    assign = []
    for tr in tracks:
        if len(tr["dets"]) < 2 and not cover_all:
            continue
        if cover_all:
            style, sz = (chosen[0][1], chosen[0][2]) if chosen else (spec.get("default_style", "smiley"), 1.4)
            assign.append((tr, style, sz))
            continue
        best, bs = None, 0.0
        for emb, style, sz in chosen:
            s = cos(tr["emb"], emb)
            if s > bs:
                best, bs = (style, sz), s
        if best is not None and bs >= 0.55:
            assign.append((tr, best[0], best[1]))
    cap = cv2.VideoCapture(video)
    try:
        cap.set(cv2.CAP_PROP_ORIENTATION_AUTO, 1)
    except Exception:
        pass
    W, H = size
    tmp = out + ".silent.mp4"
    proc = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{W}x{H}", "-r", f"{fps:.3f}", "-i", "-",
                             "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p", tmp], stdin=subprocess.PIPE)
    cache = {}
    k = 0
    checks = []
    lost = {}
    while True:
        ok, fr = cap.read()
        if not ok:
            break
        t = k / fps
        for ti, (tr, style, sz) in enumerate(assign):
            b = box_at(tr, t)
            if b is None:
                first, last = tr["dets"][0]["t"], tr["dets"][-1]["t"]
                if first < t < last and ti not in lost:
                    lost[ti] = t
                continue
            if ti in lost:
                if t - lost[ti] > 0.8:
                    checks.append(round(lost[ti], 1))
                del lost[ti]
            x, y, w, h = b
            cx, cy = x + w / 2, y + h / 2
            R = max(w, h) * 0.62 * sz
            x0, y0, x1, y1 = int(max(0, cx - R)), int(max(0, cy - R)), int(min(W, cx + R)), int(min(H, cy + R))
            if x1 - x0 < 4 or y1 - y0 < 4:
                continue
            roi = fr[y0:y1, x0:x1]
            if style == "blur":
                kk = max(3, (int(R) // 2) | 1)
                bl = cv2.GaussianBlur(roi, (kk, kk), 0)
                m = np.zeros(roi.shape[:2], "uint8")
                cv2.ellipse(m, ((roi.shape[1] / 2, roi.shape[0] / 2), (roi.shape[1] * 0.98, roi.shape[0] * 0.98), 0), 255, -1)
                m = cv2.GaussianBlur(m, (9, 9), 0)[..., None] / 255.0
                fr[y0:y1, x0:x1] = (bl * m + roi * (1 - m)).astype("uint8")
            elif style == "pixelate":
                sm = cv2.resize(roi, (max(2, roi.shape[1] // 14), max(2, roi.shape[0] // 14)), interpolation=cv2.INTER_AREA)
                fr[y0:y1, x0:x1] = cv2.resize(sm, (roi.shape[1], roi.shape[0]), interpolation=cv2.INTER_NEAREST)
            else:
                side = int(2 * R * 0.92)
                key = (style, side)
                if key not in cache:
                    from PIL import Image
                    st = sticker(style, 256).resize((side, side), Image.LANCZOS)
                    cache[key] = cv2.cvtColor(np.array(st), cv2.COLOR_RGBA2BGRA)
                st = cache[key]
                sx0, sy0 = int(cx - side / 2), int(cy - side / 2)
                for yy in range(max(0, sy0), min(H, sy0 + side)):
                    pass
                ys, xs = max(0, sy0), max(0, sx0)
                ye, xe = min(H, sy0 + side), min(W, sx0 + side)
                if ye > ys and xe > xs:
                    part = st[ys - sy0:ye - sy0, xs - sx0:xe - sx0]
                    a = part[..., 3:4] / 255.0
                    fr[ys:ye, xs:xe] = (part[..., :3] * a + fr[ys:ye, xs:xe] * (1 - a)).astype("uint8")
        proc.stdin.write(fr.tobytes())
        k += 1
    proc.stdin.close()
    proc.wait()
    cap.release()
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", tmp, "-i", video, "-map", "0:v", "-map", "1:a?", "-c:v", "copy", "-c:a", "copy", out], check=True)
    os.remove(tmp)
    return sorted(set(checks)), len(assign)


def main():
    a = sys.argv[1:]
    if len(a) >= 3 and a[0] == "analyze":
        res = analyze(a[1], a[2])
        print(f"I found {len(res)} different face(s).")
        for r in res:
            print(f"  Face {r['id']}: seen {r['seen']} times, from {r['from']}s to {r['to']}s")
    elif len(a) >= 4 and a[0] == "apply":
        checks, n = apply(a[1], a[2], json.load(open(a[3], encoding="utf-8")))
        print(f"Covered {n} face track(s).")
        if checks:
            print("Check these moments (the cover may have slipped): " + ", ".join(f"{t}s" for t in checks))
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main()
