# Compliance rules (first-pass flags, not legal advice)

One file per niche, plus `general.md`. `engine/tools/compliance_scan.py` reads them. Each rule is one line:

`- regex | why it is a risk | a safer way to say it` (separate the three parts with a space, a pipe, a space; the regex itself must not contain a space before or after a pipe)

The regex is case-insensitive. When in doubt, flag: a false flag costs a few seconds, a fine or a closed account costs much more. To add a niche, add a file named after it (for example `boutique.md`) and add its name to the niche list in `compliance-scan.md`.
