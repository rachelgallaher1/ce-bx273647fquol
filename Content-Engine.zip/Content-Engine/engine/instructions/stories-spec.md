# Stories spec (Rachel's complete spec, loaded 2026-10-20)

Where this and older notes disagree, this wins. One truth shapes it: interactive stickers (poll, quiz, question, countdown, link, Add Yours) can only be added INSIDE Instagram. The engine builds the frames and writes exact sticker instructions; she taps the sticker in. Never promise automatic native stickers.

## Job
Reels find people, carousels teach and get saved, stories talk to people already here: warm, ask, answer, point (send them to today's post), convert, keep (save to a Highlight). Every sequence has ONE of those jobs. Stories are low-stakes and today-only: behind the scenes, today moments, questions, reminders, not a second feed of finished posts.

## Technical
1080 x 1920. Keep the top ~250 px and bottom ~300 px free of text, faces and stickers (the tool keeps 340 at the bottom to be safe). Photo frames show 5 to 7 seconds: one idea, big text. Video frames up to 60 seconds, planned in segments. Sequences are 3 to 7 frames; one-frame stories are fine; 10 or more only for a real arc.

## Stickers (one interactive sticker per frame, never sticker soup)
Poll (2 options, 1 to 3 words each; show the result later) · quiz (right answer marked, wrong answers get a kind line) · question box (one specific prompt, never a bare "ask me anything") · emoji slider (a feeling check, not data) · countdown (her words, like "Cart closes Tuesday"; stories only, never in a Highlight) · link (custom text, ONE per sequence) · Add Yours (a prompt people can join in 10 seconds, with her own first example) · mention (only with the person's okay) · location (business places only; personal track delayed and general) · GIF (1 per sequence at most). Reveal and cutout are optional, never load-bearing.

## From a post (every post ships with its story package)
A) Promo, 3 frames: the hook restated for stories (never a screenshot of the post), the strongest idea line, then "it's live" with the post shared and ONE action matching the post's call to action. B) Full adaptation: the carousel told natively in 5 to 10 frames that stands alone. C) Interactive, 3 to 5 frames: poll, myth or question, answer, question box or keyword reply. Sticker mapping: checklist slide to question box, myth slide to quiz, framework slide to poll, data slide to slider, final slide to link, countdown or keyword reply. Tool: `make_stories.py --from-carousel slides.json`.

## 14 native story formats (rotate, plan them in the week)
Talking frames · today frame · question of the day · mini-teach · mailbag ("you asked", real question verbatim, blur the name) · before and after the post · win frame · this or that · confession (1 to 2 a week) · countdown runway · day in the life · Close Friends drop · share the love · sign-off.

## Sequence order
Frame 1 hooks (a question, confession, tease or face; never "new post!!" with no reason). Middle frames alternate give and ask. The last frame asks for ONE action. The frame people will want to re-read (checklist, price, date) is NOT last, so a tap-back is a visible interest signal. Every sequence works if someone enters at frame 3, so frames carry a tiny topic label.

## Close Friends
Buyers, founding members, warmest engagers; she controls the list in Instagram, the engine only keeps a names list for her to add from. 2 to 4 drops a week: early looks, real numbers she is comfortable sharing, first access, "help me decide" polls. Mark frames `[PUBLIC]` or `[CF]` on the sheet (`"cf": true` in the frame). A CF frame never contains anything that would hurt if screenshotted.

## Highlights
4 to 7, named in her words, ordered for a new visitor: Start Here, About Me, the offer, Results, FAQ, a series. Branded covers from her motif: `python3 engine/tools/make_highlights.py "Start Here,About,Waitlist" --look <id> --motif star`. Start Here is 4 to 6 frames (who she is, who it is for, what to do next, one proof, one human detail), reviewed monthly. Decide what to keep at posting time (`"save_to": "FAQ"` on the frame). Prune quarterly: expired dates and prices come OUT. Highlight frames never say "today only".

## Replies
A keyword reply fires the same automation as comments, and it must be live-tested FROM stories before a package ships with it. Story replies get drafted answers in her voice for her to send. Question-box answers are collected weekly into the FAQ and idea banks with names removed. Every poll's result gets shown.

## Learning (plain words)
Reach per frame; taps forward (a spike on frames 1 to 2 means a weak hook); taps back (strong, note what was on it); exits (a leak if it repeats at the same spot); replies and sticker taps (what stories are for); profile visits and link taps; completion. Judge sequences, not single frames; three or more sequences make a pattern. A story flop never rewrites the reel plan. Strong mini-teaches graduate into carousel or reel ideas.

## Words, design, privacy
Hook frame 8 words or fewer, teaching frames 25 or fewer, call to action 10 words plus the action. Locked templates from her look, motif and sign-off. Frames she shoots (talking, today, behind the scenes) get a shot note, never a rendered fake candid. Privacy: no live location at home or school, minors' faces per her interview defaults, blur names on every DM or comment screenshot, assume Close Friends frames escape. Default rhythm: one post-tied sequence plus one native moment a day. A daily 3-frame sequence beats an abandoned 10-frame one.

## Built in the tool
Frame types: text, poll, quiz, question, slider, addyours, countdown, link, cta, mailbag, photo, reelshare, quote, bignumber, reveal, listitem, coverpromo. Every run also writes `story-sheet.md` (one line per frame: public or CF, the picture file, the words, the exact sticker, the Highlight to save to) and `stickers.txt`. Checks: frame 1 hook (no "new post" without a reason, 8 words), a last frame that asks, 3 to 7 frames, no bare "ask me anything", teaching 25 words, call to action 10 words, Close Friends privacy.

## Bans
"New post!!" as frame 1 · a screenshot of the post as the promo · bare "ask me anything" · three or more stickers on one frame · text in the dead zones · a poll nobody ever sees the result of · keyword calls to action before the automation is tested from stories · live location at home or school · expired things in Highlights · Close Friends content that would burn her if screenshotted · text walls · a fake candid.

## Poll results frame (built)
When she runs a poll sticker, offer the result frame in the next sequence or the next day. Ask her for the real percentages from Instagram's poll results (never guess), then add `{"type": "pollresult", "question": "...", "results": [["Option", 71], ["Option", 29]], "comment": "one line in her voice"}` to the frames. The tool draws the bars and checks the percentages add up to about 100. Close Friends names list and story stats logging are deliberately not built.

## Filing
Put `"post": N` (the plan row number) in the stories json so the finished set files itself on its day in the calendar.
