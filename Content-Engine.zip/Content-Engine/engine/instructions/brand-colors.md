# Brand colors from her website

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

Tool: `engine/tools/brand_colors.py <website> --save` (or `--hex "#2A6E6F,#C9A227"`). It reads the public page and its stylesheets only, finds the real brand colors (theme color, named brand variables, most used colors, then the share image if the page has too few), and saves `customer/profile/brand.json` and `brand.md`. Some sites block automatic reading (an error like 403): say so plainly and ask her to type her colors instead.

Using it: the look called `brand` ("My brand") puts her colors on a normal look's fonts and shapes: the hook box uses her main color, the lit-up caption word uses her most lively mid-tone color, accents use the third. Set `look: "brand"` in the decisions, pass `--look brand`, or click "Use my brand colors" in the live editor (Your brand colors panel). If she has no brand colors, never make some up: offer the normal looks.

Also in the live editor: she can paste a website or type colors at any time, not just in the interview.

## When a website blocks reading (or she does not know her colors)
Never try to get around a site's block. Instead, in this order:
1. Ask her to drop her logo, or a screenshot of her website or her Canva brand kit, into the inbox (or into the live editor's "Your brand colors" box). Run `brand_colors.py --image <file>`: it lists the colors in the picture. Show them as swatches she can tap (the live editor does this; in chat, name them plainly with their codes and ask which one is her main color).
2. In the live editor she can also use the color picker and just click the shade she likes, so she never has to name a shade.
3. If she is using the desktop app and is happy for you to look, ask first, then open her website in the built-in browser like a normal visitor and read the colors from the page. Say what you are about to do and wait for her yes.

## The brand card (name, logo, fonts, colors, photos)
`python3 engine/tools/brand_colors.py <website> --kit` pulls her whole brand from her website and saves it in `customer/profile/brand.json` and `customer/profile/brand/` (logo and photos). It shows as a card in the **My brand** tab (and in the editor's Brand colors box): her name, logo, main font, the color strip, and a few photos with a "+N". She can type her website into the My brand tab or the editor box. If the logo is built into the page (not a picture file) it shows her name in place of the logo, and she can still add her logo or a screenshot. Fonts are found from the site's own styling; if one is not installed, the card shows its name.

## No website? Use her Instagram

If she has no website, or gives an Instagram link or @handle, never fetch it from the brand tool (it returns Instagram's own logo). Pull from her public profile instead, the same way as `performance-insights.md` (her own Apify account): her profile picture, name, and her latest 6 posts (for carousels, the first slide). Write `{"handle":..., "name":..., "profile_pic":..., "posts":[image urls]}` to a temp JSON and run `python3 engine/tools/brand_colors.py --instagram that.json`. Profile picture becomes the logo, posts become the photos, colors come from them. Stories cannot be pulled (they expire and need her login); if she wants one, she drops a screenshot in the inbox. Then she can edit everything on the My brand page.

## Her brand font (Canva and others)
She can upload her own font file (.ttf or .otf) on the My brand tab. If her brand kit is in Canva: fonts she uploaded to Canva herself are files she already has, so she uploads the same file. Canva's own library fonts cannot be downloaded from Canva; many of them are free Google Fonts, so she can download the same family from fonts.google.com and upload that, or pick the nearest font from the list on the My brand tab. Never ask for her Canva login.
