# "I posted it": log what happened

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

**Goal:** after she posts, capture the results in a few clicks so the engine learns which hooks win. Without this, the hook bank never improves.

**Before you start:** read her saved rules. Follow `clickable-choices.md`. Plain words only; the first time you use a metric name, add a one-line translation (saves: people who bookmarked it; shares: people who sent it to someone).

**Trigger:** she says "I posted it", or the plan/film step finishes and she says she posted. Also offer it once, a few days after a post, when she opens a new chat.

## Steps
1. **Which one?** Click the script (newest first, from `customer/scripts/` or the plan). If a script has two hooks to test, ask as a click which hook she posted: **Hook A** · **Hook B**.
2. **Where and when?** Assume Instagram and today unless she says otherwise.
3. **Pull the numbers automatically.** She should not have to write numbers down. Use her saved Instagram handle (from `customer/insights/performance.md` or her profile; ask once if missing). Follow section 0 and 2 of `performance-insights.md` (her own Apify account, say the tiny cost first, one OK): run `apify/instagram-reel-scraper` for her handle with `resultsLimit` 10 and do not skip pinned posts, and turn on the shares count only if the actor offers it. Check the real field names in the first result. Match the post to the script by its caption's first line, or by the newest reel if only one was posted today, and confirm with one click: **Yes, that one** · **A different one**. Take views, likes, comments (and shares if returned) straight from the result. Public data never includes saves, so for saves only, ask one tiny question: "Saves are private to you. Open the post, tap View insights, and tell me the saves number, or paste a screenshot of that screen and I'll read all of it." Skip is fine; a missing number is unknown, never zero. If it was posted less than 2 days ago, say numbers settle after a couple of days and pull again later. If the pull fails, fall back to asking for the numbers or a screenshot.
4. **Did it beat her usual?** Compare against her typical views from `customer/insights/performance.md` when it exists. Judge by saves plus shares first. Say it in one plain line, using only her numbers. No outside benchmarks.
5. **Log it with the tool** (this is what makes the engine learn, so never skip it). Run, with the speech environment's Python:
   `~/.cache/content-engine/whisper-venv/bin/python -X utf8 -I engine/tools/results.py add --kind reel --title "<script title>" --hook "<the hook she posted>" --pattern "<the pattern from her hook bank, like question or myth-bust>" --views N --likes N --comments N --saves N --shares N --ab A`
   For a carousel, pass the carousel's folder so the engine learns which LOOK works for her: `--kind carousel --carousel customer/content/<folder> --reach N` (the look is read from its slides.json; after 3 or more carousels in a look and 5 or more carousels in all, `learned.md` says which looks beat her typical carousel and the look picker leans toward them). Use `--kind carousel` (with `--reach`) or `--kind story` (with `--frames --forward --back --exits --replies`) for those. Leave out any number she doesn't have (unknown, never zero). Use `--ab A` or `--ab B` when two hooks or two covers were tested, with the same `--title`, so the tool can compare them. It saves `customer/insights/results-log.jsonl` and `results-log.md`, scores each post by saves plus shares (per 1,000 views when views are known), and rewrites `learned.md` and `learned.json`. Also add "After posting" to the script file if the plan row has one, and mark the plan row "posted."
6. **Learn.** The tool prints what it has learned. Tell her in one plain line. Before 5 logged posts it says it is not enough to call a pattern, so say "I'll keep watching" and never claim "this works." After that, say which pattern is beating her typical post and which is below it, using only her numbers.
7. Keep moving: **Plan the next post** · **Write another script** · **That's enough for now**.

## Carousel learning (runs by itself, no logging by her)
The engine learns which carousel LOOK works for her. She never logs a carousel. Do this at the weekly refresh, or when she says "update my results".
1. **Likes and comments, automatic.** With her Apify account (one OK, tiny cost, `performance-insights.md` sections 0 and 2), pull her last 30 posts and save the list as JSON in `customer/insights/`. Then run:
   `~/.cache/content-engine/whisper-venv/bin/python -X utf8 -I engine/tools/auto_results.py customer/insights/<that file>.json`
   (add `--dry` first if you want to see the matches). It matches posts to her carousels by caption, then by date, skips posts younger than 2 days, and logs likes and comments. Running it again updates the same rows, it never double counts. Tell her the result in one line ("matched 3 carousels, 1 reel it did not match, 1 post too new").
2. **Saves and shares, from screenshots she drops on Sundays.** The Best performing content tab has a drag-and-drop box. Her screenshots land in `inbox/` named `insights-...`. When she says "read my screenshots" (the box has a Copy button for it), look at each `insights-*` image yourself. For each one, find the post (caption, thumbnail, date), then log it:
   `results.py add --kind carousel --carousel customer/content/<folder> --saves N --shares N [--reach N]`
   It updates the row that is already there, nothing is lost. If you cannot tell which carousel a screenshot is, ask with a click showing her recent carousels. A number you cannot read is unknown, never zero. When all are logged, delete the processed `insights-*` files from the inbox and say how many you logged.
3. **How it learns.** Score is saves plus shares per 1,000 reach. Until saves and shares exist, it uses likes plus 3 times comments, and says so. Nothing is claimed before 5 logged carousels and 3 per look. Until then the look picker rotates looks on purpose (among looks used fewer than 3 times that still fit the content), so there is something to compare. Never use outside benchmarks.

## Template for the log line
`YYYY-MM-DD | script file | hook | pattern | saves | shares | views | likes | winner`

## Where the learning is used
- `step-2-scripts.md` (writing hooks) and `step-planner.md` (planning a month) read `customer/insights/learned.md` first, and lean toward the patterns that beat her typical post. A pattern needs at least 2 posts to count, and nothing is claimed before 5 logged posts.
- `step-4-carousels.md` banks the losing cover for later and compares A and B covers the same way.
- `customer/insights/learned.md` is the one place to look to see what the engine has learned.
- Instagram only shows saves, shares, reach and story taps to the account owner, so she types the numbers or sends a screenshot (see `performance-insights.md` for reading a screenshot).


## Checklist after her FIRST post goes live (once; tick it in `customer/profile/said-once.md`)
- [ ] Offered reply drafts once: "Want reply drafts for the comments so far? Paste a comment and I'll write two or three answers in your voice."

## Then
Offer once: "Want this for TikTok or LinkedIn too?" (`platform-versions.md`). A skip is always respected.
