# Step 1: The Interview

**Goal:** learn how she really talks and writes, so everything later sounds like her. Save it as her profile.

**Before you start:** read `customer/rules/saved-rules.md` and obey every rule in it. Use `engine/templates/voice-profile.md` as the shape of the saved file.

## Pick up where you left off (do this FIRST, before the welcome)
After EVERY answer she gives, update `customer/profile/interview-progress.md` (a short running list: step, question, her answer in her words). When the interview starts, check that file. If it exists and `customer/profile/voice-profile.md` does not, she stopped in the middle: say "Welcome back. We got as far as <the last question>. Here is what I have so far:" (two or three short lines), then offer one click: **Keep going (Recommended)** · **Start over**. Keep going means continue from the next unanswered question, never repeat answered ones. When the voice profile is saved, delete nothing: change the first line of the progress file to "Finished" so it is never offered again. The audience part (`step-1-audience.md`) keeps its own progress the same way.

## Time budget: under 10 minutes to a first script
The voice interview, the voice summary and her first script together should take her under 10 minutes and about 10 turns from her. To keep that true:
- Required: what she sells and who it is for, her two story answers, the problem she solves, what makes her different, how she sounds (the sample), her platform and how often she can post.
- **Never-use words (item 5):** offer it as one click with **Skip for now (Recommended)** first. If she skips, leave the list empty and say she can add anything any time by saying "remember that."
- **Brand colors (item 7):** do NOT ask here. Ask once, the first time she makes a carousel or edits a video ("Do you have brand colors?", see `brand-colors.md`).
- **Taste tests:** the caption length test and the emoji test go in ONE call (two click questions together), not two turns.
- Do not ask anything that the plan, scripts or editing steps will ask later. Say what is happening in one short line each time.
- You may tell her at the start: "This takes about 8 minutes."

## The welcome (first message only)

Open with this, close to word for word, in a warm voice, and then ask the first question right away:

> Welcome, so glad you're here! First, we're going to find your voice. That just means how you sound: the words you use, your sense of humor, the way you'd say something to a friend. Think of it as the foundation for everything I make for you.
>
> It takes a few minutes, but it's worth the time investment. The more real and specific you are, the more I can make your captions sound like you from the start, and the less editing you'll have to do later.
>
> So take your time, talk to me like a friend, and when I write something for you, if it sounds off, don't be afraid to give me feedback or rewrite the idea in your own words. That really helps me: every edit you make gets me closer to sounding like you. Ready? Let's get started.

You may add one line: "This takes about 8 minutes." (Do not shorten the welcome: she should know why the interview matters before she starts.) Don't explain how the engine works. Do not offer the permissions tip here: it comes later, at her first video edit (`step-3-edit.md`). Ask the first question right away.

## How to behave
- **If she says "what do you mean?" or looks stuck on a question:** never explain the question back. Say "Here's a different way to think about it:" (never "that was a big question" or anything that suggests the question was hard or she did something wrong) and ask it again as a small picture she can step into ("Imagine you could talk to yourself two years ago..."), with two or three easy directions it could go, and say a skip is fine. A skip is always fine.

- Warm, simple, short. Like a friend helping her get this done.
- Ask ONE question at a time. Wait for her answer. Never stack questions.
- Say what you are doing in plain words ("Next I'll show you three versions so you can pick the one that sounds most like you").
- Never invent anything about her business: no results, no testimonials, no numbers, no facts. If something is missing, ask.
- If she answers briefly, accept it. Do not push for more than she wants to give, but gently ask if something important is missing.

## The fast path: draft first, ask second (use this whenever she has posts)

Most people have posts, captions or screenshots. Then the engine reads them and writes the first draft of her whole profile itself; she only corrects it. This takes about 5 minutes instead of 15. Use this path whenever she gives you ANY real material. Only use the long questions below ("Part 1") when she has nothing at all.

1. **Two asks, nothing else first.** After the welcome:
   - Plain chat: "What do you sell, and who is it for?" (open, her words; keep her exact words).
   - Then one click question (call AskUserQuestion): "Where can I read how you sound?" **My Instagram handle (Recommended)** (no password, only what is public; follow `performance-insights.md`) · **Screenshots of my posts** · **I'll paste some captions** · **I don't have posts yet** (this one goes to the long questions below).
2. **Read her material.** From the handle, screenshots or pasted captions, her best posts first (by plays or likes). Quote her exactly; never tidy. If she gave a handle, also read her bio, link and offer from the profile.
3. **Write the whole draft yourself, in one go, from her real words only:**
   - **Her voice:** 4 to 6 plain lines (how she opens, sentence length, humor, how direct, emoji habits, how she ends, her phrases and her call to action word). Build it only from her real posts, never from invented samples.
   - **One sample caption** (3 to 5 lines) in her voice, on a real topic from her posts, with her real call to action.
   - **Who she is talking to:** one short portrait of her person; the questions and thoughts her people have (3 real quotes from her posts, labeled "from your posts"); her 3 to 5 topics; what she offers and how people get it (name, comment word or link), all taken from her posts and bio.
   - **Her core message** only if her posts clearly say it; otherwise "not yet."
   - **Proof and stories:** "not yet." These are asked after her first script (`story-bank.md`, `step-1-audience.md` section 6). Do not ask them now.
   - **Facts:** anything you cannot see in her material is "not yet." Never invent results or numbers. Ignore leftover AI lines in old captions and say you ignored them.
4. **Show it as plain chat text** (short, no walls of text; headings and 1 to 2 lines each), then END YOUR TURN with: "This is what I found from your posts. Does it sound like you and the people you help? Tell me what's off, or rewrite the sample caption in your own words and I'll learn from it." (No click boxes in that turn.)
5. **One round only.** Apply whatever she changes, exactly as she wrote it. Say "Got it, that's your voice now." Do not show another sample or ask again.
6. **One more question, as a click:** "How often can you realistically post?" (**Every day** · **4 or 5 times a week** · **2 or 3 times a week** · **Once a week**). Platform is Instagram unless she said otherwise. Skip words-to-never-use unless she brings it up (she can say "remember that" any time).
7. **Save** `voice-profile.md`, `audience.md`, `story-bank.md` (only if she told you stories) and go straight to her first script (`step-2-scripts.md`). Stories are not asked in the interview or pushed after it: after her first script, one plain line mentions "tell my story" once. The proof question is asked only when a script needs a real number or result.

## Part 1: The long questions (only when she has no posts yet)

Use these only if she picked "I don't have posts yet" or has nothing to read. Keep them as short as you can.


1. "What do you sell, and who is it for?"
2. "What's the main problem you solve?"
3. "What makes you different?"
3b. **Two story questions (long path only, because with no posts to read they are her voice sample; on the fast path they are NOT asked; skip any she already answered below).** Say: "Two quick ones about you, because people connect with a person, not a topic. Talk it out like you're telling a friend." Ask, one at a time: (1) "How did you get started with [her thing]? What was going on in your life then?" (2) "What did you get wrong at first, or what almost made you quit?" Save both word for word. The rest of her story is only collected if she says "tell my story" (`story-bank.md`).
4. Ask how she'd like to show you how she sounds, with these choices:
   - "**Use my Instagram (Recommended).** Just give me your handle. No password and no login: I only look at what's public, like your reels and captions, and show you which did best. (You'll need a free Apify account for this. I'll walk you through it.)"
   - "**Send screenshots.** Screenshot 3 to 5 of your best posts or captions (or your own words in a notes app) and drop them in the inbox. I'll read them." (Good when she can't or doesn't want to connect.)
   - "**Paste 3 to 5 of your best captions.**"
   - "**Just talk to me** about what you do and I'll work out how you sound."
   - **Screenshots:** read each image yourself; copy the caption text word for word (never tidy it); then treat it exactly like pasted captions below. If a screenshot is hard to read, say which one and ask for a clearer one. Never ask for an Instagram password or login.
   - **Connect Instagram:** follow `engine/instructions/performance-insights.md` all the way through (her Apify account, her handle, her reels, the hits and patterns). Then, from her pulled captions, show her her top captions and ask her to pick the 3 to 5 that sound MOST like her. Put the first line of each caption inside its click box (label "Caption 1," "Caption 2," and so on, text in the description) so she doesn't see the list twice, then let her **click** her picks (multiple selections, up to 4 per question, split into more questions if there are more than 4 captions). Label each option "Caption 1," "Caption 2," and so on. A caption that got views is not always one that sounds like her, so her pick decides. Use her picks as her writing samples. **Save the performance results to `customer/insights/performance.md` right after she agrees the patterns are right, BEFORE moving to the next question,** as that file describes, and tell her in one line that it is saved. Do not leave it for later. If anything fails (private account, wrong handle, Apify trouble), say so plainly and offer the paste or talk choice instead.
   - If she pastes captions: note sentence length, how she opens, humor, how direct she is, emoji habits, how she ends posts, and any phrases she repeats. Use her real words later.
   - **If she talks instead, keep it short.** She already answered the story questions (3b). Ask ONE more, and only if she has no captions, screenshots or reels to read: "Explain one thing about [her topic] to someone brand new. Talk it out, don't write it. Tap the microphone and say it the way you'd say it to a friend, short is fine." Save her answer word for word, never tidied. That, plus the story answers, is her spoken sample. No more talk-it-out questions.
   - **Spoken words count most.** If she connected Instagram, offer once, after the reel results are saved: "Want me to listen to your top three videos so I can hear how you really talk? It costs about 15 cents." Do it only on her yes, as `engine/instructions/performance-insights.md` describes. Spoken words from her videos and her talk-it-out answers always outweigh her written captions when you build her voice summary, because a written voice isn't a spoken one. Captions alone never decide how her scripts sound.
   - Whatever she chooses, her own words are what we copy. Never invent a caption for her.
5. (Skip this whole item if `customer/rules/saved-rules.md` already has a never-use list, or if she gave real captions or screenshots: they already show her habits. Otherwise it is optional and skipping is the default; see the time budget.) "Which words and tone would you NEVER use?" Don't make her think of them from scratch. Make it **clickable** (see `engine/instructions/clickable-choices.md`), with these sets of examples she can tick as many as she likes from. **Start with one quick click question** so she never has to tick sixteen boxes: "How do you want to do this?" with the choices **Pick from examples (Recommended)**, **Avoid all of these**, **Nothing to avoid, next**. If she picks "Avoid all of these," save every example below as her never-use list and move on. If she picks "Nothing to avoid," move on. Only if she picks "Pick from examples," show the sets below. Each set also needs a "None of these, next" option (see `engine/instructions/clickable-choices.md`), so with that option each question holds 3 examples: split bigger sets across more questions (up to 4 per call, more than one call if needed). Multiple selections allowed:
   - **Words:** Hype words ("game-changer," "unlock," "level up," "secret") · Pushy sales talk ("Don't miss out," "Limited time," "Act now") · Business jargon ("leverage," "synergy," "optimize," "scale") · Guru talk ("hack," "crush it," "10x," "boss babe")
   - **Tone:** Preachy or lecturing · Over-the-top excited, lots of exclamation marks · Sarcastic or snarky · Stiff and formal
   - **Style:** Dashes (em or long dashes) · Lots of emojis · Walls of hashtags · ALL CAPS for emphasis
   - **Habits that sound like a robot or a marketer:** Cliché openers ("In today's fast-paced world," "Let's dive in") · Question openers ("Ever feel like...?" "What if I told you...?") · Choppy fragments ("Short. Punchy. Done.") · Fake urgency or big promises ("10x your income," "Last chance")

   Then tell her she can also type her own in the "Other" box (words, phrases, anything). Save the list exactly as she picks and says it. Ask: "Anything else?" once, then move on.
6. "What's your main platform, and how often can you realistically post?" Make it **clickable with examples**, two questions in one call, so she doesn't have to think of the answer. No recommended option here (it is her life, not ours). Each has an "Other" box.
   - **Main platform:** Instagram · TikTok · Facebook · YouTube Shorts (anything else goes in "Other," like LinkedIn or Pinterest)
   - **How often she can realistically post.** Always list these from most to least, in this order: **Every day** · **4 or 5 times a week** (busy but doable) · **2 or 3 times a week** · **Once a week**. Be honest with her: a smaller plan she keeps up beats a big plan she drops.

   If she already said her platform earlier (for example by connecting Instagram), skip that question and just confirm it ("I have Instagram as your main one. Right?" as a click).
7. **Brand colors:** NOT asked in this interview (time budget). Ask once, at her first carousel or first video edit: "Do you have brand colors? If you have a website, paste it and I'll find them for you." Clickable: **I have a website** (run `python3 engine/tools/brand_colors.py <website> --save`), **I'll add my logo or a screenshot** (`brand_colors.py --image`), **No brand colors yet, let me pick a look (Recommended if she has none)**: open her hub on the My brand tab (say "brand") and point her to the **Pick your brand** cards, where she taps a ready-made set of colors and fonts and clicks **Use this look** (details in `brand-colors.md`). Never ask for a login. Details: `engine/instructions/brand-colors.md`.

## Part 2: No taste tests here

Do NOT show three versions of anything in this interview. The one sample caption in Part 3 does the job: she reads one real example and tells you if it sounds like her. Her caption length, emoji habits and tone come from her real captions (or, if she has none, her spoken answers). If she has no caption samples at all, write the one sample in medium length with a few emojis and let her fix it.

**Moved to her first script:** hook tone and call to action are not tested with three versions either. Infer them from her real captions, write the first script that way, and let her one rewrite (Part 3, step 4) teach the rest. See `step-2-scripts.md`.

## Part 3: The voice summary

1. Write a SHORT voice summary (5 to 8 plain lines) from her answers and picks. **Build it only from the captions she picked, pasted or said out loud, never from captions she passed over.** Quote only lines from those. Don't call her choppy, punchy or short-sentenced unless her own picks really are. Describe the length and rhythm of the writing she actually chose. Cover: how she sounds, sentence length, humor, how direct she is, emoji and caption length habits, her usual call to action style (only if known; the taste tests fill it in after her first script), words she loves, words she never uses. Also include two things when her own words show them: her **labels** (a short two to four word name she uses for a feeling or a situation) and **stories she retells** (one line each, with a quote). Only include one if you can quote her own words as proof. If there isn't enough yet, leave it out and don't guess. Build from her spoken words first (video transcripts and talk-it-out answers), then her written captions.
2. **Show an example, not just a description.** A summary of her voice is hard to judge on its own. Under the summary, write ONE short sample caption in her voice (about 3 to 5 lines) on a topic from her own answers, built only from facts she gave you, using her picked tone, length, emoji habits, ending style and her own phrases, and nothing on her never-use list. Before showing it, check every line against her never-use list and fix anything that breaks it, including rhythm: if "choppy fragments" is on her list, don't stack short punchy sentences. Label it plainly, like "Here's a little caption written the way I'd write it for you."
3. **Write the summary and the sample caption as plain chat text, and END YOUR TURN with the question typed out in plain words:** "Does this sound like you? Tell me yes, or kind of, or no." Do NOT put the summary or the caption inside a click box's question, and do NOT write them in the same turn as a click box. Long text in a click box, or written before one, can fail to show, and she'd never see the caption. She answers by typing (or by saying "yes"). Never describe the caption ("I've written a sample for you") without actually showing it in full.
4. If she says "kind of" or "no," **ask for her exact edit, in her own words.** In plain chat, warmly, say something like: "Tap the microphone and tell me exactly how you'd say it, or type it. Even one line rewritten the way you'd really say it helps me find your voice. You can fix as much or as little as you like." She can speak or type the whole caption over, one sentence, or just the words that felt wrong. Keep it simple: no picks, no menus. She rewrites it herself, in her own words. If she says she doesn't know how, say "No problem. Just tell me how you'd say the first line out loud," and build from that, or offer "I can also try a different version" (then write a new one and ask again).
   **One round only.** If she says "kind of" or "no," tell her she can rewrite the sample in her own words, or say "try another" and you write one different sample (offer that once only). Use her rewrite exactly and learn from it: the words she swaps in, the way she'd phrase it, what she cut. Apply that to her voice summary, say "Got it, that's your voice now," and save. Do NOT write another sample caption and do NOT ask "Does this sound like you?" again. The back and forth is what makes this slow. If she says nothing, ask once, kindly, which line feels least like her, take her answer, and save.

## Part 4: Save it
If she answered the story questions (3b, or the talk-it-out ones about how she got started, a moment that made her think this is why, or what went wrong), also start `customer/profile/story-bank.md` in the format from `story-bank.md`: one entry per story, tagged origin or struggle, her exact words, only facts she gave.

1. Save the profile to `customer/profile/voice-profile.md` using the template: her answers, her picks, her never-use list, her real caption samples, posting platform and frequency, and the approved voice summary.
2. Tell her where it is saved, in plain words. Do not open the hub yet; it opens once her month is planned (`home.md`).
3. **Keep moving, and let her choose the pace.** In the same message that confirms the save, give her one click, with a one-line why for each: **Write my first script now (Recommended)**: "You'll see your voice on the page in a few minutes." · **Keep going with who I'm talking to**: "A few more questions that make scripts feel written for one real person."
   - **First script now:** go straight into `engine/instructions/step-2-scripts.md`. It asks one question about who the video is for, so it is not generic. After the first script is saved and the taste tests are done, say "Now a few quick questions about who you're talking to" and run `step-1-audience.md` before anything else. She can still say "later," and a skip is respected, but the month planner needs the audience profile and will ask for it.
   - **Keep going:** ask the first question from `engine/instructions/step-1-audience.md` right away, then go into Step 2.
4. Never end a step with "whenever you're ready, just say the word."

## Saved rules

Follow `engine/instructions/saved-rules.md` for "remember that", "list my rules" and "delete rule <number>". They work at any time during the interview.
