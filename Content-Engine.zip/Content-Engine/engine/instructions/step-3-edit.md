# Step 3, Part 2: Edit Her Video

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

**Goal:** turn her recorded video into a finished vertical video, with as few Claude credits as possible (`engine/instructions/low-credit-rules.md`). Programs do the work. Claude makes one small decision, runs the tool, and opens the edit sheet.

**Before you start:** read `customer/rules/saved-rules.md`, her chosen look (see "Her look" below), and follow `engine/instructions/video-style-rules.md`. No emojis in your own messages.

## 00. The permissions tip (first edit only)
Before her first edit, offer the one-time permissions tip from `engine/instructions/permissions-setup.md` as a click (**Show me how** · **Skip for now**). Keep it quick, and never offer it again after she answers. Tell her the model-picker tip in `low-credit-rules.md` at the same time.

## 0. Her look (first time only)
If `customer/profile/look.md` doesn't exist, show her the ten looks from `engine/looks/looks.json` as a visual picker she can click (no look is marked recommended), then save her choice to `customer/profile/look.md` (just the look id and name). Never ask again unless she says "change my look."

## 1. Find the video
First run `library.py scan` (see `step-3-record.md`). If there is exactly one video with status "new", use it and its labeled script without asking. If there are several, ask as a click which one (by its label). After a good edit, set the status: `library.py status FILE edited`, and after she says she posted it, `library.py status FILE posted --posted DATE`.
Use the newest video in `customer/videos/recorded/` (say its file name back to her), or the one she names. Work on a copy. Never move or delete her original.

## 2. Tell her it takes a few minutes
One warm line: "I've got this. Go grab a coffee, I'll have it ready when you're back." Then run everything below without checking in.

## 3. Listen first (about 20 seconds, no video made)
Run, from the engine folder, with the speech environment's Python:
`~/.cache/content-engine/whisper-venv/bin/python -X utf8 -I engine/tools/first_edit.py VIDEO --look LOOKID --script SCRIPT.md --listen-only`
- `VIDEO` is her recorded video. `SCRIPT.md` is the script she recorded (gives the hook text).
- On Windows use the same relative path under her home folder with `Scripts/python.exe`.
- This writes a short **pick sheet** (`customer/videos/edited/<name>_pick-sheet.txt`, about 15 lines). Read ONLY that file, never the full transcript.

## 4. One small decision (this is Claude's only thinking job)
From the pick sheet, write two small files next to the edited video:
- `<name>_graphics.json`: 3 or 4 full-screen phrases, taken word for word from what she said. Choose the most impactful: a claim, a contrast, a number, the call to action. Format: `[{"phrase": "in one sitting", "text": "In one sitting", "hi": "sitting"}]`. `hi` is the word shown in the look color.
- `<name>_effects.json`: **add-ins are part of every first edit, by default.** Pick 3 to 5 add-ins that fit what she said, using the short guide `engine/tools/addin-guide.txt` (when to use each, and its text format). Mix the kinds, put them on different lines, and keep it calm (about one graphic every 6 seconds, none in the first 6 seconds). Format: `[{"effect": "count", "phrase": "12 years", "text": "12|years marketing"}]`. The gallery is at `engine/tools/gallery/` (she can browse it in the edit sheet).
- `<name>_gifs.json`: 2 or 3 moments for meme-style GIFs, with a short search phrase: `[{"phrase": "scrolling for ideas", "query": "scrolling phone confused"}]`. Only if Giphy is connected (`engine/instructions/connect-giphy.md`); otherwise skip it. Never put a GIF on a moment that already has a big graphic.

## 5. Build it (about 2 minutes)
Run the same command without `--listen-only`, adding `--graphics <name>_graphics.json`, `--effects <name>_effects.json` and `--gifs <name>_gifs.json`. Read only the last "Done" line. Do not look at video frames unless she reports a problem.

## 6. Hand it over
1. Tell her where it is, with a clickable link to the video, and say it is on her hub's **Edit** tab.
2. **Open her editor for her, and make sure she can see it.** Start the hub if it is not running (`home.md`), open `http://127.0.0.1:8780/#edit` and say plainly: "I opened your editor in your browser. Find [video name] and click Edit." Then ask a click question (AskUserQuestion): **Do you see it?** · **Yes, I see it** · **No, I don't see it**.
   - **No:** give her the link ("Click this: http://127.0.0.1:8780/#edit"), tell her to check for another browser window or tab, and run `open_sheet.py` again. Ask the same click question once more. If she still cannot see it, run `get-help.md` (the setup check and a help packet). Never leave her unsure whether it opened.
   - **Yes:** go on.
3. Tell her in three short lines what to do: "Trim cuts what you don't want. Style is how it looks. Audio is sound and your voice. Press Save changes as you finish each step, then Finish up to build your video. The editor costs you no credits."
4. Then stop. She'll come back when she's done or has a question.

## Notes
- Versions are kept: `<name>_edit1.mp4`, `_edit2.mp4`, and so on. Never overwrite one.
- The tool finds her face and keeps small graphics off it. Full-screen takeover words are the one exception.
- If anything fails, say so in one plain line and offer `/report-a-problem`-style help: run the tool again once, and if it still fails, tell her what happened.

## When she says "I left notes"
The edit sheet has a notes box (and a Note button on each line). Saved notes go to `customer/videos/edited/<name>_notes.txt`, a short plain-text file with the time, the line, and her note. Read ONLY that file (it is small), then do what the notes ask in the cheapest way:
- If a note is something the edit sheet's own buttons can do (cut a line, a takeover, a GIF, the look), make that change by writing it into a new decisions file and building a new version, then tell her in one line what you changed.
- If it needs something the tool can't do yet, say so plainly and offer the closest thing. Never promise what isn't built.
- Combine all her notes into ONE build, not one build per note.

## Tidying (her standing instruction: do not fill up her computer)
- After every build the tool deletes its big temporary files (about 860 MB) and keeps only the **newest two** finished versions of that video. It tells you in one line what it freed. Don't ask her each time.
- Never delete her original recording in `customer/videos/recorded/`. If her disk is getting full, offer once to list the oldest recordings and let HER choose; never delete them yourself.
- If she wants a particular older version kept, copy it to another name (like `<name>_favorite.mp4`) so the tidying can't remove it.

## 7. Optional: finish in CapCut
The edit sheet has a **Send to CapCut** button (next to Build my video). It applies whatever she changed on the sheet and makes a folder, `customer/videos/capcut/<name>_for-capcut_vN/`, and opens it. No back and forth with Claude. The folder holds:
- `1-video.mp4`: her video, already cut, zoomed and leveled, nothing drawn on it
- `2-graphics.mov`: a transparent layer with the hook, big words, GIFs and add-ins (no captions)
- `3-sounds.wav`: the little whooshes, pops and pings, lined up
- `4-captions.srt`: her captions as a file CapCut can import
- `READ-ME.txt`: the steps
All files are the same length and start at 0:00, so they line up. In CapCut she puts the video on the main track, the graphics layer above it, the sounds on an audio track, and imports the captions file or lets CapCut make its own.
If she asks you to do it instead of using the button, run the same edit command with `--capcut`. `--clean` makes only the video and captions file (no graphics or sounds layer).
It does not import a finished project. CapCut has no official way to load a project from outside, and the tools that try break when CapCut updates. Say so only if she asks. Never send both her styled captions and CapCut's captions on the same video, or the words show twice.

## 8. Optional: a before and after to post
The edit sheet has a **Before and after** button. It makes a split screen of her raw video next to her finished one (first 18 seconds), then a big end card with the real numbers (raw length, edited length, how many words of retakes were cut). It saves to `customer/content/proof/` and opens it. Use it for proof posts. Offer it once after her first edit, as a click: **Make my before and after** · **No thanks**. If she asks you to do it, run `python3 engine/tools/make_beforeafter.py customer/videos/edited <name>` with the speech environment's Python. Only real numbers are shown. Her raw video is never changed.

## 9. Reel features (what is on by default, and the switches)
On for every reel, each with a switch on the edit sheet (under the number cards checkbox) and a flag: silence, filler and retake cuts; word-by-word bouncing captions (`--captions lines` for plain lines); voice cleanup (`--no-clean-audio`); sound leveling at -14 LUFS; punch-in zooms (sheet switch, `--zoom 0` off); little sound effects (`--no-sound`); progress bar at the top (`--no-progress`).
Optional, only when she asks or it fits:
- **Floating head scene:** write `<name>_scenes.json`, like `[{"phrase": "created an engine", "text": "The engine", "hi": "engine", "seconds": 3.4}]`, and add `--scenes <file>`. She floats in front of a still background with big words behind her. `bg` can be `gradient` (from her look), `color:#RRGGBB`, or `image:/path/to/picture`. Use one or two per video, on a strong line, never in the hook.
- **Cover frame picker:** `python3 engine/tools/make_covers.py customer/videos/edited <name>` saves three clean frames (no text) to `customer/content/covers/`. She picks one.
- **Before and after:** section 8. **Send to CapCut:** section 7.
Never invent content: every cut and caption comes from her real transcript.
- **Wide video (not vertical):** the engine follows her face in the tall crop automatically (`--reframe off` or the sheet switch to turn off). **Shaky video:** `--stabilize` or the sheet switch (gentle smoothing, not a rescue). **Speed changes:** `<name>_speed.json` like `[{"phrase": "the important line", "speed": 0.6}]` with `--speed <file>` (0.6 is slow motion, 1.5 is fast). **Freeze frame:** `--freezes <file>` with `[{"phrase": "...", "seconds": 0.9}]`. **Closing card:** `--endcard "COMMENT ENGINE|ENGINE"` or the sheet field. **Blur the background:** `--blur-bg` or the sheet switch. **Name and title bar:** the `lowerthird` add-in, text like `Name|Title`.
- **Always test new features in a scratch folder (`--out`), never in her edited folder.**
- **B-roll cutaway:** `<name>_broll.json` like `[{"phrase": "the line", "file": "/path/clip.mp4", "seconds": 2.8, "transition": "whip"}]` with `--broll <file>`. `file` can be her own video clip or a picture (a picture gets a slow push in). `query` instead of `file` pulls a free stock clip from Pexels if she has a Pexels key. Her voice keeps playing and captions stay on top. Never during the hook.
- **Transitions** for full-screen inserts (B-roll, floating head scene, freeze frame): add `"transition": "whip"` (fast slide with motion blur), `"iris"` (circle opens), `"wipe"` (slides across), `"flash"`, or `"fade"`. Defaults: whip for B-roll, flash for freeze, fade for scenes. They go out with a short fade.

## 10. Transcript
After every edit, run `~/.cache/content-engine/whisper-venv/bin/python -X utf8 -I engine/tools/transcript.py customer/videos/edited <name>`. It writes `customer/videos/transcripts/<name>_transcript.txt`: what is in the edited video, and everything the engine heard (cut words in brackets). Tell her where it is with a link. She can ask "show my transcript" any time. The speech tool can mishear a word (names, slang), and fixing the caption word on the edit sheet fixes it in the video.

## Before her FIRST edit: her style (checklist, tick it in `customer/profile/said-once.md`)
- [ ] Offered "learn my style" once (see `learn-my-style.md`). If `customer/profile/style.md` exists, read it before every build and let it shape the cut pace, caption look and how often graphics appear.
- [ ] Her own GIFs (`customer/profile/gifs/`) are used before a Giphy search.

## Caption styles, mixed in one reel (built)
Three caption styles. **pop** is one big bouncy word at a time (the default). **karaoke** is a line of words with the spoken word lit up. **lines** is a plain line. Set a default with `--captions pop|lines|karaoke`, or mix styles in one reel with `"caption_styles"` in the decisions file, in output-video seconds: `[{"from":0,"to":4,"style":"karaoke"},{"from":4,"to":8,"style":"pop"},{"from":8,"to":99,"style":"lines"}]` (also `"none"`). A good mix: karaoke through the hook, pop on the punchline, plain for the rest. Captions always step aside under a full-screen takeover. If she says "show me the caption styles," make three 6-second previews of her own clip (one per style) and show them. When she asks for a caption look by name, use it. If her saved rules say "ask me which caption style," ask first as clicks.

## Her word list (built)
`customer/rules/word-list.txt` holds names and words the speech tool mishears. One line per entry: a name to listen for (`Rachel`), or a fix (`nplan => Claude`, meaning "when you hear nplan, write Claude"). The editor adds these to what the speech tool listens for and corrects the captions. When she says "add that to my word list," add the line (ask once for what it was mishearing if she did not say), confirm it in one line, and tell her it applies to every reel from now on. Never delete a line without asking.

## Effects she can ask for by name (built)
**Show me the effects:** run `python3 engine/tools/make_effects_page.py` and open the page it prints (`engine/tools/effects.html`). Each effect plays with its name and a line to say. Effects only appear when she asks for one (or when you pick 3 to 5 add-ins for a reel and name them in the creative plan, so she can say "not that one"); every other reel stays in her style. When she loves one, run the saved-rule flow so it comes back by name.
New in this round: **Shimmer sweep** (`shimmer`), **Bar chart** (`chart`, type it like `Week 1 12|Week 2 28`), **Slam words** (`slam`), **Glitch text** (`glitch`), **Orbit carousel** (`orbit`, she chooses up to eight pictures) and **film grain** for the whole reel (`--grain`, or `"options": {"grain": true}` in the decisions file). The add-in effects go in `<name>_effects.json` like the others; to rebuild the preview GIFs after adding one, run `~/.cache/content-engine/whisper-venv/bin/python -X utf8 -I engine/tools/build_gallery.py 1 KEY`.

## The live editor (built, first version: live cut, captions and hook)
The edit sheet has an **Open live editor** link (page `/live`). It plays a small, smooth copy of her original (made once, about a minute, with a progress cover) and shows her words. She taps a word to cut it or brings it back, and the preview skips the cut right away (the same cut rules as the build: `plan_cuts`), with an "Updating" dot while it recalculates and an Undo button. The captions (the default one-word "pop" style) and the hook box are the very pictures the build drew, in the same places, saved in `.live/<name>_layers_vN/` by each build, so they match the finished video. **Build my video** on that page makes a new version with the same build as always. If a reel has never been built since this feature, or uses karaoke or plain-line captions, the page says captions appear after a build. Wide (landscape) videos are not supported in the live preview yet. Not yet in the live editor: moving or resizing graphics, add-ins and GIFs on the footage, sounds, a timeline. Do not tell her it does those.

**Hook styles (built).** Her hooks no longer all look the same. There are eight hook designs, all drawn in her palette: Classic box, Big stack, Highlighter, Sticker, Editorial (serif), Handwritten, Ribbon and Outline (`engine/tools/hook_styles.py`). On a new build, if she has not picked one, the engine chooses the best fit for the length of her hook and avoids the styles used on her last reels (kept in `customer/profile/hook-history.json`), and remembers the choice in the edit plan so rebuilds keep it. In the live editor, a **Your hook** panel shows the three suggested styles drawn on her own words, plus "More styles"; tapping one swaps it on the preview right away. She can also change the words (stars highlight a word), resize the hook, and drag it anywhere on the picture (red bands show where Instagram covers the screen; dropping it there is allowed, and the page says so in one line). Decisions keys: `hook`, `hook_style`, `hook_scale`, `hook_dy`, `hook_dx`. The preview uses the same drawing code as the build, so they match. If she says "my hooks all look the same," open the live editor and offer the styles.

**Safe area on the live preview.** The picture shows Instagram's covered areas in red (top, bottom and the right-side button strip) so she can see where her hook and words will be hidden. A box under the picture hides them. They are a guide only; nothing is refused.

## Move or resize the picture (live editor)
In the live editor, "The picture" panel lets her shrink the whole video or drag it up/down/sideways (for a weird screen recording). A blurred copy of the video fills the empty space behind it. Saved as `video_scale`, `video_dx`, `video_dy` in the decisions; the build applies it before the face check and overlays.

## Record a voiceover (live editor)
The "Record a voiceover" panel records her mic in the browser while she watches the cut picture (muted). She can play it back, re-record, and set how much original sound to keep. "Use this voiceover" cuts the picture her way, lays her voice on it, and runs the normal editor on that (captions come from the voice she recorded). The result opens as its own edit sheet named `<video>-voiceover`. Her original recording is never changed.

## Caption styles from her font spec
`--captions` now also takes `soft` (Karaoke Soft: sentence case Poppins, the spoken word sits in an accent box; the calm default for reluctant marketers), `phrase` (Phrase Clean: Inter, a calm phrase with one accent word) and `boxed` (Boxed Broadcast: Roboto on a dark box, for busy footage). They can be mixed by range like the others. Spec: `reel-font-system.md`. The live editor preview still shows pop captions; the finished video uses the chosen style.

## Captions you can see and pick (live editor)
"Your captions" shows three suggested styles drawn from her own words, in plain names: Lit-up word, Calm phrases, On a dark box. More styles: Big bouncy word, Line with lit word, Plain lines. Clicking one changes the preview at once and is used in the build (`caption_mode` in the decisions). Never tell her the technical names (soft, phrase, boxed).

## Pick a vibe
"Pick a vibe" has eight plain-named vibes (Clean Authority, Warm Friend, Editorial Premium, Bold Teacher, Honest Confession, News and Data, Soft Reassurance, Launch Pop). One click sets caption style, hook style and intensity (`feel`, `intensity`). Her colors do not change. Launch Pop is for launch weeks only; warn if she stays on it more than 14 days.

## Taste ceiling
Intensity 1 to 3 (default 2 for older reels, 1 for most feels). The build keeps at most 1 / 3 / 3 full-screen words and 1 / 2 / 3 stat cards, and prints a TASTE line when it trims. Two more hook styles use the new fonts: Poster drop and Soft pill.

## Add text and extras (live editor) and the text jobs
The "Add text and extras" panel puts names, labels, lists, quotes, question bubbles, POV openers, last lines, fine print and fun moments on the video at the playhead (`texts` in the decisions: kind, text, detail, start, seconds; or `phrase` instead of `start`). Also `watermark` (her handle, whole video), `signoff` (a Caveat sign-off at the end), `season_accent` (a hex color that swaps the accent for a season), `hook_drop` (the last hook word lands a beat late), `destination` (reels, stories, tiktok, shorts: moves the safe-zone preview and the caption height), freeze `note` (a comment on a freeze frame), caption style `past` in `caption_styles` ranges (the muted typewriter "before" voice), and hook style `behind` (huge words behind her head; falls back to in front if the outline tool is missing). Kinds: lowerthird, chapter, list, quote, question, label, monolabel, pov, cta, watermark, disclaimer, strike (crossed-out rewrite), signoff, redpen, receipt, typed, costume. Defined in `engine/tools/text_jobs.py`. Every build also saves a captions file (`.srt`) next to the video. Keep fun to one moment per reel and follow the taste ceiling in `reel-font-system.md`. Brand colors: `brand-colors.md`.

## Ideas and variety
Every build saves `fun_suggestions` (fun moments that fit what she said, such as a crossed-out rewrite for "instead of", a word costume, or a typed search bar for a question hook) and `fatigue` notes (the same caption style, hook style or extra on 3 of her last 5 videos; history in `customer/profile/style-history.json`). The live editor shows them in "Add text and extras" as ideas she can add or skip. Extra kinds: `countup` (a real number rolling up) and a ghost-echo word behind `quote`. Not built: glass panels, parallax, bilingual captions, per-letter mixes.

## The live editor is four tabs (modeled on the editor she likes)
Cut (tap words) · Visuals (every line of what she says with what is on it, plus vibe, captions, hook, move the picture, add text, brand colors) · Sound (voiceover, sound effects, zoom, progress bar) · Finish (where she will post it, Build, then "ask Claude for a carousel, stories, trial reels or other platforms"). The phone preview stays on the side. "+ Add" on a line jumps the preview there and opens the add-text box. Each tab ends with a Next button. Do not add new boxes without asking her.


## Brand colors, once
The first time she edits a video or makes a carousel and `customer/profile/brand.json` does not exist, ask once: "Do you have brand colors? If you have a website, paste it and I'll find them for you." (`brand-colors.md`). A skip is always respected; never ask twice.

## Cover a face (kids and anyone she does not want shown)
In the live editor, Visuals tab, **Cover a face**: she taps **Find the faces in my video** (it works on her last built video), taps each face to cover, picks the cover (blur, pixelate, or a sticker: smiley, heart, star, flower, sun, bear), and builds. The cover is built into the footage (captions and hook stay on top) and is saved as `face_cover` in the decisions. Tool: `engine/tools/face_cover.py` (`analyze`, `apply`). The build lists "moments to check" where a cover may have slipped (`face_cover_checks` in the plan, shown in the panel). Faces are found by looking, so a face turned away or very small can be missed: ALWAYS tell her to watch the finished video before posting, and never promise it is perfect. If she says "cover my kids' faces" in chat, send her to this panel.

## The Visuals tab is line by line
Every line she says is a row with a look card: what is on that line (captions only, big words, an effect from the effects library, a text card, a picture, GIF or clip), a **Change** button and a "..." menu (add a picture, GIF or clip; add a note for Claude; take everything off the line). Too-fast lines show "May be too quick to read" with an "It's okay" button. The row buttons at the top (Captions, Vibe, Hook, Move the picture, Cover a face, Text and extras, Brand colors, Effects library) open as pop-ups. The bottom bar has play, the timeline and one big button that changes with the tab (Next: Visuals, Lock in my looks, Next: Finish, Build my video). Finish has MP4 or CapCut, the build, a player for the finished video, and copy buttons for "Make a carousel / a story / trial reels / for TikTok" to paste to Claude. Her choices on lines become `graphics`, `effects`, `gifs` and `broll` in the decisions. Notes on lines are saved for Claude (`notes_by_line`, and the notes file); when she says "check my notes", read them.

## Several clips for one reel
When she gives you more than one clip for one reel, join them first: `python3 engine/tools/merge_clips.py NAME CLIP1 CLIP2 ...` (in the order she wants), then edit the merged video as one. The tool records which clips went in, so the Edit page does not list them as "not edited yet". Spoken cut cues in the footage ("cut that", "sorry, exit that part") are cut by hand from the word list in the plan, because the engine only removes restarted takes by itself.
