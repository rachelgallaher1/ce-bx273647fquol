# Notes to the plan: "update my plan from my notes"

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list.** See `clickable-choices.md`.

**Goal:** she can change her plan by writing a note on the Calendar, the way she would say it ("one more video a week", "hard sell on Nov 5", "make a video about feeding a starter", "no posts on Sundays"). The note is saved by the hub; this step reads it, changes the plan, builds what is needed and redraws the calendar. She never edits the plan file.

**Trigger:** she pastes or types "Update my plan from my notes" (the Calendar button copies it), or says "update my plan."

## 1. Read the notes
Run `python3 engine/tools/plan_notes.py list`. Read her saved rules, her marketing settings (on-camera, off-limits, conversion goal), her pillars and the plan (`plan.py weeks`). If there are no notes waiting, say so in one line and offer to take a note by chat.

## 2. Turn each note into plan changes (do not apply yet)
- **"One more video a week" (or "fewer videos"):** add or drop a video on an empty day in each remaining week with `plan.py add DATE video JOB IDEA`, picking ideas from her pillars, banked ideas and story bank. Respect her on-camera setting and the posts-a-week she chose. Say the new weekly total.
- **"Hard sell on <day>":** `plan.py mix N "HARD PITCH"` for that post, then rewrite that day's script as a direct offer: one clear action (her conversion goal), her real offer name and facts only, honest and not pushy. Run the compliance scan.
- **"Make a video about <topic>":** `plan.py add` on the next empty day (or swap an existing unbuilt post with `plan.py swap`), and write the script from her voice, audience and story bank. If she says which day, use it.
- **"No posts on <days>" or "move things":** `plan.py shift` or `plan.py roll`; only unbuilt posts move. Posted, filmed, edited and fixed days (launch, a sale, an event) never move without her saying so.
- **Anything unclear:** ask ONE click question with 2 to 4 readings of what she meant.

## 3. Show it and confirm (one click)
List the changes in 3 to 6 plain lines ("Add a video on Tue Nov 10 and Tue Nov 17. Make Nov 5 a hard sell for the starter."). Then ask: **Looks good, make the changes (Recommended)** · **Change something** · **Skip these notes**.

## 4. Apply
Apply the plan commands. Build full scripts only for the current unlocked week (and anything she asked for by name); later weeks get outlines (`step-planner.md` section 4). Use only real facts; never invent numbers or results. Mark each note done with a one-line result: `python3 engine/tools/plan_notes.py done ID "Added a video on Nov 10 and Nov 17"`. Regenerate the calendar (`python3 engine/tools/make_calendar.py`) and open her hub on the Calendar (`home.md`). Say what changed in 2 or 3 lines and ask the click question for the next step.

## Rules
- Never change a post that is posted, filmed or edited, or a fixed day, without asking.
- Keep a backup: the plan file is copied to `.before-edit` by the hub; do the same before big changes (`cp plan.md plan.md.before-edit`).
- Her notes are requests, not commands to obey blindly: if one would break an honesty rule (a fake result, a false claim), say so in one line and offer the honest version.
