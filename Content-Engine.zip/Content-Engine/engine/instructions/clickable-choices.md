# Clickable Choices

She should be able to **click** her answer, not type a number or a letter, whenever she is choosing between options. Use the clickable question tool (`AskUserQuestion`) for these. Typing stays available: the tool always gives her an "Other" box for her own words.

## Hard rule

Choices are made with the `AskUserQuestion` tool. A typed numbered list in chat ("1. ... 2. ...", "Pick all that fit") is a mistake, even if you also say "type a number." If you wrote one, replace it with a tool call right away. The tool is always available; do not skip it because it feels easier to type the options.

## When to use it

- Picking from a list (which captions sound like her, which tone, which words to avoid).
- Choosing between a few approaches, with one marked **(Recommended)** per `engine/instructions/recommended-choices.md`.
- Yes or no checks where clicking is quicker.

Do not use it for open questions that need her own words (what she sells, who it is for, what makes her different). Ask those in plain chat.

## How to use it

- **Don't show the same thing twice.** Put what she needs to judge INSIDE the click boxes, not in chat above them. Label each option simply ("A," "B," "C," or "Caption 1") and put the actual text in that option's description line. Say only one short line of intro in chat.
- Only when a text is too long to read comfortably inside a box (for example, a long caption), show it once in chat, and keep the boxes as plain "A," "B," "C" with no repeated text.
- Each question holds 2 to 4 options. For longer lists, split into several questions in the same call (up to 4 questions per call).
- When she can choose several (captions that sound like her, words to avoid), allow multiple selections.
- Put the recommended option first and end its label with **(Recommended)**.
- Keep labels short and plain. Put the longer explanation in the description line.
- Never add an "Other" option yourself. It is provided automatically.
- **Who, what and how-many questions are multiple choice by default.** For questions about who she serves, what she offers, what her content is about or which moments apply, many people have more than one answer, so turn multiple selection on. Where there is room, add one option **Something different (I'll add a note)** so it is obvious she can type her own. Only a true either-or (A or B or C) is single choice.
- Ask one clickable set at a time, then respond to her picks warmly before moving on.

## Never show choices as a numbered list in chat

If you are offering options to pick from, they are click boxes, every time. A typed list ("1. ... 2. ... 3. ...") makes her type a number or retype her answer. This includes lists of examples, moments, topics, offers and tones. Write one short intro line in chat and put the options in the click tool. Only use a typed list if the click tool is unavailable (see the end of this file).

## Never make her type to get past a question

She must always be able to move on with a click.

- **A way out on every optional question.** If the question is optional (words to avoid, habits to keep, anything she may have nothing for), one option is always "None of these, next" (or "Nothing here, skip"). Never leave typing in the "Other" box as the only way to say "nothing."
- **An "everything" option for long lists.** When she might want all of them, ask a quick first question, before showing the long list: "Pick from the examples (Recommended)" / "All of these" / "None, next." Only show the individual examples if she chooses to pick. This avoids making her click ten boxes to say "all."
- **Count the slots.** A click question holds 4 options. If you add "None of these, next" there are 3 left for real choices, so split bigger lists into more questions in the same call.
- Only skip the way out when an answer is truly required to continue (for example, which choice from A, B or C).

## Long text goes in plain chat, not in a click box

Click boxes are for short choices. A summary, or a sample caption she has to read and judge as a whole, is long text: write it as plain chat text, end your turn, and ask the question in words. Never put long text in a click box's question line, never write it in the same turn as a click box, and never say you wrote something without showing it. Short sample lines inside option descriptions (the A, B, C tests) are fine.

## When you don't understand her

If her reply is unclear, don't ask "what do you mean?" in plain chat. Give 2 to 4 likely meanings as click options with a plain example of each, plus "Other." Keep your guesses based on where you are in the step.

## Open questions get examples too

For questions that need her own words (what she sells, the problem she solves), keep them open but add one short line of plain examples from someone else's business, clearly labeled as examples, so she isn't staring at a blank box. Never put those examples into her profile.

## If it isn't available

If the clickable tool isn't available or fails, ask in plain chat with numbered options and tell her she can just type the number.
