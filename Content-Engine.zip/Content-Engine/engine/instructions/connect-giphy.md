# Connect Giphy (for GIFs and memes on her videos)

GIFs and meme-style pictures come from Giphy. Searching Giphy needs **her own free Giphy account and key**. It takes about three minutes, once. Offer it the first time a video could use GIFs, and say plainly it is optional: without it, her videos still get captions, takeover words and stat cards.

## Say it in one warm line
"Want meme-style GIFs on your videos, like the ones you see on yapping reels? You'll need a free Giphy account. It takes about three minutes and I'll walk you through it."

## Steps (one at a time, she does the clicking and signing up)
1. Go to **developers.giphy.com** and sign up or log in. (The regular giphy.com page is a different thing. The key lives on the developers site.)
2. Click **Create an App**, choose **API** (if only iOS, Android and Web show, choose **Web**), and name it anything.
3. Check the box and click **Create App**.
4. Copy the **API key** shown (a long string of letters and numbers) and paste it into this chat.

## Saving the key
- She pastes the key in chat. Save it ONLY to `~/.cache/content-engine/giphy.key` (a private file on her own computer, permissions 600). Never put it in the engine folder, the customer folder, a script, or any message you write back. Never echo it. Tell her it stays on her computer.
- Test it with one search and say "Giphy is connected" in one line.
- On Windows, save it to the same relative place in her home folder.

## Pictures (optional)
For stock photos, the same way: a free **Pexels** key (pexels.com/api) saved to `~/.cache/content-engine/pexels.key`. Pexels sometimes pauses new keys; then use a free **Pixabay** key instead (pixabay.com, log in, open the API docs page, the key is shown there), saved to `~/.cache/content-engine/pixabay.key`. The photo tools use whichever key is saved.

## Always say this once
"Many GIFs come from movies and TV. Instagram can occasionally mute or flag a reel that uses them. Giphy's G-rated filter helps, and it's your choice."
