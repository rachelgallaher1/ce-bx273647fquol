# Video Style Rules

Rules for everything drawn on a customer's video (hook, captions, graphics). These came from Rachel and apply to every look and every video. The edit tool `engine/tools/first_edit.py` follows them, and any new graphic must too.

## Never cover a face
- **Do not put text, cards, labels or pictures over a person's face.** Small graphics (stat cards, labels, pictures, stickers) go in free space: beside, above or below the face. The tool finds the face and picks the clearest spot. When her face fills most of the frame (a close-up), there may be no clear spot, so the tool can still land near the forehead. Never promise a customer "it will never cover your face." Say "I keep graphics off your face as best I can; check the preview and fix any on the edit sheet."
- Nothing small ever lands on top of another graphic or on top of the captions.
- The one exception is a **full-screen takeover**, which is meant to cover the whole screen. Place it in the middle of the screen and keep it brief.

## Calm, not busy
- No bounce, no overshoot, no jumping. Things ease in gently with a soft fade.
- Captions show as a whole short line (at most four words), not word by word.
- Highlight a word only every now and then: a long word, never two lines in a row.
- If it feels like too much on the eyes, take something away.

## Captions
- **Plain white words with a thin dark outline.** No box behind them. The outline keeps them readable on any picture.
- One word now and then in the look's highlight color.
- They sit about 70 percent of the way down the screen, above the bottom zone Instagram covers.

## Full-screen takeover
- Big words that fill the screen, **white, on the normal picture. Do not dim or darken the video.**
- One word in the look's highlight color. A dark outline keeps the white readable.
- Captions step aside while a takeover is on screen.

## Safe zones (1080 by 1920)
- The top 270 pixels and bottom 300 pixels carry background only, because Instagram covers them.
- The hook starts at 280 pixels from the top (about 15 percent), just below Instagram's name and audio line, so nothing is cut off.

- On the right edge, from about 52 percent down to about 86 percent down (roughly the right 120 pixels), Instagram puts its like, comment and share buttons. Keep key words out of that strip too.
- The live editor shows all three areas in red on the preview (top 270 px, bottom 300 px, and the right-side buttons), with a box to hide them.

## Her look
- Colors and fonts come from `engine/looks/looks.json`. Never invent a color or a font.

## Progress bar
A rounded bar sits low on the screen (about 81 percent down, inside the safe zone and above Instagram's bottom area), a light track with a fill in the look's highlight color. It used to be a thin line at the very top, which Instagram's own top bar hides. It is on by default and can be turned off with `--no-progress`.

## Photosensitivity floor (always)
Nothing on her videos may flash. No full-screen white flashes, no strobing, no shake that changes more than about three times a second. The freeze-frame flash is a soft brightening only, and the glitch effect changes slowly. If a new effect would flicker, change it before adding it.
