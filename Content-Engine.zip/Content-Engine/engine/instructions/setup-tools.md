# Setting up the video tools (one time per computer)

The video steps (edit, add-ins, carousels from video) use free tools on her computer. Setup happens once. Claude does the typing; she only says OK.

## When to run
Before the first edit, or when a build fails. Run the check first:
`python3 engine/tools/check_setup.py`
If the last line says READY, stop and go on. Never reinstall what is already there.

## Say it in plain words first
"To edit your videos I need a few free tools on your computer. It takes about 5 to 10 minutes and happens once. I'll tell you if anything goes wrong." Get her OK, then follow the fixes in order. Install only what the check reports MISSING.

## Fixes (use the code printed next to the missing item)
- **F1, ffmpeg missing.** Mac: if `brew` is missing, tell her Homebrew is needed and walk her through brew.sh in one small step at a time (she types her computer password herself, never in the chat); then `brew install ffmpeg`. Windows: `winget install Gyan.FFmpeg`, then close and reopen the app so it finds it.
- **F2, helper Python space missing.** Needs Python 3.12 (3.13 or newer breaks the speech tool). Mac: `brew install python@3.12`. Windows: `winget install Python.Python.3.12`. Then `python3.12 -m venv ~/.cache/content-engine/whisper-venv`.
- **F3, a library missing.** `~/.cache/content-engine/whisper-venv/bin/python -m pip install "av<17" faster-whisper "numpy<2" "opencv-python-headless<5" "mediapipe==0.10.21" pillow` (on Windows use `Scripts\python.exe`).
- **F4, wrong version.** Same command with `--force-reinstall` for the named library. Newer versions break the face finder and the person cutout.
- **F5, not enough room.** Tell her she needs about 5 GB free. Offer to show the biggest folders in Downloads; delete nothing without asking.

- **F6, the engine folder is in a place that syncs (Desktop, Documents, iCloud, OneDrive, Dropbox, Google Drive).** Say it plainly: "Your computer can quietly move big video files out of those places when space runs low and leave a placeholder behind. The file looks like it is there, but I can't open it. Let's give the engine a safe home." Walk her through it one step at a time (she does the clicking): open her user folder (Mac: Shift + Command + H; PC: File Explorer, type %USERPROFILE% in the address bar and press Enter), make a folder called **Projects**, move the whole engine folder into it (Mac: drag it; PC: cut and paste), then reopen Claude in the engine folder at its new place. Never move or delete anything yourself without her OK, and never touch `customer/`.
- **F7, no inbox folder.** Make an empty folder named `inbox` at the top of the engine folder (next to `engine` and `customer`) and put `inbox/README.txt` in it from the product copy if it exists. Tell her what it is for (see "The inbox" below).
- **Wrong folder opened.** If `CLAUDE.md` is not in the folder she opened but exactly one folder inside it holds `CLAUDE.md` and `engine/`, say: "You opened the outer folder. The engine is the one inside it, the one with no version number in its name. Let's open that one." Have her reopen Claude there.

After any fix, run the check again.

## The inbox (her one place for new videos)
`inbox/` at the top of the engine folder is where every new video goes, so nothing sits scattered in Downloads. She pins it to her sidebar once (Mac: drag it into Favorites; PC: right-click, Pin to Quick access), then AirDrops or saves every video into it. When she says "edit the video in my inbox," run `python3 engine/tools/inbox.py list`, show the videos as clicks, and when she picks one run `python3 engine/tools/inbox.py take FILE` (it copies the video into `customer/videos/recorded/` and adds it to the library; her original stays in the inbox, untouched). Then go on with `step-3-edit.md`. Never delete or rename anything in the inbox.

## Stuck? Three most common failures
1. **"Command not found" after installing.** The app needs a restart so it sees the new tool. Ask her to quit and reopen the app, then run the check again.
2. **Install is slow or seems frozen.** The speech tool is a large download (a few hundred MB). Wait up to 10 minutes on slow wifi before calling it stuck.
3. **A password or permission prompt.** Her computer may ask for her password to install. She types it in her computer's own window, never in this chat. If the system blocks it, she may need an administrator to allow the install.

If a fix fails twice: stop, tell her plainly what failed in one line, save the exact error to `customer/setup-problem.txt` so she can send it to support, and offer to skip video editing for now and continue with scripts (which need no tools).

## First-run note
The first time the speech tool runs, it downloads its model (about 460 MB). Say so before it starts, so a pause doesn't look like a crash.
