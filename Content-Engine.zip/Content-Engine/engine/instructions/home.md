# Her home: everything in one place

Her folder has two files at the top: **Open My Content Engine.command** (Mac) and **Open My Content Engine.bat** (Windows). Double-clicking one opens **My Content Engine** in her browser: one page with tabs along the top.

- **Calendar:** her content calendar (Today, Week and Month), with each day's real file and caption. A banner appears in the last week of her plan with a "Plan next month" button.
- **Batch day:** the guide for filming a batch, the teleprompter button, and the drop box that edits her whole batch.
- **Edit:** every video, with Edit, Download, Show in folder and Write my caption buttons. Edit opens the editor right there (Trim, Style, Audio, Finish up).
- **Carousels:** her **My looks** row first (the eight built-in carousel looks in her colors: heart favorites, "Use for my next carousel", and "Add a look you love"), then every carousel she has made (and text reels), with every picture.
- **Stories:** every story set made from her posts, with every picture.
- **Best performing content:** her best posts, how much better they did than usual, and ways to reuse them.
- **My brand:** her logo, font, colors and photos, plus her voice and her audience. Everything on it is editable.

The page is called **Social Media Content Hub**. A small pill at the top right shows "Everything is working" or what needs attention.

## How to talk about it
Tell her once, early: "Double-click **Open My Content Engine** in your folder any time. Everything is in the tabs at the top." The first time on a Mac, if it says it cannot be opened, tell her to right-click it, choose **Open**, then **Open** again. A small black window stays open while she uses it (tell her it is fine to leave it, and to close it when she is done). On Windows, if it asks to allow network access, click Allow.

If she says "open my engine", "open my calendar" or "open my content engine" in chat, run `python3 engine/tools/batch_day.py hub` (with the speech environment's Python: `~/.cache/content-engine/whisper-venv/bin/python -X utf8 -I engine/tools/batch_day.py hub`) in the background and give her the link http://127.0.0.1:8780/ . If it is already open it just brings the page up.

When you finish something for her (a script, a video, a carousel, a story set), tell her which tab to look in. Do not hand her file paths.

## Open it for her once: when her month is planned (do not wait for her to ask)
Do not open the hub earlier (not after the interview, not after the first script): before the 30 days are planned it is mostly empty. When her month plan is built, start the hub in the background (command above), open http://127.0.0.1:8780/#calendar and say what she sees ("Each day shows the idea, the script and the caption"). Open it once, not every time. If it is already open, just give her the link. Then keep going with the next click question in chat; the hub does not replace the conversation.

## Always check that she can see it
Whenever you open the hub or an editor for her, ask one click question right after (AskUserQuestion): **Do you see it?** · **Yes, I see it** · **No, I don't see it**. If no: give her the link in plain text to click, tell her to check other browser windows or tabs, and run the setup check (`get-help.md`) if it still does not show. Never assume it opened.

## One-word tab commands, any time
When she types just one of these words, do it right away, with no questions first: start the hub in the background if it is not running (`~/.cache/content-engine/whisper-venv/bin/python -X utf8 -I engine/tools/batch_day.py hub`; on Windows the same with `Scripts\python.exe`), open the matching address, say one line about what she is looking at, and ask the click question **Do you see it?** (see above).

| She types | Open | Say |
|---|---|---|
| **edit** (or "open my editor") | `http://127.0.0.1:8780/#edit` | "I opened your hub on the Edit tab. Click Edit on any video." |
| **calendar** (or "open my hub") | `http://127.0.0.1:8780/#calendar` | "I opened your calendar. Each day shows the idea, the script and the caption." |
| **content** (or "carousels") | `http://127.0.0.1:8780/#content` | "I opened Carousels: your looks and every carousel you have made." |
| **stories** | `http://127.0.0.1:8780/#stories` | "I opened Stories, every story set you have made." |
| **batch** | `http://127.0.0.1:8780/#batch` | "I opened Batch day, your film-day guide." |
| **results** | `http://127.0.0.1:8780/#results` | "I opened Best performing content." |
| **brand** | `http://127.0.0.1:8780/#brand` | "I opened My brand: your logo, colors, voice and audience." |

If she types the word together with a name ("edit my calendar video"), open the tab and say which card to click. Do not ask which tab she means: the word is the answer.
