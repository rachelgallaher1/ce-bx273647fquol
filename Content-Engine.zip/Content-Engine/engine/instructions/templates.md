# Approve-once templates (carousels and stories)

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

Her five templates (cover, body, checklist, quote, last-slide ask) are built once from her look, brand colors and signature mark, shown on one page, and approved ONCE. After that every carousel and story set uses them, and the tool flags drift instead of redesigning per post.

1. Build the sheet: `python3 engine/tools/make_carousel.py --template-sheet --look <id> --handle @her --motif tape` (writes a phone-size preview under `customer/profile/template-preview/`). Show it in chat with a link.
2. One click: **These look like me (Recommended)** · **Change something** (a different mark, a different look, or her brand colors; then rebuild the sheet).
3. When approved: `python3 engine/tools/make_carousel.py --approve-templates --look <id> --handle @her --motif tape --signoff "..."` (adds `--motif-text` for the stamp). This writes `customer/profile/templates.json`.
4. From then on `make_carousel.py` fills the look, handle, mark, sign-off and grain from that file, and prints a `Template drift` note if a carousel uses a different look or leaves out the mark. Stories and highlight covers use the same look and mark.
5. Re-approve only when her brand or offer changes. If she says "change my look", rebuild the sheet and ask again.
