# Month Planner: plan the month, build the week

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

**Goal:** give her the whole month as a plan (cheap), and build the content one week at a time, just in time (expensive), so every week is smarter than the last. The promise: "a month of content, planned, scripted and edited for you."

**The principle:** planning is cheap, building is expensive. The month plan (idea, hook, format, why it is there, for every day) costs little and gives her the full vision and a full calendar. Word-for-word scripts, video editing and carousel rendering cost credits and go stale, so they happen week by week, informed by last week's real numbers. A script written three weeks early cannot learn from last week's flop.

**Before you start:** read `customer/rules/saved-rules.md` and obey it, her voice profile, her audience profile (including "My core message") and `customer/profile/target-persona.md` if it exists, `customer/insights/performance.md`, `customer/insights/hook-bank.json`, `customer/insights/results-log.md`, `customer/insights/winners.jsonl` and `customer/insights/learned.md` if they exist. Read `engine/instructions/script-craft.md`, `clickable-choices.md`, `recommended-choices.md` and `low-credit-rules.md`. Use `engine/templates/month-plan.md` and `outline.md` as the shapes. Read `surfacing-map.md` first: the customer has a conversation, not software, and every feature appears once at its moment. Read `customer/profile/marketing-settings.md` and follow `marketing-features.md` (pillars, sell and value mix, off-limits, things she refuses, conversion goal, seasonal ideas, compliance scan on every script, and the extras in its sections H to K). If the settings file is missing, create it silently and fill it only as each question's moment arrives (section A of that file). Order for a new customer: interview, pillars, the three planning clicks, the plan, then at approval the conversion-goal question and the week-1 build with the first script. Nothing else comes first.

If her voice profile is missing, the interview comes first. If her audience profile is missing, run `step-1-audience.md` first, because a plan built without her audience is generic. If she insists on skipping, use the one question from step 2 of `step-2-scripts.md` and tell her the plan will be less sharp.

## How to behave
- Warm, plain, short. One question at a time, as clicks where possible. Keep it moving.
- Never invent results, stories, numbers or offers. Missing facts are blanks in brackets for her.
- Write nothing beyond the plan until she approves the plan.
- Her saved rules and never-use list always win.
- Helper: `python3 engine/tools/plan.py` answers "which week is this," "what is missed," and moves things (see its top comment). Use it instead of counting dates yourself.

## Weeks
Weeks are calendar weeks, Monday to Sunday, and the refresh is always Sunday. If she plans mid-week, **week 1 is the partial week** (its remaining days are built right away) and the first refresh is the first Sunday after planning. Number the weeks with `plan.py weeks`.

## 1. Three quick clicks (all three in ONE AskUserQuestion call, as three click questions, never a typed list)
1. **How many posts a week?** 3 (light) · 4 (Recommended: busy but doable) · 5 · 7. Say the total for the month.
2. **How many of those can be videos she films?** Videos are the heavy part. Recommend about half the posts. The rest are carousels (made from the same videos) or text carousels on days with no video. **The plan only ever has three formats: video, carousel and text carousel. Stories are never planned as a day of content.** Choices: **A few (1 a week)** · **About half (Recommended)** · **Most of them**.
3. **Anything coming up this month?** A launch, a sale, an event, a holiday, a trip. Click **Nothing special** or pick one and tell me the date. These become fixed days.

## 1b. Reels she wants to remake (optional, ask this right after the three clicks)
Ask as a click: **I have reels I want to remake** · **No, just plan my month (Recommended if she has none)**. If she says yes, say plainly: "Paste the links to reels you've seen and want your own version of. Up to 5 is plenty. I'll study how they're built and make your own version, in your voice, about your topic." She pastes the links in chat (one per line). Then:
1. **Cost, then OK.** Say it in one line: "Looking up each reel costs a few cents, and about 5 cents for every minute of video if I listen to what they say." Wait for her OK. Use her own Apify account (see `performance-insights.md` section 0). Run `apify/instagram-reel-scraper` with her links, with transcript on. Check the real field names in the first result. If a link is private or fails, say so plainly and move on.
2. **Study the structure, not the words.** For each reel, write down in plain words: the hook pattern (a question, a number, a scene, a claim), the beats in order, the length, the pace, and what the viewer is asked to do at the end. Save to `customer/insights/reels-to-remake.md` (link, creator handle, date, what you saw). Never save their video file anywhere she could post it.
3. **Make HER version.** For each reel, add a post to the plan tagged **remake** with her own idea: the same shape (hook pattern, beats, length), on her topic, from her audience's moments, in her voice. Put "Inspired by: <link>" in the plan row so she remembers where it came from.
4. **Hard rules.** Never copy their words, their script, their footage, their sounds, their on-screen text or their story. The idea of a format (like "3 mistakes", "day in the life", a myth-bust) is free to use; their expression of it is theirs. Never claim their results, clients or stories as hers. If a reel only works because of the creator's own story, say so and suggest the closest true story she has, or skip it. Never tag or mention the creator unless she asks.
5. In the plan table, show remakes plainly in the "Why it's here" column: "Remake of a reel you loved (your own take)." If she gave more reels than there is room for, bank the rest in `reels-to-remake.md` for next month.

## 2. Build the plan (the strategy layer)
Make a table of every post for the next 30 days starting today. Each row has: post number and date (spread evenly, no two big videos back to back), format (exactly one of: video, carousel, text carousel; never stories), job (get found, keep people, get them to act, or proof), the idea in one line, and why it is here in one line.

Rules for the mix:
- No offer yet: use only get found, keep people and proof, never an "act now" post.
- With an offer: about one in five posts gets them to act, never two in a row (a launch is the exception, on purpose).
- **Proof posts:** about 1 in 7 shows a real result, a before and after, or a real moment. Use only what she has told you is true. No proof yet: make it a "behind the scenes of how I do it" post and say so. Leave brackets for missing details.
- **Show the transformation, hide the recipe.**
- Vary the ideas across at least four topics. Repeat her best pattern, not in a row. Bring back one or two of her winners from `winners.jsonl` per month (see `content-that-hit.md`), never in a row, and never one about something she no longer sells.
- **Her core message** shows up in about 1 post in 3, in her own words. Mark those rows "Core message" in the why column.
- Tie every idea to a moment or word from her audience profile. Fixed days first, the rest built around them.

**Two depths.** Week 1 is built in full (section 3). Weeks 2 to 4 get **outlines only** (section 4). Never write full scripts for future weeks at plan time.

**Fixed-day exception:** any fixed day (launch, event, holiday) inside the next 7 days is built in full right away, whatever week it is in. A launch does not wait for Sunday.

Show the whole plan in plain chat (not a click box), with week 1 marked "built now" and later weeks marked "outline, script unlocks Sunday." Then ask, as clicks: **Looks good, build week 1** · **Swap some ideas** · **Cut a few posts** · **Add a post**. For swap, cut or add, ask which post numbers, change them, show the updated table, and repeat until she approves.

**Month 1 honesty, say it at approval:** "Month 1 runs on what is working in your niche. From month 2, it runs on what is working for you."

**Right after approval, offer the weekly refresh as one click:** **Plan the month and refresh it every week (Recommended)** · **Just the month**. Plainly: "Every Sunday I look at how your posts did and build the next week, so each week learns from the last. Say 'weekly refresh' any time." If she picks the weekly option, write "Weekly refresh: on" in the plan Notes, run `python3 engine/tools/make_reminder.py` (writes `customer/plans/weekly-refresh.ics`) and tell her to double-click it so a repeating Sunday reminder lands on her phone calendar. Ask her preferred hour if not 6pm. The engine cannot open itself.

## 3. Build week 1 (right at approval)
**Checklist before you write the first script (tick each in `customer/profile/said-once.md`):**
- [ ] Said the month 1 honesty line and the benchmarks line ("here is what is normal"; with no niche data, say so in one line and move on).
- [ ] Asked the one conversion-goal question ("one quick thing before I write: what is the ONE action you want a follower to take?"). Save it to her settings. **Ask it with the AskUserQuestion tool, never as a typed list:** one single-choice question with up to 3 options taken from what her own posts and audience profile show ("Comment 'starter' and get the details in DMs" · "Buy through my link" · "Book or message me") plus the tool's Other box for her own words, and ask in the SAME call: "Do you have customer messages or photos you can use, with their OK?" **Yes, I have some** · **Not yet, skip this**. If she has some, ask her to drop them in the inbox, then go straight on. **Put the on-camera question and the off-limits question in this same call** (up to 4 click questions at once: conversion goal, proof assets, "How many of your videos will be on camera?" **All of them** · **About half** · **None**, and "Anything off-limits on camera?" **Nothing** · **My kids** · **My home** plus Other). Ask all of them BEFORE you build, so the build message after has no questions except the one next-step click. Never end this step with "say build week 1": after her answers, start building week 1 yourself.
In this order:
1. **Scripts:** write every week-1 video script in one batch with no questions per script, using the quick path of `step-2-scripts.md` and picking the best hook yourself (the other hooks are banked in the script file). Anything that needs a personal story she has not told gets a `[BRACKETED BLANK]`. List them all under "I need from you" and show that list **now** so she fills them before filming. Run the best-friend test and the ten hook checks quietly, then `python3 engine/tools/compliance_scan.py` on each script and caption and show only the flagged lines with a rewrite. Save each as `customer/scripts/YYYY-MM-DD-short-title.md` and put the link in the plan row with status **ready**.
2. **Film-day list:** `customer/plans/YYYY-MM-film-day.md`: the week's videos in the easiest filming order (group by setting and outfit if she told you, otherwise by length), with the hook, the first line, a filming note and a checkbox, plus the five filming tips from `step-3-record.md`. Say: "Film these in one sitting. Drop all the videos in your inbox." Then offer **film mode**, as a click (recommended first): run `python3 engine/tools/make_film_mode.py --phone` and give her the address it prints to type on her phone (same Wi-Fi; it stops by itself after two hours), or tell her she can AirDrop `customer/plans/film-mode.html` to her phone. Film mode shows one script at a time in big text (hook first), with Next, Back, Start over, Auto scroll, text size and a checkmark per video. Blanks are highlighted and flagged: get them filled first. When she finishes, she taps "Tell Claude what I filmed" and pastes the line to you; then update those plan rows to filmed.
3. **Batch edit, then a review pass:** when her videos are in, run `step-3-edit.md` for each with her saved look and default add-ins. Then show her each edited video (or a review-all screen) to approve or re-edit **before anything downstream is made**. Never let a bad edit surface at posting time.
4. **Carousels** from the week-1 videos (`step-4-carousels.md`), and text carousels on no-video days. The engine picks the look for each one and makes it in that look; she can change the style on the carousel's page or from that day on the calendar (each carousel day shows a "Change style or edit" link, and a **Make this carousel** button when its words are written: `engine/tools/auto_carousel.py N` builds it from that day's script with no chat step).
5. **No stories here.** Stories are not planned or built with the week. They are a bonus the engine offers on its own (`stories-bonus.md`). Never put a story set on the calendar as a post.
6. **Remember the file for each post:** whenever a video is edited or a carousel is finished for a plan row, run `python3 engine/tools/plan.py file N PATH` (the finished video, or the carousel's slides folder) so the calendar shows "File to use" on that day. Copy caption on the calendar always adds her hashtag set (the "Hashtag set" line in her settings) after the caption, without repeating tags already in it; ask her for 3 to 5 niche and local hashtags the first time you build a caption and save them to her settings.
7. **Posting calendar:** the calendar page is the posting calendar: each day shows the caption with a copy button and the file to use. Make a printable `YYYY-MM-posting-calendar.md` only if she asks. The engine never posts for her.
**Checklist for the film-day list step:**
- [ ] Offered film mode (the phone teleprompter) once, after the film-day list.
- [ ] Asked how many videos will be on camera (all, about half, none), in the same click call as the conversion goal (not after the build).
- [ ] Asked "anything off-limits on camera?" and saved the answer to her settings.

**Checklist at the end of the week-1 build (do all of these before you finish, then tick each):**
- [ ] Said the unlock line: "Week 2's scripts unlock at your Sunday refresh. Say 'weekly refresh' or 'unlock week 2' any time."
- [ ] Said the "post for today" line once: "Need something on a blank day? Just say 'post for today.'"
- [ ] Said the moment templates line once: "Any time you have a listing, an event or a new product, just say so."
- [ ] Offered mining old posts once: "Want me to look through your old posts for keepers?"
- [ ] Opened the calendar page once on the Month view (add #month to the address), and told her it opens on Today after that.
After week 1, say in one line: "Week 2's scripts unlock at your Sunday refresh. Say 'weekly refresh' any time, or 'unlock week 2' to build now."

**The week-1 message after the build is short:** what is ready (3 to 5 lines), the honest notes (3 short lines), then exactly ONE click question for the next step (**Film post 1 now (Recommended)** · **Plan a batch day** · **Show me my calendar**). Any fact check on a script ("Is it right to say you used to be a teacher?") is its own click question (**Yes, that's true** · **Change it**), asked one at a time before she films, never stacked in the build message. Open her hub on the Calendar once (`home.md`).

## 4. Weeks 2 to 4: outlines (cheap and throwable)
For each future day, write an outline from `engine/templates/outline.md` and save it as `customer/plans/outlines/NN-short-title.md` (no date in the name, so it survives a shift). Each outline has: a one-line **hook** (concrete first, no brag number, no ask), **3 to 5 beats** in order, the **format and filming note**, **why it is there**, and **CTA intent** (soft follow, or a hard keyword ask about 1 post in 3 or 4 while waitlisting or launching). Put the outline link in the plan row with status **outline**. The calendar shows these days as "Planned, script unlocks Sunday."

## 5. The Sunday refresh (the weekly build)
Trigger: she says "weekly refresh." She can run it any day, not only Sunday: the "Weekly refresh: run it now" link on the Calendar's Sundays copies that request, for people planning ahead who do not want to wait. Run it exactly the same way and say "Done early, so next week is ready now." Do these in order:
1. **Get last week's numbers.** **Carousel learning first (automatic):** follow the "Carousel learning" section of `step-posted.md` (pull her public posts, run `auto_results.py`, then read any Instagram Insights screenshots she dropped on the Best performing content tab). Then, for everything else, click: **Pull them for me** · **I'll paste them or send a screenshot**. Pull: her saved handle and `performance-insights.md` sections 0 and 2 (say the small cost first, wait for her OK). Paste or screenshot: read the numbers (reach, likes, comments, saves, shares per post) and log each with `results.py add`. Saves and shares are private, so ask for them. A missing number is unknown, never zero. If she says "I posted it," follow `step-posted.md` and mark the row "posted." Numbers logged the same day a post went up are **too early to call**: say "too early to call, I'll count these tomorrow" and the learning step skips them until the next day.
1b. **Standing questions:** "What did a client ask you this week?", "Any wins this week?" and "What happened this week that you could tell a friend?" (add her answer to `story-bank.md`) (see `marketing-features.md`, section H). Open the refresh with what went right.
2. **Content that hit.** Follow `content-that-hit.md`: new hits in a few lines and ways to bring one back.
3. **Say plainly what worked.** Before 5 logged posts: "Not enough yet to call a pattern, here is what is early." After: name the winning hook pattern and format, in plain words, using only her numbers.
4. **Missed posts.** Run `plan.py missed`. For each: "You did not post [day]'s [idea]. Roll it into this week, or drop it?" Roll with `plan.py roll N DATE` or drop with `plan.py drop N`. Planned days never silently pile up.
5. **Build the next locked week.** Turn its outlines into full scripts and run section 3 steps 1 to 6 for that week, applying last week's lessons: lean into the winning pattern, rest the losing one. Mention any winner she could bring back. Keep it cheap: one writing pass, only for the changed days.
6. **Hook diversity check.** Compare the new week's hooks with the previous two weeks'. No more than two scripts share one hook pattern in a 3-week window. Rewrite collisions.
7. **Never touch** anything already filmed, edited or posted, any fixed day, or any unlocked-but-unfilmed week. Never change the past, only build the future.
8. **This month in three lines (end every refresh with it).** Only her real numbers, plain words: (1) what she posted so far this month out of what was planned ("12 of 17 posted"); (2) the format or hook pattern that did best, and by how much ("your talking videos got about twice the views of your carousels"); (3) one thing to do more of next week. Before 5 logged posts, say "Not enough yet to call a pattern" instead of line 2. Never invent a number. In the last 7 days of the plan, add: "Your plan ends [date]. Say plan my next month."
9. **Save the three lines** to `customer/insights/refresh-summary.md` (the same text she sees).
10. Regenerate the calendar. Then run `python3 engine/tools/refresh_check.py`. It lists every step of this section as PASS or FAIL from the files it left behind. Fix each FAIL once (for a missed post, ask her to roll or drop it; never decide for her), then run the check again. Never tell her the refresh is done while a step still fails: say which one and what you need from her.
11. End with "Say weekly refresh next Sunday." If the reminder is not set up, offer it (section 2).
**Checklist at the end of every refresh:**
- [ ] Opened with what went right (and named any streak).
- [ ] Asked "What did a client ask you this week?" and "Any wins this week?"
- [ ] Handled every missed post (roll or drop).
- [ ] Ran the compliance scan on every new script and caption.
- [ ] First refresh only: said the benchmarks line again (or that there is no niche data yet).
- [ ] First refresh only: said the pause line once: "Going on vacation? Just say 'pause my plan.'"
- [ ] Regenerated the calendar.
Skip the build if the plan is paused (see section 8).

## 6. Unlock commands (build ahead any time)
Recognize "unlock week 3," "build week 3 now," "write next week's scripts," and natural variants: build that week's scripts, film-day list, and the rest of section 3 for that week only. Recognize "unlock the month," "unlock everything," "build it all": build every remaining locked week (this is the batch-filming path).
- Same routine as the Sunday refresh, minus performance analysis. Say so in one line if relevant.
- The refresh never overwrites an unlocked week. Unlocked-but-unfilmed scripts stand as written. The calendar shows them as ready.
- One honest line, then do it: "Heads up, week 3's scripts are usually sharper after Sunday's numbers. Unlocking now anyway." No lecture and no second question.
- A week already filmed, edited or posted has nothing to build: say so in one line.
- Show that week's "I need from you" blanks at once so she can fill them before filming.
- When several weeks are ready, the film-day list runs by week (week 2's videos first, then week 3's), each in easiest filming order.

## 7. Credit discipline
Plan table and outlines are cheap. Full scripts, batch editing and carousel rendering are expensive. When in doubt, outline first and build later. Before any big build (the whole month, or a week with 5 or more videos), give a one-line estimate of how heavy it is and a yes or no to continue. No surprise bills.

## 8. Pause and shift
- **"Pause my plan"** (also "I'm going on vacation"): `plan.py pause`. The refresh skips building until she says "resume" (`plan.py resume`).
- **"Shift everything by a week"** (or N days): `plan.py shift DAYS --keep <fixed day numbers>`. Every unbuilt (outline) post moves forward. Built, filmed, edited and posted content and fixed days stay put.
Both update the calendar and the plan file. One confirmation line, then do it.

## 9. The calendar page
`python3 engine/tools/make_calendar.py` writes `customer/plans/calendar.html` (one self-contained file, works offline) and prints its path. Open it for her; add `#month` to the address the first time so she sees the whole plan, and it opens on Today after that. It has Today, Week and Month views, a copy-caption button (the caption plus her hashtag set), the file to use, five pipeline dots per day, a progress ring and streak, filters, search, print, and an add-to-my-calendar file. Each day shows one of four states: **Ready**, **Planned, script unlocks Sunday**, **Posted**, **Missed**.
**The page is view-only except checkmarks and notes, which save in her browser only** (the page says so). The plan file is the single source of truth. Every real change happens in chat, then you rewrite the plan file and regenerate the page: swapping an idea, marking a post posted ("I posted it"), rolling or dropping a missed post, rescheduling ("move Thursday's post to Friday"), changing a status. There is no editing in the page and no drag to reschedule. Regenerate whenever scripts are written, outlines change, a status changes, or a file is saved with `plan.py file`.

## 9b. Swap a post she does not like
Triggers: "swap post 12," "I don't like this post," "give me a new idea for Thursday," or the **"Not feeling this one? Ask for a new idea"** button on the calendar (it copies a line like "Swap post 12 (Tue Oct 27): I'd like a new idea for this one." for her to paste to you). She never has to explain why. Steps:
1. Never swap a post that is filmed, edited or posted. Say so in one line if she asks.
2. Keep the date, format, job, pillar and sell-or-value label of that row. Only the idea changes.
3. Offer **three fresh ideas as clicks**, recommended one first, each with its opening line. Draw from: the Banked ideas list in the plan Notes, her client-question and win banks, her winners (`content-that-hit.md`), her pillars, her audience's moments and words, and her saved rules and off-limits list. Never repeat an idea already in the plan or one she banked and rejected. Add one last click: **Show me three more** (always fresh ones).
4. When she picks one: run `python3 engine/tools/plan.py swap N "new idea" "why it is here"` (it banks the old idea and refuses filmed, edited or posted rows). Then write what that row needs: an outline if its script is still locked, a full script only if its week is already unlocked (replace the old script file's content or point the row at the new one; never delete the old file without asking). Run the compliance scan on anything new.
5. Regenerate the calendar and say what changed in one line. Tick nothing in `said-once.md`: this is on demand.
6. Keep it cheap: three short ideas, then one outline or script for the one she picked.

## 10. After posting
When she says "I posted it," follow `step-posted.md` and mark the plan row "posted." Use `customer/insights/results-log.md` when the next month is planned.

## Next month
She can say "plan next month" any time. Read the last plan, the results log and the winners bank, keep the winning patterns, and repeat from step 1. From month 2 the plan runs on her own data.

## Commands
"show my plan," "swap post <number>," "cut post <number>," "weekly refresh," "unlock week <number>," "unlock the month," "pause my plan," "resume," "shift everything by a week," "content that hit."



## The content calendar is the home for her files
Her folder has a file called **Content Calendar.html** at the very top (made every time the calendar is built). Opening it shows the calendar. Every day shows the real file for that post: a video player for a reel, a row of slide pictures for a carousel or story set, and a Copy caption button. Always run `python3 engine/tools/plan.py file N PATH` when a video is edited or a carousel or story set is finished, so the day fills in. Tell her once: "Open Content Calendar.html any time. Your finished files are on each day, so you never have to hunt for them." Link to it from every batch page and review page ("Open my content calendar").

## When the plan is first built
Open her hub on the Calendar (`home.md`, "Open it for her") and say what she sees, once. Then keep going with the next click question.
