# Her story bank: the stories that make people connect

**Goal:** people follow a person, not a topic. Capture her real stories once, in her own words, then use them again and again in hooks, scripts, captions, carousels and Instagram stories, so her audience feels they know her. **Real stories only. Never invent, polish into something she didn't say, or borrow a story from anyone else.**

## When to run it
- **Only when she asks.** She says "tell my story" or "add a story." Never push it, and do not make it a step. After her first script, one line mentions it once (see `step-2-scripts.md`).
- Every week in the Sunday refresh, one optional question: "What happened this week that you could tell a friend?" Add her answer to the bank only if she answers.
- Whenever a script needs a first-person moment she hasn't given yet (see `step-2-scripts.md`, true story check): look in the bank first, then ask once.

## How to ask (one question at a time, talk-it-out style)
Tell her: "Just talk the way you'd tell a friend. Rambling is great. I'll keep your exact words." Ask these, skipping any she already answered in the interview (check `interview-progress.md` and her voice profile first):
1. **The before.** "What was life like right before you started [her thing]? What was hard?"
2. **The turning point.** "What made you decide to start, or what moment changed things?"
3. **The struggle.** "What did you get wrong at first, or what almost made you quit?" (Failure stories build trust. Do not rush past it.)
4. **The win.** "Think of a time doing this made you feel proud, or someone told you it helped them. What happened?" (Only what really happened. Numbers only if she says them.)
5. **The why.** "Why do you keep doing this? Who is it for?"
6. **Everyday life.** "What does a normal day look like right now, with the real mess in it?" (Kids, interruptions, mornings: this is what makes people feel they know her.)
After each answer, say one warm line back, then the next question. Save as she says it, typos and slang included.

## Save it: `customer/profile/story-bank.md`
One entry per story, in her words, with a tag line. Format:
```
## Story: <short name in her words>
Tag: origin | turning point | struggle | win | why | everyday | lesson
Her words: "<exactly as she said it>"
True facts you may use: <dates, numbers, names she gave; nothing else>
Best for: hook | teach | connect | proof | stories
Used in: <script or post names, filled in later>
```
Rules: keep her exact words in "Her words." "True facts" holds only what she said. Never add detail. If two stories are one, merge them with her OK.

## How the stories get used
- **Scripts (`script-craft.md`, "True stories only"):** pull a story from the bank for "keep people" and "proof" posts. Open on the moment, not the background. Use the "but / so" test. Tell it small and specific (the Tuesday morning, the burnt loaf), not a summary.
- **Spread them out:** no story twice within 3 weeks. Mark each use in "Used in." The Sunday refresh checks the plan has at least one personal story day every week (the month plan's "keep people" days) and offers a story from the bank.
- **Carousels and Instagram stories:** a story can be a carousel arc (setup, struggle, turn, result) or a 3 to 5 frame stories set (a moment, the problem, the turn, the point).
- **Captions:** open with a real detail from the story, end with her comment word.
- **Fresh stories:** a monthly nudge, "Anything new happen this month worth telling?" Add it to the bank.

## Never
- Never use a story she hasn't told you. Never exaggerate a number.
- Never reuse a client's or family member's story without her saying it is okay to share.
- Never make her feel behind if she has few stories: two honest ones plus everyday life is enough to start.
