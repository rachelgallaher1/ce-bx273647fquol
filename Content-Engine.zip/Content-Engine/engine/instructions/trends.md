# Trends: "is this trend worth it?"

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

**Be honest:** the engine cannot read Instagram's trending list, and it cannot download or embed trending music. What it can do is judge a trend she found, quickly, and turn it into her own angle.

## How
She pastes or describes the trend (a format, a sound, a topic). Answer with a clear yes, no or adapt, in plain words, using these checks:
1. Does it fit what she sells and who she is talking to (`audience.md`)?
2. Can she do it in her own voice without pretending?
3. Does it need something she does not have (a dance, a trending song she cannot license, a person)?
4. Can she make it within two days? Trends expire.
5. Does it break her off-limits list or her compliance rules?
6. Will it lead anywhere near her one conversion goal, or is it only views?

Say the answer first: **Do it**, **Do it her way** (with the adapted hook and script outline in her voice), or **Skip it** (with one line why). Never push a trend that needs her to stray from her message. Her own results (`customer/insights/`) beat any trend: if a trend is close to a format that already hit for her, say so.

## Sounds
Say plainly that the sound has to be picked in Instagram's own app, where the license is cleared. The engine can note an "Audio to try" line in the plan if she tells it one, and her own voice always works. If she wants a finder, it needs her free Apify account and only shows what the public pages say.
