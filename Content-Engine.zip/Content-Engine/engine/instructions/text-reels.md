# Text reels: a reel with no footage

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

**Goal:** a reel made only of her words on her brand colors or her own photos, a few frames long, with gentle motion and her voice or music under it. For the person who dreads filming. It looks intentional, not like a fallback. Offer it when she says she does not want to film, "on camera" in her settings is "none," on a busy week, or when she asks for a "text reel" or "storytelling reel."

Follow `surfacing-map.md`, `plain-words.md` and `clickable-choices.md`. Read her saved rules, voice profile and off-limits list first. Never invent facts or results; every frame is her real words.

## 1. The words
Use a script from her plan or write a short one (3 to 8 frames). Frame 1 is the hook. One idea per frame, 4 to 12 words each. Last frame is the comment word (her conversion goal). Write in her voice. Run the compliance scan on the words.
Mark the key words of each frame as `hi` (shown in her accent color).

## 2. Backgrounds (one question)
Offer as clicks: **My brand colors (Recommended)** · **My photos** (from `customer/profile/brand/photos/`) · **Pick a color**. Per frame she can also name her own picture file. Never a stock photo unless she asks.

## 3. Sound (one question)
**Record my voice (Recommended)** (Voice Memos, 20 to 40 seconds, read the frames in order) · **Music only** · **No sound (I'll pick sound in Instagram)**. With her voice, each frame lasts as long as its words take.

## 4. Build
Write the spec JSON (see the top of `engine/tools/make_text_reel.py`) and run, with the speech environment's Python:
`~/.cache/content-engine/whisper-venv/bin/python -X utf8 -I engine/tools/make_text_reel.py SPEC.json [--voice VOICE.m4a] [--music MUSIC.mp3]`
It saves `customer/content/text-reels/NAME.mp4` and `NAME.caption.txt`. A build takes under a minute. Write the post caption in her voice (with the comment word) and show it with the finished reel. Offer to open the folder.

## Rules
- Words stay out of the top, the bottom and the right edge (where Instagram puts its buttons); the tool does this.
- Her photos and recordings are never changed or deleted.
- Tell her to watch it once before posting.
