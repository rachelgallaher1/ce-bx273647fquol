# Platform versions ("make this for TikTok" / "other platforms")

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

**Goal:** one finished video, the right version for each place she posts, in her voice. Never a copy-paste of the Instagram caption.

Rules and limits live in `engine/templates/platforms.json` (caption length, hashtag count, first-line length, tone, how to ask people to act). Never state a limit that is not in that file.

## Steps
1. Ask one question: "Where else do you want to post this?" as clicks: **TikTok (Recommended)**, **YouTube Shorts**, **Facebook**, **LinkedIn**, **Pinterest**, **Just Instagram**. Skip it if she already told you where she posts (`customer/profile/marketing-settings.md`).
2. For each place she picks, write the caption (and title where the platform has one) in her voice, following that platform's tone and call to action in `platforms.json`. Same idea, new angle for the first line, so it never reads like a copy. LinkedIn is the biggest change: longer, plain, no slang, no "link in bio".
3. Check each one: `python3 engine/tools/platform_check.py <platform> <caption file>` and fix what it flags. Run `compliance_scan.py` on every caption.
4. Video: TikTok and Shorts cover more of the bottom, so rebuild once with `destination` set to `tiktok` or `shorts` in the decisions (the live editor's "Where will you post it?" does this). Instagram, Facebook and LinkedIn can use the Reels file. Every build also saves a captions file (.srt) next to the video for platforms that prefer an upload.
5. Save all of it in one file, `customer/content/<month>/<day>-platforms.md`, with a heading per platform, and show it in the chat with the link. Never post for her.
6. Log which platform did best when she says "I posted it" (`step-posted.md`), so the next plan leans toward what works for her.
