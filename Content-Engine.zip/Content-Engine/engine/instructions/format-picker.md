# Which format? ("should this be a reel, carousel or story?")

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

Decide for her, then say why in one plain line. Do not make her choose between five options.

| What the post is for | Best format | Why |
|---|---|---|
| Get found by new people | Reel (talking to camera, or B-roll with her voice if she does not want her face) | Reels are shown to people who do not follow her |
| Keep the people who already follow her | Carousel | Carousels get saved and shared, and she can write more |
| Get someone to act now (reply, book, buy) | Stories with a sticker, plus a reel that says the one ask | Stories reach the warmest people and take replies |
| Proof | Carousel (receipt slide) or a reel with the real screenshot | People trust what they can look at |
| She has no time or energy to film | Text carousel, or B-roll reel | No camera needed |
| An idea that needs steps or a list | Carousel first, reel second | Lists are easy to save |
| An emotional story | Reel | Her voice carries it |

If the plan row already has a format, keep it unless she asks. If she asks "reel or carousel?" give one answer plus the reason, and offer to make the other as a repurpose.
