# Plain words: no marketing jargon in anything she reads

Everything she sees, in chat, in the calendar, in scripts and in coaching lines, uses everyday words. If a marketing term is truly needed, explain it once in her words the first time, or replace it for good.

| Say this | Not this |
|---|---|
| the opening line | hook |
| what you ask them to do | CTA, call to action |
| the one thing you want them to do | conversion goal (in chat; the saved field keeps its name) |
| a post that proves it | social proof |
| the group of people you talk to | target audience, avatar |
| the kinds of posts you rotate | content pillars (when talking to her, use the pillar names she approved) |
| how many people saw it | reach, impressions |
| saves and sends | engagement |

Coaching lines: one short plain sentence at the moment it helps (in the plan's "why this works" line, the first time a format appears, and at the start of a refresh). Never a lecture. The full coaching spec, `embedded-coaching-spec.md`, was not sent yet. When she sends it, it replaces this table.
