# Reel font system (Rachel's spec, loaded 2026-10-20)

Reference for every piece of text on a reel. Canvas 1080 x 1920. All fonts are free Google Fonts, bundled in `engine/fonts/`. Where this file and `video-style-rules.md` overlap on sizes and treatments for on-reel text, this file wins; the hook-styles file wins for carousel covers. Part I (taste ceiling) beats everything else.

## Ban list
1. Default system font. 2. Weight under 600 on video. 3. Captions under ~52px. 4. No separation from the picture (needs stroke, shadow or box). 5. Whole sentences in one caption chunk. 6. Everything centred and the same size. 7. A different look on every reel. 8. Script, thin serif, gradient or rainbow text for spoken captions.
Fix: heavy weight + thick dark stroke or box + short chunks + one highlight colour + same look for 10+ reels.

## Font library (24)
- Heavy sans: Montserrat 800/900 (default hooks and karaoke; needs the 900 file), Anton, Bebas Neue (all caps, labels), Archivo Black, Oswald 600/700, Poppins 700/800.
- Clean sans: Inter 600/700/800, Roboto 500/700, Open Sans 700/800, Lato 700/900, Nunito 800/900.
- Serif accents only: Playfair Display 700/800 + italic, Lora 600/700, Cormorant Garamond 600 italic (accent words only).
- Mono: Courier Prime 700, IBM Plex Mono 500/600, Special Elite (covers/accents only).
- Hand, 1 to 3 words only: Caveat 700, Kalam 700, Permanent Marker.
- Fallback order: Montserrat Black > Archivo Black > Anton > Inter 800 > system bold. Never fall back to a thin font. A missing font file stops the build and reports; never silently substitute.

Bundled today: Anton, Bebas Neue, Caveat, Lora, Montserrat (variable), Nunito, Oswald, Playfair Display, Poppins (Medium and SemiBold only), plus Baloo 2, Fredoka, Gloock, Gochi Hand, Instrument Serif, Outfit, Pinyon Script, Quicksand, Rye. Still to add: Archivo Black, Inter, Roboto, Open Sans, Lato, Poppins 700/800, Cormorant Garamond, Courier Prime, IBM Plex Mono, Special Elite, Kalam, Permanent Marker.

## Text jobs (size at 1080 wide)
- B1 Hook: Montserrat 900, 84-110px, white + ~8px black stroke or black pill, Y 38-50%, max 7 words, pop-in 120ms, hold 1.2s+.
- B2 Karaoke captions: Montserrat 900 / Anton / Poppins 800, 64-88px, 1-3 words, active word in her one accent colour, 8-12px stroke (plus dark box on busy footage), Y 60-70%, never in the bottom 20%. No periods or commas.
- B3 Phrase captions: Inter 700 / Poppins 700 / Nunito 800, 56-68px, 2 lines max, 4-6 words, sentence case, break on phrase ends, one accent keyword per chunk.
- B4 Subtitles: Roboto/Open Sans/Inter, 48-56px, white on 70-80% black box, baseline about Y 78%. Replaces B2/B3, never together.
- B5 Power word: Archivo Black / Anton / Montserrat 900, 110-160px, caps, one word, slam (0.85 > 1.06 > 1.0 in ~180ms), max 3 per reel.
- B6 Keyword highlight: same font, change colour/box/underline only, max 1 per chunk.
- B7 Lower third: name Inter 700 / Lato 900 52-60px, detail 36-42px, left, Y 68-75%, out by ~5s.
- B8 Chapter label: Montserrat 700 / Oswald 600, 38-46px caps, letter-spaced, top, inside safe zone.
- B9 Lists: Inter 700 50-58px, numbers Montserrat 900 in accent, items build and stay, max 5.
- B10 Stat: number Montserrat 900 / Anton 120-180px, label Inter 600; real numbers only.
- B11 Quote break: Playfair 800 / Montserrat 800, 68-92px, 2-3 lines, slow fade, hold 1.5s+, no karaoke under it.
- B12 Question bubble: Poppins/Inter 700, 48-56px, her real question verbatim.
- B13 B-roll label: Inter 600 / Lato 700 40-48px; mono for time/place. Describes, never sells.
- B14 POV opener: Montserrat 900 accent + 800 white, 64-84px, holds 1.5-2.5s.
- B15 CTA end card: Montserrat 900 76-96px + Inter 600 support line, one action only.
- B16 Watermark: Inter/Montserrat 600, 30-36px, 60-75% white, same corner every reel.
- B17 Disclaimer: Inter 600, 34-40px, on 70% black box, held 3s+ or the whole segment.

## Five caption systems (one per reel)
C1 Karaoke Bold (caps, yellow/brand highlight). C2 Karaoke Soft (Poppins 800, sentence case, highlight box; default for reluctant marketers). C3 Phrase Clean (confessions, teaching). C4 Boxed Broadcast (busy footage). C5 Typed Story (Courier Prime, diary reels only).
Chunking: break on meaning, max 2 lines, ~32 chars per line (phrase) or 1-3 words (karaoke), no orphan words, never caption a cut word, check names against her word list, minimum chunk time ~14-17 chars/second and never under 0.8s.

## Eight looks (customer sees plain names only)
D1 Clean Authority (recommended default), D2 Warm Friend, D3 Editorial Premium, D4 Bold Teacher, D5 Honest Confession, D6 News / Data, D7 Soft Reassurance, D8 Launch Pop (cart weeks only; warn after 14 days). One look and one caption system per reel, max 2 font families on screen.

## Dimension and motion
Twelve dimension treatments (soft lift, hard offset, extruded 3D, sticker cutout, text behind subject, sandwich split, glass panel, paper and tape, marker highlight, glow halo, ghost echo, stacked cards). Each look gets one primary and one secondary. Captions stay near-flat (soft lift or box only). Motion is a closed list: pop, slam, fade/slide-up, type-on, highlight swipe, count-up, build, pulse-once, parallax drift, wipe reveal. Banned: spin, bounce loops, wave-per-letter, shake, rainbow, random per-word effects. Layer order back to front: footage, dim, ghost/behind-subject, subject, panels, main text, hard offset under its text, watermark last. Text behind subject needs a clean mask; otherwise fall back to hard offset.

## Taste ceiling (binding, Rachel's rule)
- Level 1 Subtle is the default for about 8 of 10 reels: captions with soft lift or box, hook with soft lift or hard offset, no slams, 3D, glow or behind-subject. Level 2 adds one hero moment. Level 3 (launch/announcement only, never two days running, never her everyday setting) adds a second.
- Hard caps: 1 hero dimensional moment per reel; 2 dimension treatments; 3 slams (1 for Warm Friend, Soft Reassurance, Confession); max 3 text elements on screen at once; about 60% of runtime has only captions on screen. Nothing appears just because it exists.
- Over-edit test: show 3 stills and ask "Does this look like you, just more polished?" If text is louder than she is, drop one level.

## Fun pack (max 1 fun moment per reel, about 2 seconds, never in captions)
J1 word costumes, J2 crossed-out rewrite, J3 typed-into-a-box hook, J4 red-pen annotations (max 2), J5 past-me/now-me captions, J6 freeze-frame comment (opt-in only), J7 receipt reveal (real numbers only), J8 signature sign-off (her own catchphrase), J9 seasonal accent swap, J10 delayed drop. On by default: J2, J4, J8, J10. The edit sheet suggests the fun moment and she can cut it with one word.

## Rendering rules
1. Sizes scale with canvas width (hook 7.5-10%, karaoke 6-7.5%, phrase 5.2-6.3%, labels 3.5-4.3%, watermark 2.8-3.3%). 2. Stroke about 12-15% of font size (heavy), 8-10% (phrase). 3. If the frame is bright or busy, add the box; never shrink text to fix contrast. 4. Never cover a face. 5. Safe zones: top 12%, bottom 20%, right 12%. 6. Animation vocabulary is closed. 7. Bundle fonts with a manifest; verify files before a batch. 8. One look, one caption system, max 2 families. 9. Preview gate: render one reel, show 3 stills (hook, mid-caption, CTA) at phone size, approve once, then lock. 10. Check contrast on the brightest and darkest frames.

## Completeness layer
- Cover frame is a separate still from frame 1; cover text inside the centre 4:5 band.
- Full transcript shown as plain text for fixes before any caption render; word list auto-flags near matches.
- Safe-zone profile per destination (Reels, Stories, TikTok, Shorts); export a clean wide-margin master and an .srt sidecar.
- Screenshot proof: blur names, faces and handles by default.
- Fonts must cover her characters (accents, Spanish); fallback supplies missing glyphs, never tofu or dropped accents.
- Analyst step records look and hook style per posted reel; after 8+ posts the Sunday refresh says which look her audience watches; fatigue guard swaps a fun moment or hero treatment used in 3 of the last 5 reels.
