# B-roll reels: a warm way into posting (no face needed)

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

**Goal:** a reel made from short clips of her real world (hands, her shop, her space, her product) plus her own voice. For the person who dreads being on camera, this is the gentle first step. Never call it "faceless as a downgrade": it is a real format, and it looks more personal than stock footage.

**Offer it** when she says she does not want to be on camera, when "on camera" in her settings is "none" or "about half," as the easy option on a busy week, or when she asks for B-roll. One question at a time, as clicks. Follow `surfacing-map.md`, `plain-words.md` and `clickable-choices.md`. Read her saved rules, voice profile and off-limits list first (never plan a shot that breaks one, such as kids or client faces).

## 1. Pick the script
Use a scripted video from her plan (or write a short 20 to 30 second script from an idea). Keep the lines short; B-roll reels run on one idea per line.

## 2. The shot list
From the script, write 6 to 10 shots. Each shot: the line it goes with, **what to film in concrete words** (a close-up of hands steaming a dress, the tags on a rack, a customer's bag at the door), and 3 to 5 seconds. No faces unless she wants them. Save it as `customer/plans/shot-lists/<short-title>.json`: `{"title": "...", "script": "path", "shots": [{"n": 1, "line": "...", "what": "...", "secs": 4}]}`. Run `python3 engine/tools/make_film_mode.py --phone` (or give her the file) so the shots show on her phone with a checkbox each, under "B-roll shots." Tell her: "Film each one for a few seconds, holding the phone steady, vertical. About ten minutes."

## 3. Her clips
She drops the clips in `inbox/broll/`. Run `python3 engine/tools/broll_index.py scan`. It copies them into `customer/videos/broll/`, makes a contact sheet of each, and lists the ones that need a label. LOOK at each sheet (`customer/videos/broll/_sheets/NAME.jpg`) and save a plain label with `python3 engine/tools/broll_index.py label FILE "what it shows"`. Her originals stay in the inbox.

## 4. Her voice
She records only her voice reading the script: Voice Memos on her phone is fine (film mode shows the script big while she reads). She AirDrops the audio to her inbox. Tell her: "If you mess up, pause and say the line again. I cut the mistakes." Use the clearest take.

## 5. Match clips to lines and build
Write the plan `{"look": "11", "hook": "THE HOOK *WORDS*", "captions": "pop", "shots": [{"phrase": "first words of the line", "clip": "customer/videos/broll/NAME.mov", "start": 0}, ...]}` using her labels and the shot list. A phrase is the first words said for that line, spelled as they were spoken. If a clip is too short it loops; if a shot has no clip, say so and offer a stock clip (`first_edit.py` can fetch stock with her photo key) or ask her to film one more. Then run `python3 engine/tools/make_broll_reel.py PATH_TO_VOICE_AUDIO --plan PLAN.json --name short-name` with the engine's Python (`~/.cache/content-engine/whisper-venv/bin/python -I`). Say the time first (a build usually takes about a minute for a short reel). It lays the clips under her voice, cuts retakes and pauses (picture and sound together), and adds the hook, captions, sounds and progress bar. The edit sheet opens by itself so she can fix any word, cut or add-in. To swap a clip, change that shot in the plan and run it again.

## Rules
- Real clips beat stock. Use stock only to fill a gap, and say so.
- Her voice is never changed; her clips and recording are never deleted.
- Never show a face she did not agree to, a license plate, a client or a child (check her off-limits list).
- Run the compliance scan on the script before filming.
- Keep it warm: "This is a gentle way to start. Your voice and your real world, no camera on your face."
