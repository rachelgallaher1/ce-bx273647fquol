# Carousel spec (Rachel's complete spec, loaded 2026-10-20)

Where this file and an older note disagree, this file wins. It sits on top of `step-4-carousels.md` (the steps) and obeys the taste ceiling in `reel-font-system.md`.

## Why carousels earn a place
Every swipe restarts attention. Reaching the last slide tells Instagram the promise paid off, so design backwards from the payoff. Instagram often re-shows an unswiped carousel starting on SLIDE 2, so slide 2 is a second hook that stands alone. Guides, checklists, frameworks and comparisons get saved and shared, so every teaching carousel has one deliberately save-worthy slide.

## Hard numbers
1080 x 1350 (4:5) for every slide. PNG for text, JPG for photos. Up to 20 slides; 7 to 10 is the sweet spot, 5 to 7 is fine when honestly done, never pad, over 12 only for stories or tutorials that earn it. The profile grid crops to the centre square: the cover headline and face must read inside it. Keep critical text off the very bottom and all edges. Package: numbered slides, `caption.txt`, `alt-text.txt`.

## Skeleton
1. **Cover:** the hook, 6 to 10 words, promises ONE thing. 2. **Second hook:** the cost of the problem, the "you" moment, or the first payoff; never "step 1". 3. **Body:** one idea per slide, each ends with a reason to swipe. 4. **Save-worthy slide:** a checklist, cheat sheet, framework summary or comparison, readable without the rest, labeled "save this one" (the tool adds the label). 5. **Final slide:** ONE action only. Optional sequel line only if part 2 is in the plan. Every slide has her handle and a slide number. The cover's promise must be fully paid by the save slide; an over-promising cover is a bug.

## Copy
Same voice profile, saved rules, never-use list and compliance scan as scripts. At least one slide uses a real moment from her audience profile or story bank, never a generic example. Word budgets: cover 6 to 10, headline slides 12 to 20, body slides 40 at most, checklists short lines (about 7 items). Numbers in promises are real counts. **She approves the words (every slide's headline and support lines as plain text) before anything is drawn.**

## 18 formats (pick by job and pillar, rotate, never the same format 3 posts running)
Myth vs fact · step-by-step tutorial · checklist or cheat sheet · named framework · mistake confession (her real mistakes) · before and after · POV or story arc (may run to 12) · quiz · hot take · FAQ or text conversation (real questions verbatim) · comparison · data or proof breakdown (real numbers only) · photo dump with a point · screenshot story (blur names and handles by default) · stop doing / start doing · mailbag (real questions) · glossary in plain words · series installment. Every format works text-only, photo-led or mixed: a carousel never waits for a photo shoot.

## Design
Locked templates per customer, built once from her brand colors and look, approved once, never redesigned per post. Two fonts. About 40 percent empty space. One recurring signature motif on covers and final slides, plus her sign-off. Contrast checked on every slide. Flat is the default; allowed depth is a sticker cutout, stacked cards on data slides, paper and tape on checklist or confession formats, a ghost-echo word on covers; one treatment family per carousel.

## One call to action
Mid-carousel (slides 5 to 6, over 6 slides): a soft follow line only. Final slide: ONE primary action (comment keyword, save, send to a friend, a question, or follow for the named series). The caption repeats the same one action and never adds a second.

## Reel to carousel
For every reel, draft THREE angles: teaching (the steps), story (the moment behind it), reference (checklist or framework). She picks one with a click; the other two are banked as future posts. The carousel posts on a DIFFERENT day than its reel and continues the conversation.

## Covers
Words approved first. Face on one side, headline on the other, never text across a face. Eyes toward the headline. One saturated accent per cover. Quiet negative-space covers are allowed and rotated with face covers. Thumbnail test: shrink to grid size; is the promise still readable?

## Pop (one moment per carousel, placed around slides 4 to 6)
Pace on purpose: light and dense, photo and type, near and far, one loud slide mid-deck surrounded by calm. Never 3 same-feeling slides in a row. Swipe devices: the peek (the next slide's edge bleeds in, `"peek": true` in slides.json, slide 1 into 2 by default), a panorama that pays off by slide 3, a broken headline only when slide 2 pays it off, a "2 of 5" counter. Doodles (arrow, circle, underline) only when they point at something real, 2 per slide at most. One video slide per deck at most. Failure modes to flag: a loud cover on a loud deck, doodles pointing at nothing, a loud slide at both 2 and 5, pop on a proof slide (proof pops with a real number and a clean table).

## Checks the tool runs now
Slide count, word budgets, repeated layouts, missing sources, hard ask only on the last slide, second-hook rule, one loud slide, cover word count, comment word matches the reel, proof slide, save slide, contrast, and the grid check (`grid-preview.png`, the new cover beside her last eight; flags a third look-alike cover in a row). It also prints a pacing line and saves `pacing.txt`.

## Extra versions made every time
`repost-card-square.png` (the save or verdict slide as a square post), `pinterest-pin.png` (vertical pin of the save slide), `linkedin-document.pdf` (all slides as a LinkedIn document). Reformats of the same approved words, no rewriting.

## Learning
Before delivery, say in plain words how the outline compares with her own past winners (hook pattern, format, save slide, word budget) and flag the one fix that matters most. A score with no reason is banned. When she logs "I posted it", record format, angle, slide count, save-slide type and CTA type so the Sunday refresh can say which format earns her saves. Instagram gives no per-slide drop-off: say so plainly and judge by saves, shares, comments and profile actions.

## Tracks
Business tracks lead with proof, FAQ, comparison and framework. Group or cause tracks lead with story arc, photo dump, mailbag, glossary. Personal tracks use photo dump with a point, story arc, stop/start; no sales call to action; privacy blur and minors/location defaults apply to every photo.

## Bans
Text walls · more than two fonts · rainbow decks · a cover the deck does not pay · a stack of asks on the last slide · invented stats, questions or testimonials · tiny elegant text · redesigning per post · stock examples when her stories bank has a real one · posting the carousel the same day as its source reel · emojis on slides · every slide a sales slide.

## Built in the tool (slides.json)
New slide types: `compare` (headline, left_title, right_title, rows of [old, new], verdict), `glossary` (term, definition, label), `stopstart` (headline, stop[], start[]), `timeline` (headline, steps of [time, text]), `framework` (name, parts[], active, body), `pano` (text, hi, sub: one headline that runs across two slides, pays off on the second), `videoclip` (headline, start, seconds: a still plus a short loop `slide-NN.mp4`; one per carousel). Any slide takes `doodles` (up to two: kind circle, underline, arrow, star or check, with x, y, w, h; only pointing at something real). Spec-level options: `"motif": "tape" | "star" | "stamp"` (and `motif_text`) on the cover and last slide, `"signoff": "Hit record!"` on the last slide, `"peek": true`, `"repost_slide": N`, `"format"` and `"angle"` (for the history).
Mapping the 18 formats to types: myth vs fact = `myth`; tutorial = `point` steps ending in `recap`; checklist = `list`/`recap`; named framework = `framework`; mistake confession = `point` plus `stopstart`; before and after = `transform`; POV or story arc = `timeline` and `pov`; quiz = `quiz`; hot take = `bigtext`; FAQ or text conversation = `faq`/`convo`; comparison = `compare`; data or proof = `stat`/`receipt`; photo dump = `photo`; screenshot story = `receipt`; stop/start = `stopstart`; mailbag = `faq`; glossary = `glossary`; series = `cover` with a series label.
History: `python3 engine/tools/carousel_score.py score slides.json` before she posts (how it compares with her own top carousels, in plain words; says so when there are fewer than three logged), and `carousel_score.py log slides.json --saves N --shares N --comments N` when she says "I posted it". The niche-gap idea needs her Apify account and is offered at planning time only, never inserted into a finished deck.

## Payoff check (built)
The carousel tool reads the cover's promise and checks the deck delivers it: the cover's key words must show up in the rest of the deck, a number on the cover ("5 mistakes") must match the slides or checklist lines inside, and a save slide must sit in the last few slides. It prints plain `Payoff:` notes. Fix by editing the words, not by softening the cover.

## Series covers, highlights, templates (built)
`"series": {"name": "One video series", "number": 3, "next": "The month plan"}` in slides.json puts a series label (name and number) on the cover and a "next part" and "start at part 1" pointer on the last slide, and the grid check treats a series run as one block. Make the series highlight cover with `make_highlights.py --series "<name>"`. Approve-once templates: `templates.md`. Niche gaps: `niche-gaps.md`. The progress strip is deliberately left out (the slide counter does that job).

## A photo behind a slide
Any `bigtext` slide can sit on a photo of her with a dark overlay: `"bgphoto": "/full/path.jpg", "overlay": 0.58, "photo_up": 0.1`. The text turns white, the highlighted word keeps her accent color, the same fonts are used, and the text sits low so her face stays clear.
