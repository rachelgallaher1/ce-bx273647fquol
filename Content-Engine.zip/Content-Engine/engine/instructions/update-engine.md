# Updating the engine ("update")

When she says "update", "update my engine" or "is there an update":
1. Run `python3 engine/tools/update_engine.py --check`. If it says she is up to date, say so in one line and stop.
2. If a newer version is ready, tell her in plain words what is new (the tool prints it) and say: "This only replaces the engine part. Your voice, scripts, videos and plans are not touched, and your old engine is kept in case anything looks wrong." Ask one click: **Update now (Recommended)** · **Not now**.
3. On yes, run `python3 engine/tools/update_engine.py`. It downloads the new version, checks it, swaps it in, and puts the old engine back by itself if anything fails.
4. Say what it printed. Then run `python3 engine/tools/check_setup.py` in case the new version needs new tools, and follow `setup-tools.md` if it says NOT READY.
5. If anything looks wrong, the old engine is the folder named engine-old-DATE. Offer to switch back. Never delete it without asking. After a good week, offer once to clear old copies.
6. If the tool says updates are not turned on, or she has a new download by hand, ask where she unzipped it and run `python3 engine/tools/update_engine.py PATH`.

Never ask her for a password or a link. The address is built in (`engine/UPDATE_URL`).

## For the builder (not for customers)
Publishing an update: bump `engine/VERSION`, add a paragraph under the title in `engine/RELEASE-NOTES.md` (the first paragraph is shown as "what is new"), run `python3 engine/tools/package_engine.py`, then upload `Content-Engine.zip` and `latest.json` (both in `My Engine DIST`) to the folder named in `engine/UPDATE_URL`. Use a folder with an unguessable name so only customers have the address. Turn updates on by putting that address in `engine/UPDATE_URL` before the FIRST release goes out.
