# Learn my style (a conversation, one question at a time, no pasting)

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

**Goal:** so her edits look like hers. When to bring it up: once, before her FIRST video edit, as one warm line ("Want me to learn your style first, so your edits look like you? It takes about five minutes."). A "not now" is always respected, and she can say "learn my style" any time. Tick it in `customer/profile/said-once.md`.

Read `surfacing-map.md` first. One question at a time, as clicks where bounded. Never ask her to paste a prompt. Her files go in the inbox; she never has to find a folder.

## 1. A reel she is proud of
Ask: "Do you have a finished reel you're proud of? Pick one that is really your style, not your most experimental. Drop it in your inbox." Clicks: **Yes, it's in my inbox** · **I don't have one yet (skip)**. Then run `python3 engine/tools/inbox.py list`, let her pick it as a click, and run `python3 engine/tools/style_reader.py PATH_TO_REEL --name her-best-reel`. LOOK at `customer/profile/style/her-best-reel/sheet.jpg` and read the numbers. Describe back in plain words: how fast the cuts are, how the captions look, how the hook appears, what graphics and effects she uses. Ask: "Did I get that right?" and fix anything she corrects.

## 2. Screenshots of reels she wishes hers looked like
Ask: "Do you have screenshots of moments from other reels you wish yours looked like? Screenshot the exact moment, not the whole reel. Drop them in your inbox, with the link if you have it." Clicks: **Yes, they're in my inbox** · **Skip**. Run `python3 engine/tools/inbox.py images`, then `python3 engine/tools/inbox.py take-inspo` for the ones she names. LOOK at each one. For each, ask one short question: "What do you like about this one?" and save her words. Never copy another creator's footage or words, only learn the feel.

## 3. Her own GIFs
Ask: "Do you have a folder of your own GIFs? If you do, I'll use those first so I stop picking ones you'd never use." Clicks: **Yes** · **Skip**. She drops them in `inbox/gifs/` (make that folder if it is missing). Run `python3 engine/tools/inbox.py take-gifs`. Tell her: name a file for the feeling it fits (for example `mind-blown.gif`), and the engine matches the words in a name to the words in a search.

## 4. Save it
Fill `engine/templates/style.md` into `customer/profile/style.md`. Show her the short result in the chat with a link. From now on, read `customer/profile/style.md` before every video build and let it shape the choices (cut pace, caption look, how often graphics appear), always inside `video-style-rules.md`.
