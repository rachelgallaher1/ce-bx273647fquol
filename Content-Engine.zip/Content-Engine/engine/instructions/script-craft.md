# Script Craft: what makes a script good

Reference rules for Step 2 (`engine/instructions/step-2-scripts.md`). Read this before writing any hook or script. Never show her this file or its terms as a grade or a lecture. Use it to write well, and share only a short "why" line at a time.

## 1. Each video does one job

| Job (her words) | What it's for | Usually | Judge it by |
|---|---|---|---|
| **Get found** | new people discover her | short, 5 to 10 seconds, or a quick punchy talking video | views compared with her typical video |
| **Keep the people who found her** | turn viewers into followers | her talking, names a feeling or tension, 45 to 100 seconds | shares, saves, follows |
| **Get them to act** | comment, click, buy, DM | teaches something, then one ask | comments for every thousand views |
| **Proof** | show a real result or moment so people trust her | a before and after, a real moment, a result she told you is true | saves, shares, DMs |

If she is just starting out and has no offer yet, use only "get found" and "keep people." Never write an "act now" video until she has something to offer. Use her "Until then" ask instead (follow, save, send, or come back).

## 2. Two kinds of video (call them these plain names)

- **Teaching:** pays off with something she can use: a lesson, a list or a result.
- **Personal and honest:** names a feeling and leaves it open. No lesson bolted on and no hopeful turn at the end. It ends on the question, and any ask is one short line after it.

A "keep people" video is personal and honest unless its story pays off. A story with a payoff is told as teaching, and the payoff is the proof.

## 3. The hook has three layers

- **Said:** the spoken first line. The first sentence is under 12 words.
- **Shown:** what the first frame shows in the first second.
- **Read:** the text at the top of the screen. Two short lines: a small top line that names who it is for and their situation, and a bigger line that names the tension and opens a question. It never repeats the spoken line, never all caps, and on a personal video it never hints at a happy ending.

## 4. Pre-post check for every hook

Run all ten, quietly, before showing a hook. Fix any that fail.

1. Something concrete in the first sentence or first frame: a time, a place, an object, an exact number from the moment, or a named moment. A group of people on its own ("moms," "coaches") does not count.
2. No brag or result number about herself in sentence one. Proof goes in the middle.
3. The top-of-screen text does a different job than the spoken line, and names who it is for.
4. The big line opens a question or names a tension. A time or place on its own does not.
5. No ask and no warm-up ("I'm about to," "Let me show you") in the hook.
6. No AI-sounding habits (see section 10) and no all caps on screen.
7. It sounds like her, from her voice profile.
8. Under about 10 words, so it lands in the first 2 seconds.
9. The video delivers on it. No clickbait.
10. It uses at least one proven pattern from her hook bank (`customer/insights/hook-bank.json`), when she has one.

## 5. The ten levers (stack two or three in an opening)

| Lever | The move |
|---|---|
| Curiosity gap | name something specific they almost know, and hold the answer |
| Open question | start something in line one, finish it late |
| Break the rhythm | do something unexpected in the first second |
| Specific detail | an exact time, number or named moment |
| About you | put the viewer's own situation in sentence one |
| A strong feeling | funny, surprising, fair-minded anger. Never fake urgency or fear of missing out |
| Something slipping away | name what's quietly being lost, and own it as hers |
| Her group | name the group out loud so sharing it feels like a badge |
| Others like them | show people like them already care |
| A name for a feeling | hand them a short label for something they've never put into words |

The strongest openings stack: something that says it's about them, a label that makes them feel seen, then stakes that make them stay. Across ten hooks use at least six different levers.

## 6. Writing ten hooks

- Her core message (the frustration behind her whole page, from her audience profile) belongs in about 1 script in 3. Use her words. Do not use it in every script.
- If `customer/profile/target-persona.md` exists, read it and follow its messaging rules.
- Build from HER audience's moments and words (her audience profile) and her voice. Never reuse any wording from an example in this file.
- Vary the first words (no first word more than twice across ten), the shapes (no more than two with the same structure), and the angle (cover at least four sides: their moment, what it costs, the flip, the viewer's side).
- Only first person for what is hers. If the story isn't hers yet, write in "you."
- Use only her facts. A missing number or result becomes a blank in brackets for her to fill.
- Then pick two to test: for each, the lever that carries it and why, plus the ONE thing that differs between them so a test can tell her which worked.

## 7. Shapes and their beats

| Shape | Beats |
|---|---|
| Story | setup, trigger, turn, result |
| List | promise, items, payoff |
| Contrarian take | claim, why it's wrong, receipt, reframe |
| Personal and honest | the unsaid thing, the tension, the question left open |
| Comparison | this, that, the part nobody sees in the middle |
| Series episode | where we left off, the new piece, what's next |

**"But and so" test:** join the beats with "but" and "so." If they only join with "and then," it's a list. Fine for a tutorial, flat for a story.

## 8. Pace and length (retention is written, not edited in)

- Open a question in the first line and close it late.
- Add a smaller question or re-hook in the middle.
- Land something new every few seconds.
- Put the biggest payoff near the end, where a replay makes sense.
- Keep every line short enough to read at a glance, about two seconds.
- Length fits the job. About two and a half words a second. "Trim it to N seconds" means cut whole lines, keep the hook, the payoff and the ask.

## 9. The ask

- One ask, after the payoff. On a personal video the payoff is the open question, and any ask is one short line after it.
- Curiosity first, before any comment word. Never lead with the word.
- Tie a save to a specific moment: "save this for the day you..."
- Write a send on purpose: "send this to the friend who..."
- Five options, one per ask (comment word, save, send, follow, question). Suggest the one that fits the job and put it in the script.

## 10. Default AI-sounding habits to avoid

Unless her own voice proves one is truly hers (it appears in her real words at least twice, then keep it, with a limit like "once per video"):

- dashes of any kind
- "It's not X, it's Y" lines
- lists of three out of habit
- a warm-up line before the point
- a tidy moral at the end
- sentences that all sound the same
- hustle talk, unless it's truly hers

Her own never-use list always wins over this one.

## 11. Seen, not diagnosed

Naming a hard thing she and the viewer both live in is solidarity. Implying the viewer is late, lazy, or failing is a diagnosis, and people scroll away. Test every line: does the viewer feel seen, or diagnosed? Never make anyone feel behind.

## 12. The video is its own proof (teaching videos)

A claim you tell gets doubted. A claim you show is proof. Find what the viewer can SEE: a before and after, a live demo, a number counting up, a prop, her screen, a quick drawing, or the result itself. Only suggest what she can film where she is, with what she already has. Anything she'd have to get is flagged. A personal and honest video needs no demo: the words carry it, or one quiet visual at most.

## 12b. Claims about people

A general claim about what "most people" do, feel or spend their time on is a fact she never gave you. Don't state one as true in a script. Either use something she actually said or showed (her own experience, a question her people ask, her reel results), phrase it as her view in her own words ("here's what I've noticed"), or turn it into a question for the viewer ("Where does your content time actually go?"). Never invent a statistic or a percentage.

## 13. True stories only
Her stories live in `customer/profile/story-bank.md` (`story-bank.md` explains how they are captured and reused). Pull from it first; tell stories small and specific; never repeat one inside 3 weeks.

A story, a moment or a detail is hers only if her own words say so: her interview answers, her audience profile, her captions, or what she told you in this chat. An idea Claude suggested is not her memory, even if it says "your." When a script needs a first-person story that isn't hers yet, ask once: "Has this happened to you? Tell me what really happened, in a line or two." Build from her details. A no or a skip means write it from the viewer's side in "you." Never put words in a real person's mouth (her kid, her partner, a client). Quote someone only when she told you they said it.

## 14. How to give the check (kind, never a grade)

Never show a score, a count of checks, pass or fail, or the words weak, weakest, wrong, problem, fail or fix. She just wrote this with you, so it is good work. Report:

1. **What's already working:** two or three strengths, each quoting her line.
2. **Three ways to take it further,** biggest lift first. Each: the change, one line of why, and the new line written in her voice. Hook and job ideas before polish. If fewer than three are worth making, say the rest is polish, or it's ready to film.
3. **One line to try:** a stronger version of one line, as an option, with one line on what it adds.
4. One line saying what to do next.

When she says yes to changes, make them and keep every other word exactly as it was.

**The best-friend test:** read the script as if she's saying it to her best friend at the kitchen table. Mark every line that sounds like a brand, a guru or a robot. Rewrite only those lines, in her voice.

## 15. Show the transformation, hide the recipe

Every script, carousel and caption shows **what changed and why it matters**, and never gives the full step-by-step. The viewer should finish wanting the how, which is what her offer, her comment word or her follow is for.

- **Show:** the before, the after, the feeling, one real detail, the result.
- **Hide:** the full list of steps, exact settings, templates, tools in order, anything that lets someone copy it without her.
- **Rebuild check (run quietly on every finished script, carousel and caption):** could a stranger repeat the whole result from this alone? If yes, cut the steps down to the one idea that earns the click, and move the rest behind her ask ("comment WORD and I'll send you how").
- Teaching videos can still teach one real, useful thing. The line is: a complete answer to one small question is fine, the whole method is not.
- Never hide it by being vague or dodging a question. Hide it by making the next step an invitation.

## 16. Proof posts

About 1 in 7 posts is a proof post: a real result, before and after, or real moment. Use only what she told you is true (section 13). If she has no proof yet, make it a behind-the-scenes of how she works, and bracket anything missing. Proof is shown, not claimed. Never invent a client, a number or a quote. Apply section 15 here too: show the result, not the recipe.

## Blanks in a script must be clear questions
When a script needs a fact only she knows, leave a bracket the calendar will turn into a box for her. The bracket must be a complete, plain question that says exactly what to type, for example `[Your real number: how many people have bought your starter?]` or `[One real thing you did this week while building, in your words.]`. Never write a vague bracket like `[check this]`, `[TBD]` or `[fill in]`, and never put a note to yourself in a bracket. If you need her to confirm a claim ("hundreds", "bullet proof"), do not leave a bracket: ask her one click question (**Yes, that's true** · **Change it**) before you save the script, and write only what she confirmed. Filming cues go in plain words without brackets, or in brackets that start with a verb like [show ...] (the calendar ignores those).
