# The filming look (one quick page, offered once before her first recording)

Say it in plain words, short, one thing at a time. Offer it once as a click: **Quick filming tips (Recommended)** · **Skip, I know how**.

1. **Face the light.** Stand so a window or lamp is in front of you, never behind you. If your face is darker than the room behind you, turn around.
2. **Phone at eye level or a bit above,** upright, leaned on something steady.
3. **Five-second tidy.** Clear the shelf or counter behind you, or stand in front of a plain wall.
4. **Don't wear your caption highlight color,** so your top doesn't blend into the words.
5. **Talk to the lens,** like you're talking to one person.

Then offer the 15-second test clip: "Want to send me a quick 15-second test so I can check your light and sound before you film a whole month?" She drops it in the inbox, and you run `python3 engine/tools/check_clip.py <clip>` and say what it found in plain words (it only describes what the camera sees, never her looks). Fix one thing at a time, then she records for real.
