# Something to post today: add a post, or switch a video to a carousel or text reel

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed list.** See `clickable-choices.md`.

**Goal:** she always has something to post. Two situations, both started from a button on the Calendar (it copies the request, she pastes it in the chat) or by typing the same words:

1. **An empty day** ("nothing planned"): "Add a post for Fri Oct 30."
2. **A video day she did not record:** "Switch post 4 (Fri Oct 30) to a carousel: I did not record the video." or "...to a text reel."

Warm, fast, no guilt. "No problem, let's make you something to post." Autogenerate it; she only approves the words.

## 1. Add a post for an empty day
1. Read her pillars, sell/value mix, banked ideas in the plan Notes, seasonal ideas and `customer/profile/story-bank.md`. Pick the idea that fits the gap (the mix is the tiebreaker: if the last posts were all selling, make it a value post). **Do not ask her to choose an idea.**
2. Default format: **text carousel** (no filming). Never stories: the calendar only has video, carousel and text carousel. Run `python3 engine/tools/plan.py add YYYY-MM-DD "text carousel" "<job>" "<idea>"` so the plan and calendar show it.
3. Write the carousel words in her voice (`step-4-carousels.md`, `carousel-spec.md`), compliance-scan them, and show them as plain chat text. Then ask one click: **Looks good, make the slides (Recommended)** · **Change some words** · **Make it a text reel instead**.
4. On approval, make the slides, save them with `plan.py file N PATH`, regenerate the calendar, open her hub on the Calendar if it is not open, and give the caption with a copy button (it is on that day).

## 2. Switch a video to a carousel
1. Find the post's script (`customer/scripts/...`). Keep the idea, the hook and the real facts.
2. **Rewrite the same idea as carousel words** (cover = the hook, one point per slide, ending with her comment word). Use only what is in her script, story bank and profile. Never invent a number or a result.
3. `python3 engine/tools/plan.py format N carousel`, then the same steps as above (show the words, one click, make the slides, link the file, regenerate the calendar).
4. Keep the original video script in the file (do not delete it). Tell her she can still film it another day (it goes back on her list on request).

## 3. Switch a video to a text reel
Same idea, no filming (`text-reels.md`): her words on her brand colors or photos, a few frames, her voice or music. Make the frame words from her script's hook and beats. Run `plan.py format N "text reel"`, then build as in `text-reels.md` (voice memo or music or silent).

## Rules
- She never starts from a blank page: you pick, you write, she approves.
- Never post for her. Never invent anything.
- If she pastes the request with a date in the past, build it anyway and say "This is for today (or the next open day)." and move it with `plan.py roll N DATE` if she wants.

## "Write post N now" (from the Calendar's idea-stage button)
When she taps **Get a post for this day** on the Calendar, the hub already adds the post to her plan as an idea (from her banked ideas, or "New idea (Claude will pick one for this day)"), in the format she picked. The day then shows a **Write this post now** button that copies "Write post N now". When you get it: if the idea is still the placeholder, pick the best-fitting idea first (section 1, step 1); then write the whole post in her voice (script and caption; for a carousel, the slide words, compliance scan, one click to approve, then make the slides), link the file with `plan.py file N PATH`, regenerate the calendar and say what is ready. Never ask her to choose an idea.
