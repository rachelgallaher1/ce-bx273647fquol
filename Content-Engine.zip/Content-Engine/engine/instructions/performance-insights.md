# Performance Insights: which reels hit

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

**Goal:** look at her own public Instagram reels, find the ones that did best, and use what they have in common to guide what we create next. It feeds Step 2 (scripts) and, later, the monthly plan.

**Before you start:** read `customer/rules/saved-rules.md` and obey it. Use `engine/templates/performance-insights.md` as the shape of the saved file.

## Rules for this step

- Warm, plain and short. One question at a time.
- She never gives a password. Only her public Instagram handle is needed. If she offers a password or login, tell her warmly you don't need it and to keep it private.
- Use only the numbers that come back. Never guess, round up or invent a number.
- Public numbers show views, likes and comments. They do NOT show reach, saves, shares or watch time. Say this plainly once, so she knows "hit" here means most views and engagement.
- Patterns are observations, not promises. Say "these three all start with a question," never "questions always work." If she has fewer than 10 reels, tell her it is too few to see real patterns and say what you can see anyway.
- Never delete her saved insights without asking.

## The analysis (Rachel's rules and what to show)

Use this for the report in steps 3 and 4. Plain, human language, no jargon or guru-speak. **The first time you use a metric name, add a one-line plain translation**, like "reach, the number of different people who saw your stuff."

**Inputs:** her top posts from the pull (caption, format, views, likes, comments, date) and, **only if she chooses to paste or screenshot them**, her Instagram Insights for the last 28 days (reach, views, profile visits, link taps, who follows her, when they're online). Insights are optional: public data can't see them. Without them, say plainly what you can't tell her ("I can't see profile visits or link taps unless you paste your Insights").

**Rules, no exceptions**
1. Compare like with like: reels with reels, in the same time window. One strong post is an example, not a formula.
2. Reach, impressions, views and engagement are different things. Name which one you mean, every time.
3. If a post had ad money behind it, say so. Don't treat it as proof of what works naturally.
4. A missing number is unknown, not zero. Never invent one.
5. No outside benchmarks ("the average account gets..."). Her only baseline is her own past numbers.
6. Every recommendation must trace back to a number you were given.

**What to show**
1. **Headline:** one sentence, the most important thing her numbers say.
2. **What's working:** 2 or 3 findings with the numbers. For each winning post, quote its hook (the first line of the caption, or the first 2 seconds) and name the pattern, like "concrete money math," "myth-bust," "moment-led scene."
3. **What's leaking:** where attention dies (profile visits with no link taps, views with no saves, reach far below her follower count), if the numbers show it.
4. **Fix list:** 3 to 5 concrete actions, biggest impact first. Each names the number it fixes and exactly what to change.
5. **Hook bank:** turn the winning patterns into 3 to 5 fill-in-the-blank templates, each with one worked example. Save it as `customer/insights/hook-bank.json` using `engine/templates/hook-bank.json`. The hook bank is what the scripts step uses to write hooks.

Keep it short and save the whole analysis once as `customer/insights/analysis.md`, so later steps read the file and never redo it.

## 0. Her own Apify account (one time)

Pulling her reels uses a free helper service called Apify, and each customer needs her **own** Apify account. The reels are pulled under her account, and any cost is billed to her, not to the engine's builder.

1. Check whether Apify is already connected in this session. If it is, skip the rest of this section.
2. If not, tell her in plain words: "To look at your reels, I use a free service called Apify. You'll need your own free account. It takes about five minutes, and I'll walk you through it."
3. Walk her through it one small step at a time:
   - Go to apify.com and sign up. (She does this herself.)
   - Connect Apify to Claude in her app's connectors or settings, and log in when it asks. Guide her to the right screen as it looks for her.
   - Tell her the free plan includes a small amount of monthly credit, which is plenty for a few reel pulls. Tell her to check the current amount on Apify's site, because it can change.
4. **Never ask her to paste her Apify password or API token into this chat.** She logs in on Apify's own page. If she pastes a token anyway, tell her to treat it like a password and not to share it.
5. Once Apify is connected, say so and move on to step 1.

## 1. Ask for her handle

Ask: "What's your Instagram handle?" Confirm it back to her. Ask nothing else yet.

## 2. Pull her reels (Apify)

Tell her what is about to happen in plain words and the cost: "I'll look up your public reels. It costs a fraction of a cent per reel, so about ten cents for 30 reels." Wait for her OK.

Then run the Apify actor `apify/instagram-reel-scraper`:

- `username`: her handle, in a list
- `resultsLimit`: 30 (more only if she asks)
- `skipPinnedPosts`: true (pinned reels are old and skew the results)
- leave transcript, shares and video download OFF (they cost extra and are not needed here)

Check the first results for the real field names (caption, views or plays, likes, comments, date) before using them. If the run fails or comes back empty, tell her plainly (account is private, wrong handle, or too new) and ask her to check the handle. Do not retry in a loop.

## 3. Rank and show

1. Rank her reels by views. Work out her typical reel (the middle value, not the average).
2. Show her a short table of her **top 5** and her **bottom 3**: date, first line of the caption, views, likes, comments.
3. Call a reel a "hit" only if it clearly beat her typical views. Say how much, in her numbers.

## 4. Look for patterns, with her

Compare the hits and the misses on things you can see: how the caption opens, topic, caption length, hashtags, length of the reel if known, day posted. Then describe 2 to 4 patterns in plain words, each with the reels that show it, quoting each winning hook and naming its pattern (see the analysis rules above).

Ask it as a **click** (see `engine/instructions/clickable-choices.md`): "Do these look right to you?" with the choices **Yes, that's right** · **Mostly, but I'd add something** · **Not really**.

If she picks "Mostly" or "Not really," ask a second click question: "What else was going on with those reels?" with these choices (multiple allowed): **Used a trending sound** · **Different topic than usual** · **Filmed somewhere different** · **None of these, next**. The "Other" box is there if she wants to say more. Never ask whether she was "nervous" about anything.

Her answers outweigh the numbers.

## 5. Save it

After she agrees the patterns are right, save to `customer/insights/performance.md` using the template: the date pulled, how many reels, her typical views, the hits with their numbers, the patterns she approved, and her own notes. Her top captions are good voice samples. Offer to add them to her voice profile and only do it if she says yes.

Tell her where it is saved. Say in one line what it will be used for ("I'll use this to write ideas based on what worked") and keep moving right into the next question or step. Don't wait for her OK.

## 6. Optional: listen to her top videos (her spoken words)

Spoken words teach her voice better than captions do. After saving the results, offer once as a click: **Yes, listen to my top three** · **No thanks, next**. Say the cost first, in one line: "It costs about 5 cents for every minute of video, so around 15 cents for three short ones." Do it only on her yes.

- Run `apify/instagram-reel-scraper` again with `includeTranscript` set to true, putting the links of her top three reels (from the results) in the `username` list, and `resultsLimit` of 3.
- Read the full results, not the short preview, because the preview cuts transcripts short.
- Save the transcripts word for word, never tidied, under "Her spoken words" in her voice profile (or hold them for the voice summary if the profile isn't saved yet). Tell her in one line that they're saved.
- A video with no speech (music or on-screen text only) is fine. Note "no speech" and move on.
- If it fails, say so plainly in one line and carry on without it.

## Refreshing

She can say "update my insights" any time. Pull again, show what changed since last time, and ask before replacing the saved file. Keep the old version as `performance-<date>.md`.

## If Apify is not available (full fallback, not an extra)
Apify can fail or run out of credit, and this step must still work. Offer: **Paste my numbers** · **Send screenshots**. Ask her to open Instagram, go to her reels, and paste for her last 10 to 20 reels the caption's first line plus views, likes, comments, saves and shares, or send screenshots of her insights screens, which are easier. Read the screenshots yourself. Then continue from step 3 with those numbers, and save the hook bank the same way. Saves and shares come only this way, so mention that the paste route gives a richer picture. A missing number is unknown, never zero.

## Sunday automatic refresh (offer once, after her first successful pull)
Ask as a click: **Yes, refresh every Sunday (Recommended)** · **Not now**. On yes, create a scheduled task (the scheduled-tasks tool) for Sunday 9am that pulls her latest reels through her own Apify account and runs the weekly refresh (section 5 of `step-planner.md`), then writes the date to `customer/insights/last-refresh.txt`. Tell her plainly: it only runs while her computer is on and Claude is open; if it was closed it runs the next time she opens it. A small Sunday 10am notification ("Open Claude so I can update your results") is installed by the launcher (`engine/tools/install_nudge.py`) and stays quiet if the refresh already ran. If the pull fails, never ask for a token; ask her to say "paste my numbers".

## Carousel looks (learned automatically)
Public likes and comments for her carousels are matched and logged by `auto_results.py` (see "Carousel learning" in `step-posted.md`). Saves and shares come from Instagram Insights screenshots she drags onto the Best performing content tab on Sundays; read them yourself and log with `results.py add --carousel`. She never types numbers.
