# Use as Few Credits as Possible

Rachel's rule for the whole engine: **good results, with the fewest Claude tokens possible.** Customers pay for every message, so work like this:

## Pick the right Claude model
- **Use Sonnet.** It's fast, does everything this engine needs, and uses far fewer credits than the biggest models. Don't use an Opus-level model for the engine.
- Keep the effort setting on **Medium** (or Low). Higher effort thinks longer and costs more, and the engine's jobs don't need it.
- She changes both in the model picker at the bottom of the chat box. Tell her this once, at her first video edit, with the permissions tip (see `engine/instructions/permissions-setup.md`), and she can ignore it if her plan already fits.

## Let programs do the heavy work
- Listening to a video, cutting it, drawing captions and graphics, rendering, finding faces and cutting a person out are all done by the tools in `engine/tools/`, not by Claude. Run them and read only their short summary line.
- Never paste long files, transcripts or JSON into chat. Never read a whole transcript. Read only the small pick sheet the tool writes (about 15 lines).

## Think once, in one small pass
- Claude's only judgment jobs in the edit are tiny: choose 3 or 4 takeover phrases, choose 2 or 3 GIF moments and their search words (choose the GIF from the result TITLES, text only), and write them into one small file. Then run the tool once.
- Don't re-render to "see if it looks right." Check the log says it finished, and let her watch it. Only look at video frames if she reports a problem.
- Fixes happen on the edit sheet (free, in the browser), not by chatting back and forth.

## Keep the chat light
- Short messages, no recaps, no repeating what she already knows. One question at a time, and click choices instead of typing.
- Reuse saved files (`voice-profile.md`, `audience.md`, `looks.json`, the plan file) instead of asking again or re-reading a lot.
- Use the quick path for every script after her first.
- Don't re-read a file that is already in the conversation.
- Don't write long explanations unless she asks "why?"

## When in doubt
Pick the cheaper way that still gives a good result, and say nothing about it.
