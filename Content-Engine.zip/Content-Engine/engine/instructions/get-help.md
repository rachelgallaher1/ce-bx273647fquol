# When she is stuck ("I'm stuck", "something broke", "it won't work", "help")

**Goal:** Claude (you) is her first line of help. Fix it with her in the chat, in a few minutes, every time you can. Only when you truly cannot, hand support one file that answers every question. Warm, short, plain. Never blame her. Never send her to support, or mention support, until you have tried the fixes below and asked what she sees.

## 1. You try first (always)
Run `python3 engine/tools/check_setup.py` and follow `setup-tools.md` for any MISSING item. Then match what she says:
| What she sees | What is going on | What to do |
|---|---|---|
| "ffmpeg" or "video tool" missing | The video tool is not installed | Follow `setup-tools.md` F1 |
| A page will not open | The hub is not running | Tell her to double-click "Open My Content Engine" and leave its window open |
| Page says "address already in use" or the hub opens on a different number | An old copy is still open | Close the old window, open again |
| A build is very slow | Long or wide videos take longer (a long video can take 15 minutes or more) | Say so, and offer a shorter clip first |
| A firewall box appears (Windows) | The hub asks to use the network | Tell her to choose "Allow" for private networks; it only runs on her own computer |
| Videos or pictures from Messages or Photos cannot be read | Her computer blocks those folders | Ask her to copy the files to Desktop or Downloads |
| Words look wrong (symbols instead of quotes or emojis) | A text-encoding problem | Run `help_packet.py` and send it |
| The calendar page is blank or a button does nothing | The calendar needs rebuilding | Run `python3 engine/tools/make_calendar.py`, reload the Calendar tab, and ask the click question **Do you see it?** |
| A carousel looks wrong (words overlap, a picture is cut off, it looks like her last one) | It can be adjusted | Open the carousel on the Carousels tab: **Change style**, **Move things around** (drag, resize, turn, edit the words, swap the picture), or **Undo my last save**. Offer to do it for her |
| The looks row shows blank pictures or says it is drawing | The previews are still being drawn | Wait about a minute and reload the Carousels tab; if it stays blank run `python3 engine/tools/make_looks.py --force` |
| **Make this carousel** says the words are not written yet | That day is still an outline | Say its script unlocks at the Sunday refresh (or offer "unlock week") |
| Sunday refresh did not finish | Check `customer/insights/refresh-check.md` | Fix each FAIL; ask her to roll or drop missed posts |
After any fix, ask one click question (AskUserQuestion): **Did that fix it?** · **Yes, it works now** · **No, still stuck**. Then write it in her private problem log (so the real problems can be seen later): `python3 engine/tools/help_log.py add "<area>" "<the problem in one plain line>" "<what you tried>" fixed` (or `not_fixed`). One short line, never her words, names or anything private. If it works, say so plainly and go back to what she was doing. If not, try one more thing, then go to step 2.

## 2. Still stuck: make the help packet
Run `python3 engine/tools/help_packet.py "what she was trying to do, in her words"`. Then:
Only after the fixes above did not work, say so plainly and warmly: "I tried a couple of fixes and it is still not right, so I made a small file that shows what is going on. It has no scripts, videos or private words in it. Open it and take a look (here is the link), then send it to [the address in `engine/SUPPORT`]. They will get back to you." Give a clickable link to `customer/help-packet.md`, and a clickable link to the form (the address in `engine/SUPPORT`). Tell her the form has a box where she pastes the file, and that she only needs to fill in what happened and the box. The packet already lists her recent problems and what was tried. If `engine/SUPPORT` still says REPLACE_BEFORE_RELEASE, do not mention an address at all: tell her to keep the file safe, and that if it keeps happening she can come back and tell you.

## Rules
- Never ask for passwords, tokens or card details.
- Never read or send her scripts, voice profile or videos for support.
- Say what you tried, in one line, in the packet request ("I tried the video-tool fix and it still fails").

## Messages from the hub's help button ("Help: ...")
The hub's "Need help? Click here" button copies a ready message like "Help: something will not open. I was on the Calendar tab, looking at Wed Nov 4." She pastes it here. Do not ask what is wrong again: the message already says. Act right away:
- **something will not open:** run the setup check and the fixes above; if it is a page or editor, restart the hub (`home.md`) and ask the click question **Do you see it?**
- **I do not know how to do something:** ask ONE click question about what (the tabs: calendar, edit, carousels, brand, results, the plan) and then show her, step by step, in her hub.
- **I want to change a post:** use the day in the message if there is one; tell her she can tap Edit on that day, drag it to another day, or write a note for her plan, and offer to do it for her (`plan-notes.md`).
- **something looks wrong:** look at what she was on and any details she added; fix or explain it; if it is a bug, make a help packet.
- **something else:** ask ONE click question to narrow it down, with an Other box.
Keep it short and warm, and end with a click question for the next step.
