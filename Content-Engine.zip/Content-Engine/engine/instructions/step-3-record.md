# Step 3, Part 1: Record It

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

**Goal:** the moment between "I have a script" and "I have a video." Many people freeze here and ask "what do I record?" So Claude pulls up the script, makes it easy to read off, gives a few quick filming tips, and tells her exactly where the video goes.

**Before you start:** read `customer/rules/saved-rules.md`, her voice profile, and the script she picked (from `customer/scripts/`). Follow `engine/instructions/clickable-choices.md`. No emojis in your own messages.

**Keep it moving.** Offer this right after a script is saved ("Record this one now") and any time she says "I'm ready to record," "what do I record?" or "show me my script."

## 1. Pick the script

If she has one script, use it. If she has several, ask as a click, newest first, labeled with the title and job. If she names one, use that. Don't ask more than that.

## 2. Show it to read off

Write the script in plain chat as something she can record straight from:
- The **hook first**, in a short line: what she says, what's shown, and the text at the top (from the script file).
- Then **the lines to say**, one short line per row, with a blank line between each, exactly as saved, in her voice. Don't rewrite it.
- The **ask** at the end, and the **caption first line** under it.
- At the top, one line: "Here's your script. You don't have to be perfect, just say it the way you'd say it to a friend."

## 3. Quick filming tips (five lines, no lecture)

**First time only:** before the five tips, give her the settings from `engine/instructions/recording-settings.md` (HDR off, 4K or 1080p at 30 fps, light in front, sound, framing). Ask once, as a click, **iPhone** · **Android**, and show just that part. After that, the five tips are enough.

Tailor them to her script's filming direction. Use plain words:
1. Hold the phone up, vertical, at eye level.
2. Face a window or a lamp so the light is on your face, and pick a quiet spot.
3. Prop the phone up so it stays steady, if you can.
4. If you mess up, **stop, pause for a second, and say the line again.** The editing step cuts out the mistakes and the long pauses, so don't restart the whole video.
5. Keep going to the end, even if a line feels clunky. You can always record it again.

If the script has a "what to show on screen" part, add one line: "Make a note of where to show [the thing], and we'll put it in during the edit."

## 4. Where the video goes

Tell her, in plain words: "When you've recorded it, drop the video in your recorded videos folder," and give a clickable link to the folder, like [your recorded videos folder](customer/videos/recorded/). Then: "Tell me when it's in, or drag the file right into this chat."

- **Most people record on a phone, so tell her how to get the video onto her computer.** Ask once, as a click: **iPhone** · **Android** · **It's already on my computer**, then give the matching steps in plain words:
  - **iPhone to Mac:** open the Photos app on the phone, tap the video, tap the share button, tap AirDrop, and pick her Mac. The video lands in her Downloads folder. (Turn on Wi-Fi and Bluetooth on both, and keep the phone close.) Don't send it by text or email, because those shrink the quality.
  - **iPhone to Windows:** use the iCloud for Windows app or plug the phone in with a cable and copy the video from the phone's folder.
  - **Android:** share it to Google Drive and download it on the computer, or plug the phone in with a cable and copy the video over.
  - Whichever way, tell her: "Once it's on your computer, tell me where it landed (usually Downloads), and I'll copy it into the right folder for you." Then copy it from there. Never move or delete the original.
- **Keep a library so nothing has to be searched for.** Once the video is in `customer/videos/recorded/`, run `~/.cache/content-engine/whisper-venv/bin/python -X utf8 -I engine/tools/library.py scan`, then ask as a click which script it is (newest scripts first, plus **Something else**), and label it: `library.py label FILE --title "<short name>" --script customer/scripts/<file>.md --plan-row N`. It writes `customer/videos/library.md`, a table of every video, which script it belongs to and where it is (new, edited, posted). Say "show my videos" to bring it up. Never rename, move or delete her originals; labels live in `customer/videos/library.json`.
- She can also paste or drag a file path into chat. Use that file.
- If she says "it's in," use the newest video in `customer/videos/recorded/`. Say its file name back to her so she can confirm.
- Never move or delete her original video. The edit works on a copy.

## 5. Keep going

Once the video is in, go straight into the edit (`engine/instructions/step-3-edit.md`, once it exists). Until then, tell her plainly that the editing part is coming soon, and that her video is saved safely.

## A note on music and sound
The engine does not add music. Trending sounds are licensed by Instagram, so she adds them inside Instagram when she posts: tap Add audio, pick a trending sound, and turn her voice volume up and the music low so captions stay readable. Do not add copyrighted songs to the video file itself, because it can get the post muted or removed. Say this once, after the first edit, in two lines.


## Where the video goes
Tell her once: "Save or AirDrop your video into your inbox folder. That's the only place you need to remember." (See the inbox section of `setup-tools.md`.) If her videos are scattered in Downloads, offer to look there once, then show her how to use the inbox from now on.


## Film mode (a phone teleprompter)
For a batch day, run `python3 engine/tools/make_film_mode.py --phone`: it writes `customer/plans/film-mode.html` and serves it on her Wi-Fi for two hours at the address it prints (she types it on her phone). Or she AirDrops the file. It shows each scripted video one script at a time in big text, the hook first, with Next, Back, Start over, Auto scroll, A- and A+, light or dark, and a checkmark per video that saves on her phone. Blanks in a script show highlighted. Say "film mode" or "let's film" to start it. After filming, she taps "Tell Claude what I filmed" and pastes the line to you.


## Before the first recording
Offer the quick filming tips once (`engine/instructions/filming-look.md`), with the optional 15-second test clip check. A skip is always respected.
