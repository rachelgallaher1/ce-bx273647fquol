# What it costs (tell her before she starts)

Give this in plain chat once, near the start (after the welcome, before the first question), then keep moving. Never invent a number. Prices were last checked October 2026. Re-check every few months.

## What she pays for
1. **A Claude plan.** The engine is built for the **$20 a month Pro plan** ($17 a month if she pays for the year up front; checked on claude.com, October 2026). Claude Code is included. Pro has a usage allowance that refills every 5 hours, plus a weekly limit, so a heavy day can hit a limit and she waits for the refill. Nothing is charged extra.
2. **Apify (reel results), free to start.** Reading her reels costs a fraction of a cent each: about 8 cents for 30 reels. Her free Apify account includes $5 of credit each month, needs no credit card, and unused credit does not roll over (checked on apify.com, October 2026). The free plan cannot charge extra: if she uses the $5, Apify pauses until next month. Optional extras: spoken words from her top videos, about 5 cents a minute. Checking a posted reel's numbers is the same tiny cost. Prices can change, so the engine says "as of this month" and points her to the site.
3. **Giphy and Pexels:** free accounts, optional.
4. **Everything else is free:** the editing tools, fonts, looks and add-ins run on her computer.

## What uses her Claude allowance (plain, no made-up numbers)
- **Light:** interview, scripts, the plan and checking results. These are mostly writing.
- **Light on purpose:** editing a video. Programs on her computer do the heavy work, and Claude reads a short summary and makes one small decision file. Fixes happen on the free edit sheet and cost nothing.
- **Heaviest:** writing a whole month of scripts in one go, and editing many videos back to back.

Tips to stretch it: pick **Sonnet** and keep effort on **Medium**, do the edit fixes on the edit sheet instead of asking Claude, and spread a month of work over a few days.

## Say honestly
"A full month fits in the $20 plan if you spread it over a few days. If you hit a limit, nothing is lost: it saves everything and you pick up when it refills."

## Builder to-do (not for customers)
Measure a real month on a Pro plan (interview, 12 scripts, 6 video edits, 6 carousels) and replace the "spread it over a few days" line with the measured number of days. Until measured, do not promise a time.
