# Best recording settings (give this to her before her first video)

Show it in plain chat, short and clickable if she wants one phone type first (iPhone or Android). Say it once, before she records. Menus differ a little by phone and software version, so tell her to look for the closest match, and offer to look at a screenshot of her settings if she is stuck.

**Why this matters:** newer iPhones record in HDR by default. HDR looks great on the phone but flat and gray once it is edited and posted. A few settings fix that before she ever records.

## iPhone (iPhone 12 and newer)
1. **Turn HDR off.** Settings, Camera, Record Video, switch off **HDR Video**. This is the main fix for flat, gray color.
2. **Pick the size.** Same screen: choose **4K at 30 fps** if she has the storage (the zooms in the edit look sharper), or **1080p HD at 30 fps** (smaller, faster to move and edit). Not 60 fps, not 24 fps.
3. **Format.** Settings, Camera, Formats: "High Efficiency" is fine. If a file ever won't open or edit, switch to "Most Compatible."
4. **Turn off the extras.** Use plain **Video** mode, not Cinematic and not Action mode. No filters, no beauty effects.
5. **Use the back camera** if she can see herself (a mirror or the screen on a stand), because it is sharper. The front camera also works.
6. **Don't pinch to zoom.** Use the 1x or 2x buttons. Pinch zoom makes it blurry.
7. **Lock focus and light.** Tap her face on the screen and hold until AE/AF LOCK shows, so the picture doesn't pump in and out. If her skin looks too bright, slide the little sun icon down a touch.
8. **Record in the Camera app, not inside Instagram.** Instagram's camera lowers the quality.

## Android
1. Video resolution **4K or 1080p at 30 fps**.
2. Turn off **HDR10+ video** (or "HDR video") if the phone has it.
3. Turn off beauty effects, filters and auto framing. Normal video mode.
4. Record in the phone's own Camera app, not in Instagram.

## Light, sound and framing (all phones)
- **Light in front of her, not behind.** Face a window or a lamp. No light behind her head. Overhead light alone makes shadows under the eyes.
- **Sound beats picture.** Phone at about an arm's length, quiet room, no fan or music. A clip-on mic is a cheap upgrade but not required.
- **Frame it for the edit.** Vertical. Camera at eye level. Her head in the middle of the frame, with some room above (the hook text sits there) and the bottom fifth left clear (the captions sit there). Don't hold the phone too close.
- **Steady.** Prop the phone on a stack of books or a tripod. Handheld works, and the edit can smooth it a little, but it can't fix a very shaky video.
- **Wipe the lens.** Really. A smudge makes everything look foggy.
- **Charge and space.** Plug in the phone and keep a few GB free.

## Getting it to the computer
AirDrop (iPhone to Mac) or a cable sends the original quality. Don't text or email it, because that shrinks it. (See step 4 of `step-3-record.md`.)

## If a video is already recorded and looks flat
It is probably HDR. The engine detects it and brings the color back automatically, so she doesn't have to re-record. Tell her to turn HDR off for the next one.
