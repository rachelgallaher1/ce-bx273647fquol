# Content that hit: her bank of winners

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

**Goal:** every Sunday, show her which posts did really well, save them in one bank, and make it easy to bring them back (repost, rework or reuse in another format). Keep it short: no big analysis, just "these hit."

**Before you start:** read `customer/rules/saved-rules.md`. Never ask for her Instagram or Apify password or token.

## When it runs
- Inside the weekly refresh (see `step-planner.md`), right after the numbers are pulled.
- When she says "content that hit," "show my winners" or "what did well."

## 1. Get the numbers
Use her saved handle and `performance-insights.md` sections 0 and 2 (say the small cost first and wait for her OK). Save the posts as a JSON list in the scratchpad or `customer/insights/` with title, hook (the first line), views, likes, comments, link, posted date and kind. Saves and shares are private: ask once if she wants to add them (a screenshot of a post's Insights works), and skip if she says no. A missing number is unknown, never zero.

## 2. Find the hits
Run `python3 engine/tools/winners.py find POSTS.json`. It compares each post to her typical post (the middle view count), keeps anything at 1.8 times that or more, adds new ones to the bank, and says so. Nothing is called a hit until at least 5 posts are compared.

## 3. Say it plainly (a few lines, not an analysis)
"Content that hit this week:" then each new hit in one line: the hook, the numbers, how many times her typical post. If none: "No new hits this week. Here is what is already in your bank." Then run `python3 engine/tools/winners.py ideas`.

## 4. Offer to bring one back (clicks, recommended first)
For a winner, offer: **Same idea, new hook (Recommended)** · **Same hook, new topic** · **Turn it into a carousel** · **Turn it into stories** · **Repost it as it is** (only shown when the post is 60 or more days old, because the same post too soon feels repeated).
- New hook: write ten new hooks for the same idea using `script-craft.md`.
- New topic: keep the hook shape, change the topic using her audience profile and real facts only.
- Carousel or stories: run `step-4-carousels.md` or the stories tool from the original video.
- Repost: add it to the plan on a day with no other repost.
After she picks, put it into the plan (swap an unfilmed idea, never a filmed, edited or posted one) and log it: `python3 engine/tools/winners.py used ID HOW`.

## 5. In the monthly plan
When planning a month, read `customer/insights/winners.jsonl`. Bring back one or two winners per month (never back to back), and mark them in the "Why it's here" column: "Brought back: this hit before." Never claim results she does not have.

## Old topics
If she changed what she sells or talks about, her old hits may no longer fit. When you show a hit, ask once if it is still on topic when its subject looks different from her current offer. If not, remove it with `python3 engine/tools/winners.py retire ID`. Never bring back a hit about something she no longer sells.

## Files
`customer/insights/winners.jsonl` is the bank. `customer/insights/content-that-hit.md` is the readable list. Link it when she asks.
