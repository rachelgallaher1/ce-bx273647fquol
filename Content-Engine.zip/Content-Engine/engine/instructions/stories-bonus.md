# Stories: a bonus, never a planned day

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list.** See `clickable-choices.md`.

**Rule:** the calendar plans only three formats: **video, carousel and text carousel.** Stories never count as a day of content. What matters most is that she posts on her real page; stories are an optional extra.

## What stories are here
Short story sets made from content she has **already posted** (or is about to post), so she never starts from a blank screen. The engine offers a few options each day. She never has to use them, and they never appear as planned posts.

## The daily options (shown on the Calendar's Today view, "Story options (bonus)")
Built from her most recent posted or ready post. Offer 2 or 3 of these, each in one line:
- **Tease it:** a 3-frame set that points to today's post ("New post is up: [hook]", the one best line, "Go watch it").
- **Ask about it:** a question or poll frame about the post's topic, so her followers answer.
- **One thing from it:** the single most useful line from the post, as a short story with her face or a plain background.

## When she picks one (she taps it; the page copies "Make a story from post N: <option>")
1. Write the 3 to 5 frames in her voice from the real post only (script, caption, story bank). Never invent facts. Add one sticker idea in words (poll, question, link); stickers are added in Instagram itself.
2. Show the words as plain chat text, then one click: **Looks good, make the frames (Recommended)** · **Change some words** · **Skip it**.
3. On approval run `engine/tools/make_stories.py` (see `stories-spec.md`) with her brand colors and save to `customer/content/`. Tell her where the frames are (Carousels and stories tab) and that she posts them in Instagram.
4. Never put the result on the calendar as a post, and never ask her to plan stories.

## Rules
- Never say she must post stories. Never count them toward her posting streak or "Day complete."
- Works without an edited video: stories can come from a carousel or text carousel too.
