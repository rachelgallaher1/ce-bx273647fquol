# Carousel templates (original looks)

Eight ready-made carousel looks, drawn from scratch by the engine (not copied from anyone). Each one uses HER brand colors and font. Tool: `engine/tools/carousel_templates.py`, used through `make_carousel.py` with slides of `"type": "tpl"`.

| # | Name | Feels like | Slide kinds |
|---|------|-----------|-------------|
| 1 | Scrapbook | handwritten, tilted photo, doodles | cover, point, list, quote, cta |
| 2 | Numbered tips | big number, mixed fonts, sticker photo | cover, point, list, quote, cta |
| 3 | Bold editorial | huge condensed headlines, highlight bars | cover, point, list, quote, cta |
| 4 | Photo statement | full photo, thin serif, one giant word | cover, point, split, cta |
| 5 | Warm flat color | flat color, photo row, comment bubbles | cover, point, row, comment, grid, cta |
| 6 | Photo story | photo, words low and left, italic accent word | cover, point, bigword, cta |
| 7 | Notebook caps | cover as a full photo, short caps headline on a big thin italic word; later slides a framed photo with a note blocked in | cover, point, list, quote, cta |
| 8 | Face and contrast | face photo under a dark layer, old way / new way split, proof card, italic call to action | cover, point, split2, proof, cta |

Extra middle slides, so a long carousel never repeats one layout (all eight looks have them): `list` (a title in `headline` and 3 to 5 short lines in `items`), `quote` (one big statement in `headline`, who said it in `who`), `stat` (a big number in `headline`, what it means in `body`, the source in `who`; ONLY a real number she gave, never invented) and `photo` (a big picture with a short caption in `headline`; looks 1, 2, 3 and 7 only; with no real picture it becomes a quote). **Photo statement's giant word (`hi`) is ONE strong word taken from her line (like DEAD, BUBBLY, STARTER), never a filler word like AND; if you leave `hi` out, the engine picks the strongest word itself.** **Quotes and labels never overlap:** a long quote shrinks to leave room for its `who` label. Warm flat color takes photos on its normal slide (`photo`) and has a photo-first slide (`kind: photo`). **Variety rule:** for slides 2 to the second-to-last, never put the same `kind` twice in a row, and use at least three different kinds in a carousel of 7 or more slides. Quote = her strongest line; list = steps or items; stat = a real number; photo = a good real picture.

Slide fields: `template` (1 to 8), `kind`, `items`, `who`, `headline`, `hi` (word to highlight), `body`, `n`, `note`, `lead`, `keyword`, `line`, `photo`, `photos`, `comments`, `left_title`/`left`/`right_title`/`right`/`footer` (split2), `proof_image` (a REAL screenshot she gives; without one the proof card is simply left out), `stickers` (false turns doodles off). Full list at the top of the tool file.

Rules:
- Her brand colors always (look "brand"). The built-in colors are only used when she has none.
- Real proof only: `comment` slides show only comments she pasted; `grid` slides use only her own pictures. If she has none, leave those slides out.
- Photos come from her video stills (templates 4 and 6, and every cover) or her own photos.
- Her looks live in the **My looks** row at the top of the Carousels tab (hearts for favorites, "Use for my next carousel", and an "Add a look you love" tile). Her choices are in `customer/profile/carousel-looks.json`. The engine chooses the look that fits the post (`engine/tools/pick_look.py`; see `step-4-carousels.md`) and makes the carousel in it. A look she pinned wins. She can change the style afterward. Never mention how it is built.
- Her own new looks ("learn this carousel look"): she drops screenshots in the inbox; describe what you see in plain words, ask what she likes, and save notes next to `engine/templates/carousel/_design-notes.md` (in customer/ for hers). Original drawing only, never a copy.

## Where the photos come from (Rachel's decision)
1. First, the best frames from her own video (sharp, her face showing), chosen automatically.
2. On the review page she can click a photo to swap it for another frame from her video.
3. Her own photos only if she adds them (she drops them in the inbox). The before and after cover is the one place to ask: "Drop a before photo and an after photo in your inbox."
4. No video and no photos: a plain brand-color background. Never an invented picture.

## Lettering and readability rules (all templates)
- Handwritten parts use the thin, wide Fredoka (`HAND` in `carousel_templates.py`) with only a slight tilt. Words must always be easy to read.
- Body text, big keywords and the footer use the same family, bold where they were bold; the footer is thin.
- Circles around words are clean ovals sized to the words, never wavy.
- Everything is centered and sits in the middle of its strip or box.

## Adding her own look ("learn this carousel look")
It draws a real new layout, not a copy of a built-in one. Her look is a set of choices filled in from her screenshots.
1. The screenshots come from the **Add a look you love** tile on the Carousels tab (**Choose screenshots**); they land in `inbox/` named `carousel-look-...`. If none are there, send her to the tab (say **content**). Never ask her to find the inbox folder.
2. Look at them and say in plain words what you see (background, lettering, where the picture sits, how words are highlighted, little decorations). Ask what she loves as click choices.
3. Run `~/.cache/content-engine/whisper-venv/bin/python -X utf8 -I engine/tools/learn_look.py choices` to see what can be chosen: background (flat, paper, grid, gradient, photo), colors (only if the screenshots call for others; otherwise her brand colors), alignment, headline lettering (19 fonts) and case, highlight (none, bar, underline), picture shape (none, frame, rounded, circle, full), decorations (stars, arrows, tape, dots) and number style (none, big, pill, circle).
4. Draw a preview: `learn_look.py preview --params '{...}'` (3 sample slides in `customer/looks/.preview/`). Show it, change what she says, preview again. Original drawing only, never a copy.
5. When she approves: `learn_look.py add --name "<her name for it>" --params '{...}' --refs <her screenshots>`. It becomes her next look (9, 10, ...), shows in the My looks row, and the engine can pick it for her carousels (slides use `"template": "custom:N"`). Change it later with `learn_look.py edit N --set key=value`, remove with `learn_look.py remove N`.
6. If a layout is bigger than these choices (for example a split-screen collage), say plainly it is not possible yet and offer the closest look.

## Her brand font
If she uploaded a font on the My brand tab (or her brand font is one the engine already has), headlines use it: looks 3 to 8 and her own looks (`head_font: "brand"` or any headline font). Scrapbook and Numbered tips keep their handwriting. If the font on her brand card is not installed, the My brand tab says so and asks her to upload the font file. Never ask her for a Canva login; she downloads the font file herself (see the Canva note in `brand-colors.md`).

## Her own photos come in automatically
When a carousel has no video and no photos of its own, the carousel tool uses the photos on her My brand tab (cover, photo slides, and every other point slide; the photo looks use them as the background). The choice is saved in `slides.json` (`photos_from_brand`), so a redraw never changes it. Set `"no_auto_photos": true` on a carousel to turn this off. With no brand photos, a carousel simply has no pictures (never invented ones), and the calendar shows the yellow ! on picture-carousel days: "Add photos for this carousel", with a button to the My brand tab.
