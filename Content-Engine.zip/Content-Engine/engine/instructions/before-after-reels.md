# Before and after reels

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

Four ready-made proof reels (list and details in `engine/effects-library/index.md`): **Freeze-frame reveal**, **Screen recording to result**, **Side-by-side**, **Curtain wipe**. Tool: `python3 engine/tools/before_after.py` (run with the speech environment's Python). All are 1080 x 1920, 30 fps, 7 to 10 seconds, with a suggested caption.

## How to run it (one question at a time)
1. She says "make a before and after". Offer the four as one click each: **Side-by-side (Recommended)** · **Curtain wipe** · **Freeze-frame reveal** · **Screen recording to result**. One line of what each does.
2. Find the clips yourself: the raw clip is her original in `customer/videos/recorded/`, the edited clip is the newest `_edit` in `customer/videos/edited/`. Ask only which video if more than one could fit. For screen recording to result she needs to give you a screen recording and the finished reel.
3. Ask for her niche in her own words ("Who is this for, like real estate agents or salon owners?"). Fill the "what changed" line from the edit (captions, cut restarts or dead air, hook, tighter pacing); show it and let her change it.
4. Run the tool. Save the video and `.caption.txt` in `customer/content/before-after/`. Show her the result and the caption (rewrite the caption in her voice from her voice profile; the tool's caption is a plain starting point).
5. Read the NOTE lines the tool prints and tell her the ones that matter in plain words (which length setting was used, whether a horizontal clip was cropped, a trimmed section).

## Never skip
- Screen recording to result: the tool cannot find private information. Ask her to point out anything private on the screen (names, file paths, notifications), use `--crop` or `--blur`, and always tell her to watch the finished reel before posting.
- If something cannot be done automatically, say which step and what you need from her. Never skip it silently.
