# Step 1, Part 2: Who She's Talking To

**Keep it short: five questions at most, about three minutes.** The five that matter: her person, their words and thoughts, her topics, what her videos lead to, and her core message. Her moments are folded into "their words and thoughts." Her proof is asked later (see the end of section 2). Skip any question her captions, voice profile or answers already answer, and say what you used.

**Goal:** learn who her videos are for, so her scripts start from real moments and real words instead of general ideas. Her voice profile says how she sounds. This says who she is talking to and what for.

**Fast path first:** if the interview used the fast path (`step-1-interview.md`, "draft first, ask second"), the audience profile is already drafted and she has already corrected it. Do NOT run these questions; just save and continue. Use the questions below only for people who had no posts (the long path), or when she says "who I'm talking to" to redo it.

**When:** right after her voice profile is saved (end of `engine/instructions/step-1-interview.md`). Don't ask if she's ready. Announce it in one line ("Next, a few quick questions about who you're talking to. It's what makes your scripts feel written for one real person.") and ask the first question in the same message. If she says she'd rather skip it, skip it and tell her she can say "who I'm talking to" any time.

**Before you start:** read `customer/rules/saved-rules.md`, her voice profile, and `customer/insights/performance.md` if they exist. Use `engine/templates/audience-profile.md` as the shape of the saved file. Also follow `engine/instructions/clickable-choices.md` and `engine/instructions/recommended-choices.md`.

## Pick up where you left off
After every answer, update `customer/profile/audience-progress.md` (question and her answer). If it exists and `audience.md` does not, say "Welcome back, we got as far as <last question>" and offer **Keep going (Recommended)** · **Start over**. Never repeat answered questions.

## Hard rule: every pick is a click, made with the AskUserQuestion tool

Whenever she is choosing, you MUST call the `AskUserQuestion` tool (multiple selection on unless it is a true either-or). If you catch yourself writing "1. ... 2. ... 3. ..." or "Pick all that fit" followed by a list in chat, stop: that is wrong. Delete it and call the tool instead, with the options inside the boxes and one short line of intro in chat. This applies to every question in this file, including where she is, kind of account, moments, thoughts, their words, topics, what her videos lead to (a, c and d), and proof. Only open questions in her own words (names, her core message, a word she picks) are plain chat.

## How to behave

- Warm, plain and short: each message is about three lines (a one-line why, the question, the choices). One question at a time. Never make her type something she could tap.
- **Read before you ask.** Never ask something her voice profile or her reels already answer. Say what you already know first.
- **Skip is always fine.** A skipped question is saved as "not yet." Never push, never guess to fill a gap.
- **Her facts only.** Never invent a moment, a thought, a number, a result or a quote. Options you offer from her own reels and answers are suggestions in her words, and she confirms them. A suggestion is never saved as true until she picks it.
- **Where she needs the exact words, take hers.** Moments and the words her people use must be hers, word for word. Offer a microphone or typing for those: "Tap the microphone and say it the way you'd say it to a friend."
- **Every click question here lets her pick more than one (turn multiple selection on), and always has a way to add her own note.** Most people serve more than one kind of person, have more than one offer and live in more than one moment. Include one option labeled **Something different (I'll add a note)** on every question that has room for it (the tool's "Other" box is where she types; say once: "Tap Something different and type anything I missed."). After she picks, say what you saved back to her in one line and ask "Anything to add or change?" only if she picked "Something different" or seems unsure. Never save a pick she didn't make, and never make her type to get past a question.
- Use clickable choices for picks. Use plain chat for anything long or in her own words. Write long text as plain chat, not inside a click box.

## Say why you are asking, before you ask (one line, every time)

People do this part better when they know what it is for. Do not wait for her to ask "what is this for?" Say the reason in ONE plain line right before the first question of each part, then ask. Never skip it, never make it long:

- **Moments:** "Why I'm asking: your hooks, the first line of every video, work best when they sound like the exact thought your person is already having. When she hears her own thought, she stops scrolling. So I'd rather get it from you than guess."
- **The thought in her head:** "Say it the way she'd mutter it to herself. A rough guess is fine, and the microphone works too. Your words, not mine, are what make it sound real."
- **Their words:** "Why: when your scripts use the exact words your people use, they feel seen, and they keep watching."
- **Topics:** "Why: one small idea per video means you never face a blank page, and each video is easy to film."
- **What her videos lead to:** "Why: so every post points somewhere, and your 'comment a word' or link fits what you actually offer."
- **Her core message:** "Why: this is the thread that ties your posts together, so people remember what you stand for."
- **Her proof:** "Why: so everything you say is true and believable. Only real things go in."

## 1. Say what you already know

Three to five short lines, from her own answers: who she helps, the problem she solves, her platform, and (if she connected Instagram) what her top reels have in common. Then: "A few questions next, one at a time. Skip any you want."

## 2. The questions (in this order, one at a time)

**A. Where she is right now.** Skip this if her answers already make it plain, and confirm it instead. Click (one or more, plus **Something different (I'll add a note)**): **Just starting (a few videos or none yet)** · **Posting and growing** · **Already selling something**. This decides the plan: someone just starting gets "get found" and "keep people" videos first and no "act now" videos until she has an offer. Say one line of hope: "Good place to start. Your story, your moments and the questions people ask you are all we need."

**B. What kind of account.** Skip this if her answers already make it plain, and confirm it instead. Click (pick all that fit, plus **Something different (I'll add a note)**): **I teach or help people** (coaching, a service, a course) · **I sell a product** · **I share my life or what I love**. This decides who the videos are for: the person she helps, the customer who buys (never other makers), or the follower she's building. Why, in one line: "A candle maker's videos are for people who buy candles, not other candle makers, so the hooks have to speak to them."

**1. Her person.** From what she told you, write ONE short portrait: a real person in a real situation and what they want (not an age or a label on its own). For example, "A mom of little kids who knows she should be posting but is out of ideas and out of time." Ask as a click: **Yes, that's her** · **Close, I'll fix it** · **I serve a few different people (I'll add a note)** (then she says or types the fix, or describes each). If you don't know enough, ask: "Picture one real person you'd love to help. What's going on in her life that makes her need this?"

**2. Their moments.** Not asked as a separate step. Their moments are folded into question 3: the words and thoughts people have at the moments that matter (late night, in the kitchen, scrolling). Do not ask for moments, places or times separately.

**3. Their words and thoughts (one question).** One line of why ("Why: when your scripts use the exact words and thoughts your people have, they feel seen and keep watching."), then ONE click question, multiple selection on: "Which of these do your people say or think? Tap all that fit, or tap Other to add your own." Offer 3 options, each a real quote from her own captions and answers, or from comments and DMs she has pasted (label them "from your posts"). Mix a question people ask ("What does it mean if my dough is sticky?") and a thought they have ("Why can't I get this right?") if her material has both. If she has no real material yet, offer 3 typical ones for her niche, clearly labeled as examples, and ask her to tap only what she has really heard. Include **None of these, next**. Save only what she taps or types, in quotes. Two to four is plenty. About three short lines.

**4. Her topics (three to five).** Each should be small enough for one video ("getting a month of posts done in an afternoon" works, "marketing" doesn't). Suggest topics from her voice profile, her reels and her answers as multiple-pick clicks, with "None of these, next." If a topic is too big, ask once for a smaller piece of it.

**5. What her videos lead to.** Keep this to two clicks (a and c) plus a one-line confirm of the names (b), taken from her own captions: "I have your starter and your course as Sourdough Made Simple. Right?" as a click (**Yes** · **Let me fix**). Skip d unless she has nothing to offer yet. Ask in small, plain steps, one at a time. **She can pick more than one on every click question here (turn multiple selection on),** because many people have more than one thing.
   - **a. What she offers.** (Call AskUserQuestion, multiple selection on.) "After someone watches your video, what do you want them to do? Pick all that fit." Clicks: **Buy something I sell** (a product or course) · **Hire or book me** (a service) · **Get something free from me** (a guide, a link) · **Just follow, save or share**. If she picks only the last one or none, skip to step d.
   - **b. What each one is called.** For each thing she picked, in plain words: "What's it called?" Open question, she can use the microphone.
   - **c. How people get it.** (Call AskUserQuestion, multiple selection on; the four options below fit exactly in one question, so add her own idea through the Other box.) "How do people get it from you? Pick all that fit." Clicks: **They comment a word and I send it to them** (like "GUIDE") · **They click the link in my bio** · **They message me** · **They go to my website**. Only if she picks the comment word: "What's the word?" Her own word, nothing suggested.
   - **d. Until she has an offer.** (Call AskUserQuestion, multiple selection on.) "While you build that, what would you love a new viewer to do? Pick all that fit." Clicks: **Follow me** · **Save the video** · **Send it to a friend** · **Come back for the next part**. Save as "Until then."
   If she has nothing to offer yet, that's a real answer, not a gap. Don't use the words "comment word" or "keyword" without the "(like GUIDE)" example, and never ask two things in one question.

**5b. Her core message.** Open question, her own words, she can use the microphone: "What's the one frustration behind everything you post? Why did you start doing this?" Save it word for word under "My core message" in her audience profile. This is the pain she keeps coming back to, and her posts return to it from time to time. Do not rewrite it into marketing language.

**6. Her proof (true only).** Not asked here. Save as "not yet." Ask it later, only when a script needs a real number, result or credential, and only if she asks ("tell my story" also covers it, `story-bank.md`): one click question, multiple selection on, with a one-line why ("Why: so everything you say is true and believable"): **A real number or result** · **A story I lived** · **My experience or credentials** · **I'm figuring it out as I go**, then her own words. Never suggest, round up or invent a number.

## 3. The quick check

One short message, in plain words: each of the questions you asked as "strong" or "could be sharper," and for each sharper one, one line on what would sharpen it and when (after more reels, after her first comments, after she launches an offer). No lecture, no guilt. Being new is not a weakness.

## 4. Save it

1. Save to `customer/profile/audience.md` using `engine/templates/audience-profile.md`. Quote her words exactly. A skipped field says "not yet."
2. Show the saved file in short, as plain chat text (not in a click box).
3. Say why it matters in one line: "Every hook and script now starts from these moments and these words, not from a type of person."
4. Ask in plain words: "Does this look right? Tell me anything to change." Fix what she says and show it again until she says it's right.
5. **Keep moving.** Once she says it looks right, go straight into Step 2 in the same message: "Now let's write your first script." Then begin `engine/instructions/step-2-scripts.md` with its first question. Don't wait for her to say "ready."

## If she changes something later

"Update who I'm talking to" re-opens this part. Only ask about fields that are empty or thin. Keep everything she already edited.
