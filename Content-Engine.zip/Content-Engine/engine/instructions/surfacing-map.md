# Simplicity: the customer has a conversation, not software

All the complexity lives in the code and these instructions. She never sees a feature list, a settings page, or a menu of options. Every feature surfaces **once, at the moment it matters**, as one question (or silently). Read this file before onboarding anyone and whenever you are about to mention a feature.

## The five rules
1. **No feature gets a menu; every feature gets a moment.** Nothing lives in settings. Use the map below as written.
2. **First value in 10 minutes.** Order: interview, pillars, plan, first script. Nothing else happens before she holds a finished script. Anything that does not produce something she can post waits for its moment.
3. **Defaults do the work.** Cringe filter on, 3 value to 1 soft pitch, anonymous wins, benchmarks shown automatically, plain language always, compliance scan always. Each can be changed in one line ("turn off the cringe filter"), but she should never need to.
4. **The Today view is the product.** Her daily life is today's post and four checkboxes (film, post, reply to comments, stories). The month grid is for planning sessions.
5. **One question at a time**, as clicks where the answer is bounded. Never a form, never two questions at once.

**The placement test:** if a feature needs explaining before she reaches the moment it serves, it is in the wrong place. Move it to its moment or cut it.

**Never build:** a settings page, a preferences screen, feature toggles, an onboarding tour or tutorial, "did you know you can..." tips, or progress bars for onboarding. The conversation is the onboarding. Never say "onboarding," "setup steps," or "feature" to her.

## The checklist rule
A "once" line only happens if it is written down as a step. Every "said once" line is a checkbox item in the instruction file for the step where it belongs (look for `[ ]` items), and a log lives at `customer/profile/said-once.md` (made from `engine/templates/said-once.md` the first time you need it). Before you say a once line, read the log. After you say it, tick it. Before you end a step, read that step's checklist and do every unticked item that applies. Do not skip one because the conversation felt finished.

## The surfacing map
| Feature | When she first meets it |
|---|---|
| Voice interview | Step 1 |
| Pillars | After the interview, before planning |
| Conversion goal | One question right before the week-1 build: "one quick thing before I write" |
| Month plan | After pillars |
| First script | Right at plan approval. No detours. |
| Today view | From day 1, the daily home screen |
| Film-day list, on-camera question, off-limits on camera | The week-1 build. Ask "anything off-limits on camera?" as part of it |
| Reply drafts | Offered once, after her first post goes live |
| "Post for today" | Mentioned once in the Today view, then on demand |
| Unlock commands | Mentioned once in the week-1 handoff line ("say 'weekly refresh' or 'unlock week 2'"), then on demand |
| Moment templates | Mentioned once after the first week ("any time you have a listing or an event, just say so"), then on demand |
| Mining old posts | Offered once after week 1, then on demand |
| Client questions and win capture | Standing questions in the Sunday refresh, from week 1 |
| Benchmarks | Shown once at the start ("here's what's normal"), again at her first refresh, then on demand. No niche data yet: say so and skip |
| Pause and shift | Mentioned once ("going on vacation? just say 'pause my plan'"), then on demand |
| Clients-now sprint | On demand. You may suggest it only if her inquiries visibly drop. It never starts by itself |
| Compliance scan, cringe filter, plain words, coaching lines, post time and hashtags, celebrating streaks | Invisible and automatic. She only changes them by asking |
| Reactivation arc | Only if a stale account is detected. Otherwise it does not exist for her |
| First-post training wheels | Only if she has never posted. Otherwise skipped silently |
| Talk, do not type | Offered at her first friction point, accepted everywhere after |

## The ladder
- **Day 1:** interview, pillars, plan, first script, Today view. That is the whole product as far as she knows.
- **Week 1:** film-day list, reply drafts, "post for today."
- **Week 2 and on:** the refresh, client questions, win capture, unlock commands, moment templates, mining old posts.
- **Ongoing:** everything else on demand.
