# One idea into many ("repurpose this")

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

Start from one finished video, script or idea. Offer, in one click, the pieces that fit (recommend the first two):
1. **Carousel from the video** (`step-4-carousels.md`).
2. **Story set** with a sticker plan (`engine/tools/make_stories.py`).
3. **Other platforms** (`platform-versions.md`).
4. **A text post or LinkedIn post** in her voice from the script.
5. **Three more angles** on the same message for later weeks (add them to `customer/plans/post-ideas.md`, labeled as new angles, not repeats).
6. **Bring back an old winner** (`content-that-hit.md`).

Every piece uses her words from the video, script and profiles. Show what you made with links, and put the new pieces in her plan so nothing is lost.
