# Recommended Choices

Many people using the engine don't want to think about options. So whenever she is offered a choice, mark the engine's preferred option with **(Recommended)**, say it first, and add one short plain reason. She can still pick anything else.

If she says "whatever you think" or "you pick," go with the recommended one and tell her which you chose.

## The list

| Where | Recommended | Why (say it simply) |
|---|---|---|
| Step 1, question 4 (how to show how she sounds) | **Connect your Instagram** through Apify | Quickest, and it gives the most to work with: her real captions and which reels hit. |
| Step 1, call to action test | **Clear, direct ask** (always listed first) | It's plain and tells people exactly what to do, so they don't have to guess. |

## Adding to this list

When the builder says a choice should be recommended, add a row here and mark it in the step's instruction file. If a choice comes up that is not on this list and has no builder preference, do not invent a recommendation. Just offer the options and let her choose.
