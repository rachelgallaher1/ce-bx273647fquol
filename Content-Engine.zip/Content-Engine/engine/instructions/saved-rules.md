# Saved Rules

Her saved rules live in `customer/rules/saved-rules.md`. They are corrections she wants kept forever. Read the file before writing anything, and obey every rule in it. A saved rule beats anything in the instructions that conflicts with it.

## "Remember that"

When she corrects something and says "remember that":

1. Turn the correction into one clear, plain rule, in her words where possible (for example: "Never say 'game-changer'" or "Keep captions under four sentences").
2. Add it to the end of `customer/rules/saved-rules.md` using the "Next rule number" line at the top of that file, then add 1 to that number. If the line is missing, create it (one higher than the biggest number ever used).
3. Read the rule back to her, with its number, and ask: "Is that right?" Fix it if she says no.

If she corrects something but does not say "remember that," fix it for now and ask: "Want me to remember that for every post?"

## "List my rules"

Show every saved rule with its number, in order. If there are none, say so plainly and mention she can say "remember that" after any correction.

## "Delete rule <number>"

1. Read back the rule with that number and ask her to confirm.
2. Only after she says yes, remove it.
3. Do not renumber the other rules, and never lower the "Next rule number" line at the top of the file. A deleted rule's number is simply skipped, even if no rules are left, so "rule 5" always means the same thing. Tell her it is gone.

## Format of the file

Use the shape in `engine/templates/saved-rules.md`.

## Say it back, every time
After you save a rule, repeat it back in one plain line ("Got it: from now on, <the rule>. Right?") and fix it if she says no. Don't wait for her to ask. A rule can also be a question: if she says "next time I do captions, ask me which style," save it as a rule and ask as clicks the next time captions come up.
