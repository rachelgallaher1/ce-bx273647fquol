# Step 4: Carousels

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

**Read `engine/instructions/carousel-spec.md` first. It is the full spec (second-hook rule, 18 formats, three angles per reel, one call to action, pacing, the checks). Where it disagrees with the steps below, the spec wins.** Slide counts: 5 to 20, sweet spot 7 to 10.

**Goal:** turn her reel (or a script or idea) into a swipeable Instagram carousel that is READ, not watched, in her voice and look. Never a captioned screenshot of the reel. Claude writes the words once, she approves the cover and then the rest, a tool draws the slides, and she fixes anything on a free review page. Follow `low-credit-rules.md`, `video-style-rules.md` and `script-craft.md` (section 15: show the transformation, hide the recipe). The full design notes are in the builder file CAROUSEL-SPEC.md (not shipped).

## Rules that always apply
- **No emojis** on slides, in the CTA or in the caption. Cues are a drawn arrow or the word "swipe".
- **Her words.** Pull direct quotes from the transcript or script. Use her voice profile and never-use list on all slide text.
- **Nothing that isn't hers.** Every slide's words must come from her reel, script, voice profile or audience profile. Put the origin in each slide's `source` field. Proof slides use her REAL screenshot or numbers only. Blur anything rebuildable.
- **Audience moments:** examples come from her audience profile (her moments and words), never generic ones.
- **7 to 10 slides when there is real material, 5 to 7 when the idea is honestly done, never padded.** Slide 2 is a second hook, not step one.
- Every slide carries her handle and a slide number (the tool does this). Slides 1 to 3 get a swipe cue.
- **One idea per slide, about 25 words or fewer.** At least 40 percent of a slide stays empty or photo. Two fonts only (her look's display and body fonts).
- **Income or results claims** (like her $486 math): add a plain line to the caption that her results are her own and yours will vary. Not legal advice, and she should check with someone who knows the rules.

## Her looks: the engine chooses and makes it (she changes it after)
She never has to pick a look. **Choose it for her, draw the carousel in it, and tell her which one and why in one line.** She can change the style or edit afterward.
1. **Pick the look:** run `~/.cache/content-engine/whisper-venv/bin/python -X utf8 -I engine/tools/pick_look.py --text "<the idea, headline or script in her words>" --kind <teaching|story|reference> --job "<job>" [--format "text carousel"] [--no-photos]`. It returns the look (1 to 8), a plain reason, and honors her choices: a look she pinned ("Use this look", `use` in `customer/profile/carousel-looks.json`) always wins; looks she removed (`hidden`) are never used; if she has favorites, only those are considered; the same look is not used three times in a row.
2. **Draw it as template slides:** every slide is `"type": "tpl"` with `"template": N` (see `carousel-templates.md`; use only the slide kinds that look has). Put `"look_auto": true` and `"look_reason": "..."` at the top of `slides.json`. Do **not** ask her which look to use. Her words approval (cover words, then the rest) still happens first, exactly as in the steps below.
2b. **Plan the mix so her feed never looks repetitive:** before writing slides, run `~/.cache/content-engine/whisper-venv/bin/python -X utf8 -I engine/tools/pick_look.py --mix --look <N> --beats <how many real ideas the post has> --photos <how many real photos she has> [--number] [--quotes <how many strong lines>]` (`--number` only if she gave a real number). It returns the length and the kind of each slide, different from her last few carousels (a different opener, a different order, a different length, never the same kind twice in a row, and never padded: a thin post gets a short carousel). Follow it, filling each slide with her real words. The tool's checks also warn if a finished carousel is too close to a recent one: when you see that warning, reshuffle the middle slides and redraw.
2c. **The carousel tool enforces two things itself:** if no look was chosen (no `template` on the slides) it picks one and says so (`LOOK:` line; the choice is saved in `slides.json`), and a NEW carousel that is almost the same order as one of her recent ones is refused (`REFUSED:` line, exit code 3). When you see REFUSED, reorder or change the kinds of the middle slides and run it again; only set `"allow_similar": true` if she wants it that way. Redrawing an existing carousel is never blocked.
3. **Tell her:** "I made it in Numbered tips because it is a list. You can change the style or edit the words any time on the Carousels tab, or from that day on your calendar."
4. **Faces stay in the picture:** photos are cropped to keep a face in frame, never cut through it.
4b. **After it is made she can:** change the style (the Style menu on the carousel's page redraws all slides in another look), redraw it in her brand colors, and edit the slide words (the review page). **Move things around** (button on the carousel's page): drag any piece (a picture, a headline, a note, a sticker) to a new spot, or drag its corner dot to make it bigger or smaller, slide by slide, then Save and redraw. Moves are saved on each slide as `"moves": [{"at": [x, y], "d": [dx, dy], "s": 1.0}]` (`s` is the size, 0.3 to 3) in `slides.json` (only for template slides; `engine/tools/carousel_templates.py` finds the movable pieces and writes `slide-NN.blocks.json`). Changing the style clears the moves. The handle and slide number stay fixed.
- Her own looks (`mine`) are a built-in look plus her notes: use the `base` template and apply her notes. Her renamed looks (`names`) are called by her names.
- Adding one: she says "learn this carousel look" (or taps the tile on the Carousels tab). Follow the last section of `carousel-templates.md`.

## Steps
1. **Find the source.** The newest edited video's pick sheet, the script in `customer/scripts/`, or her idea (works on an unedited video too). If she has no reel (text-only day), build from the script or idea plus her voice and audience profiles.
1b. **Offer three angles (teaching, story, reference)** as one click when the source is a reel; bank the two she does not pick in `customer/insights/hook-bank.json`.
2. **Cover words first (she approves before anything is drawn).** Find the strongest line in the reel: the most concrete image plus the biggest curiosity gap, max 10 words, matching what the reel delivers. Offer cover options as one click: A (bold headline, her face), B (a different angle on the same idea), C (negative space, one giant word). Check against her hook bank. Bank the one she doesn't pick in `customer/insights/hook-bank.json`.
3. **Write the rest in ONE pass,** then show it as a short numbered list (slide number, type, words) in plain chat. One approval or her edits in one batch.
   - Structure: cover, then one beat per slide, a soft CTA ("follow for part 2") around slide 5 or 6 and one real question to the viewer around slide 4 or 5, a recap, and the last slide the hard CTA that matches the reel's ask exactly. One hard ask only. Optional sequel line ("tomorrow: ...") only if tomorrow's post exists in her plan.
   - Reel shapes: a list reel gives each item its own slide. A story reel follows setup, struggle, turn, result, CTA. End slides on open loops.
   - Mix slide types so no two neighbors match. Types: `cover` (photo of her), `sticker` (her cut out with a white border), `negcover` (one giant word), `bigtext`, `quote`, `point`, `photo`, `stat` (big number), `receipt` (proof: her screenshot or real numbers in a white card), `transform` (before and after plus how it felt), `list` and `recap` (checklist, save-bait), `myth` (myth vs fact), `faq`, `pov`, `quiz`, `convo` (a text exchange that illustrates the point, always labeled as an illustration), `cta`. Include at least one proof slide and one checklist or recap slide.
4. **Write `slides.json`** (format at the top of `engine/tools/make_carousel.py`; each slide has `type`, its words, and `source`). Add `"post": N` (the plan row number) so the finished carousel files itself on its day in the calendar, and `"reel_cta": "ENGINE"` so the tool checks the last slide matches. Then run: `~/.cache/content-engine/whisper-venv/bin/python -X utf8 -I engine/tools/make_carousel.py customer/content/<month>/<day>-carousel/slides.json`.
5. **Read the checks.** The tool prints `CHECK:` lines and writes `checks.txt` (slide count, word counts, repeated layouts, missing sources, a comment word before the last slide, missing proof or save-bait slide, text contrast). Fix real problems by editing the words file and re-running (free).
6. **Open the review page** so she can fix words, reorder, remove, and redraw without you: `~/.cache/content-engine/whisper-venv/bin/python -X utf8 -I engine/tools/carousel_sheet.py <path>/slides.json` (runs in the background, opens at http://127.0.0.1:8766/). Tell her it costs nothing. Her original words are kept in `slides.backup.json`.
7. **Hand it over.** The folder holds `slide-01.png` and up, `caption.txt`, `alt-text.txt` (paste each into the slide's alt text field), `source-map.json`, and `phone-preview.png` (every slide at phone width). Give a link and show the phone preview. Do not inspect the pictures yourself unless she reports a problem.
8. **The caption.** A ready-to-paste caption in her voice: a first line with the keywords a person would search, two or three short lines, the one comment word, 2 to 4 hashtags. No emojis. Never numbers she can't back up.

## Before and after she posts
Before she posts, run `python3 engine/tools/carousel_score.py score <slides.json>` and tell her the result in plain words.

## After she posts
"I posted it" logs the carousel (also run `carousel_score.py log <slides.json> --saves N --shares N --comments N`) (saves, shares, reach) in `customer/insights/results-log.md`. Saves plus shares decide a winner. Compare cover A and B over time and keep the winning angle in the hook bank.

## Not built yet (later)
Panoramic carousels, collage lane, mixed-media video slides, duotone photos, series numbering, LinkedIn PDF and Pinterest sizes, pre-post score (needs logged results first), angle variations, niche-gap slide.

## Save and checklist
Save everything in `customer/content/<YYYY-MM>/day-NN-carousel/`. "Before you post": alt text pasted, caption pasted, cover picked, comment word set up to send.

## Stills from her video as backgrounds (offer once per carousel)
A face or a real moment behind the words catches more attention than a plain color. When the carousel is made from a video, offer as a click: **Put a still from my video behind the first and last slides (Recommended)** · **Pick the stills myself** · **Keep plain**. In `slides.json`, any slide that is not a photo kind takes `"bg_frame": <seconds>` (or `"auto1"`, `"auto2"`: her best stills in order) and `"overlay": 0.2 to 0.85` (how dark behind the words, default 0.55). The review page (`carousel_sheet.py`) shows her six best stills as small pictures on every slide, plus a "Still behind first and last" button. Never put a still behind a slide where the words would cover her face; pick a different still or raise the overlay.

## One editor, and older carousels (built)
- **Move things around** (on every carousel's page) is now the one editor: drag, resize and turn pieces, edit each slide's words in the panel on the right, swap a slide's picture (pictures already in the carousel's folder, or **Use a picture from my computer**), then **Save and redraw**. **Undo my last save** and **Reset all slides** are in the same bar.
- **Carousels made before the looks** show **Make this one in a look**: it brings their words and photos into any look so they can use all of the above (the old version is kept; Undo goes back).
- **Calendar days:** each carousel day whose words are written shows **Make this carousel** (`engine/tools/auto_carousel.py <post number>`): it builds the carousel from that day's script, picks the look, files it on the day, and opens it. Days that are still outlines say their script unlocks at the Sunday refresh. It never invents words.
- **My looks previews** show her own words and photos once she has a finished carousel (they redraw by themselves).

## Caption, video scripts, shorter and longer, unsaved edits, and learning (built)
- **Caption:** a carousel made from a script arrives with its caption (`caption.txt`, from the script's Caption section). Chat-made carousels: put the caption in `slides.json` as `"caption"`.
- **From a video script:** the **Make this carousel** button (and `auto_carousel.py N`) also works on a video script and on days like "carousel from post 3": her own spoken words are cut into slides (her numbered signs become a list, the last "comment" line becomes the ask). Nothing is rewritten.
- **"Make it shorter" / "make it longer"** (buttons on the carousel's page, or when she says it in chat: run `python3 engine/tools/reshape_carousel.py <slides.json> shorter|longer`, then redraw): shorter joins the two shortest neighbouring text slides or drops a picture-only slide; longer splits the slide with the most words at a sentence. Only her own words are used. It never cuts the cover or the ask. If it says there is no more material, say so plainly and offer to add words in the editor. Undo goes back one step.
- **Unsaved edits:** the editor warns before closing or leaving with changes that are not saved.
- **It learns her looks:** `results.py add --kind carousel --carousel <folder>` logs which look a carousel used; with enough carousels the look picker leans toward looks that beat her typical carousel (and away from ones that fall short). The Results tab shows it.
