# Setting Up Permissions (so Claude isn't always waiting on her)

By default, Claude asks permission before it does things like save a file or run a program. That's safe, but during the engine's long jobs (editing a video, pulling reels) it means Claude keeps stopping to wait for a click. She can switch that off for this folder.

## Offer it once, near the start, as an opt-in
Right after the welcome and before the first question, offer it as a click. Say the trade-off first, in plain words: "One optional tip. Normally I stop and ask your OK before I save a file or run a tool, which can feel slow during long jobs. You can switch that off for this chat. The trade-off: I will no longer ask first, so a mistake by me could change or remove files before you could stop it." Choices: **Keep asking me first (Recommended)** · **Show me the faster way**. Pick the first and move on. Never ask again unless she says Claude keeps stopping. Her originals are safe either way: copy her recordings somewhere else too.

## The middle option (suggest this before full bypass)
Most of the waiting goes away with **Accept edits**: Claude saves files without asking, and still asks before running anything else. Show this first. Only show full **Bypass permissions** if she says it is still too slow.

## How she does it (she does the clicking, Claude can't change this for her)
1. Look at the **bottom of the chat box**, near where she types. There's a small label for the permission mode (it may say something like "Ask permissions").
2. Click it and choose **Accept edits** (or **Bypass permissions** if she picked the faster way).
3. It applies to this conversation. In a new conversation, switch it on again.

If the label looks different on her screen, ask her to describe or screenshot the bottom of the chat box and point her to the right spot.

## Say this honestly, in plain words
- "With this on, I can save files and run the engine's tools in this folder without asking you each time."
- "Use it only in your engine folder, the one you opened for this."
- "You can switch it back any time."
- Even with it on, never delete or overwrite her files without asking her first, and never touch anything outside the engine folder. Those rules still apply.

## Also offer the credit-saving tip (same moment, one extra line)
"Another tip: in the model picker at the bottom of the chat box, choose **Sonnet** and keep the effort on **Medium**. It does everything the engine needs and uses far fewer of your credits."
