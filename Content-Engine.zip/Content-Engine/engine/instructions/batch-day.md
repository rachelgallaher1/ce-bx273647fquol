# Batch day: teach her to make a month of content in one sitting

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

**Why this matters (say it in her words, short):** the hard part of posting is not the ideas, it is sitting down again and again. Batching turns "post every day" into "film once a week." One sitting of about an hour covers the whole week, and the engine does the planning before and the editing after.

Tools: `python3 engine/tools/batch_day.py` (`guide`, `match`, `assign`, `edit-all`, `review`). Never post for her. Her originals are never touched.

## The flow (one question at a time, keep it moving)
1. **Pick the size.** One click: **This week's videos (Recommended)** · **The next two weeks** · **Just one video today**. Check there are ready scripts (`plan.py week N`). If not, build the week's scripts first (`step-planner.md`).
2. **Ask where she films** (one question, her words: "Where will you film? A desk, a couch, a kitchen?"), also ask "How many different tops can you rotate? (about 4 or 5 is plenty)" and make her batch day page: `batch_day.py guide --locations "desk,couch" --outfits 4`. The page films in SHOOT order, not post order: grouped by the script's `**Setting:**` line so she changes setups as few times as possible, with a table-props list from each script's `**Props:**` line, an outfit rotation by posting day (never the same top two posting days in a row), blocks of about 45 minutes with a 5-minute break, a reminder to say the post number out loud before each take (the slate), a pause-and-look-at-the-lens beat for the cover frame, and "do not film these today" for flex-slot scripts. Give her the link to `customer/plans/batch-day.html` (and `batch-day.md`). It holds the 10-minute setup, an "extra shots while you are set up" list per location (30 seconds of you typing, a walk-in shot, close-up of hands, a slow pan, a reaction, an over-the-shoulder screen shot, plus any `[b-roll: ...]` cues in her scripts; shot once, used all month for edits, carousels and B-roll reels), the order to film in with each opening line and time, and a checkbox per video. Tell her the total time in one line.
3. **Teach the five rules in chat, in plain words, once:**
   - Film in one sitting, in the order on the page. Do not edit as you go.
   - Stumble? Say the line again. The engine cuts mistakes and silences.
   - Pause a second before you start and after you finish.
   - Do not watch it back. Go straight to the next one.
   - Reset between videos: water, shoulders, look at the lens.
   Offer film mode (the phone teleprompter, `step-3-record.md`) and the quick filming tips (`filming-look.md`) as clicks.
4. **She films, then drops every clip in her inbox at once** (the extra shots go in `inbox/broll/`; run `broll_index.py scan` and label them, see `broll-reels.md`). Run `inbox.py` to bring them in. Then `batch_day.py match`. It listens to each clip and matches it to its script, first by the slate number she said, then by what she said. It prints a missing-take report ("3 of 4 filmed. Missing: post 9") so nothing silently vanishes: she can film the stragglers or you go ahead without them. A second take of the same script is kept aside (the more complete one is edited, nothing is deleted). Show the matches in plain words ("This clip is your 'four kids' video"). Where it says it is not sure, ask her which post it is (one click per clip) and run `batch_day.py assign CLIP POST`.
5. **Edit them all:** `batch_day.py edit-all`. It runs as one queue in posting-date order, can be stopped and run again (finished ones are skipped), uses her saved look, files each finished video in her plan, and writes `customer/plans/batch-review.html`. Give her that link: one page, every video playing, a checkbox and a notes box on each. Anything she wants changed goes through the live editor for that video.
6. **After the review:** make the carousels for the batch (`step-4-carousels.md`); stories are a separate bonus (`stories-bonus.md`), then show the calendar (`customer/plans/calendar.html`) with every post filled in. Say what is done and when the next batch day is (about a week out), and put it in her calendar.

## The teleprompter button
The batch page has a yellow **Ready to record? Open the teleprompter** box. It opens a big scrolling script page for the batch (the scripts of the videos she is filming). It also shows an address for her phone on the same Wi-Fi. On the phone she reads the script, films with her camera, then taps **Done? Add my video**; the clip goes straight into her inbox and is already matched to that script, so no matching is needed. The first time, her computer may ask "allow incoming connections": tell her to click Allow (it only works on her own Wi-Fi, and only the teleprompter page is reachable from the phone). The old phone teleprompter (`make_film_mode.py`) still works for people who prefer it.

## The drop box
Run `~/.cache/content-engine/whisper-venv/bin/python -X utf8 -I engine/tools/batch_day.py serve --outfits 4` in the background (not once per step). It prints a link like http://127.0.0.1:8780/ . Give her that link: her batch page opens with a **Drop your videos here** box. She drops her clips, taps **Edit my batch**, and the engine brings them in, matches them, asks her only about clips it is unsure of, edits them, and shows **Look at your videos** (the review page). She never touches a folder. The page also links to her content calendar.

## Rules
- Match by listening, never by file name. If two clips could be the same script, ask.
- Never edit a clip that was not confirmed.
- Time estimates come from the script length (talk time with retakes plus a reset). Never promise exact minutes.
- A batch is not a chore: end with what she got ("Four videos, edited, in your calendar") and one click to **Plan the next batch** or **Done for now**.
- Phrases she can say: "batch day", "film my week", "edit my batch".

## When writing scripts for a batch
Add two optional lines near the top of each script: `**Setting:** desk` (a short place name) and `**Props:** laptop, mug` (what must be on the table). The batch page uses them. Mark a script as a flex slot by putting the word flex in its plan row; batch day skips it.
A reel that is missing from the batch holds its carousel too, so nothing points at a post that does not exist.

## Wording (her words, not ours)
On the batch page and in chat, never say "slate", "block", "cover frame", "shoot order" or "setup change". Say: "say the number first," "start with...," "halfway through, look at the camera for one second," "Part 1," "get ready first."
