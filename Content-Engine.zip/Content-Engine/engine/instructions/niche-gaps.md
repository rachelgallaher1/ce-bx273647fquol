# Niche gaps (ideas from what her niche posts)

> **Every choice in this file is a click box (the `AskUserQuestion` tool), never a typed numbered list or "pick all that fit" in chat.** If you catch yourself typing options, delete them and call the tool. See `clickable-choices.md`.

Only with her own Apify account (see `performance-insights.md`, section 0). Never ask for her Apify password or token. Offered at planning time, never put into a finished post automatically.

1. Ask for 3 to 5 accounts or one hashtag in her niche (public only). Run the Apify Instagram scraper under her account with a small limit (about 30 posts per account), keep only captions, likes, comments and the owner's handle, and save them as a list `[{"caption", "likes", "comments", "owner"}]` in a scratch file.
2. Run `python3 engine/tools/niche_gaps.py <that file>`. It compares phrases that show up across several accounts with her own plan, scripts and captions and writes `customer/insights/niche-gaps.md`.
3. Show the top few in plain words, labeled "niche data". Offer each as an idea, never a claim: "nobody on your list has posted X as a checklist." She picks, you add it to the plan's idea bank (`customer/plans/post-ideas.md`) with a date.
4. Never copy anyone's words, structure or story. The gap is the topic only; the post is hers.
If Apify is unavailable, skip this feature quietly. It is optional.
