#!/bin/bash
cd "$(dirname "$0")"
PY="$HOME/.cache/content-engine/whisper-venv/bin/python"
[ -x "$PY" ] || PY=python3
"$PY" -I engine/tools/batch_day.py hub
